# Prepared staged temporal forward diagnostic

TEMP-only preparation. Parent owns integration, marker publication, preflight,
upload and dispatch. No FDTD solve, server access or production edit was made.
Official Ansys documentation was consulted through web search.
Calibration stays FAILED. This is a temporal intervention at one parameter step,
not an h-convergence study, new calibration, noise bound or optimizer approval.

Final runner: `s2_temporal_forward.py`, SHA256
555f3d13b42c494171e7658cc4263c588ce418e5d937da1497d690824b41d44a.
The public interface is `main(task_idx)`, matching the actual Athena dispatcher's
`module.main(task_idx=idx)` call. The6e7 predecessor is preserved in `versions/`.

Tasks0/1/2: exact nominal/shift30+.0625nm/shift30-.0625nm, common100ps.
Tasks3/4/5: the same triplet at150ps, blocked by a separate later review marker
binding the authentic completed100ps checkpoints/NPZ/FSP/H5/log evidence.
Nominal index metadata29, sign0; perturbed index149. All296 parameters and
complete original numerical spec are pinned; only the diagnostic label differs.

The supported control is **FDTD `use early shutoff=0`**, set directly after the
original project build alongside `simulation time=100e-12` or150e-12. Ansys
documents [this switch in the FDTD solver object](https://optics.ansys.com/hc/en-us/articles/360034382534-FDTD-solver-Simulation-Object)
and recommends disabling it for certain
[resonator studies](https://optics.ansys.com/hc/en-us/articles/360041567754-Photonic-crystal-cavity).
Auto minimum remains1e-7, divergence checking remains enabled/max1e5, and
downsampling100 is unchanged. Zero is not passed through the builder's falsey
`auto_shutoff_min` fallback. Raising the old2000ps cap would not disable its
auto termination. No new threshold or duration is silently introduced.

Hidden CAD accepts both properties. All three points were built and checked at
both windows: `actual_temporal_cad_v4oohtm5/validation.json` (193.8s). That
earlier runner hash predates added vendor-result guards and save/reload checks;
its controls/snapshot functions are the same ones used in the final package.
The6e7 predecessor was tested by
`actual_persistence_cad__mgrjsjt/validation.json` (29.2s), using generated
shift30+.0625nm geometry, new fwd_default.fsp files, then guarded reload at
both100/150ps. Timing, dt, source, ports, full mesh coordinates and refinement
sections are bitwise identical after reload. One of723 geometry properties
changes by -8.470329472543003e-22m, R_narrow_16_229 xspan. Raw before/after
values and complete snapshots are retained. Geometry alone may differ by
min(1e-20m,64*float64eps*max(abs(before),abs(after))); every other section must
match exactly. The initial bitwise-only failures are preserved too.
The555f successor changes only the public main argument/local assignment;
every other function is AST-identical to6e7. The signature-only fix required
no CAD rebuild and does not change those hidden CAD checks.

The runner repeats save/invalidate/load/full-snapshot checking before every
future forward, then invalidates loaded state before the single run_forward.
It never modifies saved historical sources. Generated nominal geometry and
all source/port settings are recorded, alongside both actual refinement fields.
Optimization_dft storage is disabled, matching the existing forward diagnostic;
mesh preservation and its actual enabled readback are checked and fingerprinted.

Source-global getter is `pulselength`: measured10.3034886591fs, offset29.2137355919fs,
standard source, optimize-for-short-pulse enabled. Frequency192.066526624THz,
bandwidth42.8273582768THz and wavelength limits remain unchanged by timing
controls. Ansys defines the pulse duration and offset in its
[mode-source documentation](https://optics.ansys.com/hc/en-us/articles/360034902153-Mode-source-Simulation-object).
The pulse-parameter fit check requires offset>=2pulse lengths and
offset+10pulse lengths<target duration; the measured values fit100ps easily.
This is a source-parameter check, not a bound on cavity decay, normalization
error or the precise time waveform. No source/time-signal arrays were extracted.
CAD also measured dt=6.671026479768415e-17s and max source time-signal length32768.

After a solve, the runner requires FDTD status1, success-log completion,
no early-termination message and actual elapsed time within the recorded ONE
timestep of the requested duration. Exact decimal equality is not assumed.
Recorded dt and timing readback persist in the checkpoint. GPU behavior and
the post-solve status return type remain hardware gates; status scalar or a
dictionary's `status` field are accepted, all other results fail closed.

The exact original center SHA and standalone port NPZ SHA are hard-pinned.
Completed171162 tasks0..3 raw checkpoint SHA256s are hard-pinned and bound to
the exact50ef6253... marker, frozen prior runner/dependencies, task identities,
ports hashes, scores and preserved FSP/H5 success evidence. The new runner
fingerprints every configured lumopt2 Python source plus lumapi/lumslurm,
using relative paths; those hashes are included in review scope and identity.
The parent must generate/review the actual remote API manifest rather than
blindly copying a local vendor map. Result records also include FDTD version.

Every new task gets an exclusive attempt. NPZ publication is exclusive;
checkpoint publication uses existing atomic exclusive recovery code. Final
FSP/H5/NPZ and termination log content hashes are retained. Resume revalidates
full identity, all artifact hashes, timing/control snapshots, same nominal
port frequency/wavelength arrays and saved scoring to1e-12. Changed sources,
missing data, altered identity or malformed/cold checkpoints cannot trigger
silent reuse. Failed attempt directories are preserved.

Parent-only example environment, with NEW unused output and marker paths:

```bash
export S2_TIME_REPO=/work/project
export S2_SHIFT_CENTER_CHECKPOINT=/work/results/diagnose_te_s2_fdstep/results/lumopt2_te_s2_fdstep_diagnostic_20261007/task_00.json
export S2_TIME_PRIOR_ROOT=/work/results/diagnose_te_s2_shift30_convergence/results/s2_shift30_convergence_20261007
export S2_TIME_PRIOR_MARKER=/work/data/s2_shift30_review_20261007_1142.json
export S2_TIME_OUTPUT_ROOT=/work/results/diagnose_te_s2_temporal/results/s2_shift30_temporal_20261007
export S2_TIME_FIRST_MARKER=/work/data/NEW_temporal100_review.json
export S2_TIME_LATER_MARKER=/work/data/NEW_temporal150_review.json
export KEEP_H5=1
```

The ordinary deployed driver must configure its existing GPU/API/license
settings identically to the prior forwards. This package does not submit jobs.
The configured API path must resolve on the compute host before templates.

```bash
# Print NOT_REVIEWED first-stage template; no CAD or file writes.
python -B /work/project/runners/lumopt2_design/s2_temporal_forward.py --review-template 100
# Parent reviews and publishes NEW marker; only then may its driver call:
python -B /work/project/runners/lumopt2_design/s2_temporal_forward.py --task 0
# Same for tasks1,2. No automatic release of tasks3..5.
# After authentic100ps results and review, print separate NOT_REVIEWED template:
python -B /work/project/runners/lumopt2_design/s2_temporal_forward.py --review-template 150
```

Templates are metadata only, never approvals. The parent sets the exact bounded
status/allowed task list and substantive verdict in a NEW immutable marker;
an unchanged template cannot run.100ps and150ps markers cannot be the same path.
First-wave byte hashes and lead verdict are required in the latter marker.

Offline: `python -B test_temporal.py`,12 groups passed. The new actual dispatcher
keyword regression verifies checkpoint reuse and blocked review/type gates with
CAD constructors forbidden. A focused regression
also passes observed geometry delta and oneULP, rejects material geometry drift,
and rejects even oneULP mesh change. Other tests cover live indices/full vectors,
staging, vendor/marker mismatches, source/mesh drift before a forward,
early/wrong-time/missing-H5 failures, exact grid tampering, scalar/control
tampering, immutable artifacts/checkpoints and cold resume. Synthetic fixtures
are retained in this package and do not claim hardware physics.

All local CAD constructors use hide=True with class identity preserved. The
copied no_solve_guard forbids engine calls and permits saves only to new TEMP
files. Baseline FSPs are byte-unchanged. No repository or vendor file is edited.
The previous termination review is preserved byte-for-byte in
`termination_review_preserved/`, with original hashes.

Open limits: no actual100/150ps solve exists from this preparation; fixed-time
termination, pulse normalization and GPU timing must be inspected on hardware.
Results need same-duration center parity comparisons. Temporal stability at
one h does not certify h-convergence or explain the previous unequal-window
derivative. Existing stored-field adjoint contractions remain tied to their
original forward/adjoint timing and cannot be relabeled extended-time gradients.
Lead reviews100ps evidence before deciding whether150ps is scientifically useful.
