"""Offline N80 physical-truncation blueprint. No CAD, runner or dispatch."""
import argparse,dataclasses,hashlib,json,re,sys
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
CP_SHA='a0ff55eacaa52e00a2aab17dcc43d0e5fff9a72566e15da371ff25279c172663'
ENGINE_SHA='53108bbd368dd699179ab65029628aa4c4b2d8ad687777f88b82f404a0952569'


def require(ok,message):
    if not ok:raise ValueError(message)


def canonical(properties):
    out={}
    for key,value in properties.items():
        object_name,prop=key.split('::');match=re.fullmatch(r'([LR])_(narrow|wide)_(\d+)_\d+',object_name)
        name='_'.join(match.groups()) if match else 'cavity' if re.fullmatch(r'cavity_\d+',object_name) else object_name
        result=name+'::'+prop;require(result not in out,'Duplicate physical property');out[result]=float(value)
    return out


def candidate_spec(spec):
    require(spec.n_periods_side==98 and spec.n_free==60 and spec.bare and spec.polarization=='TE','Requires original N98/free60/bare TE family')
    return dataclasses.replace(spec,n_periods_side=80,label='s2_N80_fixed_N98_domain_PREPARATION_ONLY')


def build(row,eng):
    require(row['identity']['task']==row['result']['task']==3 and row['result']['duration_ps']==150 and row['result']['sign']==row['result']['delta_nm']==0,'Not temporal150 exact nominal task3')
    p=np.asarray(row['identity']['point'],float)
    require(p.shape==(296,) and np.array_equal(p,np.asarray(row['result']['params'])),'Exact296 point differs')
    spec=eng.CampaignSpec(**row['identity']['spec']);short=candidate_spec(spec)
    long_map=eng.make_func(spec)(p);short_map=eng.make_func(short)(p)
    require(canonical(long_map)==canonical(short_map) and len(long_map)==723,'Inner60/cavity mapping differs')
    cfg98=eng.build_base_cfg(spec);cfg80=eng.build_base_cfg(short)
    require(not cfg98.apodization.enabled and not cfg80.apodization.enabled,'Unexpected native apodization')
    require(cfg98.grating.width_narrow_per_tooth_m is None and cfg80.grating.width_narrow_per_tooth_m is None,'Unexpected native per-tooth arrays')
    # N+port-gap-periods constant preserves the native domain/port formula.
    cfg80.mesh.n_periods_dist_to_port=cfg98.mesh.n_periods_dist_to_port+(98-80)
    kw98=cfg98.to_device_kwargs();kw80=cfg80.to_device_kwargs()
    differences={k:{'N98':v,'N80':kw80[k]} for k,v in kw98.items() if v!=kw80[k]}
    require(set(differences)=={'n_periods_each_side','n_periods_dist_to_port'},'Unexpected builder family change')
    pitch=spec.pitch_nm*1e-9;ends={n:n*pitch+pitch/4 for n in (80,98)}
    geom=canonical(row['result']['controls']['persisted']['geometry'])
    saved_delta={k:geom[k]-v for k,v in canonical(long_map).items() if geom[k]!=v}
    domain=lambda n,k:(n*pitch+pitch/4)+(k['n_periods_dist_to_port']*pitch)+k['n_wls_dist_port_to_pml']*(2*k['n_eff_guess']*pitch)
    ports=lambda n,k:(n*pitch+pitch/4)+round(k['n_periods_dist_to_port']*pitch/(pitch/(2*k['cells_per_half_period'])))*(pitch/(2*k['cells_per_half_period']))
    control=row['result']['controls']['persisted'];mesh=control['mesh']
    native_domain_diff=domain(80,kw80)-domain(98,kw98);native_port_diff=ports(80,kw80)-ports(98,kw98)
    require(abs(native_domain_diff)<=1e-20 and abs(native_port_diff)<=1e-20,'Fixed-gap compensation changed native domain/ports materially')
    properties={}
    names,cavity=eng.tooth_names(80,80)
    for d in range(61,81):
        for arm,pos in [('L',-ends[80]+(80-d)*pitch),('R',pitch/4+(d-1)*pitch)]:
            n,w=(names[d][:2] if arm=='L' else names[d][2:])
            properties.update({n+'::x':pos+pitch/4,n+'::x span':pitch/2,n+'::y span':kw80['width_narrow'],w+'::x':pos+3*pitch/4,w+'::x span':pitch/2,w+'::y span':kw80['width_wide']})
    return dict(status='OFFLINE_BLUEPRINT_ONLY_NOT_RELEASED',checkpoint_sha256=CP_SHA,physical_N_each_side=80,
        point_nm=p.tolist(),point_le_f64_sha256=hashlib.sha256(p.astype('<f8').tobytes()).hexdigest(),spec=dataclasses.asdict(short),
        mapped_inner_properties_SI=short_map,inner723_physical_properties_bitwise_equal=True,
        mapped_vs_saved_N98_serialization=dict(nonbitwise_count=len(saved_delta),max_abs_delta_m=max(map(abs,saved_delta.values()),default=0.)),
        outer_uniform_properties_prediction_SI=properties,outer_periods_retained_each_side=20,outer_periods_removed_each_side=18,
        native_builder_kwargs_changes=differences,native_predicted_domain_half_m={str(n):domain(n,k) for n,k in [(98,kw98),(80,kw80)]},
        native_predicted_port_abs_x_m={str(n):ports(n,k) for n,k in [(98,kw98),(80,kw80)]},
        native_domain_delta_m=native_domain_diff,native_port_delta_m=native_port_diff,
        physical_grating_end_um={str(n):v*1e6 for n,v in ends.items()},
        engine_production_crop_half_um={str(n):n*spec.pitch_nm/1000 for n in (80,98)},
        predicted_profile_monitor=dict(N98_fixed_x_span_m=2*ends[98]+2e-6,N80_unmodified_x_span_m=2*ends[80]+2e-6,
            fixed_y_span_m=1.5*kw98['width_wide'],fixed_z_m=0.,measurement='Prediction from builder; baseline CAD/profile axes must independently verify'),
        other_N_dependent_monitors=dict(time_input_x_m=-ends[98]-.5e-6,time_output_x_m=ends[98]+.5e-6,time_cavity_x_m=0.),
        held_measured_controls=dict(source=control['source'],ports=control['ports'],timing=control['timing'],refinement=control['refinement'],ports_monitor=control['monitor'],
            mesh_points={a:len(np.asarray(v).ravel()) for a,v in mesh.items()},mesh_extents_m={a:[float(np.min(v)),float(np.max(v))] for a,v in mesh.items()},dt_s=row['result']['controls']['dt_s']),
        user_mesh_source='Pinned task03 result.controls.persisted.mesh; exact arrays required, not reconstructed from extrema',
        actual_N80_saved_CAD_geometry_mesh_PML_source_monitor_equality='UNMEASURED: no CAD has been run',
        limitations=['No saved original FSP or scene was loaded, changed, deleted or rewritten.',
            'Direct fresh N80 native scene must receive engine.make_func(N80)(exactpoint); do not substitute native inner_shift arrays.',
            'N+port-gap compensation preserves native formula to rounding; actual locked mesh and vendor port offsets still require build/reload readback.',
            'Fixed N98 domain offers no domain-cell speedup; physical response, temporal adequacy and profile width remain unmeasured.'])


def load(checkpoint,repo):
    raw=Path(checkpoint).read_bytes();require(hashlib.sha256(raw).hexdigest()==CP_SHA,'Wrong pinned temporal150 task03 bytes')
    repo=Path(repo).resolve();source=repo/'runners/lumopt2_design/lumopt2_design.py'
    require(hashlib.sha256(source.read_bytes()).hexdigest()==ENGINE_SHA,'Frozen engine changed')
    row=json.loads(raw)
    for name,digest in row['identity']['code'].items():
        rel=Path(name) if name in ('bragg_device.py','simulation_config.py','sim_helpers.py','config.py') else Path('runners/lumopt2_design')/name
        require(hashlib.sha256((repo/rel).read_bytes()).hexdigest()==digest,'Frozen dependency changed: '+name)
    sys.path.insert(0,str(repo));from runners.lumopt2_design import lumopt2_design as eng
    return row,eng


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for k in ('checkpoint','repo','output'):parser.add_argument('--'+k,required=True)
    a=parser.parse_args();row,eng=load(a.checkpoint,a.repo);report=build(row,eng)
    with Path(a.output).open('x',encoding='utf-8') as f:json.dump(report,f,indent=2,allow_nan=False)
    print('723 mapped properties bitwise equal after object-name remap; N80 CAD/physics not measured')
