import unittest,json,types,ast,sys
from pathlib import Path
import numpy as np
sys.dont_write_bytecode=True
import auxiliary_diagnostics as diag
import probe_aux_repeat as probe

class Tests(unittest.TestCase):
    def data(self):return dict(freqs_wls=np.linspace(1.9e14,2.1e14,501),source_powers=np.full(501,8e-16),transmittance_factor=np.linspace(.1,1.,501)+.2j)
    def test_ulp_and_component_differences_retained(self):
        original=self.data();initial=diag.snapshot(original,'original.fsp')
        original['source_powers'][244]=np.nextafter(original['source_powers'][244],np.inf)
        original['transmittance_factor'][252]+=1e-10j
        after=diag.snapshot(original,'original.fsp');d=diag.difference(initial,after)
        self.assertFalse(d['selected_equal']);self.assertFalse(d['full_arrays_equal'])
        self.assertEqual(d['arrays']['sourcepower']['changed_indices'],[244])
        self.assertEqual(d['arrays']['sourcepower']['ulp']['max_ulp'],1.)
        self.assertEqual(d['arrays']['direction_selected_a_or_b']['changed_selected_indices'],[252])
        self.assertAlmostEqual(d['arrays']['direction_selected_a_or_b']['component_ulp']['imag']['max_abs'],1e-10,places=16)
        json.dumps(diag.plain(d),allow_nan=False)

    def test_exact_trace_rejects_drift_after_storing_both_and_loading_forward(self):
        root=Path(__file__).parent;source=root/'synthetic_original.fsp'
        calls=[];data=self.data()
        session=types.SimpleNamespace(_loaded_state=None,_getresult_cache={},fdtd=types.SimpleNamespace(getnamed=lambda obj,key:'Port_1'))
        def load(path):session._loaded_state=(str(Path(path).resolve()),123);calls.append(path)
        session.load_if_needed=load
        fom=types.SimpleNamespace(_collect_fwd_side_aux=lambda session,entry:data)
        report={'active_objective':'control'};diag.install_exact_trace(fom,report);entry={'fwd_filename':str(source)}
        returned=fom._collect_fwd_side_aux(session,entry);self.assertIs(returned,data)
        report['active_objective']='onehot244';data['source_powers'][244]=np.nextafter(data['source_powers'][244],np.inf)
        with self.assertRaisesRegex(RuntimeError,'exact before/after retained'):fom._collect_fwd_side_aux(session,entry)
        self.assertEqual(len(report['auxiliary_snapshot_history']),2)
        self.assertIn('baseline',report['auxiliary_mismatch']);self.assertIn('offending',report['auxiliary_mismatch'])
        self.assertEqual(report['auxiliary_mismatch']['difference']['arrays']['sourcepower']['ulp']['max_ulp'],1.)
        self.assertEqual(calls,[str(source),str(source)])
        json.dumps(diag.plain(report),allow_nan=False)

    def test_repeat_probe_same_frequency_inputs_and_roundtrip_are_separate(self):
        data=self.data();calls=[]
        class Cad:
            def getnamed(self,obj,key):return 'Port_1'
            def sourcepower(self,f):calls.append(np.asarray(f).copy());return np.full(len(f),8e-16)
        session=types.SimpleNamespace(fdtd=Cad(),_loaded_state=('original',1),_getresult_cache={})
        session.load_if_needed=lambda path:None
        fom=types.SimpleNamespace(_collect_fwd_side_aux=lambda session,entry:data)
        entry={'fwd_filename':'original'}
        record,initial=probe.collect_repeat(session,fom,entry,'initial',None)
        self.assertEqual([len(x) for x in calls],[501,501,5,5])
        np.testing.assert_array_equal(calls[0],data['freqs_wls'])
        np.testing.assert_array_equal(calls[1],data['freqs_wls'])
        np.testing.assert_array_equal(calls[2],data['freqs_wls'][list(diag.UNION)])
        self.assertTrue(all(x['max_abs']==0 for x in record['independent_sourcepower_calls']))
        record,later=probe.collect_repeat(session,fom,entry,'repeat',initial)
        self.assertTrue(record['difference_from_initial']['selected_equal'])

    def test_no_field_no_solver_no_geometry_and_invalid_arrays(self):
        class Fake:
            def __getattr__(self,name):return lambda *a,**k:None
        g=probe.NoFieldCAD(Fake(),Path(__file__).parent)
        for action in (lambda:g.run(),lambda:g.eval('run;'),lambda:g.getresult('optimization_dft','E'),lambda:g.getdata('optimization_dft','Ex'),lambda:g.eval("s2_deps_slice = pinch(getdata('optimization_dft','Ex',2),4,253);")):
            with self.assertRaises(RuntimeError):action()
        for value in (np.ones(500),np.full(501,np.nan)):
            data=self.data();data['source_powers']=value
            with self.assertRaises(RuntimeError):diag.snapshot(data,'original')
        tree=ast.parse(Path(probe.__file__).read_text());calls=[n.func.attr for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)]
        for forbidden in ('make_project','generate','switchtolayout','update_structure','single_deps','calculate_gradient_fields','set_fwd','run_forward','compute_gradient'):self.assertNotIn(forbidden,calls)
        with self.assertRaisesRegex(RuntimeError,'NEW and exclusive'):probe.run(types.SimpleNamespace(output_root=str(Path(__file__).parent)))

    def test_actual_failed_report_is_pinned_and_before_data_matches(self):
        repo=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
        path=repo/'docs/readiness_evidence_20261007/s2_fixed_bin_re_original.json'
        self.assertEqual(probe.guard.sha256(path),'d6ab05927276d43ceea194b23f1cccbd389abd586b3ee0dccae2fe71efb6b454')
        r=json.loads(path.read_text());self.assertEqual(r['onehot_raw'],[])
        self.assertTrue(r['original_file_identity_unchanged']);self.assertLess(abs(r['old_peak3_control']['relative_difference']),1e-12)
        v=r['vendor_forward_normalization'];self.assertEqual(v['indices'],list(diag.UNION))
        self.assertNotIn('auxiliary_mismatch',r) # exact offender truly unavailable
        self.assertEqual(len(v['sourcepower']),5)

if __name__=='__main__':unittest.main()
