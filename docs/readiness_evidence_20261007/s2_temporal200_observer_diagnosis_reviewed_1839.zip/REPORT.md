# Saved150→200ps diagnosis (no convergence/gradient pass)

Exact200 pin map82b5a5...fd26 and fetch manifeste7fdd7...adf verified; every raw200 CP/NPZ byte SHA/size checked. Matched150→200 geometry and observed spectra reproduce the raw NPZ. Actual new MAT scalar spectra (six501x6 curve matrices across100/150/200, Tout/modal) match verified JSON bitwise. No files in the repository, native packet9076 or servers were changed.

Units: heights/differences are dimensionless power fractions; FD/projection units are power fraction per nm of shift30 GEOMETRY, not wavelength. Vertex offsets/FWHM are wavelength pm. J weights are dimensionless.

## Measured drift location

|Observable/geometry|Δ peak3 height|Δ vertex(pm)|150FWHM(pm)|ΔFWHM(pm)|max drift / offset(pm)|squared drift inside halfheight interval|
|---|---:|---:|---:|---:|---:|---:|
|peak3_tout/center|+0.00014492216|-0.03990|209.33640|-0.02306|0.000147497 / -0.456|96.92%|
|peak3_tout/plus|+0.00010649347|-0.03352|209.42214|-0.00148|0.000116508 / +9.916|90.04%|
|peak3_tout/minus|+0.00013521424|-0.04133|209.34965|-0.01636|0.000135143 / -2.805|96.77%|
|peak3_modal/center|-1.4438446e-05|-0.13301|201.57885|+0.00536|0.000153294 / -7.607|96.95%|
|peak3_modal/plus|-5.9201841e-05|-0.13420|201.60080|+0.01169|0.000127445 / +2.755|90.89%|
|peak3_modal/minus|-1.993017e-05|-0.16494|201.65884|-0.00425|0.000149092 / -9.973|97.27%|

Drift maxima lie within .05FWHM of the150ps vertex;90–97% of squared spectral drift lies inside its halfheight interval. This locates the change; it does NOT establish slow resonant decay, exclude other excited modes/numerics, or establish a noise floor. Source pulse is broadband despite the2nm monitor window (lead-verified10.30fs pulse/42.83THz bandwidth); saved point traces remain unexamined and GPU warned their spatial interpolation is unsupported.

## Actual three-bin Jacobian support

|Observable/time|support|J_i FD_i terms(/nm shift30)|sum projection|Σabs/abs(sum)|moving peak3 FD|moving−projection residual|
|---|---|---|---:|---:|---:|---:|
|peak3_tout/150|[251, 252, 253]|+0.0033047472, -0.0071423936, +0.0033892634|-0.000448383082|30.86|-0.000153814689|+0.000294568393|
|peak3_tout/200|[251, 252, 253]|+0.0030747683, -0.0067362151, +0.003155907|-0.000505539887|25.65|-0.00038358091|+0.000121958977|
|peak3_modal/150|[249, 250, 251]|-0.003353477, +0.0069563796, -0.0032693064|+0.000333596157|40.71|-0.000163699124|-0.000497295281|
|peak3_modal/200|[249, 250, 251]|-0.0043268966, +0.008074044, -0.0043929119|-0.000645764477|26.01|-0.000477872495|+0.000167891983|

Bins244/260 do not contribute to these peak3 projections. Their apparent stability cannot be used to estimate peak-gradient noise. The cancellation factors are26–41 on the actual three-bin support. This is exact scalar-Jacobian algebra applied to a finite spectral displacement, not a spectral adjoint or an infinitesimal geometry-gradient measurement. The endpoint residual identity is independently reproduced.

Temporal projection change decomposes exactly as J150·(FD200−FD150)+(J200−J150)·FD200:
- peak3_tout: +0.000547377797 + -0.000604534602 = -5.71568049e-05 /nm shift30.
- peak3_modal: +0.00126119623 + -0.00224055686 = -0.000979360634 /nm shift30.

All corresponding peak bins and carrier windows are unchanged150→200: Tout center/plus/minus252/250/253; modal250/249/252. Carrier windows respectively[122,382],[120,380],[123,383] (261samples) and[125,376],[124,375],[127,378] (252samples). Center parabola offsets changeTout−.113933→−.103959bin and modal+.098238→+.131489bin. Endpoint supports differ from the center through real spectral displacement; changing a selected index across displacement would not by itself prove nonsmoothness.

## One offline observer: quartic11

Least-squares quartic in frequency-uniform INDEX coordinates normalized over11samples (±5bins≈±20pm), unique concave stationary peak within1bin; unsupported branches reject. Height derivative uses stationarity and the LS pseudoinverse. No production objective/adoption or coefficient fit.

|Observer|150 moving FD|200 moving FD|150 center-J FD|200 center-J FD|
|---|---:|---:|---:|---:|
|peak3_tout quartic11|-0.000123190171|-0.000387061855|+1.86186703e-05|-8.77009214e-05|
|peak3_modal quartic11|-0.000184539692|-0.000525872641|-0.000325773507|-0.000629086566|

Quartic11 does not remove temporal sensitivity. Across the six fits/duration, max residuals span2.26e−5–4.91e−5; normalized design condition16.686; center L2 white-independent-sample-noise gain≈.577 is a MODEL property, not measured noise. Supported one-bin anchor changes shift center heights up to1.61e−5; opposite anchors reject because the stationary peak leaves the allowed central-bin branch. Those residual/model differences are comparable to endpoint odd heights.

At nominal modal,150→200 height drift changes sign between observers: peak3−1.44384e−5 versus quartic+1.03483e−5. Thus even the continuous fitted-height observer is model-dependent here; smaller grid ripple in earlier synthetic translation does not establish an improved physical gradient. Existing150 h.125 data need not be re-audited to reach this limited conclusion.

## Ranked next discriminating work — lead decision, no release

1. Inventory stored100/150/200 CENTER time_input/cavity/output records, then bounded CPU-only prefix/local-tail measurements if data are qualified. Zero new FDTD solves. Plan8CPU64–128GiB with a15–30min allowance pending sample counts/load benchmark, not a promised minute-scale cost. Record actual coordinates, t/intervals, components/decimation and sampling settings first; real192THz carrier matters, not bandwidth alone. Compare same-component field prefixes and tails in their own units. This can reveal recorded late-time content or cross-run prefix differences; nonidentical prefixes are not automatically nondeterminism, quiet point fields do not exclude port drift, point FFT/field ratios are not transmission or FD/nm, and apodization would require separate normalization review.
2. If traces do not resolve reproducibility, repeat the SAME200ps triplet under a new immutable family/marker:3forwards≈3x70min=3.5GPUhours;21A100 solve seats if simultaneous,8CPU256GiB per task. This tests run-to-run variation of the actual small height differences/J cancellation while keeping duration and h fixed; one repeat is not a statistical noise bound or proof of a correct adjoint.
3. If repeatability is adequate for the expected signal, ONE matched200ps smaller-h pair can test finite-displacement vs local sampled-peak differentiation. Conditional h=.0078125nm predicts≈.18bin motion; current moving slopes predict odd heights≈3.0e−6 Tout/3.7e−6 modal, not guaranteed signal or noise bounds. Cost2forwards≈2.3GPUhours/14simultaneousA100 seats; reuse exact200 center. It targets the Taylor-residual hypothesis; it cannot establish time convergence, global calibration or all parameter classes. Do not launch a ladder solely on synthetic ripple arguments.
4. A larger-duration matched triplet tests remaining duration dependence only when trace/repeat evidence motivates a specific hypothesis. Example250ps would cost3forwards≈4.25–5GPUhours (85–100min each planning range),21simultaneousA100 seats. It would not by itself prove asymptotic convergence, identify decay cause or validate adjoints. Prefer a predeclared decision criterion to an endless duration ladder.

No global calibration, finite-E payload, width-gradient, scalar-normalization equivalence or optimization readiness is inferred. Spatial width150→200 small changes are separate measured observables and do not validate these spectral derivatives.

Reproduce:
```powershell
python -B C:/Users/evyat/AppData/Local/Temp/s2_temporal200_diagnosis_8rk_b406/test_analysis.py
python -B C:/Users/evyat/AppData/Local/Temp/s2_temporal200_diagnosis_8rk_b406/analyze.py --output NEW_ABSOLUTE_OUTPUT_DIRECTORY
```

Three arithmetic tests passed exit0; actual analysis exit0. Tests verify exact3-bin peak Jacobian directional derivative/support/cancellation arithmetic, quartic stationary-height Jacobian/branch rejection, and endpoint-residual identity with geometry-nm units. The actual run verifies rawpins/NPZ/MAT/published projection identities. Root independently reran all three and actual analysis successfully.

Artifacts: actual/diagnosis.json, actual/temporal_drift_and_support.png; source/analyzer/observer/tests/input hashes in manifest.json. No full501 arrays printed in this report.
