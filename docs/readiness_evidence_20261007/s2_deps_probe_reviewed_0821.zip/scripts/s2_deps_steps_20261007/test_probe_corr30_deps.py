"""No-CAD offline controls and selected-sum/single-parameter equivalence tests."""
import ast
import copy
import dataclasses
import json
import os
from pathlib import Path
import sys
import types
import unittest

sys.dont_write_bytecode=True
import numpy as np
import probe_corr30_deps as probe


class ProbeTests(unittest.TestCase):
    def test_exact_support_and_rejections(self):
        np.testing.assert_array_equal(probe.exact_active([0,.08,.98,-.06,0]),[1,2,3])
        for value in ([0,0], [1,2,3,4], [1,float('nan')]):
            with self.assertRaises(RuntimeError): probe.exact_active(value)
        active=probe.exact_active([0,1e-100,1.,0])
        np.testing.assert_array_equal(active,[1,2])  # exact, never threshold away a nonzero weight

    def test_selected_sum_equals_full_complex_vendor_style_sum(self):
        rng=np.random.default_rng(21)
        fwd=rng.normal(size=(8,2,3,2,3))+1j*rng.normal(size=(8,2,3,2,3))
        adj=rng.normal(size=fwd.shape)+1j*rng.normal(size=fwd.shape)
        jac=np.array([0,0,.0825,.9792,-.0617,0,0,0])
        scale=np.arange(8)+.2
        active=probe.exact_active(jac)
        sparse_fwd=probe.assemble_selected(8,active,[fwd[i] for i in active])
        sparse_adj=probe.assemble_selected(8,active,[adj[i] for i in active])
        for phase in (1.,1j):
            for symmetry in (1.,2.):
                full=sum(scale[i]*(jac[i]/symmetry)*fwd[i]*adj[i]*phase for i in range(8)).real
                selected=sum(scale[i]*(jac[i]/symmetry)*sparse_fwd[i]*sparse_adj[i]*phase for i in range(8)).real
                np.testing.assert_array_equal(full,selected)
        with self.assertRaises(ValueError): probe.assemble_selected(2,[1,1],[0,0])

    def test_solver_save_full_field_and_script_guards(self):
        class Fake:
            def __getattr__(self,name): return lambda *a,**k:None
        guard=probe.SelectedFieldGuard(Fake(),Path(__file__).parent)
        for action in (lambda:guard.run(),lambda:guard.eval('run;'),
                       lambda:guard.getresult('optimization_dft','E'),
                       lambda:guard.getdata('optimization_dft','Ex'),
                       lambda:guard.eval("x=getdata('optimization_dft','Ex',2);"),
                       lambda:guard.eval("s2_deps_slice = pinch(getdata('optimization_dft','Hx',2),4,253);"),
                       lambda:guard.eval("s2_deps_slice = pinch(getdata('optimization_dft','Ex',2),4,253);runjobs('FDTD');"),
                       lambda:guard.save(),lambda:guard.save(Path(__file__).parent.parent/'original.fsp')):
            with self.assertRaises(RuntimeError): action()
        guard.eval("s2_deps_slice = pinch(getdata('optimization_dft','Ex',2),4,253);")

    def test_single_parameter_vendor_mapping_and_nominal_midpoint(self):
        events=[]
        class Fdtd:
            def switchtolayout(self): events.append('layout')
            def eval(self,text): events.append(text)
            def getv(self,key): self_key=key; events.append(self_key);return {'raw':'corr30'}
        par=types.SimpleNamespace(get_bounds=lambda:[(0.,750.)]*296,
                                  update_structure=lambda session,p:events.append(('update',p[29])))
        class Calc:
            parametrization=par
            fdtd_session=types.SimpleNamespace(fdtd=Fdtd(),invalidate_loaded_state=lambda:events.append('invalidate'))
            def _grab_bounding_boxes(self,objects): events.append(('bbox',objects));return {'box':[0,1]}
            def _combine_bounding_boxes(self,boxes): return boxes
            def _reset_index_monitor_size(self): events.append('reset_index')
            def _d_eps_sparse_single_param(self,**kw): events.append(('single',kw))
            def _postprocess_d_eps_results(self,raw,sub):
                events.append(('post',raw,sub))
                return {'params[29]::params[29]':{}},np.array([2,3,2,1]),np.array([1.56e-6])
        column=np.array([-.5e-9,.5e-9,0.,-.5e-9,.5e-9])
        props=['L_narrow::y span','L_wide::y span','cavity::x','R_narrow::y span','R_wide::y span']
        params=np.zeros(296);params[29]=580.5
        for step in probe.STEPS:
            events.clear()
            deps,shape,wl,objects=probe.single_deps(Calc(),params,step,column,props)
            self.assertEqual(objects,['L_narrow','L_wide','R_narrow','R_wide'])
            singles=[e for e in events if isinstance(e,tuple) and e[0]=='single']
            self.assertEqual(len(singles),1)
            self.assertEqual(singles[0][1]['param_ind'],29)
            self.assertEqual(singles[0][1]['sub_dict']['h'],step)
            self.assertEqual(singles[0][1]['sub_dict']['nominal_value'],580.5)
            posts=[e for e in events if isinstance(e,tuple) and e[0]=='post']
            self.assertEqual(list(posts[0][2]),[0])
            self.assertEqual(posts[0][2][0]['object_name'],'params[29]')
        with self.assertRaises(RuntimeError): probe.single_deps(Calc(),params,.125,column,props)
        params[29]=.1
        with self.assertRaises(RuntimeError): probe.single_deps(Calc(),params,1.,column,props)

    def test_meshing_refinement_unavailable_is_explicit_and_never_set(self):
        class Fake:
            def getnamed(self,obj,key):
                if key=='meshing refinement': raise RuntimeError('unsupported property')
                return 'precise volume average'
        readback=probe.mesh_refinement_readback(Fake())
        self.assertTrue(readback['mesh refinement']['available'])
        self.assertFalse(readback['meshing refinement']['available'])
        self.assertIn('unsupported property',readback['meshing refinement']['error'])

    def test_sampler_matches_original_field_slices_and_rejects_grid_mismatch(self):
        rng=np.random.default_rng(32)
        field=rng.normal(size=(2,2,2,501,3))+1j*rng.normal(size=(2,2,2,501,3))
        axes={a:np.array([0.,1.]) for a in ('x','y','z')}
        freqs=np.linspace(1.9e14,2.1e14,501)
        class Fdtd:
            def getnamed(self,obj,key): return 'precise volume average' if key=='mesh refinement' else 5
            def getdata(self,obj,key,option): return freqs if key=='f' else axes[key]
            def eval(self,script):
                if script.startswith('clear'): return
                import re
                match=re.search(r"'(Ex|Ey|Ez)',2\),4,(\d+)\)",script)
                self.component=('Ex','Ey','Ez').index(match[1]);self.k=int(match[2])-1
            def getv(self,key): return field[:,:,:,self.k,self.component]
        session=types.SimpleNamespace(fdtd=Fdtd(),load_if_needed=lambda path:None)
        sr=types.SimpleNamespace(wavelengths=299792458./freqs)
        active=np.array([251,252,253])
        sampled=probe.sampler(session,active,axes)(sr,'/fake/preserved.fsp')
        for index in active: np.testing.assert_array_equal(sampled[index],field[:,:,:,index,:])
        self.assertEqual(sampled[0],0.)
        wrong=dict(axes,x=np.array([1.,2.]))
        with self.assertRaisesRegex(RuntimeError,'coordinate mismatch'):
            probe.sampler(session,active,wrong)(sr,'/fake/preserved.fsp')

    def test_source_syntax_no_solve_and_class_identity_helper(self):
        tree=ast.parse(Path(probe.__file__).read_text())
        calls=[node.func.attr for node in ast.walk(tree) if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute)]
        self.assertNotIn('run_forward',calls)
        self.assertNotIn('compute_gradient',calls)
        self.assertNotIn('run_adjoint',calls)
        self.assertNotIn('_run_perturbation_loop',calls)
        self.assertEqual(probe.STEPS,(1.,.5,.25))
        # This helper's offline tests include the real vendor-style
        # super(FDTD,self) pattern; running it opens no actual CAD.
        probe.guard.self_test()

    def test_actual_saved_identity_and_negative_spec_task_controls_without_cad(self):
        repo=Path(os.environ.get('S2_DEPS_TEST_REPO',Path.cwd())).resolve()
        sys.path.insert(0,str(repo))
        from runners.lumopt2_design import recover_te_s2 as recovery
        from runners.lumopt2_design import recover_te_s2_peak as peak
        provenance=json.loads((repo/'docs/readiness_evidence_20261007/s2_provenance_first_report_original.json').read_text())
        point=recovery.val.te_point(recovery.SPEC)
        for imaginary,task,label in ((False,0,'re'),(True,1,'im')):
            spec=dataclasses.replace(peak.SPEC,label='test_'+label,adj_phase_fix=imaginary,
                adj_fix_re=0. if imaginary else 1.,adj_fix_im=1. if imaginary else 0.)
            probe.verify_full_spec(spec,provenance['spec'],imaginary)
            for field,value in (('dp_tooth_nm',.75),('n_wl_points',499),('colocate_fields',True)):
                with self.assertRaisesRegex(RuntimeError,'Complete spec'):
                    probe.verify_full_spec(dataclasses.replace(spec,**{field:value}),provenance['spec'],imaginary)
            with self.assertRaisesRegex(RuntimeError,'Quadrature phase'):
                probe.verify_full_spec(dataclasses.replace(spec,adj_phase_fix=not imaginary),provenance['spec'],imaginary)
            path=repo/f'results_from_athena/recover_te_s2_20261006/watch/recover_te_s2_peak/task_{task:02d}.json'
            row=json.loads(path.read_text())
            # These are actual POSIX server identities; preserve their strings
            # on Windows rather than converting them to Windows Path syntax.
            forward=row['result']['forward'];adjoint=row['result']['adjoint']
            value=probe.validate_saved_gradient(row,imaginary,point,forward,adjoint,recovery.INDICES,provenance['spec'])
            self.assertEqual(value,row['result']['gradient'][1])
            for key,bad in (('task',1-task),('indices',[29]),('point',[0.]*296)):
                altered=copy.deepcopy(row);altered['identity']['base'][key]=bad
                with self.assertRaises(RuntimeError):probe.validate_saved_gradient(altered,imaginary,point,forward,adjoint,recovery.INDICES,provenance['spec'])
            altered=copy.deepcopy(row);altered['identity']['objective']='softmax'
            with self.assertRaisesRegex(RuntimeError,'objective'):
                probe.validate_saved_gradient(altered,imaginary,point,forward,adjoint,recovery.INDICES,provenance['spec'])
            altered=copy.deepcopy(row);altered['identity']['base']['spec']['dp_tooth_nm']=.75
            with self.assertRaisesRegex(RuntimeError,'physical/numerical'):
                probe.validate_saved_gradient(altered,imaginary,point,forward,adjoint,recovery.INDICES,provenance['spec'])
            # Historical source identity is reported, not falsely required
            # equal to the later optimizer-only integration.
            altered=copy.deepcopy(row);altered['identity']['base']['code']['lumopt2_design.py']='0'*64
            self.assertEqual(probe.validate_saved_gradient(altered,imaginary,point,forward,adjoint,recovery.INDICES,provenance['spec']),value)


if __name__=='__main__': unittest.main()
