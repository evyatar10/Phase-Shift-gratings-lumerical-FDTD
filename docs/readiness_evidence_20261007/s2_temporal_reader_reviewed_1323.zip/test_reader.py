"""Focused TEMP-only synthetic temporal results over actual trusted old inputs."""
import copy,json,shutil,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
import numpy as np
import analyze_temporal as a
REPO=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');sys.path.insert(0,str(REPO))
from runners.lumopt2_design import s2_temporal_forward as r
EVIDENCE=REPO/'docs/readiness_evidence_20261007'
CAD=Path('C:/Users/evyat/AppData/Local/Temp/s2_temporal_diagnostic_u8x6m02t/actual_temporal_cad_v4oohtm5/validation.json')

class ReaderTests(unittest.TestCase):
    def setUp(self):
        self.root=Path(tempfile.mkdtemp(prefix='fixture_SYNTHETIC_',dir=Path(__file__).parent))
        self.markerpath=self.root/'s2_temporal100_review_original.json';shutil.copyfile(EVIDENCE/self.markerpath.name,self.markerpath)
        self.marker=json.loads(self.markerpath.read_text())
        for name in ['s2_fdstep_task00_original.json','s2_fdstep_task00_ports.npz']+[f's2_shift30_task{t:02d}_{s}' for t in (2,3) for s in ('original.json','ports.npz')]:
            shutil.copyfile(EVIDENCE/name,self.root/name)
        self.baseline=a.h.load_npz((self.root/'s2_fdstep_task00_ports.npz').read_bytes())
        self.cad=json.loads(CAD.read_text());self.pins100=self.triplet(100,self.marker,a.FIRST_REMOTE)
        self.manifest=dict(schema=1,family=a.FAMILY,runner_sha256=a.RUNNER_SHA,stages={'100':self.stage(self.pins100,self.markerpath,a.FIRST_SHA,a.FIRST_REMOTE,100)})
    def stage(self,pins,markerpath,sha,remote,d):return a.stage_from_fetch_pins(pins,markerpath,sha,remote,d)
    def triplet(self,duration,marker,remote):
        pins={};marker_sha=a.f.sha(self.markerpath) if duration==100 else a.f.sha(self.laterpath)
        tasks=range(3) if duration==100 else range(3,6)
        for task in tasks:
            position=task%3;p,index,d,sign=r.task_params(task);c=copy.deepcopy(self.cad['measurements'][position]['controls100'])
            c['after']['timing']['simulation time']=duration*1e-12;c['after_sha256']=r.semantic(c['after'])
            c['changed_properties']['FDTD::simulation time'][1]=duration*1e-12
            c.update(persisted=copy.deepcopy(c['after']),persisted_sha256=r.semantic(c['after']),serialization=r.persisted_check(c['after'],c['after']))
            arrays={k:v.copy() for k,v in self.baseline.items()};scale=(1+.00001*duration)*(1+sign*.006*.0625+.001*.0625**2 if sign else 1.)
            arrays['p2_T_out']*=scale;arrays['p2_S']*=np.sqrt(scale)*np.exp(1j*sign*.37)
            npz=self.root/f'temporal{duration}_task{task:02d}_SYNTHETIC_ports.npz'
            with npz.open('xb') as f:np.savez(f,**arrays)
            attempt=marker['output_root']+f'/task_{task:02d}_SYNTHETIC_FIXTURE';source=attempt+'/files/fwd_default.fsp'
            termination=dict(log=source[:-4]+'_p0.log',log_sha256='c'*64,iterations=1000000,physical_time_s=duration*1e-12,
                requested_time_s=duration*1e-12,recorded_dt_s=c['dt_s'],delta_s=0.,status=1,reason='completed_full_simulation_time')
            review=dict(path=remote,sha256=marker_sha,duration_ps=float(duration),lead_verdict=marker['lead_verdict'],
                allowed_tasks=marker['allowed_tasks'],first_stage=marker['first_stage'])
            ident=dict(schema=1,task=task,spec=marker['spec'],point=p.tolist(),index=index,sign=sign,delta_nm=sign*.0625,
                duration_ps=float(duration),task_map=marker['task_map'],center_checkpoint=a.f.CENTER_REMOTE,center_sha256=a.f.CENTER_SHA,
                code=marker['code'],vendor_api_sha256=marker['vendor_api_sha256'],parent_review=review,timing_changes=marker['timing_changes'])
            result=dict(task=task,index=index,duration_ps=float(duration),sign=sign,delta_nm=sign*.0625,params=p.tolist(),source=source,
                h5=source[:-4]+'/fwd_default_output.h5',ports_npz=attempt+'/ports.npz',ports_sha256=a.f.sha(npz),fsp_sha256='a'*64,
                h5_sha256='b'*64,setup_fsp_sha256='d'*64,FDTD_version='SYNTHETIC_NO_ENGINE',controls=c,termination=termination,
                parent_review=review,reviewed_center_sha256=a.f.CENTER_SHA,vendor_api_sha256=marker['vendor_api_sha256'],
                comparison_status='TEMPORAL_DIAGNOSTIC_REVIEW_REQUIRED_NO_PHYSICS_PASS',existing_overall_gradient_gate='FAILED_UNCHANGED',**r.recovery.score(arrays))
            cp=self.root/f'temporal{duration}_task{task:02d}_SYNTHETIC_original.json';cp.write_text(json.dumps(dict(identity=ident,result=result)))
            pins[f'{task}:checkpoint']=dict(local=str(cp),path=marker['output_root']+f'/task_{task:02d}.json',sha256=a.f.sha(cp),bytes=cp.stat().st_size)
            pins[f'{task}:ports']=dict(local=str(npz),path=result['ports_npz'],sha256=a.f.sha(npz),bytes=npz.stat().st_size)
        return pins
    def row(self,t=0):return json.loads(Path(self.pins100[f'{t}:checkpoint']['local']).read_text())
    def put(self,row,t=0):
        binding=self.pins100[f'{t}:checkpoint'];p=Path(binding['local']);p.write_text(json.dumps(row));binding.update(sha256=a.f.sha(p),bytes=p.stat().st_size)
        self.manifest['stages']['100']=self.stage(self.pins100,self.markerpath,a.FIRST_SHA,a.FIRST_REMOTE,100)
    def analyze(self):
        with patch.object(r,'main',side_effect=AssertionError('Runner main called')),patch.object(r.eng,'import_lumopt2',side_effect=AssertionError('CAD/API imported')):
            return a.analyze(self.manifest,self.root,REPO)
    def add150(self):
        wave=dict(marker=a.FIRST_REMOTE,marker_sha256=a.FIRST_SHA,checkpoints={})
        for t in range(3):
            row=self.row(t);z=row['result'];wave['checkpoints'][str(t)]=dict(checkpoint=self.marker['output_root']+f'/task_{t:02d}.json',sha256=self.pins100[f'{t}:checkpoint']['sha256'],
                ports_sha256=z['ports_sha256'],fsp_sha256=z['fsp_sha256'],h5_sha256=z['h5_sha256'],termination=z['termination'])
        m=copy.deepcopy(self.marker);m.update(duration_ps=150.,allowed_tasks=[3,4,5],status=r.STATUS[150.],
            timing_changes={'simulation time':150e-12,'use early shutoff':0},lead_verdict='SYNTHETIC later marker not scientific approval',first_stage=wave)
        self.laterpath=self.root/'SYNTHETIC_later_marker.json';self.laterpath.write_text(json.dumps(m));remote='/work/data/SYNTHETIC_temporal150_review.json'
        pins=self.triplet(150,m,remote);self.manifest['stages']['150']=self.stage(pins,self.laterpath,a.f.sha(self.laterpath),remote,150)
    def test100_reader_full_arrays_same_center_parity_and_no_solve(self):
        report,full=self.analyze();self.assertTrue(report['no_automatic_approval']);self.assertEqual(report['status'],'DIAGNOSTIC_ONLY_CALIBRATION_FAILED_UNCHANGED')
        self.assertNotIn('150',report['duration_labels'])
        for metric,o in report['observables'].items():
            t=o['triplets']['100'];self.assertEqual(set(t['fixed_bins']),{'244','252','260'})
            self.assertAlmostEqual(t['central_derivative'],t['center_peak3']*.006,places=12)
            self.assertAlmostEqual(t['even'],t['center_peak3']*.001*.0625**2,places=12)
            self.assertAlmostEqual(t['same_duration_center_jacobian_projection'],t['central_derivative'],places=12)
            self.assertEqual(len(full['observables'][metric]['100']['spectral_even_with_same_duration_center']),501)
        raw=full['raw_port_spectra']['100']['plus']['p2_S']
        decoded=np.asarray(raw['real'])+1j*np.asarray(raw['imag'])
        expected=a.h.load_npz(Path(self.pins100['1:ports']['local']).read_bytes())['p2_S'].ravel()
        np.testing.assert_array_equal(decoded,expected)
    def test150_optional_exact_ancestry_and_same_geometry_duration_compare(self):
        self.add150();report,full=self.analyze()
        self.assertIn('150_minus_100',report['observables']['peak3_tout']['same_geometry_temporal_differences'])
        self.assertEqual(len(full['observables']['peak3_modal']['150_minus_100']['same_geometry_spectral_differences']['plus']),501)
        marker=json.loads(self.laterpath.read_text());marker['first_stage']['checkpoints']['1']['sha256']='0'*64;self.laterpath.write_text(json.dumps(marker))
        self.manifest['stages']['150']['marker_sha256']=a.f.sha(self.laterpath)
        with self.assertRaisesRegex(a.h.EvidenceError,'ancestry'):self.analyze()
    def test_mismatched_family_task_and_exact_center_after_repin(self):
        original=self.row()
        for key,value in [('index',149),('point',[0.]*296),('center_sha256','0'*64),('duration_ps',150.)]:
            row=copy.deepcopy(original);row['identity'][key]=value;self.put(row)
            with self.assertRaisesRegex(a.h.EvidenceError,'checkpoint/task'):self.analyze()
    def test_grid_tamper_after_hashes_updated_and_score_tamper(self):
        path=Path(self.pins100['1:ports']['local']);arrays=a.h.load_npz(path.read_bytes());arrays['p2_lambda']+=1e-15
        with path.open('wb') as f:np.savez(f,**arrays)
        self.pins100['1:ports'].update(sha256=a.f.sha(path),bytes=path.stat().st_size);row=self.row(1);row['result']['ports_sha256']=a.f.sha(path);self.put(row,1)
        with self.assertRaisesRegex(a.h.EvidenceError,'grid mismatch'):self.analyze()
    def test_controls_and_termination_tamper_after_repin(self):
        original=self.row()
        row=copy.deepcopy(original);row['result']['termination']['status']=2;self.put(row)
        with self.assertRaisesRegex(a.h.EvidenceError,'termination'):self.analyze()
        row=copy.deepcopy(original);row['result']['controls']['after']['timing']['use early shutoff']=1
        row['result']['controls']['after_sha256']=r.semantic(row['result']['controls']['after']);self.put(row)
        with self.assertRaisesRegex(a.h.EvidenceError,'control intervention'):self.analyze()
        row=copy.deepcopy(original);row['result']['peak3_tout']+=1e-8;self.put(row)
        with self.assertRaisesRegex(a.h.EvidenceError,'scalar not reproduced'):self.analyze()
    def test_fetch_manifest_remote_path_missing_bytes_and_missing_input(self):
        with self.assertRaisesRegex(a.h.EvidenceError,'Remote marker'):self.stage(self.pins100,self.markerpath,a.FIRST_SHA,'relative_marker.json',100)
        pins=copy.deepcopy(self.pins100);pins['0:checkpoint']['path']='/work/results/other/task_00.json'
        with self.assertRaisesRegex(a.h.EvidenceError,'remote path'):self.stage(pins,self.markerpath,a.FIRST_SHA,a.FIRST_REMOTE,100)
        pins=copy.deepcopy(self.pins100);pins['0:ports']['bytes']+=1
        with self.assertRaisesRegex(a.h.EvidenceError,'byte count'):self.stage(pins,self.markerpath,a.FIRST_SHA,a.FIRST_REMOTE,100)
        Path(self.pins100['2:checkpoint']['local']).rename(self.root/'retained_missing_cp.json')
        with self.assertRaises(FileNotFoundError):self.analyze()

    def test_exact_fetch_format_cli_and_exclusive_output(self):
        pins=self.root/'SYNTHETIC_fetch_pins.json';a.f.write(pins,self.pins100)
        out=self.root/'SYNTHETIC_cli_report.json';full=self.root/'SYNTHETIC_cli_full.json'
        command=[sys.executable,'-B',a.__file__,'--100-pins',str(pins),'--100-pins-sha256',a.f.sha(pins),
            '--100-marker',str(self.markerpath),'--existing-evidence-dir',str(self.root),'--repo',str(REPO),
            '--output',str(out),'--spectra-output',str(full)]
        run=subprocess.run(command,capture_output=True,text=True);self.assertEqual(run.returncode,0,run.stderr)
        self.assertTrue(json.loads(out.read_text())['no_automatic_approval']);original=out.read_bytes()
        rerun=subprocess.run(command,capture_output=True,text=True);self.assertNotEqual(rerun.returncode,0)
        self.assertIn('Exclusive distinct',rerun.stderr);self.assertEqual(out.read_bytes(),original)

if __name__=='__main__':unittest.main(verbosity=2)
