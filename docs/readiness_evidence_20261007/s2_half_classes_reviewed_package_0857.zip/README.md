# Prepared staged S2 half-step class check

Preparation is isolated in this temp package. The parent owns review, shared
license/resource preflight, upload and dispatch. Existing source and old half-
step results are preserved. No fitting, gradient, optimizer or automatic
scientific approval is implemented. Calibration remains FAILED_UNCHANGED.

| Task | Parameter | Live index | Delta nm | Stage |
|---|---|---:|---:|---|
| 0 | corr30 repeat | 29 | +0.5 | first |
| 1 | corr30 repeat | 29 | -0.5 | first |
| 2 | shift30 | 149 | +0.5 | first |
| 3 | shift30 | 149 | -0.5 | first |
| 4 | corr1 | 0 | +0.5 | later |
| 5 | corr1 | 0 | -0.5 | later |
| 6 | avg1 | 60 | +0.5 | later |
| 7 | avg1 | 60 | -0.5 | later |
| 8 | shift1 | 120 | +0.5 | later |
| 9 | shift1 | 120 | -0.5 | later |
| 10 | wcav | 295 | +0.5 | later |
| 11 | wcav | 295 | -0.5 | later |

Map derives from live val._indices and layout60. Index180 is an inert comb slot;
wcav tasks modify only295. All legs use the exact recovered te_point anchor
and unchanged numerical family. The pinned NEW center SHA is
cd2dd4a58be7b83c46ef6a6ac90a874e5fc33edda884edfc8ac50ce5e3be4a06.
Its reviewed-center marker, complete original diagnostic spec and current
dependency hashes must match before any solve.

Configure in the existing validated Athena wrapper/runtime:

```bash
export S2_HALF_REPO=/work
export S2_HALF_CENTER_CHECKPOINT=/work/results/diagnose_te_s2_fdstep/results/lumopt2_te_s2_fdstep_diagnostic_20261007/task_00.json
export S2_HALF_OUTPUT_ROOT=/work/results/diagnose_te_s2_fdhalf_classes/results/lumopt2_te_s2_fdhalf_classcheck_20261007
export S2_HALF_FIRST_REVIEW_MARKER=/NEW/firstwave_review.json
export S2_HALF_LATER_REVIEW_MARKER=/NEW/laterwave_review.json
export KEEP_H5=1
```

Use the existing server wrapper for actual config.LUMAPI_PATH, resource row,
GPU configuration, thread count and HDF5 preservation. The runner does not
guess or change those settings. Import s2_fdhalf_classes.py as a standalone
module in that wrapper, then call module.main(integer_task_index).

Build the first review template in the configured runtime, no CAD/solve:

```python
center = module.load_center()
template = module.review_template('first', module.output_root(), center,
                                  '/PRESERVED/s2_provenance_first_report_original.json')
```

It has status NOT_REVIEWED and allowed_tasks=[]. Only the parent may create a
NEW immutable marker after reviewing it. For the first stage set status
APPROVED_FOR_FIRSTWAVE_HALFSTEP_FD and allowed_tasks=[0,1,2,3]; preserve all
other identity/hash fields. Do not change that marker after dispatch.

After ALL four first-wave checkpoints exist and the parent inspects their
scalar and full-spectrum evidence, obtain a separate later-stage template:

```python
later = module.review_template('later', module.output_root(), center,
                               '/PRESERVED/s2_provenance_first_report_original.json')
```

This refuses missing/inconsistent first-wave evidence. It records the exact
four checkpoint paths/SHA256s/scalars and original first-marker path/SHA.
It is still NOT_REVIEWED with no allowed tasks and lead_verdict=NOT_REVIEWED.
Only after actual lead review, create a DIFFERENT NEW marker with status
APPROVED_FOR_REMAINING_CLASS_FD_LEGS_AFTER_FIRSTWAVE_REVIEW,
allowed_tasks=[4,5,6,7,8,9,10,11], and a substantive lead_verdict explaining
the bounded continuation decision and any scientific limitations. Preserve
all other fields. No automatic fit or calibration pass is inferred.

Later tasks verify all four first-wave identities again, including source
hashes, parameters/class/task metadata, successful solve logs, preserved
FSP/H5/NPZ paths, NPZ SHA and scalar reproduction from NPZ. They verify the
new marker's exact first-wave manifest and shared original provenance hash.
Reusing or mutating the first marker is refused. Missing, stale, tampered or
unapproved evidence fails before CAD. The code never writes review markers.

Every task executes one forward only, disables optimization_dft only after
confirming exact locked mesh equality, and preserves unique attempt files.
Atomic exclusive checkpoints and exclusive NPZ creation prevent overwrite.
Completed tasks verify their evidence and resume without a new solve. Failed
attempts remain intact. Do not dispatch concurrent copies of the same task;
checkpoint publication is not a scheduler lock against duplicate solves.

Offline tests:

```powershell
python -B test_s2_fdhalf_classes.py
```

Six test groups pass, including all twelve live deltas/bounds, the295-versus180
negative control, first/later stage scope, incomplete first-wave refusal,
separate immutable markers, checkpoint/SHA/lead-verdict tampering, successful
log/NPZ score checks, cold resume, KEEP_H5 and mesh/H5 failures. Fixtures stay
in this package; synthetic center hashes are patched only inside tests.
These offline tests do not establish new FDTD physics.

validate_task2_cad.py is a separately authorized hidden local CAD harness for
shift30 task2 only. It keeps the lumapi.FDTD class symbol intact through the
copied no_solve_guard.py, prepares the new forward layout, checks all723 mapped
geometry properties and the locked-mesh field-disable equality, and never
calls run_forward. Its unique output directory preserves its build/evidence.

Actual task2 hidden CAD check passed exit0. The first attempt was safely
refused because the copied guard resolved a vendor relative save against
Python cwd instead of CAD pwd. Its failure evidence is preserved. Only this
temp package's guard was corrected to resolve relative paths using captured
CAD pwd, then apply the same absolute-root and no-overwrite checks. Relative
inside-root/outside-root/existing-file offline controls passed.

The successful attempt is actual_cad_task2_pqo55t7f/validation.json. It validates
shift30 index149 at+0.5nm, all723 geometry properties, optimization_dft disabled
in the prepared CAD and identical locked x/y/z grids. No FDTD solve or physics
result is claimed. The production runner and engine were not changed by this
test-guard correction.
