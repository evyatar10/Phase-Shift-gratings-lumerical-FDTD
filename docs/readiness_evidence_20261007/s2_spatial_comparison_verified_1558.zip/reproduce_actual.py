"""Reproduce actual parent-pinned profiles locally into NEW output paths."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
PINS_SHA='ea650471e70e426373a75074520d64836bd21c6d87066e6f89869187257f33cf'
p=argparse.ArgumentParser();p.add_argument('--output-prefix',required=True);a=p.parse_args()
repo=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');ev=repo/'docs/readiness_evidence_20261007';data=ev/'s2_saved_profiles_fetch_154823'
raw=(data/'pins.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==PINS_SHA,'Parent pin manifest changed';pins=json.loads(raw)
prefix=Path(a.output_prefix);argv=[sys.executable,'-B',str(Path(__file__).with_name('compare_profiles.py')),'--repo',str(repo),'--evidence-dir',str(ev),'--output',str(prefix)+'.json','--mat-output',str(prefix)+'.mat']
for d in (100,150):
 argv += ['--report'+str(d),str(data/'report.json'),'--report-sha256'+str(d),pins['report.json']['sha256'],'--npz'+str(d),str(data/f'profiles_{d}ps.npz'),'--npz-sha256'+str(d),pins[f'profiles_{d}ps.npz']['sha256']]
raise SystemExit(subprocess.run(argv).returncode)
