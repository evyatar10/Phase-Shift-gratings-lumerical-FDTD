import dataclasses,json,sys,unittest
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
import blueprint as b
REPO=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
CP=REPO/'docs/readiness_evidence_20261007/s2_temporal150_fetch_1434/s2_temporal150_task03_original.json'


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.row,cls.eng=b.load(CP,REPO);cls.spec=cls.eng.CampaignSpec(**cls.row['identity']['spec']);cls.p=np.asarray(cls.row['identity']['point']);cls.report=b.build(cls.row,cls.eng)
    def test_inner_geometry_matches_exactly_for_saved_and_nonzero_shift_variants(self):
        short=b.candidate_spec(self.spec)
        for offsets in ({},{0:2.,60:-1.,120:3.,149:-.5,295:1.}):
            p=self.p.copy()
            for k,v in offsets.items():p[k]+=v
            a=self.eng.make_func(self.spec)(p);z=self.eng.make_func(short)(p)
            self.assertEqual(len(a),723);self.assertEqual(b.canonical(a),b.canonical(z));self.assertNotEqual(set(a),set(z))
        cavity=b.canonical(self.eng.make_func(short)(self.p))
        self.assertAlmostEqual(cavity['cavity::x span']*1e9,265.53,places=10)
        self.assertEqual(cavity['cavity::y span'],self.p[295]*1e-9)
    def test_only_physical_N_and_gap_change_native_domain_is_preserved(self):
        self.assertEqual(set(self.report['native_builder_kwargs_changes']),{'n_periods_each_side','n_periods_dist_to_port'})
        self.assertEqual(self.report['native_builder_kwargs_changes']['n_periods_dist_to_port'],{'N98':20,'N80':38})
        self.assertLessEqual(abs(self.report['native_domain_delta_m']),1e-20)
        self.assertLessEqual(abs(self.report['native_port_delta_m']),1e-20)
        self.assertAlmostEqual(self.report['physical_grating_end_um']['98']-self.report['physical_grating_end_um']['80'],8.83908,places=10)
    def test_retained_outer_geometry_is_uniform_and_joins_at_unchanged_free_edge(self):
        props=self.report['outer_uniform_properties_prediction_SI'];self.assertEqual(len(props),240)
        objects={k.split('::')[0] for k in props};self.assertEqual(len(objects),80)
        right=[]
        for name in objects:
            center=props[name+'::x'];span=props[name+'::x span'];self.assertAlmostEqual(span,491.06e-9/2,places=18)
            if name.startswith('R_'):right.append((center-span/2,center+span/2))
        self.assertAlmostEqual(min(v[0] for v in right),29.586365e-6,places=17)
        self.assertAlmostEqual(max(v[1] for v in right),39.407565e-6,places=17)
        self.assertTrue(all(61<=int(n.split('_')[2])<=80 for n in objects))
    def test_accidental_inner_count_or_non_nominal_family_refuses(self):
        with self.assertRaises(ValueError):b.candidate_spec(dataclasses.replace(self.spec,n_free=40))
        with self.assertRaises(ValueError):b.candidate_spec(dataclasses.replace(self.spec,n_periods_side=60))
        row=json.loads(json.dumps(self.row));row['result']['params'][29]+=.5
        with self.assertRaises(ValueError):b.build(row,self.eng)
    def test_current_production_crop_excludes_quarter_pitch_physical_edge(self):
        # +/-39.35um are within N80 physical39.407565um ends, outside engine crop39.2848um.
        x=np.asarray([-39.35,0.,39.35])*1e-6;y=np.asarray([-1e-6,0.,1e-6]);E=np.ones((3,3,1,1,3),complex)
        res=dict(x=x,y=y,**{'lambda':np.asarray([1560.8e-9])},E=E)
        short,_,aux=self.eng._line_from_res(res,1560.8,80,491.06)
        long,_,_=self.eng._line_from_res(res,1560.8,98,491.06)
        self.assertEqual(short.tolist(),[0.]);self.assertEqual(len(long),3)
        self.assertEqual(aux['keep'].tolist(),[False,True,False])


if __name__=='__main__':unittest.main(verbosity=2)
