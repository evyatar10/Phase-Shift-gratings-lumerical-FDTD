"""Actual hidden CAD for three exact points and both timing windows; zero FDTD."""
import sys,json,tempfile,time,traceback
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,'C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
import s2_temporal_forward as r
import no_solve_guard as guard
import config
ROOT=Path(tempfile.mkdtemp(prefix='actual_temporal_cad_',dir=Path(__file__).parent))
config.BASE_SAVE_DIR=str(ROOT/'generated');config.LUMAPI_PATH='C:/Program Files/Lumerical/v261/api/python/lumapi.py';config.USE_GPU=False
lmpt=r.eng.import_lumopt2()
import lumapi
sessions=[];symbol=lumapi.FDTD;restore=guard.install_constructor_guard(symbol,ROOT,sessions)
report=dict(mode='HIDDEN_CAD_ONLY_NO_FDTD_SOLVE',started=time.time(),runner_sha256=r.sha(r.__file__),
    harness_sha256=r.sha(__file__),guard_sha256=r.sha(guard.__file__),sources=r.code(),measurements=[],
    vendor_files={str(p):guard.sha256(p) for p in (Path(config.LUMAPI_PATH),Path('C:/Program Files/Lumerical/v261/api/python/lumopt2/Project.py')) if p.is_file()})
try:
    for task in range(3):
        p,index,_,sign=r.task_params(task);folder=ROOT/f'point_{task}'
        project,_=r.eng.make_project(r.SPEC,str(folder),lmpt);project.set_fwd(p);f=project.fdtd_session.fdtd
        c100=r.controls(f,p,100.)
        for key in ('simulation time','use early shutoff'):f.setnamed('FDTD',key,c100['before']['timing'][key])
        f.setnamed('optimization_dft','enabled',1)
        c150=r.controls(f,p,150.)
        assert c100['before']==c150['before'] and c100['after']['source']==c150['after']['source']
        report['measurements'].append(dict(task=task,index=index,delta_nm=sign*.0625,params=p.tolist(),
            controls100=c100,controls150=c150,mapped_geometry_properties=len(c100['before']['geometry']),
            mesh_points={a:len(v) for a,v in c100['before']['mesh'].items()}))
        project.fdtd_session.fdtd.close()
    report.update(passed=True,FDTD_version=guard.attempt(lambda:sessions[-1]._raw.version()) if hasattr(sessions[-1]._raw,'version') else 'API version logged by build',
        class_preserved=lumapi.FDTD is symbol)
except Exception as exc:report.update(passed=False,error=repr(exc),traceback=traceback.format_exc())
finally:
    report['audits']=[s.audit for s in sessions]
    for s in sessions:guard.attempt(s.close)
    restore();report['elapsed_seconds']=time.time()-report['started'];out=ROOT/'validation.json'
    with out.open('x') as stream:json.dump(guard.plain(report),stream,indent=2,allow_nan=False)
    print(out,flush=True);print('PASS' if report['passed'] else 'FAIL',report.get('error',''),flush=True)
sys.exit(0 if report['passed'] else 2)
