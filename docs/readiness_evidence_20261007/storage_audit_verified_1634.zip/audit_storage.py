"""One bounded read-only SSH per cluster; no scans, cleanup or scheduler mutations."""
import argparse,concurrent.futures,datetime,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
EXTRACTION=ROOT/'docs/readiness_evidence_20261007/s2_saved_profiles_fetch_154823/report.json'
EXTRACTION_SHA='01a6fe6540c7cf903de67cecc42a89c6318983301364b679b9da0870dede595a'
HOSTS={'athena':('evyatarrubin@athena.technion.ac.il','/home/evyatarrubin/bragg_sim_athena'),'igum':('evyatarrubin@132.68.58.101','/home/evyatarrubin/research/bragg_sim_igum')}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def execute(argv,input_bytes=None,timeout=50):
 start=now()
 try:
  p=subprocess.run(argv,input=input_bytes,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,check=False)
  return dict(argv=argv,started_UTC=start,ended_UTC=now(),exit_code=p.returncode,stdout=p.stdout.decode('utf-8','replace'),stderr=p.stderr.decode('utf-8','replace'))
 except Exception as e:return dict(argv=argv,started_UTC=start,ended_UTC=now(),exit_code=None,error=type(e).__name__+': '+str(e))
def remote_script(base,host,files):
 # Sent in memory via stdin; no remote helper file is written.
 return '''import datetime,json,os,subprocess
def run(args):
 try:
  p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
  return dict(argv=args,exit_code=p.returncode,stdout=p.stdout.decode('utf-8','replace'),stderr=p.stderr.decode('utf-8','replace'))
 except Exception as e:return dict(argv=args,exit_code=None,error=type(e).__name__+': '+str(e))
base=BASE
paths=[base,base+'/results','/home/evyatarrubin']
commands={name:run(args) for name,args in [('quota_human',['quota','-s']),('quota_exact_blocks',['quota','-v']),('df_human',['df','-hP']+paths),('df_bytes',['df','-B1','-P']+paths),('df_inodes',['df','-iP']+paths),('queue',['squeue','-u','evyatarrubin','--noheader'])]}
if HOST=='igum':commands['shared_solve_seats']=run(['/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261/licensingclient/linx64/lmutil','lmstat','-c','1055@132.68.48.51','-f','lum_fdtd_solve'])
stat=[]
for path in FILES:
 try:
  s=os.stat(path);stat.append(dict(path=path,bytes=s.st_size,mtime_ns=s.st_mtime_ns))
 except Exception as e:stat.append(dict(path=path,error=type(e).__name__+': '+str(e)))
print(json.dumps(dict(timestamp_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),paths=paths,real_paths=[os.path.realpath(p) for p in paths],commands=commands,exact_known_artifact_stats=stat)))
'''.replace('BASE',repr(base)).replace('HOST',repr(host)).replace('FILES',repr(files))
def collect_host(name,files):
 host,base=HOSTS[name];script=remote_script(base,name,files)
 result=execute(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','StrictHostKeyChecking=yes',host,'python3 -'],script.replace('\r\n','\n').encode('utf-8'),timeout=50)
 if result.get('exit_code')==0:
  try:result['parsed']=json.loads(result['stdout'])
  except Exception as e:result['parse_error']=str(e)
 return result
def df_rows(raw):
 rows=[]
 for line in raw.splitlines()[1:]:
  parts=line.split()
  if len(parts)==6:
   try:rows.append(dict(filesystem=parts[0],total=int(parts[1]),used=int(parts[2]),available=int(parts[3]),use_percent=parts[4],mount=parts[5]))
   except ValueError:pass
 return rows
def collect():
 if sha(EXTRACTION)!=EXTRACTION_SHA:raise RuntimeError('Measured artifact-size evidence changed')
 saved=json.loads(EXTRACTION.read_text());local=[]
 for name,path in [('repo',ROOT),('temp',Path(os.environ['TEMP'])),('local_results',ROOT/'results_from_athena')]:
  d=shutil.disk_usage(path);local.append(dict(role=name,path=str(path),drive=path.resolve().drive,total_bytes=d.total,used_bytes=d.used,free_bytes=d.free,total_GiB=d.total/2**30,free_GiB=d.free/2**30,qualification='Volume free space,not Windows user quota'))
 measured=[];athena_files=[]
 for duration,pins in saved['inputs'].items():
  total=sum(p['bytes'] for p in pins)
  measured.append(dict(duration_ps=int(duration),artifact_bytes=total,artifact_GiB=total/2**30,includes='checkpoint,FSP,H5,portNPZ only; excludes logs/intermediates/failed attempts',artifacts=pins))
  athena_files.extend(p['path'].replace('/work/results/',HOSTS['athena'][1]+'/results/') for p in pins)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  pending={name:pool.submit(collect_host,name,athena_files if name=='athena' else []) for name in HOSTS};hosts={name:f.result() for name,f in pending.items()}
 for host in hosts.values():
  if 'parsed' in host:
   for key in ['df_bytes','df_inodes']:
    command=host['parsed']['commands'][key]
    if command['exit_code']==0:command['numeric_rows']=df_rows(command['stdout'])
 max_result=max(r['artifact_bytes'] for r in measured);attempt_margin=2*max_result
 return dict(timestamp_UTC=now(),scope='BOUNDED_READ_ONLY_STORAGE_NO_CLEANUP_OR_JOB_ACTIONS',local=local,local_filesystem_inventory=execute(['powershell','-NoProfile','-Command','Get-PSDrive -PSProvider FileSystem | Select-Object Name,Root,Used,Free | ConvertTo-Json -Compress']),measured_size_evidence=dict(path=str(EXTRACTION),sha256=EXTRACTION_SHA,rows=measured,max_artifact_bytes=max_result),hosts=hosts,planning=dict(per_attempt_planning_bytes=attempt_margin,per_attempt_planning_GiB=attempt_margin/2**30,margin='2x largest measured100/150ps CP+FSP+H5+NPZ; allowance only,not an upper bound on200ps/new-family/intermediate storage',unfinished_200ps_triplet_reserve_bytes=3*attempt_margin,unfinished_triplet_plus_one_replacement_triplet_bytes=6*attempt_margin,N80_one_forward_increment_bytes=attempt_margin,N80_triplet_increment_bytes=3*attempt_margin,trigger='Before a new allocation, compare soft-quota headroom AND filesystem free bytes/inodes against outstanding expected attempts plus proposed attempts plus an explicitly budgeted retry,using measured updated family sizes. If quota is unavailable,report allocation uncertainty instead of claiming safe capacity.',cadence='One combined storage/queue/quota connection per host before dispatch and after completion/fetch; while waiting fold into an existing20-30min status check,never a recursive home scan. Refresh earlier if output sizes exceed the planning allowance.'))
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--collect',action='store_true',required=True);parser.parse_args()
 with Path(__file__).with_name('storage_evidence.json').open('x',encoding='utf-8') as stream:json.dump(collect(),stream,indent=2)
 print(Path(__file__).with_name('storage_evidence.json'))
