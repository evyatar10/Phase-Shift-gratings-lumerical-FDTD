# Fixed-bin saved-field shift30 diagnostic — preparation only

No dispatch, network, CAD or FDTD action was performed. Parent reviews/uploads and
runs preflight. Production FOM, calibration and all existing helpers remain unchanged.

Files to deploy together: probe_fixed_bin_shift30.py, frozen_h1_mechanics.py and
no_solve_guard.py. The latter two are byte-identical private copies of the tested
five-class helper and guard, pinned at runtime to SHA0be8299d...d526d and40dd4878...99d.
This is a standalone diagnostic, not a new discoverable runner/menu or objective.

## Scope and fail-closed behavior

One shift30(index149) dEps1nm derivative per quadrature at the original recovered
point, with full nominal restoration before bbox and after the private mesher call.
Only cached E slices[244,251,252,253,260] are read per explicit saved FSP. Exact
501-frequency grid/order and original Tout scored peak252 / peak3 support251..253
must match; the helper never silently relocates these bins. E shape/coordinates,
finite components, FSP hash/size/mtime, original H5 size/mtime and vendor/spec/point
identity checks are retained. Cache hits re-check FSP identity and request grid.
Unregistered files, missing/nonfinite a/b/N/sourcepower/E or identity mismatch fail.
No normalization, phase, coefficient, fit or noise tolerance is invented.

The old peak3 shift30 contraction is checked against the exactly bound original
six-vector checkpoint before any one-hot output. Arithmetic reproduction tolerances
are rtol1e-12/atol1e-14, explicitly not a scientific acceptance/noise band. Published
five-class controls are Re0.20875441140950038 versus0.20875441140949622 and
Im-1.7084692721685912 versus-1.708469272168592. Unsupported control aborts onehots.
All three one-hot contractions share the same sparse dEps and cached raw fields.
The current vendor gradient-field code is called unchanged for each objective.
Exact vendor frequency/a-or-b/sourcepower inputs are logged unchanged and must
remain identical across Jacobians. Each raw scalar is labeled unqualified vendor
Re/Im, not certified Tout or modal derivative. No full spectral adjoint is assumed.

## Source and observable metadata

Readonly queries record source port/mode, port amplitude/phase/direction/mode/profile
properties and global pulse/band properties. Unsupported property/API queries are
reported with exact failures. Required mode-expansion a/b/N and positive finite
source powers at selected wavelengths must be readable in each saved file.
Optional S/Tout/Tin/total/P values and their absence are separately recorded.

Raw |a|²ReN/Psource and |b|²ReN/Psource are labeled uncorrected continuum algebra.
Comparison is direction-aware: Backward outgoing=a/incoming=b; Forward
outgoing=b/incoming=a. Unknown/missing direction produces no inferred comparison.
Built-in grid-dispersion corrections can differ; no correction is applied. Reported
abs(Tout), abs(S)^2, Tin and their ratios remain independent. Tin is not used as a
universal conversion. Complex quantities serialize as explicit real/imag values.

## Command / artifacts

CLI arguments are the same as the successful original stored-field helpers:

    python -B probe_fixed_bin_shift30.py --repo <deployed_repo> --lumapi <lumapi.py> --quadrature re --provenance <original_complete_provenance.json> --reviewed-provenance-sha256 a742c0d0921620a04d7e186a9baf7a1959d9752a40c7729815825265fe8c5c47 --saved-gradient /work/results/recover_te_s2_peak/results/lumopt2_te_s2_peak_calibration_20261006/task_00.json --output-root <new_unique_directory>

For Im use --quadrature im and task_01.json. Optional --old-root preserves the
registered original recovery pair rule; it is not an arbitrary replacement source.
Output directory must not exist. Final report fixed_bin_shift30.json uses exclusive
creation and exit2 on failure, changed originals or production dependencies.
Partial/failed reports must not be consumed as completed diagnostics.

Original full source/spec/vendor guards are strict; Windows vendor byte hashes and
path keys differ from the recorded Linux ones, so this packet is for the original
Athena environment. Tests do not waive runtime identity checks. The canonical raw
checkpoint bindings accept JSON whitespace differences only, not changed data/code.

## Validation and pending hardware evidence

Five focused offline tests exit0; AST syntax checks pass. Logs/commands are in
 offline_tests.log / VALIDATION.json; checked ROOT sources and original helpers
are unchanged (PRODUCTION_SOURCE_HASH_CHECK.json). Actual vendor scaling,
forward-aux normalization and phased adjoint assembly are exercised with a fake
backend:30component reads total for2files over4Jacobians, then6cache hits. Tests
cover one-hot math/support, cache independence/stale identity, absent coefficients,
nonfinite powers/E, grid/coordinates, direction mapping/unavailable direction,
normalization drift, actual saved checkpoint controls, no-solve guards and no overwrite.

No actual five-slice stored-field CAD validation has run. Required next evidence is:
readability/finite data from both original pairs, source properties or explicit
availability failures, exact vendor normalization stability, old peak3 numerical
reproduction, all three raw onehots, unchanged source/H5/production identities.
Only after successful reports should parent compare fixed-frequency Tout and modal
FD separately; existing scientific calibration failure remains unchanged.

Resources: separate CPU-only Re then Im, conservative128G/8CPUs as prior probes,
subject to preflight and parent walltime choice. Selected raw Python fwd+adj fields
~0.483GiB for5λ; summed gradient field~25MiB. CAD getdata/pinch full-component
transient~8.06GiB persists, plus CAD/H5/index/sparse storage. Cache adds no full501λ
field transfer. Runtime and peak memory for this new packet are unmeasured.
