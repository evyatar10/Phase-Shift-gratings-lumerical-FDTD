import json,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import extract_length_profiles as e
class Raw:
 def __init__(self):
  self.x=np.linspace(-55e-6,55e-6,221);self.y=np.array([-1e-6,0,1e-6]);self.lam=np.linspace(1.54e-6,1.55e-6,501);self.k=0
 def eval(self,script):
  import re
  if 'sp_slice=' in script:self.k=int(re.search(r',([0-9]+)\);',script)[1])-1
 def getv(self,name):
  return {'sp_x':self.x,'sp_y':self.y,'sp_z':np.array([0.]),'sp_lam':self.lam,'sp_shape':np.array([221,3,1,501,3]),'sp_slice':np.sqrt(np.exp(-(self.x[:,None,None]/10e-6)**2))*np.ones((221,3,3))}[name]
 def getresult(self,*args):return 1
 def getnamed(self,*args):return 1
class Engine:
 DEAD_T_FLOOR=1e-8
 @staticmethod
 def measure_peak(wl,v):return wl[250],1.,.1
 @staticmethod
 def _line_from_res(r,target,n,pitch):
  keep=abs(r['x']*1e6)<=n*pitch/1000;I=np.trapz(np.sum(abs(r['E'][:,:,0,0,:])**2,axis=-1),r['y'],axis=1)
  return r['x'][keep]*1e6,I[keep],dict(keep=keep,i_lam=0,wy=np.ones(3))
 @staticmethod
 def extract_envelope_peaks(x,I):return I
 @staticmethod
 def fwhm_env_of_line(x,I):return float(x[I>np.max(I)/2][-1]-x[I>np.max(I)/2][0])
 @staticmethod
 def sigma_of_line(x,I):return 7.
class Tests(unittest.TestCase):
 def setUp(self):
  self.raw=Raw();self.cad=e.s.ReadOnlyCAD(self.raw,'fake.fsp');self.coords,self.shape,self.selected=e.s.transfer_selected(self.cad)
  self.ports={'p2_lambda':self.raw.lam,'p2_f':3e8/self.raw.lam,'p2_T_out':np.ones(501),'p2_S':np.ones(501)}
  self.row={'identity':{'physical_N':80},'result':{'profile_metadata':{'have_raw_data':True,'have_E_result':True,'E_shape':list(self.shape),'axes':{**{k+'_m':v for k,v in self.coords.items()},'f_Hz':self.ports['p2_f']}}}}
 def test_positive_profiles(self):
  report,arrays=e.profiles(self.cad,Engine,self.row,self.ports)
  self.assertEqual(len(report['profiles']),4);self.assertEqual(len(arrays['Tout_cropN80__monitor_x_m']),221)
  self.assertTrue(report['profiles']['Tout_cropN80']['own_production_crop']);self.assertFalse(report['profiles']['Tout_cropN98']['own_production_crop'])
 def test_grid_refusal(self):
  self.coords['lambda']=self.coords['lambda'].copy();self.coords['lambda'][0]+=1e-15
  with self.assertRaisesRegex(RuntimeError,'coordinate'):e.validate_grid(self.coords,self.shape,self.row,self.ports)
 def test_shape_refusal(self):
  with self.assertRaisesRegex(RuntimeError,'shape'):e.validate_grid(self.coords,(3,221,1,501,3),self.row,self.ports)
 def test_status_refusal(self):
  self.raw.getresult=lambda *a:2
  with self.assertRaisesRegex(RuntimeError,'status'):e.profiles(self.cad,Engine,self.row,self.ports)
 def test_mutation_refusal(self):
  for method in ['run','save','setnamed','switchtolayout']:
   with self.assertRaises(RuntimeError):getattr(self.cad,method)
  with self.assertRaises(RuntimeError):self.cad.eval('sp_x=setnamed("FDTD","x",0);')
 def test_selection_refusal(self):
  old=self.raw.getv;self.raw.getv=lambda k:np.zeros((3,221,3)) if k=='sp_slice' else old(k)
  with self.assertRaisesRegex(RuntimeError,'axis shape'):self.selected(0)
 def test_crop_refusal(self):
  class Bad(Engine):
   @staticmethod
   def _line_from_res(*a):
    x,I,aux=Engine._line_from_res(*a);return x+0.001,I,aux
  with self.assertRaisesRegex(RuntimeError,'crop'):e.profiles(self.cad,Bad,self.row,self.ports)
 def test_hash_refusal(self):
  with patch.object(e.s,'sha',return_value='0'*64), patch.object(e,'ROOT',e.ROOT.resolve()):
   with self.assertRaisesRegex(RuntimeError,'SHA'):e.checkpoint(e.ROOT/'task_00.json',0)
 def test_path_refusal(self):
  with self.assertRaisesRegex(RuntimeError,'path'):e.checkpoint(Path('task_00.json'),0)
 def test_actual_schema_and_termination(self):
  import copy
  root=Path(r'C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007/length_pair_verified_2156')
  for task in [0,1]:
   row=json.loads((root/f'task_{task:02d}.json').read_text());e.validate_checkpoint_schema(row,task)
   bad=copy.deepcopy(row);bad['result']['termination']['physical_time_s']+=1e-12
   with self.assertRaisesRegex(RuntimeError,'completion'):e.validate_checkpoint_schema(bad,task)
   bad=copy.deepcopy(row);bad['identity']['scope']['API_path']='/wrong/lumapi.py'
   with self.assertRaisesRegex(RuntimeError,'API'):e.validate_checkpoint_schema(bad,task)
if __name__=='__main__':unittest.main()
