"""Bounded read-only selective MAT/workbook/mesh evidence inventory."""
from pathlib import Path
import hashlib,json,sys,contextlib,io
import scipy.io as sio
import numpy as np
import openpyxl
sys.path.insert(0,str(Path.cwd()));from sim_helpers import calculate_fwhm_relative
OUT=Path(__file__).parent
keys=['resonance_wavelength_nm','resonance_transmission','spectral_fwhm_nm','fwhm_m','n_periods_each_side','pitch_m','L_device','corrugation_depth_m','field_x','field_energy_density_1D','field_envelope_1D','wl_nm','T','S21_complex']
records=[]
for root in ['results_from_athena/farfield_sph_20um','results_from_athena/te_q3db_20um','results_from_athena/te_span_z_check']:
 for p in sorted(Path(root).rglob('*.mat')):
  d=sio.loadmat(p,variable_names=keys,squeeze_me=True);scalar=lambda k:float(np.asarray(d[k]).squeeze());x=np.asarray(d['field_x']).ravel();env=np.asarray(d['field_envelope_1D']).ravel();lam=scalar('resonance_wavelength_nm');fwhm=scalar('spectral_fwhm_nm');wl=np.asarray(d['wl_nm']).ravel()
  with contextlib.redirect_stdout(io.StringIO()):width=calculate_fwhm_relative(x,env)*1e6
  stat=p.stat();r=dict(path=str(p.resolve()),bytes=stat.st_size,mtime_ns=stat.st_mtime_ns,input_sha256=hashlib.sha256(p.read_bytes()).hexdigest() if stat.st_size<25e6 else None,hash_note='SHA skipped for large field-bearing MAT; selected-variable read only' if stat.st_size>=25e6 else 'SHA measured',N_per_side=int(scalar('n_periods_each_side')),pitch_nm=scalar('pitch_m')*1e9,L_device_um=scalar('L_device')*1e6,corr_nm=scalar('corrugation_depth_m')*1e9,lambda_nm=lam,T_stored=scalar('resonance_transmission'),spectral_FWHM_nm=abs(fwhm),stored_signed_spectral_FWHM_nm=fwhm,Q_loaded_derived=lam/abs(fwhm),spatial_FWHM_saved_um=scalar('fwhm_m')*1e6,spatial_FWHM_from_saved_envelope_um=width,defect_in_window=bool(np.min(wl)<lam<np.max(wl)),approx_samples_per_linewidth=abs(fwhm)/np.median(abs(np.diff(wl))),envelope_end_x_um=[float(x[0]*1e6),float(x[-1]*1e6)],intensity_envelope_end_over_peak=[float(env[0]/np.max(env)),float(env[-1]/np.max(env))],sqrt_intensity_end_over_peak=[float(np.sqrt(max(env[0],0)/np.max(env))),float(np.sqrt(max(env[-1],0)/np.max(env)))],T_array_matches_modal_max_abs_error=float(np.max(abs(np.asarray(d['T']).ravel()-abs(np.asarray(d['S21_complex']).ravel())**2))))
  records.append(r)
book=Path('C:/Users/evyat/OneDrive/Documents/תואר שני/Photonics Research/simulation_stats/mesh_convergence_results.xlsx');w=openpyxl.load_workbook(book,read_only=True,data_only=True);wb=dict(path=str(book),sha256=hashlib.sha256(book.read_bytes()).hexdigest(),rows=[dict(row=i,values=list(row)) for i,row in enumerate(w['Mesh Convergence'].iter_rows(values_only=True),1) if any(v is not None for v in row)])
cp=Path('docs/readiness_evidence_20261007/s2_temporal150_fetch_1434/s2_temporal150_task03_original.json');row=json.loads(cp.read_text());c=row['result']['controls']['before'];mesh={}
for k,v in c['mesh'].items():
 a=np.asarray(v).ravel();dd=np.diff(a);mesh[k]=dict(coordinates=len(a),extent_um=[float(a[0]*1e6),float(a[-1]*1e6)],spacing_min_med_max_nm=[float(np.min(dd)*1e9),float(np.median(dd)*1e9),float(np.max(dd)*1e9)])
report=dict(scope='READ_ONLY_STORED_EVIDENCE_NO_SOLVE',MAT_selective_records=records,workbook=wb,current_S2_mesh=dict(checkpoint=str(cp),sha256=hashlib.sha256(cp.read_bytes()).hexdigest(),axes=mesh,refinement=c['refinement'],dt_s=row['result']['controls']['dt_s']),historical_TE_CMP=[dict(path=str(p),**json.loads(p.read_text())) for p in sorted(Path('results_from_athena/mesh_convergence_te_cmp').glob('array_part_*.json'))])
(OUT/'measured_inventory.json').write_text(json.dumps(report,indent=2)+'\n')
for r in records:print(Path(r['path']).name,'T',round(r['T_stored'],7),'lambda',round(r['lambda_nm'],6),'Q',round(r['Q_loaded_derived'],2),'W',round(r['spatial_FWHM_from_saved_envelope_um'],6),'endI',r['intensity_envelope_end_over_peak'],'samples',round(r['approx_samples_per_linewidth'],1))
