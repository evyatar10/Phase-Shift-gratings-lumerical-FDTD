# Bounded storage snapshot

Measured2026-10-07 16:34 Israel (13:34UTC). One bounded read-only SSH per host, both exit0. No CAD, solver, cleanup, deletion, upload, cancellation or whole-home scan. Existing Athena171390_0/1/2 preserved; this snapshot shows allthree PENDING(Priority),IGUM userqueue empty,shared solve seats0/50 used. Queued A100 triplet commits21 seats when released; current occupancy is not a reservation.

| Location | Used / total or quota | Available/headroom |
|---|---|---|
|Windows C: repo,results,TEMP|923,526,995,968 /1,023,272,808,448bytes|99,745,812,480bytes =92.895527GiB|
|Athena USER quota|234,045,698,048bytes =217.972042GiB /300GiB soft,330GiB hard|88,076,849,152bytes =82.027958GiB belowsoft;112.027958GiB belowhard|
|Athena home/project/results SHARED filesystem|46,139,301,167,104 /54,975,581,388,800bytes|8,836,280,221,696bytes,8.1TiB roundedbydf|
|IGUM research project/results SHARED filesystem|108,211,726,389,248 /135,548,107,034,624bytes|25,964,646,268,928bytes,24TiB roundedbydf|
|IGUM home SHARED filesystem|108,211,730,604,032 /135,548,107,034,624bytes|25,964,639,784,960bytes|

Athena df reports1,409,740,799 free inodes; quota file count114,963 /4,294,967,295soft. IGUM home and research report924,820,705free inodes. Windows filesystem inventory exposes only C:; no second actual output drive was found. Windows user quota was not queried. Filesystem capacity is not user quota.

IGUM standard quota executable is absent (both quota-s and quota-v report FileNotFoundError). No quota value was invented. Lustre-specific user/project quota was not queried in this one-connection scope; that is the remaining allocation limitation. SSH access and all df/queue/sharedlmstat commands succeeded. Athena quota-s,quota-v,all df,queue succeeded. The exact known Athena artifacts were statted individually and every size matches the previously pinned extraction report; nothing was recursively scanned or rehashed remotely.

Measured output sizes from the pinned100/150ps center report, CP+FSP+H5+portNPZ only:
-100ps:806,941,509bytes =0.751523GiB.
-150ps:822,760,419bytes =0.766255GiB (H5 alone796,961,650bytes).
These exclude logs/intermediate files/failed attempts. Longer duration with the same stored501-frequency monitor grid may have similar retained size, but200ps/newN-family storage is not yet measured here.

Planning allowance =2x largest measuredartifact set =1,645,520,838bytes =1.532511GiB perattempt. This explicit margin is an estimate, not an upper bound. Conservatively count full unfinished output even if a partial write is already charged:
-Current three200ps attempts:4,936,562,514bytes =4.597532GiB.
-Currentthree plusone full replacementtriplet:9,873,125,028bytes =9.195064GiB.
-One additional N80 forward adds1.532511GiB; an N80 triplet adds4.597532GiB. These are storage scenarios, not dispatch authorization.

Before a proposed run, reserve outstanding attempts + proposed attempts + explicitly budgeted retained retry attempts at the updated per-family allowance. For example currentthree+one N80 forward+one replacementtriplet =10.727575GiB; currentthree+N80triplet+one replacementtriplet =13.792596GiB. Reconsider the proposal if SOFT quota headroom or filesystem free bytes falls below that reserve; do not treat the hardquota grace as normal headroom. Update the allowance if actual output/intermediate bytes exceed it. Verify inode headroom against the intended retained file count. IGUM userquota must be established before claiming allocation capacity even though df space is large.

Cheap cadence: combine quota/df/queue into existing20-30minute waiting checks (2-3SSH/hour/cluster), plus a fresh pre-dispatch and post-completion/fetch snapshot. No separate tight disk watcher or recursive du is needed. Record errors and wait for the next useful cadence after lost access; do not infer job failure from lost visibility.

Files: storage_evidence.json contains timestamped exact stdout/stderr and per-commandexitcodes; storage_summary.json provides byte conversions; audit_storage.py is reproducible and sends in-memory LF Python over one SSH perhost. It requires --collect and refuses to overwrite storage_evidence.json, so reproduce in a NEW TEMP directory. Both skill procedures and configpaths were read; no repository/skill edits.
