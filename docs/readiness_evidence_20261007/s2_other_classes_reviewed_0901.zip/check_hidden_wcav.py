"""One hidden local CAD wcav dEps API check; no saved field or solver use."""
from pathlib import Path
import sys,json
sys.dont_write_bytecode=True
import numpy as np
import probe_other_classes_h1 as probe
repo=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
sys.path.insert(0,str(repo))
import config
root=Path(__file__).parent/'hidden_wcav'
root.mkdir(exist_ok=False)
config.BASE_SAVE_DIR=str(root/'generated');config.USE_GPU=False
from runners.lumopt2_design import recover_te_s2 as recovery
from runners.lumopt2_design import recover_te_s2_peak as peak
eng,val=recovery.eng,recovery.val
lmpt=eng.import_lumopt2()
import lumapi
from lumopt2.parametrization.d_eps_calculator import DEpsCalculator as DEC
sessions=[];restore=probe.guard.install_constructor_guard(lumapi.FDTD,root,sessions)
report=dict(no_fdtd_solve=True,hidden=True,index=295,label='wcav',step_nm=1.,runner_sha256=probe.guard.sha256(probe.__file__))
try:
    spec=peak.SPEC
    assert (295,'wcav') in probe.selected_parameters(val,spec)
    project,wl=eng.make_project(spec,str(root/'generated'),lmpt)
    project.generate()
    par=project.parametrization;session=project.fdtd_session
    params=val.te_point(spec)
    session.fdtd.switchtolayout();par.update_structure(session,params);session.invalidate_loaded_state()
    column=np.asarray(par.compute_params_to_lumerical_jacobian(params))[:,295]
    deps,shape,wavelength,objects=probe.single_deps(DEC(session,par,directly_on_params=True,use_jac=True),params,295,'wcav',1.,column,par.prop_to_array_map)
    report.update(key=list(deps),shape=np.asarray(shape).ravel().tolist(),wavelength_m=np.asarray(wavelength).ravel().tolist(),objects=objects,
        nonzero={k:int(np.count_nonzero(v['data'])) for k,v in next(iter(deps.values())).items()},mesh_readback=probe.mesh_refinement_readback(session.fdtd))
except Exception as exc:report['error']=type(exc).__name__+': '+str(exc)
finally:
    report['audits']=[s.audit for s in sessions]
    for s in sessions:probe.guard.attempt(s.close)
    restore()
    with (root/'report.json').open('x') as f:json.dump(probe.guard.plain(report),f,indent=2,allow_nan=False)
print(json.dumps({k:v for k,v in report.items() if k!='audits'}))
sys.exit(2 if 'error' in report else 0)
