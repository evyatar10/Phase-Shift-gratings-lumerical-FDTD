"""Explicit staged fixed200ps preparation/release; new source and markers only."""
import base64,hashlib,importlib.util,json,sys
from pathlib import Path
mode=sys.argv[1]
s=importlib.util.spec_from_file_location('ops','C:/Users/evyat/AppData/Local/Temp/s2_step150_ops_1503.py');ops=importlib.util.module_from_spec(s);sys.argv=['readonly','none'];s.loader.exec_module(ops)
REPO=ops.REPO;E=ops.E;BASE=ops.BASE
SOURCE_SHA='fa6a6528e34cb9c004604ec490543c3b0579d76224c936568c2e11e4f9996053'
env=dict(KEEP_H5='1',S2_TEMP200_REPO='/work/project',S2_TEMP200_OUTPUT_ROOT='/work/results/diagnose_te_s2_temporal200/results/s2_shift30_temporal200_20261007',S2_TEMP200_PARENT150_ROOT='/work/results/diagnose_te_s2_temporal/results/s2_shift30_temporal_20261007',S2_TEMP200_PARENT150_MARKER='/work/data/s2_temporal150_review_20261007_1257.json',S2_TEMP200_STEP150_ROOT='/work/results/diagnose_te_s2_step150/results/s2_shift30_step150_20261007',S2_TEMP200_STEP150_MARKER='/work/data/s2_step150_review_20261007_1507.json')
inner="""import json,config
config.LUMAPI_PATH='/opt/lumerical/v261/api/python/lumapi.py';config.BASE_SAVE_DIR='/work/results';config.NEFF_DATA_PATH='/work/data/FDE_sweep_results.mat';config.USE_GPU=True
from runners.lumopt2_design import s2_temporal200_forward as r
def blocked(*a,**k):raise RuntimeError('COLD_VALIDATION_NO_CAD_OR_SOLVE')
r.main=r.forward_only=r.eng.make_project=r.eng.import_lumopt2=blocked
c=r.load_ancestry()
"""
container="""args=['apptainer','exec','--bind',str(b/'project')+':/work/project','--bind',str(b/'results')+':/work/results','--bind',str(b/'data')+':/work/data','--bind','/home/evyatarrubin/scilibs:/scilibs','--pwd','/work/project','/home/evyatarrubin/containers/lumerical-2026R1.sif','env','LD_LIBRARY_PATH=/scilibs']+[k+'='+v for k,v in env.items()]+['/opt/lumerical/v261/python/bin/python','-B','-c',inner]
validation=run(args)
"""
if mode=='prepare':
 raw=(REPO/'runners/lumopt2_design/s2_temporal200_forward.py').read_bytes();assert hashlib.sha256(raw).hexdigest()==SOURCE_SHA
 code=ops.COMMON+f"""
import base64
b=Path({BASE!r});p=b/'project/runners/lumopt2_design/s2_temporal200_forward.py'
assert not p.exists(),'New-only upload; reconcile existing source first'
with p.open('xb') as stream:stream.write(base64.b64decode({base64.b64encode(raw).decode()!r}))
assert hashlib.sha256(p.read_bytes()).hexdigest()=={SOURCE_SHA!r}
env={env!r};inner={inner+"print(json.dumps(r.review_template(r.root_path(),c)))"!r}
"""+container+"print(json.dumps(dict(source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),validation=validation)))\n"
 compile(code,'remote_prepare','exec');result=ops.remote('athena.technion.ac.il',code);ops.save('s2_temporal200_preparation_1619.json',result);assert result['rc']==0,result
 payload=json.loads(result['out']);assert payload['validation']['rc']==0,payload
 template=json.loads(payload['validation']['out']);ops.save('s2_temporal200_review_template_1619.json',template);ops.save('s2_temporal200_environment_1619.json',env)
 print('Exact historical/source/vendor/artifact validation passed; marker remains NOT_REVIEWED')
elif mode=='release':
 m=json.loads((E/'s2_temporal200_review_template_1619.json').read_text(encoding='utf-8'));assert m['status']=='NOT_REVIEWED' and m['allowed_tasks']==[]
 m.update(status='APPROVED_FOR_THREE_FIXED200PS_CENTER_SHIFT30_STEP00625_FORWARDS_ONLY',allowed_tasks=[0,1,2],lead_verdict='Lead reviewed exact150ps triplet and completed171276 step pair, fullspectra/derivatives and strict measuredcurve controls. Temporal and peakheight-step sensitivities remain; release ONLY200ps nominal/shift30 +/-0.0625nm forwards to measure duration dependence. Ten offline tests, parent, realdriver tasklist and keyword coldreuse, all3 hiddenCAD build/reload, independentreview, and exactremote source/vendor/ancestor FSP/H5/log/NPZ checks passed. No arbitrary new tolerance, no coefficient/optimizer/N80/mesh/adjoint release. Latest16:16 bothqueues empty, shared0/50solve seats,3A100 jobs budget21/50,quota230G/300Gsoft; preserve all existing artifacts.')
 raw=(json.dumps(m,indent=2,allow_nan=False)+'\n').encode();digest=hashlib.sha256(raw).hexdigest();marker='/work/data/s2_temporal200_review_20261007_1619.json';tasks='/work/data/s2_temporal200_tasks_20261007_1619.txt'
 with (E/'s2_temporal200_review_original.json').open('xb') as f:f.write(raw)
 env.update(S2_TEMP200_REVIEW_MARKER=marker,S2_TEMP200_REVIEW_SHA256=digest)
 code=ops.COMMON+f"""
import base64
b=Path({BASE!r})
assert hashlib.sha256((b/'project/runners/lumopt2_design/s2_temporal200_forward.py').read_bytes()).hexdigest()=={SOURCE_SHA!r}
assert hashlib.sha256((b/'jobs/run_python_array.sh').read_bytes()).hexdigest()=='ebf1780e1d23f6a5a885577ba6b562111482935b69be63f27389d5ae87bcdcf1'
q=run(['squeue','-u','evyatarrubin','--noheader']);assert q['rc']==0 and not q['out'].strip(),q
for path,data in [({marker!r},base64.b64decode({base64.b64encode(raw).decode()!r})),({tasks!r},b'0\\n1\\n2\\n')]:
 p=b/Path(path).relative_to('/work')
 with p.open('xb') as f:f.write(data)
env={env!r};inner={inner+"print(json.dumps([r.reviewed(t,r.root_path(),c)['sha256'] for t in range(3)]))"!r}
"""+container+f"""
assert validation['rc']==0,validation;assert json.loads(validation['out'])==[{digest!r}]*3
env.update(SWEEP_KIND='lumopt2_design',SWEEP_LIST={tasks!r},SWEEP_SPEC_MODULE='runners.lumopt2_design.s2_temporal200_forward',ATHENA_LICENSE='1055@132.68.48.51',ATHENA_INTERCONNECT='2325@132.68.48.51',REQUIRE_GPU='1',NTFY_TOPIC='')
a=['sbatch','--parsable','--array=0-2%3','--gpus=1','--cpus-per-task=8','--mem=256G','--time=02:00:00','--qos=12h_4g','--partition=a100-public','--mail-type=NONE','--chdir='+str(b/'jobs'),'--export=ALL,'+','.join(k+'='+v for k,v in env.items()),str(b/'jobs/run_python_array.sh')]
test=run(a[:1]+['--test-only']+a[1:]);assert test['rc']==0,test
submission=run(a)
print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),queue=q,validation=validation,test_only=test,submission=submission,args=a,marker_sha256={digest!r},runner_sha256={SOURCE_SHA!r},env=env,planned_shared_solver_seats=21)))
"""
 compile(code,'remote_release','exec');result=ops.remote('athena.technion.ac.il',code);ops.save('s2_temporal200_dispatch_1619.json',result);ops.save('s2_temporal200_environment_released_1619.json',env);assert result['rc']==0,result
 payload=json.loads(result['out']);print(json.dumps(dict(submission=payload['submission'],marker_sha256=digest)));assert payload['submission']['rc']==0,payload
else:raise ValueError('Explicit prepare or release required')
