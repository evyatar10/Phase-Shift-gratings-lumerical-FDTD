"""Offline comparison; exact current peak tracker, fixed isolated candidate fits."""
import sys,json,argparse,hashlib
from pathlib import Path
import numpy as np
from scipy.interpolate import CubicSpline,PchipInterpolator
from scipy.optimize import minimize_scalar
import autograd
from height_estimators import estimate,UnsupportedPeak
sys.dont_write_bytecode=True
NAMES=('peak3','quadratic7','quartic11')
SPEED=-22.6

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def plain(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    if isinstance(x,dict):return {k:plain(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [plain(v) for v in x]
    return x

def tracked_index(eng,wl,y):
    lam,_,_=eng.measure_peak(wl,y)
    return int(np.argmin(np.abs(wl-lam)))

def measured(eng,v3,wl,y,name,index=None):
    i=tracked_index(eng,wl,y) if index is None else index
    if name!='peak3':return estimate(y,i,name)
    fct=lambda values:v3.peak3(values,i)
    jac=np.asarray(autograd.grad(fct)(y))
    support=np.flatnonzero(jac)
    return dict(height=float(fct(y)),jacobian=jac,indices=support,weights=jac[support],
        offset_bins=v3.peak3_r(y,i),jacobian_l2=float(np.linalg.norm(jac)))

def phase_scan(eng,v3,wl,center,kind):
    n=len(center);x=np.arange(n,dtype=float);i=tracked_index(eng,wl,center)
    actual_height=measured(eng,v3,wl,center,'peak3')['height']
    _,_,width=eng.measure_peak(x,center)
    if kind=='lorentzian':
        height=actual_height;gamma=width/2
        shape=lambda z:height/(1+((z-i)/gamma)**2)
        shape_deriv=lambda z:-2*height*(z-i)/(gamma**2*(1+((z-i)/gamma)**2)**2)
        trueheight=height
    else:
        spline=(CubicSpline if kind=='cubic' else PchipInterpolator)(x,center,extrapolate=False)
        shape=spline;shape_deriv=lambda z:spline(z,1)
        # Include knots: bounded minimization alone can miss a PCHIP knot maximum.
        candidates=[float(center[i]),-minimize_scalar(lambda z:-float(spline(z)),bounds=(i-1,i+1),method='bounded',options={'xatol':1e-12}).fun]
        trueheight=max(candidates)
    xx=x[1:-1];ww=wl[1:-1]
    phases=np.linspace(-.4999,.4999,801)
    records={name:dict(height=[],derivative=[],l2=[],rejections=[]) for name in NAMES}
    for phase in phases:
        y=shape(xx-phase);dydp=-SPEED*shape_deriv(xx-phase)
        for name in NAMES:
            try:
                fitted=measured(eng,v3,ww,y,name)
                records[name]['height'].append(fitted['height'])
                records[name]['derivative'].append(float(fitted['jacobian']@dydp))
                records[name]['l2'].append(fitted['jacobian_l2'])
            except UnsupportedPeak as exc:records[name]['rejections'].append(dict(phase=float(phase),reason=str(exc)))
    out={}
    for name,r in records.items():
        h=np.array(r['height']);d=np.array(r['derivative']);l2=np.array(r['l2'])
        out[name]=dict(accepted=len(h),rejected=len(r['rejections']),rejections=r['rejections'],
            known_model_height=trueheight,height_bias_min=float(h.min()-trueheight),height_bias_max=float(h.max()-trueheight),
            height_ripple_range=float(np.ptp(h)),local_derivative_min=float(d.min()),local_derivative_max=float(d.max()),
            local_derivative_rms=float(np.sqrt(np.mean(d*d))),jacobian_l2_range=[float(l2.min()),float(l2.max())])
    for name in NAMES:
        nominal=measured(eng,v3,ww,shape(xx),name)
        out[name]['nominal_local_derivative']=float(nominal['jacobian']@(-SPEED*shape_deriv(xx)))
    return dict(model=kind,fwhm_bins=width,phase_samples=len(phases),parameter_speed_bins_per_nm=SPEED,
        estimators=out,qualification='MODEL_PHASE_AND_DERIVATIVES_NOT_PHYSICAL_OR_NOISE_BOUNDS')

def white_noise(eng,v3,wl,y,sigma=1e-6,draws=2000):
    rng=np.random.default_rng(20261007);i=tracked_index(eng,wl,y)
    baseline={name:measured(eng,v3,wl,y,name,index=i) for name in NAMES}
    changes={name:[] for name in NAMES};rejects={name:0 for name in NAMES}
    for k in range(draws):
        noisy=y+rng.normal(0,sigma,len(y))
        # Perturb only local neighborhoods to preserve nonnegative stopband tails.
        mask=np.abs(np.arange(len(y))-i)>5;noisy[mask]=y[mask]
        for name in NAMES:
            try:changes[name].append(measured(eng,v3,wl,noisy,name,index=i)['height']-baseline[name]['height'])
            except UnsupportedPeak:rejects[name]+=1
    return dict(sigma_per_independent_sample=sigma,draws=draws,seed=20261007,
        nominal_branch_frozen=True,qualification='SYNTHETIC_INDEPENDENT_GAUSSIAN_MODEL_NOT_MEASURED_FDTD_NOISE',
        estimators={name:dict(predicted_local_std=sigma*baseline[name]['jacobian_l2'],
            empirical_std=float(np.std(changes[name],ddof=1)),mean_shift=float(np.mean(changes[name])),rejected=rejects[name]) for name in NAMES})

def spectra(a):return dict(tout=np.abs(a['p2_T_out'].ravel()),modal=np.abs(a['p2_S'].ravel())**2)

def run(repo,out):
    out=Path(out);out.mkdir(exist_ok=False)
    repo=Path(repo);sys.path.insert(0,str(repo))
    from runners.lumopt2_design import lumopt2_design as eng,v3_step as v3
    e=repo/'docs/readiness_evidence_20261007';summary=json.loads((e/'s2_firstwave_measured_1113.json').read_text())
    names=['s2_fdstep_task00_ports.npz']+[f's2_half_classes_task{t:02d}_ports.npz' for t in range(4)]
    data={};wl=None;freq=None
    for name in names:
        if sha(e/name)!=summary['provenance']['observed_files'][name]:raise RuntimeError('Exact NPZ SHA mismatch: '+name)
        with np.load(e/name,allow_pickle=False) as a:
            if wl is None:wl=a['p2_lambda'].ravel()*1e9;freq=a['p2_f'].copy()
            elif not np.array_equal(freq,a['p2_f']) or not np.array_equal(wl,a['p2_lambda'].ravel()*1e9):raise RuntimeError('Full grid mismatch')
            data[name]=spectra(a)
    output=dict(status='TWO_CANDIDATE_OBJECTIVE_DIAGNOSTIC_NO_ADOPTION',source_sha256=sha(__file__),measured_summary_sha256=sha(e/'s2_firstwave_measured_1113.json'),
        estimators_source_sha256=sha(Path(__file__).parent/'height_estimators.py'),
        engine_sha256=sha(repo/'runners/lumopt2_design/lumopt2_design.py'),v3_sha256=sha(repo/'runners/lumopt2_design/v3_step.py'),
        inputs={name:sha(e/name) for name in names},models={},stored_forward_comparisons={},noise_model={})
    center=data[names[0]]
    for observable,y in center.items():
        output['models'][observable]={kind:phase_scan(eng,v3,wl,y,kind) for kind in ('lorentzian','cubic','pchip')}
        output['noise_model'][observable]=white_noise(eng,v3,wl,y)
        byfile={}
        for file,values in data.items():
            byfile[file]={}
            for name in NAMES:
                fitted=measured(eng,v3,wl,values[observable],name)
                byfile[file][name]={k:v for k,v in fitted.items() if k!='jacobian'}
        pairs={}
        for label,ids in [('corr30',(0,1)),('shift30',(2,3))]:
            plus,minus=[f's2_half_classes_task{t:02d}_ports.npz' for t in ids]
            pairs[label]={}
            for name in NAMES:
                a,b,c=(byfile[f][name]['height'] for f in (plus,minus,names[0]))
                pairs[label][name]=dict(halfstep_nm=.5,plus=a,minus=b,center=c,odd=(a-b)/2,even=(a+b)/2-c,central_derivative=a-b)
        output['stored_forward_comparisons'][observable]=dict(rows=byfile,pairs=pairs,
            qualification='ESTIMATOR_DIFFERENCES_AND_FIT_RESIDUALS_NOT_KNOWN_PHYSICAL_BIAS')
    for t in range(4):
        checkpoint=e/f's2_half_classes_task{t:02d}_original.json'
        if sha(checkpoint)!=summary['provenance']['observed_files'][checkpoint.name]:raise RuntimeError('Checkpoint SHA mismatch')
        row=json.loads(checkpoint.read_text())
        filename=f's2_half_classes_task{t:02d}_ports.npz'
        if row['result']['ports_sha256']!=output['inputs'][filename]:raise RuntimeError('Checkpoint/NPZ identity mismatch')
        for observable,key in [('tout','peak3_tout'),('modal','peak3_modal')]:
            value=output['stored_forward_comparisons'][observable]['rows'][filename]['peak3']['height']
            if not np.isclose(value,row['result'][key],rtol=0,atol=1e-12):raise RuntimeError('Stored peak3 score not reproduced')
    output['limitations']=['Candidate selection is detached existing scored Bragg peak; quartic unsupported branches fail closed.','Gradient is with respect to nonnegative scalar spectral samples; raw abs(T) requires the existing absolute-value chain rule.','No interpolant is exact physics; lower phase ripple is not proof of improved physical gradient.','White-noise results are synthetic unit-sample sensitivity, not measured noise or acceptance tolerance.','Original two scalar adjoint contractions cannot be reweighted to obtain candidate gradients.','Stored-field reconstruction would need new7/11-wavelength assembly and source/objective checks; no production integration or calibrated coefficients.']
    with (out/'report.json').open('x') as f:json.dump(plain(output),f,indent=2,allow_nan=False)
    return output

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--output',required=True);a=p.parse_args();r=run(a.repo,a.output)
    print(json.dumps({o:{k:{n:{v:q[v] for v in ('height_ripple_range','height_bias_min','height_bias_max','local_derivative_rms','rejected')} for n,q in model['estimators'].items()} for k,model in models.items()} for o,models in r['models'].items()},indent=2))
