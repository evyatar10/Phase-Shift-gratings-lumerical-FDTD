"""Hidden no-solve property discovery; owns only NEW TEMP files."""
import json,sys,tempfile,time,traceback
from pathlib import Path
sys.dont_write_bytecode=True
REPO=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
sys.path.insert(0,str(REPO))
import numpy as np
from runners.lumopt2_design import s2_shift30_convergence as prior
import no_solve_guard as guard
import config
ROOT=Path(tempfile.mkdtemp(prefix='property_discovery_',dir=Path(__file__).parent))
config.BASE_SAVE_DIR=str(ROOT/'generated');config.LUMAPI_PATH='C:/Program Files/Lumerical/v261/api/python/lumapi.py';config.USE_GPU=False
lmpt=prior.eng.import_lumopt2()
import lumapi
sessions=[];symbol=lumapi.FDTD;restore=guard.install_constructor_guard(symbol,ROOT,sessions)
report=dict(mode='HIDDEN_PROPERTY_DISCOVERY_NO_FDTD',started=time.time())
try:
    project,wl=prior.eng.make_project(prior.SPEC,str(ROOT/'generated'),lmpt)
    project.set_fwd(prior.val.te_point(prior.SPEC));f=project.fdtd_session.fdtd
    fdtdkeys=('simulation time','use early shutoff','auto shutoff min','use divergence checking','auto shutoff max','down sample time','max source time signal length')
    props=('pulse length','offset','frequency','bandwidth','set time domain','set frequency','wavelength start','wavelength stop','optimize for short pulse','source type','phase','enabled')
    def snap():return dict(fdtd={k:guard.attempt(lambda k=k:f.getnamed('FDTD',k)) for k in fdtdkeys},
        sources={obj:{k:guard.attempt(lambda obj=obj,k=k:f.getnamed(obj,k)) for k in props} for obj in ('FDTD::ports','FDTD::ports::Port_1','FDTD::ports::Port_2')},
        global_source={k:guard.attempt(lambda k=k:f.getglobalsource(k)) for k in props})
    report['before']=snap();f.setnamed('FDTD','use early shutoff',0);f.setnamed('FDTD','simulation time',100e-12);report['after100']=snap()
    f.setnamed('FDTD','simulation time',150e-12);report['after150']=snap();report['class_preserved']=lumapi.FDTD is symbol
    report['passed']=True
except Exception as exc:report.update(passed=False,error=repr(exc),traceback=traceback.format_exc())
finally:
    report['audits']=[s.audit for s in sessions]
    for s in sessions:guard.attempt(s.close)
    restore();report['seconds']=time.time()-report['started'];out=ROOT/'property_discovery.json'
    with out.open('x') as stream:json.dump(guard.plain(report),stream,indent=2,allow_nan=False)
    print(out);print('PASS' if report['passed'] else 'FAIL',report.get('error',''))
sys.exit(0 if report['passed'] else 2)
