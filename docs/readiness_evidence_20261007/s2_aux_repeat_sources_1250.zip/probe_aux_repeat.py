"""Read-only original FSP auxiliary repeat/reload probe: no fields/DEps/build/solve."""
import argparse,hashlib,json,re,sys
from pathlib import Path
import numpy as np
sys.dont_write_bytecode=True
import frozen_h1_mechanics as base
import auxiliary_diagnostics as diag
guard=base.guard

class NoFieldCAD(guard.NoSolveCAD):
    def eval(self,script):
        if re.search(r'getdata\s*\([^;\n]*,[\s]*["\'](?:Ex|Ey|Ez|Hx|Hy|Hz)["\']',script,re.I):
            raise RuntimeError('No electric/magnetic spatial field read permitted')
        return super().eval(script)

def collect_repeat(session,fom,entry,label,initial):
    before=diag.state(session)
    session.load_if_needed(entry['fwd_filename'])
    raw=fom._collect_fwd_side_aux(session,entry)
    snap=diag.snapshot(raw,entry['fwd_filename']);f=snap['arrays']['frequency_hz']
    independent=[]
    requests=[('same501_first',f),('same501_second',f),('same_selected5',f[list(diag.UNION)]),('roundtrip_selected5',299792458./(299792458./f[list(diag.UNION)]))]
    for tag,freq in requests:
        powers=np.asarray(session.fdtd.sourcepower(freq)).ravel()
        if powers.shape!=freq.shape or not np.all(np.isfinite(powers)) or np.any(powers<=0):raise RuntimeError('Independent sourcepower read missing/nonfinite/nonpositive')
        baseline=snap['arrays']['sourcepower'] if len(freq)==501 else snap['arrays']['sourcepower'][list(diag.UNION)]
        delta=powers-baseline;spacing=np.abs(np.spacing(baseline));ulps=np.abs(delta)/spacing
        independent.append(dict(tag=tag,frequency_hz=freq.tolist(),sourcepower=powers.tolist(),difference_from_vendor=delta.tolist(),
            max_abs=float(np.max(np.abs(delta))),max_relative=float(np.max(np.abs(delta)/np.abs(baseline))),max_ulp=float(np.max(ulps))))
    return dict(label=label,before=before,after=diag.state(session),snapshot=diag.plain(snap),
        difference_from_initial=diag.plain(diag.difference(initial,snap)) if initial is not None else None,
        independent_sourcepower_calls=independent),snap

def run(args):
    root=Path(args.output_root).resolve()
    if root.exists():raise RuntimeError('Output root must be NEW and exclusive')
    if guard.sha256(base.__file__)!='0be8299d6607388f373876bf16b5f15e3d894220efcd770b9cccedd6f46d526d' or guard.sha256(guard.__file__)!='40dd487831da68080b29813cdbef2e1ce9e6629528dccd3d7c431dfc1229e99d':raise RuntimeError('Frozen helper/guard identity mismatch')
    repo=Path(args.repo).resolve();sys.path.insert(0,str(repo))
    import config
    config.LUMAPI_PATH=args.lumapi;config.USE_GPU=False
    from runners.lumopt2_design import recover_te_s2 as recovery
    evidence_path=Path(args.provenance)
    if guard.sha256(evidence_path)!=args.reviewed_provenance_sha256:raise RuntimeError('Reviewed provenance SHA mismatch')
    evidence=json.loads(evidence_path.read_text())
    if evidence.get('critical_evidence_available') is not True or evidence.get('original_file_identity_unchanged') is not True:raise RuntimeError('Required complete preserved provenance absent')
    failed_path=Path(args.failed_report)
    if guard.sha256(failed_path)!=args.failed_report_sha256:raise RuntimeError('Failed original report SHA mismatch')
    failed=json.loads(failed_path.read_text())
    if failed.get('execution_error')!='RuntimeError: Vendor normalization changed across objective Jacobians' or not failed.get('old_peak3_control') or failed.get('onehot_raw')!=[] or failed.get('original_file_identity_unchanged') is not True:raise RuntimeError('Unexpected failed diagnostic identity/state')
    quad=args.quadrature
    forward=Path(evidence['cases'][quad+'_fwd']['source']);adjoint=Path(evidence['cases'][quad+'_adj']['source'])
    if failed.get('quadrature')!=quad or failed.get('forward')!=str(forward) or failed.get('adjoint')!=str(adjoint) or not np.array_equal(np.asarray(failed.get('params_nm')),np.asarray(evidence['params_nm'])):raise RuntimeError('Failed report/source/quadrature/point binding mismatch')
    folder=Path(recovery.OLD)/('lumopt2_te_s2_cport_im_c_files' if quad=='im' else 'lumopt2_te_s2_cport_fd_c_files')
    if forward.resolve()!=(folder/'fwd_default.fsp').resolve() or adjoint.resolve()!=(folder/'adj_default_Port_2.fsp').resolve() or root.is_relative_to(folder.resolve()):raise RuntimeError('Original source pair/output path mismatch')
    originals=[forward,adjoint]+[p.parent/p.stem/(p.stem+'_output.h5') for p in (forward,adjoint)]
    before=[guard.file_identity(p,p.suffix!='.h5') for p in originals];reviewed={x['path']:x for x in evidence['originals_before']}
    if any(not x['available'] or x['path'] not in reviewed or any(x.get(k)!=reviewed[x['path']].get(k) for k in ('bytes','mtime_ns','sha256')) for x in before):raise RuntimeError('Original FSP/H5 identity mismatch')
    for p in (forward,adjoint):recovery.successful_log(p)
    lmpt=recovery.eng.import_lumopt2()
    import lumapi
    from lumopt2.core.fdtd_session import FdtdSession
    api_root=Path(lumapi.__file__).resolve().parent
    vendor={str(p.relative_to(api_root)):guard.sha256(p) for p in sorted((api_root/'lumopt2').rglob('*.py'))}
    if vendor!=evidence['vendor_sources'] or guard.sha256(lumapi.__file__)!=evidence['lumapi_sha256']:raise RuntimeError('Actual vendor/Lumapi identity mismatch')
    root.mkdir(parents=True,exist_ok=False)
    report=dict(status='READONLY_METADATA_MEASUREMENT_NO_GUARD_RELAXATION',no_fdtd_solve=True,no_spatial_fields=True,no_DEps=True,no_build=True,
        source_sha256=guard.sha256(__file__),provenance_sha256=args.reviewed_provenance_sha256,failed_report_sha256=args.failed_report_sha256,
        quadrature=quad,originals_before=before,prior_selected_snapshot=failed['vendor_forward_normalization'],
        prior_full501_snapshot_available=False,vendor_sources=vendor,captures=[])
    sessions=[];oldguard=guard.NoSolveCAD;guard.NoSolveCAD=NoFieldCAD;restore=guard.install_constructor_guard(lumapi.FDTD,root,sessions)
    try:
        session=FdtdSession(show_fdtd_cad=False)
        wanted=np.asarray(evidence['requested_wavelengths_m'],float)
        sim=lmpt.PortResults('Port_2','transmission',wanted.tolist());fom=lmpt.Fom(sim,fct=recovery.eng.make_fct_peak(wanted*1e9))
        for c in fom.config_map.config_map.values():
            c['fwd_filename']=str(forward)
            for a in c['adjoints']:a['adj_filename']=str(adjoint)
        for info in fom.config_map._sim_result_info.values():info['fwd_filename'],info['adj_filename']=str(forward),str(adjoint)
        entry=fom.config_map.get_filenames_in_order()[0]
        session.load_if_needed(str(forward));fom._get_port_monitor_info(session)
        initial=None
        for label in ('initial_forward','same_forward_repeat','invalidate_reload_forward','adjoint_then_forward_onehot'):
            if label=='invalidate_reload_forward':session.invalidate_loaded_state()
            elif label=='adjoint_then_forward_onehot':
                session.load_if_needed(str(adjoint));report['adjoint_transition_state']=diag.state(session)
                fom.fct=lambda x:x[244]
            jac=np.asarray(fom.get_jacobian(session)).ravel()
            support=np.flatnonzero(jac!=0).tolist()
            expected=[244] if label=='adjoint_then_forward_onehot' else [251,252,253]
            if jac.shape!=(501,) or support!=expected:raise RuntimeError('Exact objective/grid support differs from original')
            record,snap=collect_repeat(session,fom,entry,label,initial)
            record['objective_support']=support;report['captures'].append(record)
            if initial is None:initial=snap
            prior=failed['vendor_forward_normalization']
            record['selected_exactly_equal_to_failed_v1_initial']=snap['selected']==prior
        report['completed_metadata_measurement']=True
    except Exception as exc:report['execution_error']=type(exc).__name__+': '+str(exc)
    finally:
        report['originals_after']=[guard.file_identity(p,p.suffix!='.h5') for p in originals]
        report['originals_unchanged']=before==report['originals_after'];report['CAD_call_audits']=[s.audit for s in sessions]
        for s in sessions:guard.attempt(s.close)
        restore();guard.NoSolveCAD=oldguard
        with (root/'aux_repeat.json').open('x',encoding='utf-8') as f:json.dump(diag.plain(report),f,indent=2,allow_nan=False)
        print(root/'aux_repeat.json')
    return 2 if report.get('execution_error') or not report['originals_unchanged'] else 0

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('repo','lumapi','provenance','reviewed-provenance-sha256','failed-report','failed-report-sha256','output-root'):p.add_argument('--'+k,required=True)
    p.add_argument('--quadrature',choices=('re','im'),default='re');sys.exit(run(p.parse_args()))
