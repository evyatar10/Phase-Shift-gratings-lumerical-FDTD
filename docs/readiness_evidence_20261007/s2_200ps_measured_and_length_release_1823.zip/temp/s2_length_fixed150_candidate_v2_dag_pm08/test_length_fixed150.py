"""Focused offline tests; fake files are NOT new native/CAD/FDTD evidence."""
import ast,copy,dataclasses,importlib.util,json,os,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import s2_length_fixed150 as a
OUT=Path(__file__).parent
REPORT=json.loads((OUT/'frozen_builder_cad_report_original.json').read_text())
class LengthChecks(unittest.TestCase):
 def setUp(self):
  self.root=Path(tempfile.mkdtemp(prefix='SYNTHETIC_TEST_',dir=OUT));self.solve_root=self.root/a.LABEL
  self.paths=dict(root=self.solve_root,repo=Path.cwd(),host=self.root,cp=OUT/'reference_150_center_original.json',profile=OUT/'reference_spatial_inventory_original.json',grid=OUT/'reference_port_grids.json',marker=self.root/'marker.json',api=Path('C:/Program Files/Lumerical/v261/api/python/lumapi.py'))
  self.reference=a.load_reference(self.paths);self.review=dict(path=str(self.paths['marker']),sha256='a'*64,lead_verdict='SYNTHETIC_TEST_NOT_APPROVAL',scope_sha256='b'*64,allowed_tasks=[0,1])
 def case(self,n,directory):
  c=copy.deepcopy(REPORT['cases'][str(n)]);directory.mkdir(parents=True,exist_ok=True);source=directory/'fwd_default.fsp';source.write_bytes(b'SYNTHETIC_NOT_A_CAD_FILE')
  pre=directory/f'N{n}_native_pre_correction.fsp';pre.write_bytes(b'SYNTHETIC_PREPARATORY_NOT_CAD')
  c.update(source=str(source),setup_fsp_sha256=a.sha(source),serialized_native_geometry=c['native_saved_format_construction']['reloaded']);c['native_saved_format_construction'].update(preparatory_fsp=str(pre),sha256=a.sha(pre));return c
 def result(self,task):
  directory=self.solve_root/f'task_{task:02d}_SYNTHETIC';c=self.case(a.TASK_MAP[task],directory);anchor=self.case(98,directory/'fresh_N98_anchor') if task==1 else None
  setup=directory/'prepared_forward_before_solve.fsp';setup.write_bytes(Path(c['source']).read_bytes());c['immutable_setup_fsp']=str(setup)
  source=Path(c['source']);h5=source.with_suffix('')/'fwd_default_output.h5';h5.parent.mkdir();h5.write_bytes(b'SYNTHETIC_NOT_FIELD_DATA')
  ports=directory/'ports.npz';ports.write_bytes(Path('docs/readiness_evidence_20261007/s2_temporal150_fetch_1434/s2_temporal150_task03_ports.npz').read_bytes());log=source.with_name('fwd_default_p0.log');log.write_text('Completed 100 iterations, or 1.5e-10s of Simulation Time\nSimulation completed successfully\n')
  with np.load(ports) as z:arrays={k:z[k] for k in z.files}
  p,spec=a.task_params(task,self.reference)
  result=dict(task=task,physical_N=spec.n_periods_side,duration_ps=150.,params=p.tolist(),source=str(source),h5=str(h5),ports_npz=str(ports),fsp_sha256=a.sha(source),h5_sha256=a.sha(h5),ports_sha256=a.sha(ports),build_case=c,fresh_N98_anchor=anchor,pair_comparison=a.compare_pair(anchor,c) if task==1 else None,termination=a.base.termination(source,150.,c['reloaded']['timing']['dt'],1),resource={'device_type':'GPU','threads':'8'},FDTD_version='SYNTHETIC_NO_SOLVE',parent_review=self.review,vendor_api_sha256=a.base.vendor_sources(),qualification=a.QUALIFICATION,overall_gradient_gate='FAILED_UNCHANGED',**a.recovery.score(arrays))
  coords=self.reference['profile_stage']['raw_profile_coordinate_inventory'];metadata=dict(have_raw_data=True,have_E_result=True,axes={k:copy.deepcopy(coords[k]) for k in ['x_m','y_m','z_m','lambda_m']},E_shape=copy.deepcopy(coords['E_shape']),monitor_configuration=copy.deepcopy(c['reloaded']['field_profile']),readback='COLD_LOADED_NEW_SOLVED_FSP_RESULT_DATASET_COORDINATES_NO_E_TRANSFER',source=str(source),h5=str(h5),fsp_sha256=a.sha(source),h5_sha256=a.sha(h5))
  metadata['axes']['f_Hz']=copy.deepcopy(self.reference['grids']['p2_f']['values']);metadata['metadata_sha256']=a.semantic(metadata);result['profile_metadata']=metadata;return result
 def test_exact2task_specs_points_bounds_native_refusal(self):
  for t,n in [(0,98),(1,80)]:
   p,spec=a.task_params(t,self.reference);self.assertTrue(np.array_equal(p,self.reference['point']));self.assertEqual((spec.n_periods_side,spec.n_free,spec.n_wl_points),(n,60,501));self.assertEqual(len(p),296)
  d0=dataclasses.asdict(a.task_spec(0));d1=dataclasses.asdict(a.task_spec(1));self.assertEqual([k for k in d0 if d0[k]!=d1[k]],['n_periods_side'])
  for task in [True,-1,2,0.,'0']:
   with self.assertRaises(ValueError):a.task_spec(task)
  bad=copy.deepcopy(self.reference);bad['point'][0]=1e8
  with self.assertRaises(RuntimeError):a.task_params(0,bad)
  with patch.object(sys,'platform','win32'),patch.object(a.eng,'import_lumopt2',side_effect=AssertionError('CAD forbidden')):
   with self.assertRaisesRegex(RuntimeError,'native IGUM'):a.native_paths()
 def test_frozen_builder_functions_identical_and_ordering(self):
  old=ast.parse((OUT/'frozen_builder_v6_original.py').read_text());new=ast.parse(Path(a.build.__file__).read_text());olddefs={n.name:n for n in old.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};newdefs={n.name:n for n in new.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
  for name,node in newdefs.items():self.assertEqual(ast.dump(node,include_attributes=False),ast.dump(olddefs[name],include_attributes=False))
  self.assertNotIn('main',newdefs);self.assertNotIn('self_test',newdefs)
  source=Path(a.__file__).read_text();self.assertLess(source.index('f.save(pre);f.load(pre)'),source.index('build.restore_retained_outer_and_feed_joins(f'))
  self.assertNotIn('project.set_fwd',source);self.assertNotIn('PortFom',source);self.assertIn("f.run('FDTD','GPU')",source)
  self.assertEqual(a.sha(OUT/'frozen_builder_v6_original.py'),a.BUILDER_ORIGINAL_SHA)
 def test_actual_reference_bytes_and_metadata_only_failures(self):
  self.assertEqual(self.reference['access_policy'],a.ref.ACCESS_POLICY);a.ref.validate(self.reference['checkpoint'],json.loads(self.paths['profile'].read_text()))
  bad=self.root/'modified_cp.json';bad.write_bytes(self.paths['cp'].read_bytes()+b' ')
  with self.assertRaises(RuntimeError):a.ref.load(bad,self.paths['profile'],self.paths['grid'])
  with self.assertRaises(FileNotFoundError):a.ref.load(self.root/'missing.json',self.paths['profile'],self.paths['grid'])
  profile=json.loads(self.paths['profile'].read_text());profile['inputs']['150'][0]['sha256']='b'*64
  with self.assertRaises(RuntimeError):a.ref.validate(self.reference['checkpoint'],profile)
  cp=copy.deepcopy(self.reference['checkpoint']);cp['result']['controls']['persisted']['timing']['use divergence checking']=0
  with self.assertRaises(RuntimeError):a.ref.validate(cp,json.loads(self.paths['profile'].read_text()))
 def test_explicit_marker_missing_wrong_scope_source_and_notreviewed(self):
  with patch.dict(os.environ,{},clear=True):
   with self.assertRaises(RuntimeError):a.reviewed(0,self.paths,self.reference)
  marker=a.scope(self.paths,self.reference);marker.update(status=a.APPROVAL_STATUS,lead_verdict='SYNTHETIC_EXPLICIT_NO_HARDWARE_APPROVAL')
  for change in [None,('duration_ps',200.),('task_map',[98,70]),('platform','ATHENA'),('reference',{}),('code',{}),('vendor_api_sha256',{}),('allowed_tasks',[0]),('lead_verdict','NOT_REVIEWED')]:
   m=copy.deepcopy(marker)
   if change:m[change[0]]=change[1]
   self.paths['marker'].write_text(json.dumps(m))
   with patch.dict(os.environ,{'S2_LEN_REVIEW_SHA256':a.sha(self.paths['marker'])}):
    if change:
     with self.assertRaises(RuntimeError):a.reviewed(0,self.paths,self.reference)
    else:self.assertEqual(a.reviewed(0,self.paths,self.reference)['allowed_tasks'],[0,1])
  self.assertEqual(a.review_template(self.paths,self.reference)['allowed_tasks'],[])
 def test_actual_frozen_pair_validation_and_material_controls_fail(self):
  cases=[]
  for n in [98,80]:
   c=self.case(n,self.root/f'case{n}');a.validate_case(c,self.reference,n);cases.append(c)
  a.compare_pair(*cases)
  bad=copy.deepcopy(cases[1]);bad['reloaded']['ports']['FDTD::ports::Port_1']['x']+=1e-9
  with self.assertRaises(RuntimeError):a.compare_pair(cases[0],bad)
  bad=copy.deepcopy(cases[1]);bad['reloaded']['all_teeth_and_feeds']['L_narrow_61']['x']+=1e-9
  with self.assertRaises(RuntimeError):a.compare_pair(cases[0],bad)
  bad=copy.deepcopy(cases[1]);bad['outer_geometry_restoration']['reloaded_endpoint_delta_m']['left']=1e-12
  with self.assertRaises(RuntimeError):a.validate_case(bad,self.reference,80)
 def test_cold_resume_no_CAD_immutable_artifacts_and_incompatible_CP(self):
  for task in [0,1]:
   r=self.result(task);a.verify_result(r,task,self.paths,self.reference,self.review);ident=a.identity(task,self.paths,self.reference,self.review);cp=self.solve_root/f'task_{task:02d}.json';a.recovery.checkpoint(cp,ident,r)
   with patch.object(a,'native_paths',return_value=self.paths),patch.object(a,'reviewed',return_value=self.review),patch.object(a,'forward_only',side_effect=AssertionError('solve forbidden')),patch.object(a,'build_case',side_effect=AssertionError('CAD forbidden')):
    self.assertEqual(a.main(task),r)
   bad=copy.deepcopy(r);bad['peak3_tout']+=1e-4
   with self.assertRaises(RuntimeError):a.verify_result(bad,task,self.paths,self.reference,self.review)
   with self.assertRaises(FileExistsError):a.recovery.checkpoint(cp,ident,r)
  bad=copy.deepcopy(ident);bad['duration_ps']=200.
  with self.assertRaises(RuntimeError):a.recovery.read_checkpoint(cp,bad)
  Path(r['build_case']['immutable_setup_fsp']).write_bytes(b'TAMPERED')
  with self.assertRaises(RuntimeError):a.verify_result(r,1,self.paths,self.reference,self.review)
 def test_buildonly_import_tasklist_guards_and_no_fallthrough(self):
  source=Path(a.__file__).read_text();tree=ast.parse(source);self.assertNotIn('run_adjoint',source);self.assertNotIn('compute_gradient',source)
  node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='build_only');calls={n.func.attr for n in ast.walk(node) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)};self.assertFalse(calls & {'run','runjobs','run_forward','main','forward_only'})
  with patch.object(a,'build_case',side_effect=AssertionError('CAD forbidden')):
   with self.assertRaises(RuntimeError):a.build_only(self.paths,self.root)
  with patch.object(a.eng,'import_lumopt2',side_effect=AssertionError('CAD import forbidden')):
   s=importlib.util.spec_from_file_location('offline_import',a.__file__);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
  proc=subprocess.run([sys.executable,'-B',a.__file__,'--tasklist'],capture_output=True,text=True);self.assertEqual(proc.returncode,0,proc.stderr);self.assertEqual(json.loads(proc.stdout)['N_TASKS'],2)
 def test_separate_buildonly_entry_does_not_request_solve_approval(self):
  import s2_length_native_buildonly as entry
  output=self.root/'NEW_BUILD_ONLY';report={'status':'SYNTHETIC_GUARDED_NO_SOLVE'}
  with patch.object(a,'native_paths',return_value=self.paths) as path_call,patch.object(a,'envpath',return_value=output),patch.object(a,'build_only',return_value=report) as build_call,patch.object(a,'reviewed',side_effect=AssertionError('No solve review required')),patch.object(a,'main',side_effect=AssertionError('FDTD entry forbidden')),patch.object(a,'forward_only',side_effect=AssertionError('FDTD entry forbidden')):
   self.assertEqual(entry.main(0),report);path_call.assert_called_once_with(for_review=False);build_call.assert_called_once_with(self.paths,output)
   for value in [True,-1,1,'0']:
    with self.assertRaises(ValueError):entry.main(value)
  tree=ast.parse(Path(entry.__file__).read_text());calls={n.func.attr for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)}
  self.assertFalse(calls & {'run','runjobs','forward_only','main','run_forward','run_adjoint','make_project','import_lumopt2'})
 def test_profile_coordinate_only_readback_and_missing_tamper_failclosed(self):
  coords=self.reference['profile_stage']['raw_profile_coordinate_inventory'];cfg=REPORT['cases']['98']['reloaded']['field_profile'];variables={f'sf_meta_{axis}':np.asarray(coords[axis+'_m']) for axis in ['x','y','z']};variables.update(sf_meta_f=np.asarray(self.reference['grids']['p2_f']['values']),sf_meta_lambda=np.asarray(coords['lambda_m']),sf_meta_shape=np.asarray(coords['E_shape']))
  class Fake:
   def __init__(self):self.calls=[]
   def havedata(self,*args):return 1
   def haveresult(self,*args):return 1
   def eval(self,script):self.calls.append(script)
   def getv(self,name):self.calls.append(name);return variables[name]
   def getnamed(self,obj,key):return cfg[key]
  f=Fake();m=a.profile_metadata(f,self.reference);self.assertEqual(m['E_shape'],[2008,39,1,501,3]);self.assertEqual(len(m['axes']['f_Hz']),501)
  self.assertTrue(all(name!='sf_meta_result' for name in f.calls));self.assertIn('size(sf_meta_result.E)',f.calls[0])
  with patch.object(f,'haveresult',return_value=0),patch.object(f,'eval',side_effect=AssertionError('No missing E read')):
   with self.assertRaises(RuntimeError):a.profile_metadata(f,self.reference)
  for mutate in [lambda x:x.update(have_raw_data=False),lambda x:x['axes']['f_Hz'].__setitem__(0,np.nextafter(x['axes']['f_Hz'][0],np.inf)),lambda x:x['axes']['lambda_m'].__setitem__(0,np.nextafter(x['axes']['lambda_m'][0],np.inf)),lambda x:x.update(E_shape=[39,2008,1,501,3]),lambda x:x['monitor_configuration'].update(enabled=0)]:
   bad=copy.deepcopy(m);mutate(bad)
   with self.assertRaises(RuntimeError):a.validate_profile_metadata(bad,self.reference)
  result=self.result(0);result['profile_metadata']['h5_sha256']='b'*64
  with self.assertRaises(RuntimeError):a.verify_result(result,0,self.paths,self.reference,self.review)
 def test_preserved_feed_properties_and_outer_endpoint_rejected(self):
  left=self.case(98,self.root/'feed98');right=self.case(80,self.root/'feed80');a.compare_pair(left,right)
  for key,value in [('y',1e-9),('y span',1.1e-6),('z',1e-9),('z span',1e-6),('material','SYNTHETIC_OTHER_MATERIAL'),('index',9.),('x',1e-6)]:
   bad=copy.deepcopy(right);bad['reloaded']['all_teeth_and_feeds']['wg_left_feed'][key]=value
   with self.assertRaises(RuntimeError):a.compare_pair(left,bad)
if __name__=='__main__':unittest.main(verbosity=2)
