# Existing termination evidence, 2026-10-07

The nine logs do **not** distinguish finite-time DFT effects from geometry/PVA
response. They establish that these runs ended at the auto-shutoff event, not
the 2000ps simulation-time cap. Calibration remains FAILED. No new run, runner,
source edit or scientific approval was made in this review.

Every log says `Early termination ... autoshutoff criteria are satisfied` and
successful completion. Source paths match their saved checkpoint exactly.
All report A100 execution with `real32`. The last reported `Auto Shutoff`
statistic is 9.92611e-8..9.99643e-8, consistent with the source default1e-7.
That statistic is not a measured coherent port-DFT tail or a spectral error
bound. No time-resolved phase/tail integral is present in these log tails.

| Geometry/task | Actual time(ps) | Last auto statistic | GPU run(s) |
|---|---:|---:|---:|
| exact repeated center | 67.39992 | 9.94436e-8 | 1367.685406 |
| corr30 +.5 | 67.39992 | 9.96808e-8 | 1368.547188 |
| corr30 -.5 | 67.39992 | 9.98635e-8 | 1368.969752 |
| shift30 +.5 | 67.76375 | 9.92611e-8 | 1373.462058 |
| shift30 -.5 | 67.91198 | 9.98035e-8 | 1377.421917 |
| shift30 +.125 | 67.94567 | 9.96026e-8 | 1379.089562 |
| shift30 -.125 | 67.61552 | 9.99643e-8 | 1370.072767 |
| shift30 +.0625 | 68.01979 | 9.94382e-8 | 1382.061894 |
| shift30 -.0625 | 68.34320 | 9.96321e-8 | 1386.656595 |

These are only3.3700..3.4172% of the source-default2000ps cap. The largest
time difference among these runs is0.94328ps. GPU runtime ranges1367.7..1386.7s;
wall runtime ranges1841.2..2008.9s and includes differing initialization time.
Wall/GPU duration is a cost measurement, not a physical convergence metric.
Historical h2 termination logs are not in this nine-run file; no claim about
their stopping times is made.

The association worth testing is quantitative. For shift30 h=.5,.125,.0625,
Tplus-Tminus is respectively -.14823,+.33015,-.32341ps, whereas Tout moving
peak derivatives are -2.703278e-4,+6.685871e-4,-1.763296e-3 pernm. Their signs
agree in these three pairs, but both time and peak are affected by the changed
geometry. This is not causal evidence. Mean endpoint time exceeds the nominal
time by .437945,.380675,.781575ps; Tout peak even terms are respectively
2.800482e-4,2.454618e-4,5.018230e-4. No error bar follows from these numbers.

The new Tout odd numerators are +8.357338e-5 and -1.102060e-4. The even term
grows by2.0444x when h is halved from.125 to.0625; the derivative changes sign.
Fixed-center exact peak3 projections also change sign: +8.107731e-4 to
-1.579754e-3 pernm. Thus moving peak selection alone is insufficient to explain
the observed instability. This still does not identify its numerical source.
Tout peak indices are249/255 and250/253 (nominal252); modal indices247/253 and
249/251 (nominal250). These steps still move across sampling bins.

At fixed bins244/260, Tout FD derivatives change .3685982→.3727911 and
-.3791297→-.3842663, i.e.1.1375% and1.3548%. Modal changes are1.2798% and
1.2297%. This contrast is compatible with a stable large line-translation
signal on the flanks plus a much smaller, unresolved peak-height signal; it
does not bound solver error, prove temporal truncation or prove PVA artifacts.

Finite-time hypothesis: port spectra accumulated only to each geometry's
different ~68ps stop may retain a geometry-dependent coherent tail. A small
global final auto statistic alone cannot quantify the missing coherent DFT
contribution. Geometry/PVA hypothesis: discrete material averaging and peak
response may generate small non-smooth or finite-step height changes while
large flank responses remain similar. The source/mesh evidence and stable
dEps contractions already reviewed do not, by themselves, exclude that
forward-response possibility. Both hypotheses remain open; no new audit of
their implementation is implied by this log review.

Minimum useful temporal intervention: keep the exact nominal center and
shift30 +/-0.0625nm geometries, PVA settings/refinement, mesh coordinates,
source pulse, port frequency grid, precision and hardware class unchanged.
Evaluate that triplet at a common fixed100ps window, then the same triplet at
a common fixed150ps window (six forward solves, staged three plus three).
Use a supported control that prevents early shutdown before each target,
and verify the actual elapsed physical time and termination reason. Raising
the existing2000ps cap alone would not change the observed auto-shutoff stop.
Passing zero through the existing builder is also not an off switch:
bragg_device.py:426 maps falsey values to None and :772 uses `or 1e-7`.
The parent must separately validate any new temporal control before dispatch.

For each fixed duration retain full-grid Tout, complex modal S, moving peak3,
peak indices, odd/even terms against the center of that same duration, fixed
bins244/260 and the exact center-Jacobian projections. Also report changes
versus the existing unequal-duration endpoints. Do not mix the ~67.4ps center
with extended-duration endpoints to judge physical even terms.

One extended triplet can detect sensitivity to the changed temporal window;
two common durations are the minimum here to separate an observed extension
effect from an assertion of temporal stability for odd and even observables.
If endpoint peak changes or odd-numerator changes are comparable to the
existing ~1e-4 signal, temporal sensitivity is material. If100→150ps changes
are small, that only limits sensitivity across those two tested windows; it
does not certify convergence to infinite time or diagnose PVA. An absolute
review tolerance should be chosen before interpreting a derivative that
crosses zero. A new adjoint comparison would eventually need fields computed
under the same reviewed temporal controls; current stored-field contractions
cannot be silently treated as derivatives of the extended-time objective.

Observed median GPU cost is20.292s per simulatedps. A simple linear estimate
is~34 and51 GPU minutes per100/150ps solve, plus initialization. This is a
rough planning estimate, not a runtime guarantee or a request to launch.

`termination_and_spectral_data.json` retains exact parsed rows, input wrapper
hashes, checkpoint byte hashes, parent-recorded full-log hashes, pair data and
fixed-flank values. The downloaded wrapper contains tails plus full-log hash
metadata; the full original log bytes were not available here to independently
recompute those full-log hashes. Parsing checked all nine checkpoint source
bindings, explicit early-termination messages and successful completions.
