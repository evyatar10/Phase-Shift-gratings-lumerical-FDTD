import copy,io,json,sys,tempfile,unittest
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
import compare_profiles as c
REPO=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');EV=REPO/'docs/readiness_evidence_20261007'
sys.path.insert(0,str(REPO))
from runners.lumopt2_design import lumopt2_design as eng


def fixture(duration):
    cp=EV/('s2_temporal100_task00_original.json' if duration==100 else 's2_temporal150_fetch_1434/s2_temporal150_task03_original.json')
    pp=EV/('s2_temporal100_task00_ports.npz' if duration==100 else 's2_temporal150_fetch_1434/s2_temporal150_task03_ports.npz')
    row=c.json_pin(cp,c.CP_SHA[duration]);ports=c.npz(pp.read_bytes());wl=ports['p2_lambda'].ravel()
    x=np.linspace(-50,50,4001);xm=x*1e-6;y=np.asarray([-1.,0.,1.])*1e-6;wy=np.asarray([.5,1.,.5])*1e-6
    arrays={'monitor_lambda_m':wl};profiles={};nearby={};peaks=[]
    def put(prefix,k,target):
        sigma=(5. if duration==100 else 6.)+.01*(k-250)
        full=.005+np.exp(-x*x/(2*sigma*sigma));canonical,keep,envelope=c.crop_stats(eng,xm,full,98*491.06/1000)
        v=dict(x_um=xm[keep]*1e6,I_y_integrated=full[keep],envelope_y_integrated=envelope,y_m=y,wy_m=wy,monitor_x_m=xm,monitor_I_y_integrated=full)
        for key,value in v.items():arrays[prefix+'__'+key]=value
        return dict(production_FWHM_um=canonical['FWHM_um'],sigma_um=canonical['sigma_um'],crop_half_extent_um=98*491.06/1000,original_monitor_frequency_index=k,monitor_sampled_lambda_nm=float(wl[k]*1e9),target_port_sampled_resonance_nm=float(target))
    for name,curve in [('Tout',abs(ports['p2_T_out'].ravel())),('modal',abs(ports['p2_S'].ravel())**2)]:
        lam,_,_=eng.measure_peak(wl*1e9,curve);k=int(np.argmin(abs(wl-lam*1e-9)));peaks.append(k);profiles[name]=put(name,k,lam)
    for k in sorted({p+offset for p in peaks for offset in range(-3,4)}):nearby[str(k)]=put('nearby_bin_'+str(k),k,wl[k]*1e9)
    inputs=[dict(path=str(cp),sha256=c.CP_SHA[duration],bytes=cp.stat().st_size,mtime_ns=0)]
    for role,digest in [('source','fsp_sha256'),('h5','h5_sha256'),('ports_npz','ports_sha256')]:inputs.append(dict(path=row['result'][role],sha256=row['result'][digest],bytes=1,mtime_ns=0))
    stage=dict(duration_ps=duration,profiles=profiles,nearby_profiles=nearby,monitor_geometry={'enabled':{'value':1}},raw_profile_coordinate_inventory=dict(x_m=xm.tolist(),y_m=y.tolist(),lambda_m=wl.tolist()))
    report=dict(status='SAVED_RAW_PROFILE_EXTRACTION_COMPLETE_NO_PHYSICS_PASS',no_solve=True,all_inputs_preserved=True,FDTD_class_unchanged=True,FDTD_constructor_unchanged=True,inputs={str(duration):inputs},immutable_inputs_rechecked=[dict(before=p,after=p.copy(),unchanged=True) for p in inputs],stages={str(duration):stage})
    return report,row,arrays,ports


class Tests(unittest.TestCase):
    def test_analytic_Gaussian_FWHM_sigma_and_supplemental_crop(self):
        x=np.linspace(-50,50,4001);I=np.exp(-x*x/50)
        s,_=c.stats(eng,x,I)
        self.assertAlmostEqual(s['FWHM_um'],2*np.sqrt(2*np.log(2))*5,delta=2e-5)
        self.assertAlmostEqual(s['sigma_um'],5.,places=10)
        raw=I+.1;wide,_,_=c.crop_stats(eng,x*1e-6,raw,48.12388);short,_,_=c.crop_stats(eng,x*1e-6,raw,39.2848)
        self.assertGreater(wide['sigma_um'],short['sigma_um'])
        self.assertAlmostEqual(wide['FWHM_um'],short['FWHM_um'],places=10)
    def test_complete_both_profiles_and_Wlambda_tables_recompute(self):
        stages={};grids={}
        for duration in (100,150):
            report,row,a,p=fixture(duration);stages[duration],grids[duration]=c.stage(report,duration,row,a,p,eng)
        result=c.combine(stages,grids)
        self.assertGreater(result['changes_150_minus_100']['Tout']['FWHM_um'],2.)
        self.assertTrue(result['same_bin_W_lambda_changes'])
        self.assertIn('no physical N80',result['qualification'][1])
    def test_noncomplete_or_nonpreserved_or_wrongCP_refuses(self):
        report,row,a,p=fixture(100)
        for key,value in [('status','EXTRACTION_FAILED_CLOSED'),('no_solve',False),('all_inputs_preserved',False)]:
            bad=copy.deepcopy(report);bad[key]=value
            with self.assertRaises(ValueError):c.stage(bad,100,row,a,p,eng)
        bad=copy.deepcopy(report);bad['inputs']['100'][0]['sha256']='0'*64
        with self.assertRaises(ValueError):c.stage(bad,100,row,a,p,eng)
    def test_raw_grid_anchor_and_intensity_binding_tamper_refuses(self):
        report,row,a,p=fixture(100)
        bad={k:v.copy() for k,v in a.items()};bad['monitor_lambda_m'][252]+=1e-18
        with self.assertRaises(ValueError):c.stage(report,100,row,bad,p,eng)
        bad={k:v.copy() for k,v in a.items()};bad['Tout__I_y_integrated'][0]+=.01
        with self.assertRaises(ValueError):c.stage(report,100,row,bad,p,eng)
        bad=copy.deepcopy(report);bad['stages']['100']['profiles']['Tout']['original_monitor_frequency_index']+=1
        with self.assertRaises(ValueError):c.stage(bad,100,row,a,p,eng)
    def test_nearby_table_and_between_duration_spatial_grid_refuse(self):
        report,row,a,p=fixture(100);bad=copy.deepcopy(report);bad['stages']['100']['nearby_profiles'].pop(next(iter(bad['stages']['100']['nearby_profiles'])))
        with self.assertRaises(ValueError):c.stage(bad,100,row,a,p,eng)
        s,g=c.stage(report,100,row,a,p,eng);other=copy.deepcopy(g);other['Tout']['monitor_x_m'][0]+=1e-18
        with self.assertRaises(ValueError):c.combine({100:s,150:s},{100:g,150:other})
    def test_mat_roundtrip_original_arrays_units_tables_and_no_raw_E(self):
        from scipy.io import loadmat
        stages={};grids={};stored={}
        for duration in (100,150):
            report,row,a,p=fixture(duration);stages[duration],grids[duration]=c.stage(report,duration,row,a,p,eng);stored[duration]=a
        result=c.combine(stages,grids);result['fixture_only_NOT_ACTUAL_PROFILES']=True
        # Unexpected raw E input must never be exported.
        stored[100]['E']=np.ones((2,2,3),complex)
        folder=Path(tempfile.mkdtemp(prefix='mat_roundtrip_',dir=Path(__file__).parent));path=folder/'processed.mat'
        metadata=c.mat_export(path,result,stored,eng);read=loadmat(path,simplify_cells=True)
        for d in (100,150):
            for key in ('Tout__monitor_x_m','Tout__monitor_I_y_integrated','modal__x_um','modal__envelope_y_integrated'):
                self.assertTrue(np.array_equal(read['profiles'+str(d)][key].ravel(),stored[d][key].ravel()))
        self.assertNotIn('E',read['profiles100']);self.assertEqual(json.loads(read['metadata_json'])['units']['x_um'],'um')
        self.assertTrue(np.array_equal(read['profiles100']['Tout__monitor_envelope_y_integrated'].ravel(),eng.extract_envelope_peaks(stored[100]['Tout__monitor_x_m'].ravel()*1e6,stored[100]['Tout__monitor_I_y_integrated'].ravel())))
        crop_x=read['profiles100']['Tout__N80_measurement_crop__x_um'].ravel()
        self.assertTrue((abs(crop_x)<=80*491.06/1000).all())
        self.assertEqual(json.loads(read['metadata_json'])['units']['monitor_x_m'],'m')
        self.assertEqual(read['W_lambda150'].shape[1],9)
        self.assertEqual(json.loads(read['report_json'])['status'],'OFFLINE_PROFILE_COMPARISON_ONLY_NO_PHYSICS_PASS')
        self.assertTrue(metadata['no_raw_E'])
        with self.assertRaises(ValueError):c.mat_export(path,result,stored,eng)
    def test_supplied_hash_mismatch_refuses(self):
        path=EV/'s2_temporal100_task00_original.json'
        with self.assertRaises(ValueError):c.pinned(path,'0'*64)


if __name__=='__main__':unittest.main(verbosity=2)
