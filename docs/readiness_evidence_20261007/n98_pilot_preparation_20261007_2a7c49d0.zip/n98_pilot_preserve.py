"""Persist offline preparation and its small guard-test evidence."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

HERE=Path(__file__).resolve().parent
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
BOOTSTRAP=Path('C:/Users/evyat/AppData/Local/Temp/te_modal_guard_candidate_20261007_52ed8b9e/run_gate.py')
EVIDENCE=ROOT/'docs/readiness_evidence_20261007'
sys.path.insert(0,str(HERE))
import n98_pilot_packet as packet
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

# The requested bootstrap has already imported the pinned isolated engine.
# Provisional coefficients serve offline geometry derivation only and are
# removed from the packet; no calibration approval is manufactured.
description=packet.describe_spec((1.,0.))
description['spec']['adj_fix_re']=None
description['spec']['adj_fix_im']=None
description['port_calibration_coefficients']=None
description['port_calibration_status']='Unset: only exact reviewed peak3 checkpoint may supply coefficients'
description['code']['n98_pilot_packet.py']=sha(HERE/'n98_pilot_packet.py')
packet_path=EVIDENCE/'n98_pilot_spec_20261007_2a7c49d0.json'
record_path=EVIDENCE/'n98_pilot_gate_results_20261007_2a7c49d0.json'
archive_path=EVIDENCE/'n98_pilot_preparation_20261007_2a7c49d0.zip'
for target in (packet_path,record_path,archive_path):
    if target.exists():
        raise RuntimeError('Refusing to replace existing preparation artifact: '+str(target))
packet_path.write_text(json.dumps(description,indent=2),encoding='utf8')
command=[sys.executable,'-X','utf8',str(BOOTSTRAP),str(HERE/'n98_pilot_tests.py')]
run=subprocess.run(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                   encoding='utf8',timeout=60)
log=HERE/'n98_pilot_tests.log';log.write_text(run.stdout,encoding='utf8')
record=dict(date_utc=datetime.now(timezone.utc).isoformat(),status='PREPARATION_ONLY',
    command=command,exit_code=run.returncode,test_count=6,log=str(log),
    bootstrap_sha256=sha(BOOTSTRAP),
    files={str(p):sha(p) for p in (HERE/'n98_pilot_packet.py',HERE/'n98_pilot_tests.py',packet_path)},
    candidate_engine_sha256=packet.CANDIDATE_ENGINE_SHA256,
    max_restarts=0,CAD=False,FDTD=False,server_actions=False)
record_path.write_text(json.dumps(record,indent=2),encoding='utf8')
if run.returncode!=0:
    raise RuntimeError(run.stdout)
with zipfile.ZipFile(archive_path,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for source in (HERE/'n98_pilot_packet.py',HERE/'n98_pilot_tests.py',
                   HERE/'n98_pilot_preserve.py',packet_path,record_path,log):
        z.write(source,source.name)
with zipfile.ZipFile(archive_path) as z:
    assert z.testzip() is None
print(json.dumps(dict(spec=str(packet_path),gates=str(record_path),
    archive=str(archive_path),archive_sha256=sha(archive_path),exit_code=run.returncode,
    packet_sha256=sha(HERE/'n98_pilot_packet.py'),
    seed_sha256=hashlib.sha256(json.dumps(description['seed_nm'],separators=(',',':')).encode()).hexdigest()),indent=2))
