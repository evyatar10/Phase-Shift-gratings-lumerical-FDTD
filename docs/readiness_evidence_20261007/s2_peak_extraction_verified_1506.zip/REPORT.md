# Peak extraction sensitivity on pinned 100/150 ps triplets

Status: diagnostic only; calibration FAILED unchanged. Same shift30 +/-0.0625nm spectra and exact 501-point grids. Existing peak3 and own-center-J results reproduced exactly from pinned NPZs and the reviewed report.

Observer: interpolating cubic spline (SciPy not-a-knot), actual frequency coordinate, no extrapolation. Each observable uses its100 ps nominal peak as a fixed window center for all six spectra. Primary radius 25 samples; radii 20/30 check window dependence. Every spectrum has one interior maximum exceeding both endpoints. This observer is not a proposed replacement objective.

Central moving-maximum derivatives, per nm:

| Observable | Duration | Existing peak3 | Spline | Spline minus peak3 |
|---|---:|---:|---:|---:|
| Tout |100 ps| -2.083311538330079e-4 | -2.229789214256428e-4 | -1.464776759263486e-5 |
| Tout |150 ps| -1.538146888400149e-4 | -1.386637251625800e-4 | +1.515096367743496e-5 |
| modal |100 ps| -3.165705232062166e-4 | -3.295277941850472e-4 | -1.295727097883059e-5 |
| modal |150 ps| -1.636991240543395e-4 | -1.778746734455439e-4 | -1.417554939120436e-5 |

The derivative method changes are 4.1â€“9.9%. Individual endpoint height corrections reach 8.31e-6, but their +/-difference is 1.62â€“1.89e-6, versus odd numerators 1.92â€“3.96e-5. The differential correction, rather than either individual correction, changes centralFD. These effects matter for the small height differences but are smaller than150 ps peak3 movingFD-minus-ownJ gaps: Tout 2.94568e-4/nm and modal -4.97295e-4/nm. Method shifts are approximately 5.1%/2.85% of those gap magnitudes. Comparing spline movingFD with the peak3 Jacobian is not a consistent adjoint test for a spline objective.

No sampled-winner change occurs between100 and150 ps: Tout indices(center,+,-)=(252,250,253), modal=(250,249,252). Continuous spline maxima translate across different grid cells, without a competing local maximum. The150 ps modal-minus maximum lies at 251.504409, near a sampling-cell boundary; this records extraction sensitivity, not a diagnosed physical branch or error bound.

Window 20/25/30 derivative range is 1.78e-15/nm for every case. This is stability within these windows, not an interpolation error or noise bound.

The estimated Tout100â†’150 derivative change is+5.45165e-5/nm using peak3 versus+8.43152e-5/nm using spline; extraction choice changes that temporal difference substantially. Modal change is+1.52871e-4 versus+1.51653e-4/nm. Small even terms are also observer-sensitive: modal100 changes from -1.58083e-6 to +1.32262e-6; other even values are retained in JSON.

Synthetic control: a smooth analytically translating Lorentzian with exact constant maximum 1.01 and true peak-height derivative 0, sampled with 1.4-cell +/-translation. Existing peak3 gives -4.85754e-6/nm, spline -5.93369e-7/nm, fixed nominal peak3J spectral FD -5.69511e-5/nm. Reflection-symmetric sampling gives zero peak3 movingFD. This establishes that finite-step extraction/grid phase can create a moving-height signal or a movingFD-versus-fixedJ difference even for a smooth line. It does not estimate the actual-device bias, asymptotic order, noise floor or cause.

All three offline test groups pass; actual pinned-data execution exits 0. No convergence, scientific approval, calibration coefficient or causal conclusion is generated.
