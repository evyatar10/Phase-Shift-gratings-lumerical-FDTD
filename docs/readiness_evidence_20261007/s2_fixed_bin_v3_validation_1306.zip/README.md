# Saved-field fixed-bin shift30 V3 — frozen preparation packet

Upload together only: probe_fixed_bin_shift30_v3.py, auxiliary_diagnostics_v3.py,
frozen_h1_mechanics.py, no_solve_guard.py. These runtime files are frozen. V1,
its failed report, metadata-only probe and production are unchanged. Parent alone
reviews/preflights/dispatches Re128G/8CPU/45min; Im follows only after Re review.
No CAD, network, dispatch, solve or calibration fit occurred during this preparation.

## Evidence motivating the arithmetic reuse check

171210 metadata-only probe completed47s, exit0, originals preserved. Raw report
s2_aux_repeat_original.json SHA5b1d25ec720134e870cde30ad981cffdff48d110a7e435822f23f63407a627fa.
Same-forward repeat was bitwise equal across all501auxiliary samples. Invalidate/
reload changed457complex amplitudes by at most9.2363e-16relative, with6real/8imagULPs;
frequencies and source powers remained exactly equal across all501samples. V1initial
selected amplitude comparison differed at most7.4764e-16relative. Its exact offending
snapshot was not retained, so this does not identify that discarded offender.
Selected5 versus501sourcepower query differences near1ULP are recorded separately;
V3 compares the actual501vendor calls and gives powers no tolerance.

## Exact policy

All501samples must be finite. Source string, all frequencies and all source powers
must match exactly. Complex mode-amplitude reuse is permitted only when

    abs(new-old) <= 32 * float64_eps * max(abs(old),abs(new))

at every sample. float64_eps=2.220446049250313e-16. No absolute floor exists;
zeros must match exactly. This is explicitly an arithmetic reload/reuse check,
not a physical gradient/calibration gate, measured-noise bound or tolerance for
objective acceptance. Meaningful1e-10phase/amplitude changes remain rejected.

No vendor data are corrected, canonicalized or mutated. The original auxiliary
object is returned unchanged. Full501initial/current snapshots, loaded-state
tracker/CAD source-port availability, raw differences/ULPs and arithmetic-check
results are retained even when the reload check passes. A rejection retains the
full offending snapshot before raising. Forward state is explicitly loaded before
vendor collection and checked by the session tracker; original vendor normalization
and phase remain unchanged. This is not independent proof from that tracker alone.

## Retained diagnostic/control behavior

Only shift30index149 at original recovered point; one1nm central mesher dEps with
full nominal restoration. Cache only union[244,251,252,253,260] finite E slices per
identity-checked original FSP. Exact501grid/order, old Tout peak252 and peak3 support
251..253 are required. Source metadata comparisons remain direction-aware;
unsupported properties are explicit; required finite a/b/N/sourcepower/E fail closed.
Uncorrected mode-power algebra never substitutes for Ansys reported Tout/modal.

Old peak3 h1raw shift30 control must reproduce the immutable original six-vector
reference at unchanged arithmetic rtol1e-12/atol1e-14 before one-hot244/252/260
outputs. FSP/H5/vendor/spec/point guards, copied mechanics/guard hashes and production
preservation checks remain unchanged. Onehots are raw vendor Re/Im quadratures,
not certified physical Tout or modal derivatives. Failed calibration remains failed.
No frequency-dependent/global fit or new objective is included.

Same CLI as V1, with the new filename and a new exclusive output root. Original
provenance SHA a742c0d0921620a04d7e186a9baf7a1959d9752a40c7729815825265fe8c5c47;
original saved-gradient task00forRe/task01forIm. Output fixed_bin_shift30.json uses
exclusive creation; exit2 for runtime/identity/control/reuse failure. Pending real
stored-field evidence is complete V3Re report/control/onehots/preservation and review.

## Tests

Ten focused tests and AST syntax checks pass, exit0. Parent independently reran them.
Logs/commands and unchanged runtime hashes are in offline_tests.log/VALIDATION.json.
Tests include actual captured all501reload acceptance; exact source/frequency/power
rejection (including1ULP off-support changes);1e-10complex phase/amplitude rejection;
zero/no-floor boundary; unchanged returned vendor objects; retained rejected snapshots;
actual vendor normalization/cache one-hot math; old controls; missing/nonfinite data;
identity/grid/direction/no-solve/no-overwrite gates. No full13 rerun needed.

Memory/runtime are not newly measured: selected raw Python fields~0.483GiB plus
summed field and CAD/index/sparse allocations; full-component CAD pinch transient
~8.06GiB remains. Cache avoids repeated E transfers but forward/adjoint file reloads
still occur across objectives. Parent's conservative128G CPU request is retained.
