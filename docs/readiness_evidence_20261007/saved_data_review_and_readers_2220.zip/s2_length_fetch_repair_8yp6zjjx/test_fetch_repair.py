import importlib.util, tempfile, types, sys, unittest, hashlib
from pathlib import Path
p=Path(__file__).with_name('fetch_length_native.py');sp=importlib.util.spec_from_file_location('fetch',p);h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
NAMES=['diagnose_te_s2_fdstep.py','lumopt2_design.py','recover_te_s2.py','validate_te.py','campaign_te_s2.py','bragg_device.py','simulation_config.py','sim_helpers.py','v3_step.py','s2_shift30_convergence.py','config.py','s2_fdhalf_classes.py']
EXTRA=['s2_temporal_forward.py','s2_length_fixed150.py','s2_length_fixed_domain_build.py','s2_length_no_solve_guard.py','s2_length_reference_checks.py']
class Test(unittest.TestCase):
 def setUp(self):
  self.old=list(sys.meta_path);self.d=tempfile.TemporaryDirectory();self.repo=Path(self.d.name);self.folder=self.repo/'runners/lumopt2_design';self.folder.mkdir(parents=True);self.expected={}
  for name in NAMES+EXTRA:
   path=self.folder/name;path.write_text(name);self.expected[name]=h.digest(path.read_bytes())
  prior=types.SimpleNamespace(dependency_hashes=lambda: (_ for _ in ()).throw(AssertionError('eager builder import')))
  base=types.SimpleNamespace(prior=prior);base.code=lambda:{**prior.dependency_hashes(),'s2_temporal_forward.py':self.expected['s2_temporal_forward.py']}
  self.lane=types.SimpleNamespace(__file__=str(self.folder/'s2_length_fixed150.py'),base=base)
  self.lane.code=lambda:{**base.code(),**{n:self.expected[n] for n in EXTRA if n!='s2_temporal_forward.py'}}
 def tearDown(self):sys.meta_path[:]=self.old;self.d.cleanup()
 def test_nested_map_and_guard(self):
  original=self.lane.code;h.install_metadata_code(self.lane,self.repo,self.expected)
  self.assertIs(self.lane.code,original);self.assertEqual(self.lane.code(),self.expected);self.assertEqual(self.lane.base.code(),{n:self.expected[n] for n in NAMES+['s2_temporal_forward.py']})
  for name in ['lumapi','bragg_device','lumopt2.core.fdtd_session','lumslurm']:
   with self.assertRaisesRegex(RuntimeError,'FORBIDS_CAD_IMPORT'):sys.meta_path[0].find_spec(name)
 def test_changed_source(self):
  h.install_metadata_code(self.lane,self.repo,self.expected);(self.folder/'bragg_device.py').write_text('changed')
  with self.assertRaisesRegex(RuntimeError,'Changed released source'):self.lane.base.code()
 def test_bad_imported_lane(self):
  self.lane.__file__=str(self.repo/'wrong.py')
  with self.assertRaisesRegex(RuntimeError,'Imported lane source'):h.install_metadata_code(self.lane,self.repo,self.expected)
 def test_ambiguous_source(self):
  (self.repo/'config.py').write_text('duplicate')
  with self.assertRaisesRegex(RuntimeError,'ambiguous'):h.install_metadata_code(self.lane,self.repo,self.expected)
if __name__=='__main__':unittest.main()
