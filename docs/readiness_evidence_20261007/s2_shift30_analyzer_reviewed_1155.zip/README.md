# Offline shift30 four-step analyzer

Preparation only for Athena171162. No network, CAD, FDTD, optimizer, fit,
approval-marker creation or automatic scientific verdict. All writes are new
exclusive outputs in paths chosen by the caller. Python bytecode writes are
disabled. Repository and prior TEMP packages are read-only.

Run `python -B test_shift_steps.py` here. Ten focused tests pass with retained
`fixture_SYNTHETIC_*` directories. The new ladder spectra in those fixtures
are synthetic amplitude changes with independent complex modal phases. They
are not measured171162 results. Existing firstwave and h2 inputs are the actual
preserved, pinned bytes. Tests exercise the whole analyzer, independent byte
pins, semantic task/sign/index/step/full-point/spec/source/review checks even
after deliberate re-pinning, grid changes after updating both hashes, score
reproduction, local dependency tampering in a TEMP mirror, missing inputs,
explicitly unavailable historical data, analytic parity/Jacobian/wavelength
calculations, and refusal to overwrite outputs.

The package includes the unchanged tested `firstwave_helpers.py` and
`numerical_helpers.py`. It imports frozen recovery scoring solely for offline
arithmetic and validates all twelve current dependency source hashes against
the exact shift30 marker before scoring. Historical h2 identities keep their
separate export/FD creator roles; current source equality is not imposed on
those old identities.

Required local evidence, all in `--evidence-dir`:

- Original exact center and corr30 half-pair: s2_fdstep_task00..02_original.json
  and s2_fdstep_task00..02_ports.npz.
- Actual firstwave: s2_half_classes_task00..03_original.json and matching NPZs,
  s2_half_classes_first_review_original.json.
- s2_shift30_review_original.json, SHA256
  50ef62531e338f57b5cbc78d05905a2cd5d805297407a4ba0913cedf3a5404df.
- NEW actual artifacts: s2_shift30_task00..03_original.json and
  s2_shift30_task00..03_ports.npz, original checkpoint bytes. Override the
  basename prefix with `--new-prefix` if the parent uses another fetch name.

Retain the existing pins file unchanged:
`docs/readiness_evidence_20261007/firstwave_analysis/actual_existing_pins.json`,
SHA256 cff7165a1cc6e7c4aae9024b6ce3dda8d1c9d62dfc007040bd0deaf6f14c7581.
It also refers to the preserved h2 port archive and separately pinned task09/10
JSONs. If explicitly omitted or no longer accessible, the historical comparison
is labeled unavailable. Present historical data with wrong hashes fails.
Required new artifacts always fail if missing.

After the parent fetches and independently verifies the four completed tasks,
create a NEW pin file from `new_artifact_pins_TEMPLATE.json`, filling all eight
checkpoint/NPZ SHA256s from that verification. Record its exact SHA separately.
Do not use newly computed local hashes of unverified replacements as authority.
This is an artifact manifest, never a scientific approval. The template has
invalid placeholders and cannot produce a measured report.

The exact deployed marker path is pinned to
`/work/data/s2_shift30_review_20261007_1142.json`, read from dispatch receipt
s2_shift30_dispatch_1143.json. Runner SHA256:
7f0500a8a037961a3d72e3aa5d58ae2cd52ebbab2a8505f5395097adfac5c857.
Task0/1 change only index149 by +/-0.125nm; task2/3 by +/-0.0625nm.
Nominal checkpoint metadata remains index29, sign0. Complete numerical specs
must equal that exact center except diagnostic label.

Exact command (substitute actual parent-verified new pin filename and SHA,
and NEW output filenames):

```powershell
python -B C:/Users/evyat/AppData/Local/Temp/s2_shift30_analyzer_e125c232ed434191b386d27c8044a3db/analyze_shift_steps.py `
  --repo C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes `
  --evidence-dir C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007 `
  --pins C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007/firstwave_analysis/actual_existing_pins.json `
  --pins-sha256 cff7165a1cc6e7c4aae9024b6ce3dda8d1c9d62dfc007040bd0deaf6f14c7581 `
  --new-pins NEW_parent_verified_artifact_pins.json --new-pins-sha256 EXACT_RECORDED_SHA `
  --output NEW_shift30_review.json --spectra-output NEW_shift30_full_grid.json
```

Compact output compares moving peak3 Tout/modal at h2,.5,.125,.0625: odd/even
and second differences, exact nominal peak3-Jacobian spectral-FD projections,
peak indices, sampled wavelengths and the index-parabola vertex converted via
the validated uniform frequency grid. Scalar parity and projections are
retained against both old and repeated exact nominal centers with explicit
provenance. Saved recovery scores must reproduce to1e-12; this is arithmetic
verification, not a physical tolerance. All four frequency/wavelength grids
must exactly equal the nominal arrays.

The full-grid output includes both observables, all501 samples: plus/minus,
odd, spectral central derivative, even versus each center, both nominal
spectra, their difference, and the exact grids. These arrays support later
per-frequency comparisons without re-extracting fields. They are not the
unavailable full-spectral adjoint Jacobian.

Every report retains `DIAGNOSTIC_ONLY_CALIBRATION_FAILED_UNCHANGED` and
`no_automatic_approval=true`. Successive step differences do not establish
convergence order or a noise bound. Finite-step moving-peak versus fixed-center
projection differences do not prove nondifferentiability. Old/repeated center
differences are observed values, not a statistical bound. This tool does not
re-open remote FSP/H5 or infer server completion; those checks stay with the
parent's verified retrieval.
