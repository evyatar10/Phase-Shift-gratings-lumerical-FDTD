# S1 accepted-candidate replay assessment — planning only

**Do not dispatch yet; independently recompute recovered profiles first.** The
parent has now found and fetched24 small profiles/eval JSONLs with matched
remote/local hashes. A new solve should follow only if that read-only recovery
leaves a concrete physics question. Scene/timing parity and single-forward cost
remain unbounded. S2 temporal/gradient remains critical; an idle GPU is no gate.

## Exact candidate, without another optimization

- Source: results_from_athena/campaign_te_s1/lumopt2_te_s1_v3_evals.jsonl,
  line8 of8, restarted eval3, t1791301856.8761804
  (2026-10-06T15:50:56.876180+00:00).
- JSONL SHA367d943b744bd61feb57195a8c8d706cec66274050b706dc43a7e44b5b7ebb3f.
- params:296 finite nm values; SHA of little-endian float64 bytes
  66e7c00468886c448467ee8432d878eb36ac2451bf2d508608b1dea707be1dd8.
- Exactly equals `lumopt2_te_s1_v3_grads_it003.npz` arrayp and the existing
  te_saved_results_audit.json best_params_nm. Archive SHA
  aa99468889acac27c234cd22c52d5339f1ab2b9da583ef907ddd70fe0786a345.
- Existing audit already established best-eligible selection/bounds. Optstate
  has n_acc7/n_rej1/ineligible[]; eval number alone is not the row identity.
- Logged modal peak0.9527603093, Tout objective0.9085966310,
  lambda1561.0439896nm, spectral FWHM1.00723576nm, spatial FWHM19.38500619um.
  These are stored scalars, not independently re-extracted final-candidate data.
- Spatial band18.73858..19.50342um is satisfied. Width exceeds19.121um anchor
  by0.264006um/1.3807%; this does not meet a strict no-width-increase goal.

## Numerics and provenance that are available

S1 campaign module SHA07c5b058bac7abf774d230c70ee2e736329fb3b128ef6d1289b05765f60bc1c1
still matches the existing audit. SPEC_V3 gives TE,N98/free60,bare, pitch500nm,
bulk corr250nm/mean800nm,h350nm,n1.97/1.444, PVA, dx50nm, region yhalf1050nm,
box_y6.8um/box_z_mult4.14, scan1560.936nm/span10nm/501 frequency-uniform points.
Outer38 periods per side remain bulk;181 of296 slots affect the bare scene.
main resolves WG anchors18.738/19.121 and fitted port/field factors; those
gradient factors are not required to establish a forward transmission value.

The last row records twin lambda1561.003986nm (lagging the reported peak),
softw_adj19.072258um and width-proxy residual0.052445um. A replay of raw spatial
FWHM must use the broadband production profile at its own selected resonance;
matching or changing the lagged twin is a separate surrogate/gradient question.
Source default2000ps/auto1e-7 is known from the builder, not measured S1-final
termination. Actual source pulse, refinement integer, dt and stop time are absent.
The audit recorded engine8f093505...295e5; current engine53108bbd...52569 differs.
That audit source hash is not a proven creation fingerprint for the final FSP.
Known optimizer/selector fixes do not by themselves establish historical parity.

Initial local data had scalars/projections/state/gradient vectors/design figures,
with no raw final ports/fullE/FSP/H5/log. The new recovered campaign profiles
contain x_um(1960),I(1960),lam_pk_nm, but no parameter vector. Recompute envelope
FWHM independently and join the unique wavelength/row carefully; filename/eval
alone cannot establish the full candidate identity or recheck the y-integration.
The JSONL does not name immutable profile/source paths or a full resolved spec.
Recovered s1_v3_toy_ports.npz is a different point (toy-final objective0.8897724,
modal0.9346100), not evidence for the final66e7 candidate. The S1 anchor H5 was
reported missing in the recovery record; a copied FSP alone did not yield ports.

## Parent inventory discovery and remaining exact targets

Athena base B=/home/evyatarrubin/bragg_sim_athena.
Final campaign C=B/results/campaign_te_s1/results/lumopt2_te_s1_v3/:
- C/lumopt2_te_s1_v3_files/fwd_default.fsp and its companion
  C/lumopt2_te_s1_v3_files/fwd_default/fwd_default_output.h5;
- C/lumopt2_te_s1_v3_files/fwd_default_p0.log;
- C/profiles/lumopt2_te_s1_v3_ev0003.npz and ev0000..0002.npz now exist/fetched.
  Legacy ev numbers restart and profiles may overwrite. Names alone cannot
  associate these with line8: match full scene/vector/time before extraction.
- Existing state/projection/gradient files in C and deployment-log candidate
  B/jobs/logs/lum_array-170253_0.out (launcher-pattern inference; confirm actual).

Original calibration root V=B/results/validate_te/results/validate_te_s1/:
- V/lumopt2_te_s1_cport_fd_files/ and V/lumopt2_te_s1_cport_im_files/:
  inspect fwd_default.fsp, adj_default_Port_2.fsp, matching H5 and p0 logs;
  list FD-leg files rather than assuming unstripped solved results survive.
- V/lumopt2_te_s1_cfield_fd_files/ and V/lumopt2_te_s1_cfield_im_files/:
  list original forward/twin/tile adjoint files/H5/logs; do not invent tile names.
- V/lumopt2_te_s1_anchor_files/fwd_default.fsp and companion/log (old missing-H5
  observation must be rechecked, not treated as a fresh inventory).
- Toy root B/results/validate_te/results/validate_te_s1_v3/ with
  lumopt2_te_s1_v3_toy_files/fwd_default.fsp/H5/log, already used for toy ports.
Parent inventory found campaign fwd_default.fsp(10,084,175bytes), its directory
and p0log(3,923bytes), plus port/field adjoint files/logs. A companion directory
does not yet establish H5 presence/completion or association with66e7. All six
original calibration stdout logs168581_4/168582_5/168641_6/168642_7/170201_16/17
are locally fetched with hashes. Inventory at TEMP/te_original_remote_inventory_q8_9_zk0;
new profiles/evals in its profiles_recovery/, original byte pins in pins.json.
Parent owns additional reads; this worker made no server call or duplicate fetch.

## Preconditions and minimum useful outputs

First independently process recovered anchor/toy/campaign1D profiles; preserve
their pins and state the missing parameter/fullE identity limit. Then bind any
surviving final raw scene to66e7 via723 mapped geometry values,
exact spec/source/ports/mesh coordinates/refinement, success/stop logs and H5.
If intact raw data exist, independent extraction may answer the question without
a new solve. If parity cannot be recovered, explicitly label a future run a
current-numerics remeasurement of saved geometry, not an exact historical replay.
Before that run: preserve all old files, freeze the full vector/resolved spec/API
and scene readbacks, validate hidden CAD/save-reload and raw extraction, estimate
profile/port storage and solver runtime, then fresh licenses/quota/queue preflight.

Minimum one forward, no adjoints/optimizer: both ports' full expansions
(complexS,a/b,N,P,Tin/Tout and grids), explicit sourcepower/normalization data,
and full-component broadband field_profile with x/y/lambda at the selected
resonance. Retain raw FSP+H5+log and immutable outputs. Compute spatial width by
sum|Ex/Ey/Ez|², integrate overy, crop to ±98*500nm, then the canonical envelope
half-height convention. A port-only S2 temporal clone omitting that profile is
insufficient. Record modal/Tout sampled+peak3 peaks separately, spectral FWHM,
spatial FWHM, profile wavelength, stop/status/energy/dt and GPU wall/threads.

Use recovered original timing for a parity replay. A chosen common100/150ps
window would instead be a deliberate temporal control; do not transfer S2's
convergence or stopping-time response to S1. No S1-final single-forward timing
log has been parsed locally. Calibration stdout shows S1 forward+adjoint3726s
including a license-seat retry, not a final-candidate one-forward bound.
Accepted-row intervals~2.35..2.56h contain complete
optimizer/adjoint work and are not one-forward costs. S2's100ps35:45..35:51 is
only a different-scene/window/recording analogy, not a meaningful S1 bound.

A fresh replay can check present-solver transmission, resonance and spatial
width for this candidate and expose source/time sensitivity. It cannot prove
global/S2 gradient calibration, corrected-optimizer behavior, convergence,
no-width-increase, conformal/fabrication performance or model-derived intrinsicQ.
No calibration replay, new runner, CAD, server action or dispatch was done here.
