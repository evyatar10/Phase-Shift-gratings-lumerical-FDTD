"""Pinned same-spectra peak-extraction diagnostic; never changes objective."""
import argparse,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
import scipy
from scipy.interpolate import CubicSpline
import firstwave_helpers as f
h=f.h
PINS_SHA={'100':'94b062900bd3765dd4a3ef78543dd6998378720ed429264e5aa7833339d5e919','150':'4fbe923b0fb770b19670946773edc5f892b0efedd07d821a3fee2a750793670b'}
REFERENCE_SHA='929527d24122050acc41878b9e80b36d21550b2392de317120e93ac534352e8a'
SPECTRA_SHA='b7bf52bf22561880c0238be4adee6a23913954ac2883298b57d62293068576a0'
ENGINE_SHA='53108bbd368dd699179ab65029628aa4c4b2d8ad687777f88b82f404a0952569'
STEP=.0625
WINDOW_RADII=(20,25,30)
def spline_peak(u,y,k,radius):
    u=np.asarray(u,float);y=np.asarray(y,float)
    h.require(u.ndim==y.ndim==1 and u.shape==y.shape and np.isfinite(u).all() and np.isfinite(y).all() and np.all(np.diff(u)>0),'Invalid interpolation axes/spectrum')
    left,right=k-radius,k+radius;h.require(0<=left<k<right<len(u),'Fixed window escapes sampled grid')
    spline=CubicSpline(u[left:right+1],y[left:right+1],bc_type='not-a-knot',extrapolate=False)
    roots=spline.derivative().roots(extrapolate=False)
    maxima=[float(v) for v in roots if np.isfinite(v) and u[left]<v<u[right] and float(spline(v,2))<0]
    h.require(bool(maxima),'No interior maximum in fixed resonance window')
    position=max(maxima,key=lambda v:float(spline(v)));height=float(spline(position))
    h.require(height>max(float(y[left]),float(y[right])),'Window boundary dominates interpolated maximum')
    index=float(np.interp(position,u,np.arange(len(u),dtype=float)))
    return dict(height=height,frequency_grid_coordinate=position,continuous_sample_index=index,
        nearest_sample_index=int(np.rint(index)),distance_to_nearest_cell_boundary_samples=float(.5-abs(index-np.rint(index))),
        interior_maxima_count=len(maxima),candidate_maxima_coordinates=maxima,fixed_window_indices=[left,right],
        second_derivative=float(spline(position,2)),boundary_heights=[float(y[left]),float(y[right])])
def synthetic():
    x=np.arange(-50.,51.);center=.217;gamma=26.;shift=1.4
    line=lambda c:.01+1/(1+((x-c)/gamma)**2)
    c,p,m=[line(q) for q in (center,center+shift,center-shift)]
    q0=h.peak3(c);qp=h.peak3(p);qm=h.peak3(m);sp=[spline_peak(x,y,50,25) for y in (c,p,m)]
    d3=(qp[1]-qm[1])/(2*STEP);ds=(sp[1]['height']-sp[2]['height'])/(2*STEP)
    spectral=(p-m)/(2*STEP);projection=float(q0[2]@spectral[q0[0]-1:q0[0]+2])
    h.require(abs(d3)>1e-6 and abs(ds)<abs(d3) and all(abs(v['height']-1.01)<2e-7 for v in sp),'Analytic translating-line control did not resolve expected interpolation behavior')
    symmetric=[line(q) for q in (0.,shift,-shift)];symmetric_fd=(h.peak3(symmetric[1])[1]-h.peak3(symmetric[2])[1])/(2*STEP)
    h.require(abs(symmetric_fd)<1e-12,'Symmetric translating line has unexpected odd extraction bias')
    return dict(model='Analytic Lorentzian + .01 baseline; true maximum1.01 for every center',true_height_gradient=0.,
        nominal_fractional_grid_center=center,gamma_samples=gamma,translation_plus_minus_samples=shift,parameter_half_step_nm=STEP,
        peak3_moving_FD=d3,spline_moving_FD=ds,nominal_peak3_J_spectral_FD=projection,
        peak3_plus_minus_bias=[qp[1]-1.01,qm[1]-1.01],spline_plus_minus_bias=[sp[1]['height']-1.01,sp[2]['height']-1.01],
        symmetric_center_peak3_FD=symmetric_fd,scope='Illustrative synthetic line, not an inferred actual lineshape, error bound or cause')
def analyze(evidence,repo):
    reference,_=h.load_json(evidence/'s2_temporal150_review_1442.json',REFERENCE_SHA)
    full,_=h.load_json(evidence/'s2_temporal150_spectra_1442.json',SPECTRA_SHA)
    h.require(reference['status']=='DIAGNOSTIC_ONLY_CALIBRATION_FAILED_UNCHANGED' and reference['no_automatic_approval'],'Wrong reviewed data family/status')
    sys.path.insert(0,str(repo));from runners.lumopt2_design import recover_te_s2 as recovery
    h.require(f.sha(recovery.eng.__file__)==ENGINE_SHA,'Frozen engine arithmetic changed')
    triplets={};identity={};baseline=None
    for duration in ('100','150'):
        folder=evidence if duration=='100' else evidence/'s2_temporal150_fetch_1434'
        pins,_=h.load_json(folder/f's2_temporal{duration}_artifact_pins_original.json',PINS_SHA[duration]);tasks=range(3) if duration=='100' else range(3,6)
        arrays=[]
        for task in tasks:
            cp,port=pins[f'{task}:checkpoint'],pins[f'{task}:ports'];row,cp_sha=h.load_json(cp['local'],cp['sha256'])
            raw=Path(port['local']).read_bytes();h.require(h.sha(raw)==port['sha256'] and len(raw)==port['bytes'],'Pinned NPZ transport differs')
            i,z=row['identity'],row['result'];rpin=reference['provenance']['new_artifacts'][str(task)]
            h.require(cp_sha==rpin['checkpoint_sha256'] and port['sha256']==rpin['ports_sha256']==z['ports_sha256'] and
                i['task']==z['task']==task and i['duration_ps']==z['duration_ps']==float(duration),'Reviewed checkpoint/task/NPZ family mismatch')
            a=h.load_npz(raw);baseline=a if baseline is None else baseline;h.check_grid(a,baseline,501);f.verify_scores(row,a,recovery.score)
            arrays.append(a);identity[str(task)]=dict(checkpoint_sha256=cp_sha,NPZ_sha256=port['sha256'],port_path=port['path'])
        triplets[duration]=arrays
    freq=baseline['p2_f'].ravel();df=np.diff(freq)
    h.require(np.all(df>0) and np.allclose(df,df[0],rtol=1e-9,atol=0),'Expected exact501 uniform-frequency grid')
    u=(freq-freq[0])/df[0]
    report=dict(schema=1,status='EXTRACTION_DIAGNOSTIC_ONLY_CALIBRATION_FAILED_UNCHANGED',no_objective_change=True,
        source_data=dict(pins_SHA256=PINS_SHA,reference_SHA256=REFERENCE_SHA,full_spectra_SHA256=SPECTRA_SHA,original_bytes=identity),
        method=dict(interpolator='scipy CubicSpline',SciPy_version=scipy.__version__,bc_type='not-a-knot',extrapolate=False,
            coordinate='Normalized actual frequency; no wavelength-grid approximation',fixed_window_radii_samples=list(WINDOW_RADII),
            fixed_window_center='Each metric own100ps nominal sampled peak; same window for every100/150 center/plus/minus',
            selection='Largest interior local maximum; require it exceed both window endpoints; record all maxima'),
        observables={},synthetic_control=synthetic(),limitations=['Diagnostic observer is not a replacement FOM or calibrated gradient.',
            'Interpolants pass through the same samples and do not establish true continuous peak height or its error bound.',
            'Method differences, window stability and synthetic controls infer no numerical noise floor, convergence order or physical cause.',
            'Comparison to original peak3-J projection is a magnitude diagnostic, not an adjoint test for the spline objective.'])
    for metric,transform in h.METRICS.items():
        k=reference['observables'][metric]['triplets']['100']['center_peak_index'];data={}
        for duration,arrays in triplets.items():
            curves=[transform(a) for a in arrays];select=lambda y:f.selected_peak(y,baseline['p2_lambda'],recovery.eng)
            r,derivative=f.pair_report(curves[1],curves[2],curves[0],STEP,select);saved=reference['observables'][metric]['triplets'][duration]
            h.require(all(r[key]==saved[key] for key in ('plus_peak3','minus_peak3','center_peak3','central_derivative','even','exact_center_peak3_jacobian_projection')),'Existing peak3/J arithmetic not reproduced')
            for role,curve in zip(('center','plus','minus'),curves):h.require(np.array_equal(curve,np.asarray(full['observables'][metric][duration][role])),'NPZ and reviewed full spectral arrays differ')
            windows={}
            for radius in WINDOW_RADII:
                peaks={role:spline_peak(u,curve,k,radius) for role,curve in zip(('center','plus','minus'),curves)}
                d=(peaks['plus']['height']-peaks['minus']['height'])/(2*STEP)
                windows[str(radius)]=dict(peaks=peaks,moving_FD=d,odd=(peaks['plus']['height']-peaks['minus']['height'])/2,
                    even=(peaks['plus']['height']+peaks['minus']['height']-2*peaks['center']['height'])/2)
            primary=windows['25'];diff=primary['moving_FD']-r['central_derivative']
            plus=primary['peaks']['plus']['height']-r['plus_peak3'];minus=primary['peaks']['minus']['height']-r['minus_peak3']
            data[duration]=dict(peak3=r,spline_windows=windows,spline_minus_peak3_FD=diff,
                relative_method_FD_difference=diff/r['central_derivative'] if r['central_derivative'] else None,
                endpoint_height_corrections_plus_minus=[plus,minus],differential_endpoint_height_correction=plus-minus,
                odd_correction=(plus-minus)/2,odd_correction_relative_to_peak3_odd=((plus-minus)/2)/r['odd'] if r['odd'] else None,
                spline_window_FD_range=max(v['moving_FD'] for v in windows.values())-min(v['moving_FD'] for v in windows.values()),
                same_duration_original_peak3_J_projection=r['exact_center_peak3_jacobian_projection'])
        data['150_minus_100']=dict(peak3_FD_change=data['150']['peak3']['central_derivative']-data['100']['peak3']['central_derivative'],
            spline_FD_change=data['150']['spline_windows']['25']['moving_FD']-data['100']['spline_windows']['25']['moving_FD'])
        report['observables'][metric]=data
    return report
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ('evidence-dir','repo','output'):p.add_argument('--'+arg,required=True)
    a=p.parse_args();report=analyze(Path(a.evidence_dir),Path(a.repo).resolve());f.write(a.output,report)
    print(json.dumps({m:{t:dict(peak3_D=v[t]['peak3']['central_derivative'],spline_D=v[t]['spline_windows']['25']['moving_FD'],
        method_difference=v[t]['spline_minus_peak3_FD'],window_FD_range=v[t]['spline_window_FD_range']) for t in ('100','150')} for m,v in report['observables'].items()},indent=2))
