"""Calibration + hold-out backtests for the q3db predictive engine (zero GPU).

Fits per-family model parameters from STORED results only and runs the plan's
hold-out backtest matrix B1-B14: every prediction is made from a fit that never
saw the held-out row, then compared to the MEASURED stored value. This script
IS the program's verification (plan: recently-we-have-been-vivid-pike.md).
Size justification (CLAUDE.md par.10): one analysis engine = loaders + fits +
the B1-B14 test matrix; splitting it would create files that only run together.
The .mat loader follows analyze_batch.py's par.2 sanity conventions (in-window
+ dead-floor asserts) but reads the extra fields this program needs (spectra,
Qc/Qi decomposition, geometry).

Model: L0 exact two-port algebra (Qc = QL/sqrt(T), Qi = QL/(1-sqrt(T)),
T = (Qi/(Qi+Qc))^2) + L1 coherent lane (empirical exp-Qc fit AND the bragg_cmt
TMM engine) + L2 radiation lane (Qi power law with optional saturation).
Every number printed is MEASURED (from a named stored file), DERIVED (L0 from
measured), or PREDICTED (model output; the point of the exercise).

Data provenance: engine version 2026 R1.3 build 4572 everywhere; numerics per
family are stated in the loaded study runners (q3db family: box y8.0/z8.8,
20 nm window @ 4001 pts, dx=50 nm optimization mesh, conformal, ASL 1e-7).
Noise floors used for weights: T mesh jitter 0.0018 (tm_span_conv_c325);
lnQ_L 1% below Q=5e4, 20% above (grid/ring-down adequacy, memory
project_highq_measurement_adequacy).

Usage: python calibrate_q3db.py prints the report AND replaces the adjacent
q3db_calibration.csv. There is no --csv option. For read-only audits run an
isolated copy with its own CSV; preserve the production calibration.
"""

import glob
import os
import re
import sys
import warnings

import numpy as np
from scipy.io import loadmat
from scipy.optimize import least_squares, curve_fit, brentq, OptimizeWarning

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bragg_cmt as cmt

REPO = r"c:\Users\evyat\Lumerical\phase_shift_grating_FTDT_codes"
DIRS = dict(
    nladder_c325=os.path.join(REPO, r"results_from_igum\tm_nladder_c325\results"),
    trench=os.path.join(REPO, r"results_from_igum\trench_q3db_20um\results"),
    invdesign_igum=os.path.join(REPO, r"results_from_igum\invdesign_q3db_20um\results"),
    invdesign_athena=os.path.join(REPO, r"results_from_athena\invdesign_q3db_20um\results"),
    apod=os.path.join(REPO, r"results_from_athena\tm_te_apod\results"),
    te_q3db=os.path.join(REPO, r"results_from_athena\te_q3db_20um\results"),
    nladder_c276=os.path.join(REPO, r"results_from_igum\tm_nladder_c276\results"),
    knob_c448=os.path.join(REPO, r"results_from_igum\tm_q3db_14um_knob\results"),
)
ITAI_CSV = os.path.join(REPO, r"results_from_igum\itai_hh_summary.csv")
SIG_T = 0.0018          # T mesh jitter floor (MEASURED, tm_span_conv_c325)
SIG_LNQ_LO = 0.01       # lnQ_L noise below the adequacy limit
SIG_LNQ_HI = 0.20       # lnQ_L noise above Q=5e4 (grid/ring-down adequacy)
Q_ADEQ = 5e4
KAPPA_ANCHORS = [(325.0, 0.0353e6), (400.0, 0.0440e6)]  # MEASURED per-family kappas

# ---------------------------------------------------------------- L0 algebra

def qc_of(T, QL):
    return QL / np.sqrt(T)

def qi_of(T, QL):
    return QL / (1.0 - np.sqrt(T))

def T_of(qc, qi):
    return (qi / (qi + qc)) ** 2

def QL_of(qc, qi):
    return 1.0 / (1.0 / qc + 1.0 / qi)

def cond_A(T):
    return np.sqrt(T) / (2.0 * (1.0 - np.sqrt(T)))

# ---------------------------------------------------------------- loaders

def parse_name(fname):
    d = dict(decorated="_sc" in fname)
    m = re.search(r"result_N(\d+)", fname)
    d["N"] = int(m.group(1)) if m else None
    m = re.search(r"_C(\d+)[_.]", fname)
    d["C"] = float(m.group(1)) if m else None
    m = re.search(r"_A(\d+)_", fname)
    d["A"] = int(m.group(1)) if m else None
    d["pol"] = "TM" if "_TM_" in fname else "TE"
    return d

def load_mat_row(path, *, require_tcmt=True):
    # Stored files also contain large field arrays. Only these observables are
    # used by calibration; loading every field made the offline audit time out.
    m = loadmat(path, squeeze_me=True, variable_names=[
        "resonance_transmission", "resonance_wavelength_nm", "spectral_fwhm_nm",
        "fwhm_m", "pitch_m", "corrugation_depth_m", "wl_nm", "T", "R"])
    row = parse_name(os.path.basename(path))
    T = float(m["resonance_transmission"])
    lam = float(m["resonance_wavelength_nm"])
    fw = abs(float(m["spectral_fwhm_nm"]))
    if not (np.isfinite([T, lam, fw]).all() and T > 0 and lam > 0 and fw > 0):
        raise ValueError(f"Invalid saved observables: {path}")
    if require_tcmt and T >= 1:
        raise ValueError(f"Invalid observables for finite positive TCMT Q inference: {path}")
    row.update(
        file=os.path.basename(path), T=T, lam=lam, QL=lam / fw,
        fwhm_um=float(m["fwhm_m"]) * 1e6,
        pitch=float(m["pitch_m"]), corr_nm=float(m["corrugation_depth_m"]) * 1e9,
        wl_nm=np.asarray(m["wl_nm"], float), Tspec=np.asarray(m["T"], float),
        Rspec=np.asarray(m["R"], float),
    )
    # Width-only comparisons can use saved profiles with T>=1; these rows
    # must not silently acquire a negative intrinsic Q or enter a TCMT fit.
    row["Qc"], row["Qi"], row["A_cond"] = (
        (qc_of(T, row["QL"]), qi_of(T, row["QL"]), cond_A(T))
        if T < 1 else (np.nan, np.nan, np.nan))
    row["sig_lnQL"] = SIG_LNQ_LO if row["QL"] < Q_ADEQ else SIG_LNQ_HI
    row["sig_lnQi"] = row["sig_lnQL"] + row["A_cond"] * SIG_T / T
    row["sig_lnQc"] = row["sig_lnQL"] + SIG_T / (2 * T)
    # CLAUDE.md par.2 sanity
    assert row["wl_nm"].min() <= lam <= row["wl_nm"].max(), f"off-window: {path}"
    assert T > 0.02, f"dead device: {path}"
    return row

def load_family(dirkey, pred, *, require_tcmt=True):
    rows = [load_mat_row(p, require_tcmt=require_tcmt)
            for p in sorted(glob.glob(os.path.join(DIRS[dirkey], "*.mat")))]
    return sorted([r for r in rows if pred(r)], key=lambda r: r["N"])

def load_itai(pol):
    rows = []
    for line in open(ITAI_CSV).read().strip().splitlines()[1:]:
        who, p, N, T, Qi, fw = line.split(",")
        if who != "his" or p != pol:
            continue
        T, Qi = float(T), float(Qi)
        QL = Qi * (1 - np.sqrt(T))
        r = dict(N=int(N), T=T, Qi=Qi, QL=QL, Qc=qc_of(T, QL), fwhm_um=float(fw),
                 A_cond=cond_A(T), sig_lnQL=SIG_LNQ_HI, file="itai_hh_summary.csv")
        r["sig_lnQi"] = r["sig_lnQL"] + r["A_cond"] * SIG_T / T
        r["sig_lnQc"] = r["sig_lnQL"] + SIG_T / (2 * T)
        rows.append(r)
    return sorted(rows, key=lambda r: r["N"])

# ---------------------------------------------------------------- lane E fits

def wlin(x, y, sig):
    """Weighted linear fit y = a + b x -> (a, b)."""
    w = 1.0 / np.asarray(sig) ** 2
    W = np.sum(w); xm = np.sum(w * x) / W; ym = np.sum(w * y) / W
    b = np.sum(w * (x - xm) * (y - ym)) / np.sum(w * (x - xm) ** 2)
    return ym - b * xm, b

def fit_qc_exp(rows):
    N = np.array([r["N"] for r in rows], float)
    a, b = wlin(N, np.log([r["Qc"] for r in rows]),
                [r["sig_lnQc"] for r in rows])
    return dict(lnQc0=a, rate=b)

def fit_qi_pow(rows):
    N = np.array([r["N"] for r in rows], float)
    a, b = wlin(np.log(N), np.log([r["Qi"] for r in rows]),
                [r["sig_lnQi"] for r in rows])
    return dict(lnA=a, p=b, sat=None)

def fit_qi_sat(rows):
    """1/Qi = 1/(A*N^p) + 1/Qsat; falls back to pure power if it can't beat it."""
    if len(rows) < 4:
        return fit_qi_pow(rows)
    N = np.array([r["N"] for r in rows], float)
    lnQi = np.log([r["Qi"] for r in rows])
    sig = np.array([r["sig_lnQi"] for r in rows])
    pw = fit_qi_pow(rows)

    def model(th):
        lnA, p, lnQs = th
        return -np.log(np.exp(-(lnA + p * np.log(N))) + np.exp(-lnQs))

    def resid(th):
        return (model(th) - lnQi) / sig
    th0 = [pw["lnA"], max(pw["p"], 1.0), np.log(np.exp(lnQi[-1]) * 1.5)]
    try:
        fit = least_squares(resid, th0, method="lm", max_nfev=5000)
        pow_cost = np.sum(((pw["lnA"] + pw["p"] * np.log(N) - lnQi) / sig) ** 2)
        if fit.cost * 2 < pow_cost * 0.98:
            return dict(lnA=fit.x[0], p=fit.x[1], sat=np.exp(fit.x[2]))
    except Exception:
        print(f"  note: saturating Qi fit failed for {len(rows)} rows,"
              " using pure power law")
    return pw

def qc_model(fit, N):
    return np.exp(fit["lnQc0"] + fit["rate"] * np.asarray(N, float))

def qi_model(fit, N):
    qi = np.exp(fit["lnA"] + fit["p"] * np.log(np.asarray(N, float)))
    if fit.get("sat"):
        qi = 1.0 / (1.0 / qi + 1.0 / fit["sat"])
    return qi

def solve_crossing(qcf, qif, T_target=0.5, lo=50, hi=400):
    f = lambda N: T_of(qc_model(qcf, N), qi_model(qif, N)) - T_target
    return brentq(f, lo, hi, xtol=1e-3)

def fit_width(rows):
    N = np.array([r["N"] for r in rows], float)
    F = np.array([r["fwhm_um"] for r in rows], float)
    fn = lambda n, Finf, B, c: Finf - B * np.exp(-c * n)
    p0 = [F.max() + 0.3, 5.0, 0.03]
    with warnings.catch_warnings():   # 3 rows / 3 params: exact fit, no covariance
        warnings.simplefilter("ignore", OptimizeWarning)
        popt, _ = curve_fit(fn, N, F, p0=p0, maxfev=20000)
    return dict(Finf=popt[0], B=popt[1], c=popt[2],
                fn=lambda n: fn(np.asarray(n, float), *popt))

# ---------------------------------------------------------------- lane C (engine)

def kappa_per_nm():
    """kappa(corr) line through the two measured family anchors (through origin)."""
    c = np.array([a[0] for a in KAPPA_ANCHORS])
    k = np.array([a[1] for a in KAPPA_ANCHORS])
    return float(np.sum(c * k) / np.sum(c * c))

def engine_qc(kappa, n_eff, pitch, N):
    lamD = 2 * n_eff * pitch
    dev = cmt.pi_shift_device(kappa, int(N), pitch)
    lam0, Tpk, fw = cmt.find_resonance(dev, n_eff, pitch, lamD - 4e-9, lamD + 4e-9)
    return lam0 / fw, lam0

def engine_calibrate_kappa_width(width_um, N, n_eff, pitch, k0):
    """Secant: kappa such that the engine's envelope FWHM at N matches the
    measured spatial width. Width is the well-conditioned observable (box-
    independent, 0.03% floor) — never calibrate kappa on a Q level."""
    tgt = float(width_um)
    k1, k2 = k0 * 0.9, k0 * 1.1
    f = lambda k: engine_width(k, n_eff, pitch, N) - tgt
    y1, y2 = f(k1), f(k2)
    for _ in range(20):
        k3 = k2 - y2 * (k2 - k1) / (y2 - y1)
        k1, y1, k2, y2 = k2, y2, k3, f(k3)
        if abs(y2) < 1e-4:
            break
    return k2

def engine_qc_ratio(kappa, n_eff, pitch, N, anchor_row):
    """Lane-C Qc prediction: engine used as a SHAPE function, level anchored on
    one measured row (absorbs the n_g/n_eff level offset the 1D model lacks)."""
    qN, _ = engine_qc(kappa, n_eff, pitch, N)
    qA, _ = engine_qc(kappa, n_eff, pitch, anchor_row["N"])
    return anchor_row["Qc"] * qN / qA

def engine_width(kappa, n_eff, pitch, N, profile=None):
    lamD = 2 * n_eff * pitch
    dev = cmt.pi_shift_device(kappa, int(N), pitch, kappa_profile=profile,
                              seg_periods=1 if profile else 2)
    lam0, _, _ = cmt.find_resonance(dev, n_eff, pitch, lamD - 4e-9, lamD + 4e-9)
    z, I = cmt.envelope(dev, lam0, n_eff, pitch)
    return cmt.fwhm_of(z, I) * 1e6

# ---------------------------------------------------------------- report utils

RESULTS = []

def check(test, qty, pred, meas, tol_rel=None, tol_abs=None, note="", info=False,
          span=None):
    """span = periods extrapolated past the fit rows (predicted N - max fitted N);
    it buckets the row into the empirical deviation bands. None = excluded."""
    err = pred - meas
    rel = err / meas if meas else np.nan
    if info:
        ok = "INFO"
    else:
        ok = "PASS" if ((abs(rel) <= tol_rel) if tol_rel is not None
                        else (abs(err) <= tol_abs)) else "FAIL"
    RESULTS.append((test, qty, pred, meas, rel, ok, note, span))
    return ok

def report():
    print(f"\n{'test':<14}{'quantity':<26}{'PREDICTED':>12}{'MEASURED':>12}{'err':>9}  ok    note")
    print("-" * 96)
    for t, q, p, m, r, ok, note, _ in RESULTS:
        print(f"{t:<14}{q:<26}{p:>12.4g}{m:>12.4g}{100*r:>8.1f}%  {ok:<5} {note}")
    gated = [x for x in RESULTS if x[5] != "INFO"]
    n_ok = sum(1 for x in gated if x[5] == "PASS")
    print(f"\n{n_ok}/{len(gated)} gated checks pass "
          f"(+{len(RESULTS)-len(gated)} informational rows)")

BUCKETS = dict(le30=(0, 30), gap=(31, 45), gt45=(46, 10 ** 6))   # extrapolation span

def error_bands():
    """Empirical deviation bands: how far the MEASURED value actually sat from a
    hold-out prediction, bucketed by extrapolation span. This is the honest
    answer to "my run landed — how far off may it be?". The deliberate B2-E
    stress rows are excluded (they mark the boundary, not the expected error);
    so are corr-knob and width rows (no N span). Q rows are relative, T absolute."""
    out = {}
    for name, (lo, hi) in BUCKETS.items():
        key = "31_45" if name == "gap" else name
        ql = [abs(r[4]) for r in RESULTS if _in_band(r, lo, hi)
              and ("Q_L" in r[1] or "Q_i" in r[1])]
        t = [abs(r[2] - r[3]) for r in RESULTS if _in_band(r, lo, hi) and " T at" in f" {r[1]}"]
        out[f"ql_n_{key}"], out[f"t_n_{key}"] = len(ql), len(t)
        out[f"n_{key}"] = len(ql) + len(t)
        for tag, v in (("ql", ql), ("t", t)):
            out[f"{tag}_p90_{key}"] = float(np.percentile(v, 90)) if v else np.nan
            out[f"{tag}_max_{key}"] = float(max(v)) if v else np.nan
    print("\nEmpirical deviation bands (hold-out |error| vs extrapolation span):")
    print(f"  {'span':<8}{'n Q':>5}{'Q p90':>9}{'Q max':>9}{'n T':>6}{'T p90':>8}{'T max':>8}")
    for key in ("le30", "31_45", "gt45"):
        print(f"  {key:<8}{out['ql_n_'+key]:>5}{100*out['ql_p90_'+key]:>8.1f}%"
              f"{100*out['ql_max_'+key]:>8.1f}%{out['t_n_'+key]:>6}"
              f"{out['t_p90_'+key]:>8.3f}{out['t_max_'+key]:>8.3f}")
    return out

def _in_band(row, lo, hi):
    return row[5] != "INFO" and row[7] is not None and row[0] != "B2-E" \
        and lo <= row[7] <= hi

# ---------------------------------------------------------------- backtests

def b1_invdesign():
    rows = load_family("invdesign_igum", lambda r: True) + \
           load_family("invdesign_athena", lambda r: True)
    rows = sorted(rows, key=lambda r: r["N"])
    byN = {r["N"]: r for r in rows}
    # B1a: reproduce the recorded 2-point prediction (fit N=100+150 only)
    tr = [byN[100], byN[150]]
    qcf, qif = fit_qc_exp(tr), fit_qi_pow(tr)
    Nx = solve_crossing(qcf, qif)
    check("B1a", "crossing N* (2-pt fit)", Nx, 220, tol_rel=0.06,
          note=f"recorded model gave ~230 (+4.5%); rate={qcf['rate']:.5f}, p={qif['p']:.3f}")
    # B1b: design-grade — fit N=100..200, hold out 220
    tr = [byN[n] for n in (100, 150, 180, 200)]
    qcf, qif = fit_qc_exp(tr), fit_qi_sat(tr)
    m = byN[220]
    sp = 220 - max(r["N"] for r in tr)
    satnote = f"Qi sat={qif['sat']:.3g}" if qif.get("sat") else "Qi pure power"
    check("B1b", "Q_L at N=220", QL_of(qc_model(qcf, 220), qi_model(qif, 220)),
          m["QL"], tol_rel=0.10, note=satnote, span=sp)
    check("B1b", "T at N=220", T_of(qc_model(qcf, 220), qi_model(qif, 220)),
          m["T"], tol_abs=0.03, span=sp)
    check("B1b", "crossing N*", solve_crossing(qcf, qif), 220, tol_rel=0.05)

def b2_b5_bare_c325():
    rows = load_family("nladder_c325", lambda r: True) + \
           load_family("trench", lambda r: (not r["decorated"]) and r["C"] == 325 and r["N"] != 150)
    rows = sorted(rows, key=lambda r: r["N"])
    ladder = [r for r in rows if r["N"] <= 120]
    byN = {r["N"]: r for r in rows}
    m165 = byN[165]
    # lane E stress case: whole short ladder (60-120), extrapolate ACROSS the
    # crossover to 165 — the known-hard regime, kept gated for honesty
    qcf, qif = fit_qc_exp(ladder), fit_qi_pow(ladder)
    check("B2-E", "Q_L at N=165", QL_of(qc_model(qcf, 165), qi_model(qif, 165)),
          m165["QL"], tol_rel=0.10, note=f"stress: fit 60-120 only; rate={qcf['rate']:.5f} p={qif['p']:.2f}")
    check("B2-E", "T at N=165", T_of(qc_model(qcf, 165), qi_model(qif, 165)),
          m165["T"], tol_abs=0.03, note="stress case")
    # lane E recipe-compliant: Qc (fast variable) from the two rows nearest the
    # target; Qi (slow variable) from the FULL ladder with the saturating form
    near = [byN[100], byN[120]]
    qcf2, qif2 = fit_qc_exp(near), fit_qi_sat(ladder)
    sp = 165 - max(r["N"] for r in ladder)
    check("B2-E2", "Q_L at N=165 (near-fit)", QL_of(qc_model(qcf2, 165), qi_model(qif2, 165)),
          m165["QL"], tol_rel=0.10, span=sp,
          note=f"recipe: Qc from 100+120, Qi sat-fit on 60-120; rate={qcf2['rate']:.5f}")
    check("B2-E2", "T at N=165 (near-fit)", T_of(qc_model(qcf2, 165), qi_model(qif2, 165)),
          m165["T"], tol_abs=0.03, span=sp)
    # lane C informational: engine N-trend drift (arbitrated: lane E primary
    # for N-trends; engine is the fixed-N shape tool — see B11)
    pitch, n_eff = byN[80]["pitch"], byN[80]["lam"] * 1e-9 / (2 * byN[80]["pitch"])
    kap = engine_calibrate_kappa_width(byN[80]["fwhm_um"], 80, n_eff, pitch, 0.036e6)
    qc165 = engine_qc_ratio(kap, n_eff, pitch, 165, byN[80])
    check("B2-C", "Q_c at N=165 (engine)", qc165, m165["Qc"], info=True,
          note="engine crossover shape steeper than measured — lane E primary for N-trends")
    # B5 width: fit N=60/70/80, hold out 100/120; engine width too
    wf = fit_width([byN[n] for n in (60, 70, 80)])
    for n in (100, 120):
        check("B5-E", f"width at N={n} (fit)", float(wf["fn"](n)), byN[n]["fwhm_um"],
              tol_rel=0.01)
        check("B5-C", f"width at N={n} (engine)", engine_width(kap, n_eff, pitch, n),
              byN[n]["fwhm_um"], info=True,
              note="engine width-vs-N flatter than measured — truncation fit primary")
    return byN, kap, n_eff, pitch

def b3_b4_trench():
    for C, name, fitN, holdN in [
            (325, "B3", (150, 165, 180), (195,)),
            (276, "B4", (110, 125, 140), (150, 165))]:
        bare = load_family("trench", lambda r, C=C: (not r["decorated"]) and r["C"] == C)
        byN = {r["N"]: r for r in bare}
        tr = [byN[n] for n in fitN if n in byN]
        qcf, qif = fit_qc_exp(tr), fit_qi_pow(tr)
        for n in holdN:
            if n not in byN:
                continue
            m = byN[n]
            sp = n - max(r["N"] for r in tr)
            check(name, f"C{C} Q_L at N={n}", QL_of(qc_model(qcf, n), qi_model(qif, n)),
                  m["QL"], tol_rel=0.10, note=f"p={qif['p']:.2f}", span=sp)
            check(name, f"C{C} T at N={n}", T_of(qc_model(qcf, n), qi_model(qif, n)),
                  m["T"], tol_abs=0.03, span=sp)
    # B4b — the 2026-09-01 LIVE validation, kept as a permanent hold-out: full
    # c276 stored family (N=110-165, saturating Qi) predicts the N=200 rung
    # that was DISPATCHED against this prediction (IGUM 67731; landed inside
    # the pre-registered bands: T +0.0055, Q_L -1.9%)
    bare276 = load_family("trench", lambda r: (not r["decorated"]) and r["C"] == 276)
    live = load_family("nladder_c276", lambda r: True)
    if live:
        qcf, qif = fit_qc_exp(bare276), fit_qi_sat(bare276)
        m = live[0]
        sp = 200 - max(r["N"] for r in bare276)
        check("B4b-live", "c276 Q_L at N=200", QL_of(qc_model(qcf, 200), qi_model(qif, 200)),
              m["QL"], tol_rel=0.10, span=sp,
              note="fit stored 110-165; truth = live job 67731")
        check("B4b-live", "c276 T at N=200", T_of(qc_model(qcf, 200), qi_model(qif, 200)),
              m["T"], tol_abs=0.03, span=sp)
    # decorated c325 arm (trench): fit low rungs, hold out the top
    dec = load_family("trench", lambda r: r["decorated"] and r["C"] == 325)
    byN = {r["N"]: r for r in dec}
    tr = [byN[n] for n in (165, 169, 170, 185) if n in byN]
    qcf, qif = fit_qc_exp(tr), fit_qi_sat(tr)
    for n in (205, 225):
        if n in byN:
            check("B3-dec", f"trench Q_L at N={n}", QL_of(qc_model(qcf, n), qi_model(qif, n)),
                  byN[n]["QL"], tol_rel=0.10, span=n - max(r["N"] for r in tr))

def b6_b7_itai():
    tm = load_itai("TM")
    tr = [r for r in tm if r["N"] <= 140]
    qcf, qif = fit_qc_exp(tr), fit_qi_sat(tr)
    m = [r for r in tm if r["N"] == 189][0]
    sat_s = f"{qif['sat']:.3g}" if qif.get("sat") else "-"
    sp = 189 - max(r["N"] for r in tr)
    check("B6", "Itai TM T at N=189", T_of(qc_model(qcf, 189), qi_model(qif, 189)),
          m["T"], tol_abs=0.03, note=f"p={qif['p']:.2f} sat={sat_s}", span=sp)
    check("B6", "Itai TM Q_L at N=189", QL_of(qc_model(qcf, 189), qi_model(qif, 189)),
          m["QL"], tol_rel=0.10, span=sp)
    te = load_itai("TE")
    te = [r for r in te if abs(r["fwhm_um"] - 19.8) < 0.3]  # the consistent device family
    tr = [r for r in te if r["N"] <= 155]
    qif = fit_qi_pow(tr)
    for n in (175, 195):
        m = [r for r in te if r["N"] == n][0]
        check("B7", f"Itai TE Q_i at N={n}", float(qi_model(qif, n)), m["Qi"],
              tol_rel=0.25, span=n - max(r["N"] for r in tr),
              note=">1e5 regime: REPORT — defines stated uncertainty")

def b8_decorations():
    anchors = dict(ctrl=(0.4906, 13930.0), comb=(0.4961, 16203.0),
                   flush=(0.5017, 16942.0), trench=(0.5021, 18777.0))
    qi_ctrl = qi_of(*anchors["ctrl"])
    lore = dict(comb=1.171, flush=1.216, trench=1.348)  # recorded gains (memory)
    for k in ("comb", "flush", "trench"):
        mult = qi_of(*anchors[k]) / qi_ctrl
        check("B8", f"{k} Q_i multiplier", mult, lore[k], tol_rel=0.10,
              note="DERIVED from anchor T,Q_L pairs vs recorded lore")

def b9_lambda():
    rows = load_family("trench", lambda r: (not r["decorated"]) and r["N"] == 150)
    for r in rows:
        if r["C"] is None:               # untagged filename = corr 400 default
            r["C"] = r["corr_nm"]
    rows = sorted(rows, key=lambda r: r["C"])
    C = np.array([r["C"] for r in rows]); L = np.array([r["lam"] for r in rows])
    for j, r in enumerate(rows):        # leave-one-out
        msk = np.arange(len(rows)) != j
        a, b = wlin(C[msk], L[msk], np.ones(msk.sum()))
        check("B9", f"lambda at C{int(r['C'])}", a + b * r["C"], r["lam"], tol_abs=1.0)

def b10_spectral():
    """Rahimof-recipe fit on ONE short c276 rung -> predict the N=165 lineshape."""
    bare = load_family("trench", lambda r: (not r["decorated"]) and r["C"] == 276)
    byN = {r["N"]: r for r in bare}
    src, tgt = byN[110], byN[165]
    pitch = src["pitch"]
    wl = src["wl_nm"] * 1e-9
    # fit window: main reflection lobe + shoulders, EXCLUDING the pm-wide
    # cavity notch (hyper-sensitive to sub-linewidth misalignment; the arms'
    # stopband shape carries kappa and n_eff — Rahimof fitted notchless
    # uniform gratings, this is the pi-shift equivalent of their window rule)
    Rm = src["Rspec"]
    lobe = Rm > 0.02 * Rm.max()
    i0, i1 = np.argmax(lobe), len(lobe) - np.argmax(lobe[::-1])
    sl = np.zeros(len(wl), bool)
    sl[max(0, i0 - 200):min(len(wl), i1 + 200)] = True
    notch_hw = 50 * abs(src["lam"] / src["QL"])       # 50 linewidths, in nm
    sl &= np.abs(src["wl_nm"] - src["lam"]) > notch_hw

    def resid(th):
        kap, n_eff = th
        dev = cmt.pi_shift_device(kap, src["N"], pitch)
        t, r = cmt.spectrum(dev, wl[sl], n_eff, pitch)
        return np.concatenate([(np.abs(r) ** 2 - src["Rspec"][sl]),
                               0.1 * (np.abs(t) ** 2 - src["Tspec"][sl])])
    n0 = src["lam"] * 1e-9 / (2 * pitch)
    fit = least_squares(resid, [0.030e6, n0], method="trf",
                        bounds=([0.005e6, n0 - 0.01], [0.08e6, n0 + 0.01]),
                        max_nfev=200)
    kap, n_eff = fit.x
    _, lam_pred = engine_qc(kap, n_eff, pitch, 165)
    qc_pred = engine_qc_ratio(kap, n_eff, pitch, 165, src)
    check("B10", "c276 N=165 peak lambda nm", lam_pred * 1e9, tgt["lam"], tol_abs=1.0,
          note=f"spectral fit on N=110: kappa={kap*1e-6:.4f}/um n_eff={n_eff:.5f}")
    check("B10", "c276 N=165 Q_c", qc_pred, tgt["Qc"], tol_rel=0.10,
          note="engine shape ratio, level anchored on the N=110 row")

def b11_apodized():
    """kappa anchored on THIS polarization's own A0 row — never borrowed across
    families or polarizations; then the 4 apodized rows per pol are pure held-out
    predictions of the kappa(z)-profile envelope. A0 widths/lambdas MEASURED in
    results_from_athena/tm_te_apod/graphs/apod_summary.csv (rows "TM,0"/"TE,0")."""
    for pol, test, A0_WIDTH, A0_LAM in (("TM", "B11", 17.8992, 1523.57),
                                        ("TE", "B11-TE", 15.2164, 1570.74)):
        rows = load_family("apod", lambda r, pol=pol: r["pol"] == pol,
                           require_tcmt=False)  # B11 checks spatial width only
        pitch = rows[0]["pitch"]
        n_eff = A0_LAM * 1e-9 / (2 * pitch)
        kap0 = engine_calibrate_kappa_width(A0_WIDTH, 80, n_eff, pitch, 0.039e6)
        for r in rows:
            A, corr_edge = r["A"], r["corr_nm"]

            def prof(d, A=A, corr_edge=corr_edge):
                if d <= A:
                    corr_d = 40.0 + (corr_edge - 40.0) * (d - 1) / float(A)
                    return corr_d / corr_edge
                return 1.0
            w = engine_width(kap0, n_eff, pitch, r["N"], profile=prof)
            check(test, f"apod A{A} width um", w, r["fwhm_um"], tol_rel=0.05,
                  note=f"kappa={kap0*1e-6:.4f}/um from {pol} A0 width; corr={r['corr_nm']:.0f}")

def b13_te_q3db():
    """TE polarization hold-out — the TE q3db family (corr 250, pitch 500) is
    fitted and tested entirely on TE rows; no TM anchor touches it."""
    rows = load_family("te_q3db", lambda r: r["pol"] == "TE" and r["C"] == 250)
    byN = {r["N"]: r for r in rows}
    tr = [byN[n] for n in (166, 168, 176, 190)]
    qcf, qif = fit_qc_exp(tr), fit_qi_sat(tr)
    m = byN[215]
    sp = 215 - max(r["N"] for r in tr)
    check("B13-TE", "te c250 Q_L at N=215", QL_of(qc_model(qcf, 215), qi_model(qif, 215)),
          m["QL"], tol_rel=0.10, span=sp,
          note=f"TE-only fit; rate={qcf['rate']:.5f} p={qif['p']:.2f}")
    check("B13-TE", "te c250 T at N=215", T_of(qc_model(qcf, 215), qi_model(qif, 215)),
          m["T"], tol_abs=0.03, span=sp)

def b14_corr_transform():
    """The 2026-09-01 corr-knob live test (jobs 68086/68925, corr 448.4 — 38%
    outside the calibration range). Two things are validated here: kappa prop.
    corr (Qc RATE) and the two-term Qc transform (rate + intercept) that the
    rung-0 miss forced. Fit source for the intercept: the STORED N=150 corr
    ladder; c448 rows are the hold-out."""
    rows = load_family("knob_c448", lambda r: True)
    if len(rows) < 2:
        return
    fams_rate = fit_qc_exp(rows)["rate"]
    check("B14", "Qc rate at corr 448 (kappa prop corr)", fams_rate,
          0.03688 * 448.4 / 325.0, tol_rel=0.03,
          note="c325 family rate scaled by corr ratio vs the MEASURED c448 pair")
    # two-term transform, predicting the c448 Qc LEVEL from the c325 family
    p325_rate, p325_ln0 = 0.03688, None
    for line in open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  "q3db_calibration.csv")).read().splitlines()[1:]:
        f_, k_, v_ = line.split(",")[:3]
        if f_ == "tm_bare_c325" and k_ == "qc_lnQ0":
            p325_ln0 = float(v_)
    QC_H = -0.002818                      # MEASURED intercept slope, N=150 ladder
    for r in rows:
        pred = np.exp(p325_ln0 + QC_H * (448.4 - 325.0)
                      + p325_rate * (448.4 / 325.0) * r["N"])
        check("B14", f"Qc at corr448 N={r['N']} (2-term)", pred, r["Qc"], tol_rel=0.15,
              note="rate-only transform gave +31% (the rung-0 miss)")

def b12_kappa_corr_reconciliation():
    """Phase-3 reconciliation, zero GPU: kappa(corr) is linear (coherent
    channel); the conflicting corr-exponents in memory belong to Q_i (radiative
    channel) — measured here at fixed N=150 from the stored corr ladder."""
    check("B12", "kappa(276)/kappa(325)", 0.0300 / 0.0353, 276.0 / 325.0,
          tol_rel=0.02, note="B10 spectral kappa vs corr ratio — linear law")
    check("B12", "kappa(400)/kappa(325)", 0.0440 / 0.0353, 400.0 / 325.0,
          tol_rel=0.02, note="measured family kappas vs corr ratio")
    rows = load_family("trench", lambda r: (not r["decorated"]) and r["N"] == 150)
    for r in rows:
        if r["C"] is None:
            r["C"] = r["corr_nm"]
    rows = sorted(rows, key=lambda r: r["C"])
    C = np.log([r["C"] for r in rows])
    Qi = np.log([r["Qi"] for r in rows])
    a, b = wlin(C, Qi, [r["sig_lnQi"] for r in rows])
    check("B12", "Q_i ~ corr^x at N=150", b, -1.8, info=True,
          note="radiative exponent from stored corr ladder (lore: -1.8 and -2.9)")

ENGINE_VER = "2026R1.3-b4572"
NUMERICS = "y8.0/z8.8 box, 20nm/4001pts, dx50 conformal, ASL 1e-7"

def calibration_table(bands):
    """PRODUCTION per-family fits (all rows — unlike the hold-out backtests)
    -> q3db_calibration.csv next to this script, for predict_q3db.py."""
    fams = {}
    bare = load_family("nladder_c325", lambda r: True) + \
        load_family("trench", lambda r: (not r["decorated"]) and r["C"] == 325 and r["N"] != 150)
    fams["tm_bare_c325"] = sorted(bare, key=lambda r: r["N"])
    fams["tm_bare_c276"] = sorted(
        load_family("trench", lambda r: (not r["decorated"]) and r["C"] == 276) +
        load_family("nladder_c276", lambda r: True), key=lambda r: r["N"])
    fams["tm_bare_c448"] = load_family("knob_c448", lambda r: True)  # 2026-09-01 knob-test rows
    fams["tm_trench_c325"] = load_family("trench", lambda r: r["decorated"] and r["C"] == 325)
    fams["tm_invdesign"] = sorted(load_family("invdesign_igum", lambda r: True) +
                                  load_family("invdesign_athena", lambda r: True),
                                  key=lambda r: r["N"])
    fams["itai_tm"], fams["itai_te"] = load_itai("TM"), [
        r for r in load_itai("TE") if abs(r["fwhm_um"] - 19.8) < 0.3]
    fams["te_q3db_c250"] = load_family("te_q3db", lambda r: r["pol"] == "TE" and r["C"] == 250)
    lines = ["family,param,value,n_rows,source,engine_version,numerics"]
    # empirical deviation bands (item: what a landed run may deviate by)
    for k, v in bands.items():
        bucket = next(b for b in ("31_45", "le30", "gt45") if k.endswith(b))
        lines.append(f"errband,{k},{v:.6g},{bands['n_' + bucket]},"
                     f"hold-out |err| (Q rel frac / T abs),{ENGINE_VER},\"{NUMERICS}\"")
    # width<->corr knob lines, ONE per polarization (1/w linear in corr; the
    # lock-target linearizing coordinate). TM: corr_bisect_log.csv MEASURED
    # rows. TE: stored te rows C233(N=170)/C250(N=166) + the corr_bisect TE
    # C300 reference (N=80 legacy — carries ~4% truncation bias, noted).
    te_rows = load_family("te_q3db", lambda r: r["pol"] == "TE")
    te_by = {(r["C"], r["N"]): r for r in te_rows}
    knobs = dict(
        knob_tm=[(300.0, 19.25844), (350.0, 17.24287), (400.0, 15.54882), (450.0, 13.85999)],
        knob_te=[(233.0, te_by[(233.0, 170)]["fwhm_um"]),
                 (250.0, te_by[(250.0, 166)]["fwhm_um"]),
                 (300.0, 15.54448)],
    )
    for kn, pts in knobs.items():
        c = np.array([p[0] for p in pts]); iw = 1.0 / np.array([p[1] for p in pts])
        b, a = np.polyfit(c, iw, 1)
        lines.append(f"{kn},iw_a,{a:.6g},{len(pts)},corr-width knob,{ENGINE_VER},\"{NUMERICS}\"")
        lines.append(f"{kn},iw_b,{b:.6g},{len(pts)},corr-width knob,{ENGINE_VER},\"{NUMERICS}\"")
    print("\nProduction calibration table (all-rows fits):")
    for fam, rows in fams.items():
        src = rows[0]["file"] + f" (+{len(rows)-1})"
        qcf, qif = fit_qc_exp(rows), fit_qi_sat(rows)
        ent = dict(qc_rate=qcf["rate"], qc_lnQ0=qcf["lnQc0"], qi_p=qif["p"],
                   qi_lnA=qif["lnA"], qi_sat=qif.get("sat") or np.nan,
                   n_lo=min(r["N"] for r in rows), n_hi=max(r["N"] for r in rows))
        lams = [r["lam"] for r in rows if "lam" in r]      # itai rows carry none
        if lams:
            ent["lam_nm"] = float(np.mean(lams))
        if all("fwhm_um" in r and np.isfinite(r.get("fwhm_um", np.nan)) for r in rows) \
                and len(rows) >= 4:
            try:
                wf = fit_width(rows)
                ent.update(w_Finf=wf["Finf"], w_B=wf["B"], w_c=wf["c"])
            except Exception:
                print(f"  note: width fit failed for {fam}, no w_* params written")
        for k, v in ent.items():
            lines.append(f"{fam},{k},{v:.6g},{len(rows)},{src},{ENGINE_VER},\"{NUMERICS}\"")
        sat_s = f" sat={ent['qi_sat']:.3g}" if np.isfinite(ent["qi_sat"]) else ""
        print(f"  {fam:<13} Qc rate {ent['qc_rate']:.5f}/period, Qi p={ent['qi_p']:.2f}{sat_s}"
              + (f", Finf={ent.get('w_Finf', float('nan')):.2f} um" if "w_Finf" in ent else ""))
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "q3db_calibration.csv")
    with open(out, "w") as f:
        f.write("\n".join(lines) + "\n")
    print(f"wrote {out}")

def main():
    print("q3db predictive-engine backtests — stored data only, zero GPU")
    b1_invdesign()
    b2_b5_bare_c325()
    b3_b4_trench()
    b6_b7_itai()
    b8_decorations()
    b9_lambda()
    b10_spectral()
    b11_apodized()
    b12_kappa_corr_reconciliation()
    b13_te_q3db()
    b14_corr_transform()
    report()
    calibration_table(error_bands())

if __name__ == "__main__":
    main()
