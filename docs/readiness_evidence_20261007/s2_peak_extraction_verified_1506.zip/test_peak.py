import sys,unittest
sys.dont_write_bytecode=True
import numpy as np
import peak_diagnostic as d

class PeakTests(unittest.TestCase):
    def test_exact_cubic_reproduces_quadratic_interior_height_location(self):
        x=np.arange(-50.,51.);y=3-.1*(x-.22)**2
        result=d.spline_peak(x,y,50,20)
        self.assertAlmostEqual(result['height'],3.,places=12)
        self.assertAlmostEqual(result['frequency_grid_coordinate'],.22,places=12)
        self.assertEqual(result['interior_maxima_count'],1)
        self.assertAlmostEqual(result['distance_to_nearest_cell_boundary_samples'],.28,places=12)
    def test_true_constant_height_translation_has_sparse_extraction_bias(self):
        evidence=d.synthetic();self.assertEqual(evidence['true_height_gradient'],0.)
        self.assertGreater(abs(evidence['peak3_moving_FD']),1e-6)
        self.assertLess(abs(evidence['spline_moving_FD']),abs(evidence['peak3_moving_FD']))
        self.assertAlmostEqual(evidence['symmetric_center_peak3_FD'],0.,places=12)
        self.assertNotEqual(evidence['nominal_peak3_J_spectral_FD'],evidence['peak3_moving_FD'])
    def test_boundary_monotone_invalid_and_nonfinite_refuse(self):
        x=np.arange(-50.,51.)
        with self.assertRaisesRegex(d.h.EvidenceError,'No interior'):d.spline_peak(x,x,50,20)
        with self.assertRaisesRegex(d.h.EvidenceError,'escapes'):d.spline_peak(x,3-x*x,50,60)
        y=3-x*x;y[50]=np.nan
        with self.assertRaisesRegex(d.h.EvidenceError,'Invalid'):d.spline_peak(x,y,50,20)

if __name__=='__main__':unittest.main(verbosity=2)
