# Server environment and continuation checks

Repository root: `C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes`.
Read `docs/INVERSE_DESIGN_READINESS_2026-10-06.md` for the source map,
verified commands, remaining bugs and evidence paths; current job state lives
in `docs/TE_RECOVERY_2026-10-06.md`. Recheck volatile claims before acting.

## Athena

The deployed array script supplies Apptainer binds, Xvfb, license environment,
scientific libraries and TBB preload. A bare Python call on the login host
does not reproduce that runtime. Container path and inner API are in SKILL.md.
Follow deploy -> build_sweep_list -> run_python_array -> athena_run_one ->
study.main(task_idx). `--upload-only` replaces matching files; it is not a dry run.

On October 6 local DNS briefly failed while IGUM resolved Athena to
132.68.1.206. A verified address can be supplied as SSH `HostName` while
retaining `HostKeyAlias=athena.technion.ac.il`, `StrictHostKeyChecking=yes`,
BatchMode and a bounded timeout. Never bypass host verification. Verify the
address again rather than treating this dated IP as permanent configuration.
Windows subprocess input to `bash -s` should be encoded bytes; text-mode
newline conversion can send CRLF to Bash.

The local read-only recovery watcher supports `--ssh-hostname=<verified IP>`.
Its completion verdict requires all expected tasks and successful accounting
queries. The scalar fit's scientific verdict still needs separate review.
Watcher tests: `python -X utf8 athena/scripts/test_watch_te_recovery.py`.
Changing the file does not change an already running Python watcher; inspect
the process and preserve its logs before any intentional replacement.

## IGUM

Account is `acct-lumerical`, not the old README's `acct-preempt`. Native
R1.3 build4572, bundled Python3.13.1, NumPy2.2.2 and SciPy1.14.1 were verified.
Use the environment from `igum/jobs/run_python_array.sh`: LUM_HOME/lib plus
WORK_DIR/scilibs in LD_LIBRARY_PATH and LUMERICAL_LD_LIBRARY_PATH, TBB malloc
preload, Qt offscreen, license variables and fabric guards. A bare engine
`-v` failed on libglut; with the job environment it succeeded. Plain
fdtd-engine is used; do not substitute the MPI wrapper without checking libs.

Hidden CAD build-only verification passed on the login node, including GPU
and eight-thread readbacks and restoration. One prior attempt timed out;
the retry's success does not establish the timeout's cause. This is not
proof of every compute node's native libraries or a new TE solve.

`sacctmgr` may fail on localhost:6819 even when submission works. Use
`sshare -U`, `scontrol show assoc_mgr flags=qos`, and an appropriate
`sbatch --test-only` request. October 6 test-only accepted both:
- part-preempt / qos-preempt: one GPU, 8 CPUs, 256G, five minutes.
- part-lumerical / qos-lumerical: one GPU, 8 CPUs, 32G, five minutes.
Test-only validates the scheduler request and starts no job.

Both QOS records showed REQUEUE with MaxWallPJ=10080 minutes. Partition
PreemptMode=OFF alone is misleading with cluster PreemptType=preempt/qos.
Inspect the applicable QOS, not only sinfo/scontrol partition output.
Reference: https://slurm.schedmd.com/preempt.html .

The local thread patch has not been uploaded to IGUM. Compare deployed hashes
before future launches, preserve the prior wrapper, and verify the actual
engine command's thread count. Do not change matching sources during active
fingerprinted jobs. The current S2 recovery's OLD path is Athena-specific;
the runner is not portable to IGUM just by changing deploy scripts.
