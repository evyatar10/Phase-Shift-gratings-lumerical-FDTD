"""Offline pinned100/150 spatial comparison; crops are measurement diagnostics."""
import argparse,contextlib,hashlib,io,json,sys
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
import numpy as np
CP_SHA={100:'38dcd852f7bcb5e2ef7bb27cb4085257a5b70098d146e41d73b8038180d72f49',150:'a0ff55eacaa52e00a2aab17dcc43d0e5fff9a72566e15da371ff25279c172663'}
ENGINE_SHA='53108bbd368dd699179ab65029628aa4c4b2d8ad687777f88b82f404a0952569'
PITCH_NM=491.06


def need(ok,message):
    if not ok:raise ValueError(message)


def sha(raw):return hashlib.sha256(raw).hexdigest()


def pinned(path,digest):
    raw=Path(path).read_bytes();need(sha(raw)==digest,'Caller/original pin differs: '+str(path));return raw


def json_pin(path,digest):return json.loads(pinned(path,digest))


def npz(raw):
    with np.load(io.BytesIO(raw),allow_pickle=False) as z:out={k:z[k].copy() for k in z.files}
    need(all(np.isfinite(v).all() for v in out.values()),'Nonfinite stored profile arrays')
    return out


def stats(eng,x,I):
    x=np.asarray(x,float).ravel();I=np.asarray(I,float).ravel()
    need(x.size>=4 and I.shape==x.shape and np.isfinite(I).all() and (I>=0).all() and (np.diff(x)>0).all() and max(I)>0,'Invalid integrated intensity/grid')
    with contextlib.redirect_stdout(io.StringIO()):
        envelope=np.asarray(eng.extract_envelope_peaks(x,I));width=eng.fwhm_env_of_line(x,I);sigma=eng.sigma_of_line(x,I)
    need(width is not None and np.isfinite([width,sigma]).all() and width>0 and sigma>0 and np.isfinite(envelope).all(),'Production envelope/FWHM/sigma unavailable')
    floor,peak=float(min(envelope)),float(max(envelope));level=floor+.5*(peak-floor)
    crossing=np.flatnonzero(np.diff(np.sign(envelope-level)))
    need(len(crossing)>=2,'Missing outermost half-level crossings')
    def location(k):
        slope=(envelope[k+1]-envelope[k])/(x[k+1]-x[k]);return float(x[k]+(level-envelope[k])/slope) if slope else float(x[k])
    return dict(FWHM_um=float(width),sigma_um=float(sigma),floor=floor,peak=peak,half_level=level,
        half_level_crossings_um=[location(int(crossing[0])),location(int(crossing[-1]))],
        end_x_um=[float(x[0]),float(x[-1])],end_I_over_envelope_peak=[float(I[0]/peak),float(I[-1]/peak)]),envelope


def crop_stats(eng,full_x_m,full_I,bound):
    x=np.asarray(full_x_m).ravel()*1e6;I=np.asarray(full_I).ravel();keep=abs(x)<=bound
    s,e=stats(eng,x[keep],I[keep]);s.update(crop_half_extent_um=bound,sample_count=int(sum(keep)))
    return s,keep,e


def profile(eng,arrays,prefix,meta):
    required=('x_um','I_y_integrated','envelope_y_integrated','y_m','wy_m','monitor_x_m','monitor_I_y_integrated')
    values={k:np.asarray(arrays[prefix+'__'+k]).ravel() for k in required}
    x,I=values['monitor_x_m'],values['monitor_I_y_integrated']
    need(x.shape==I.shape and len(x)>4 and (np.diff(x)>0).all() and (I>=0).all(),'Invalid full monitor integral')
    y=values['y_m'];need(len(y)>=2 and (np.diff(y)>0).all(),'Invalid y grid')
    wy=np.empty_like(y);wy[0]=(y[1]-y[0])/2;wy[-1]=(y[-1]-y[-2])/2;wy[1:-1]=(y[2:]-y[:-2])/2
    need(np.array_equal(wy,values['wy_m']),'Production y weights differ')
    canonical,keep,env=crop_stats(eng,x,I,98*PITCH_NM/1000)
    need(np.array_equal(x[keep]*1e6,values['x_um']) and np.array_equal(I[keep],values['I_y_integrated']),'Production crop differs from same full integral')
    rawdiff=float(max(abs(env-values['envelope_y_integrated'])))
    bound=128*np.finfo(float).eps*max(float(max(abs(env))),np.finfo(float).tiny)
    need(rawdiff<=bound,'Stored production envelope not reproduced within recorded arithmetic roundoff')
    need(abs(canonical['FWHM_um']-meta['production_FWHM_um'])<=1e-12 and abs(canonical['sigma_um']-meta['sigma_um'])<=1e-12,'Stored production width/sigma not reproduced')
    need(meta['crop_half_extent_um']==98*PITCH_NM/1000,'Canonical crop family differs')
    result=dict(canonical_production_N98=canonical,stored_envelope_reproduction=dict(max_abs_difference=rawdiff,roundoff_bound=bound),supplemental_crops={})
    for name,extent in [('native_N98_physical_end',98*PITCH_NM/1000+PITCH_NM/4000),('N80_measurement_crop_of_same_N98_field',80*PITCH_NM/1000)]:
        extra,mask,_=crop_stats(eng,x,I,extent);extra['FWHM_change_from_canonical_um']=extra['FWHM_um']-canonical['FWHM_um'];result['supplemental_crops'][name]=extra
    return result,values


def identity_report(report,duration,row):
    need(report['status']=='SAVED_RAW_PROFILE_EXTRACTION_COMPLETE_NO_PHYSICS_PASS' and report['no_solve'] is True and report['all_inputs_preserved'] is True,'Incomplete/non-preserved/no-solve extraction report')
    need(report['FDTD_class_unchanged'] is True and report['FDTD_constructor_unchanged'] is True,'Extractor altered FDTD identity')
    task=0 if duration==100 else 3;i,r=row['identity'],row['result']
    need(i['task']==r['task']==task and i['duration_ps']==r['duration_ps']==duration and i['sign']==r['sign']==i['delta_nm']==r['delta_nm']==0,'Wrong nominal center/duration')
    need(i['point']==r['params'] and len(i['point'])==296 and i['spec']['n_periods_side']==98 and i['spec']['n_free']==60 and i['spec']['bare'] and i['spec']['polarization']=='TE','Wrong exact point/family')
    inputs=report['inputs'][str(duration)];need(len(inputs)==4 and inputs[0]['sha256']==CP_SHA[duration],'Wrong original input checkpoint')
    for pin,role,key in zip(inputs[1:],('source','h5','ports_npz'),('fsp_sha256','h5_sha256','ports_sha256')):
        need(pin['path']==r[role] and pin['sha256']==r[key],'Original source/H5/ports binding differs: '+role)
    preserved=report['immutable_inputs_rechecked']
    need(len(preserved)>=4 and all(item['unchanged'] is True and item['before']==item['after'] for item in preserved),'Missing/changed preservation receipts')
    for pin in inputs:need(any(item['before']==pin for item in preserved),'Input omitted from preservation recheck')


def stage(report,duration,row,arrays,ports,eng):
    identity_report(report,duration,row);s=report['stages'][str(duration)]
    need(s['duration_ps']==duration and s['monitor_geometry']['enabled']['value']==1,'Monitor/duration mismatch')
    grid=np.asarray(arrays['monitor_lambda_m']).ravel();need(grid.size==501 and np.array_equal(grid,ports['p2_lambda'].ravel()),'Exact501 profile/port spectral grid differs')
    inventory=s['raw_profile_coordinate_inventory']
    need(np.array_equal(grid,np.asarray(inventory['lambda_m']).ravel()),'Raw profile spectral coordinate inventory differs')
    result=dict(duration_ps=duration,profiles={},nearby_W_lambda=[],monitor_geometry=s['monitor_geometry'],monitor_lambda_m=grid.tolist());grids={}
    for name,curve in [('Tout',abs(ports['p2_T_out'].ravel())),('modal',abs(ports['p2_S'].ravel())**2)]:
        meta=s['profiles'][name];lam,T,width=eng.measure_peak(grid*1e9,curve);k=int(np.argmin(abs(grid-lam*1e-9)))
        need(width is not None and T>eng.DEAD_T_FLOOR and k==meta['original_monitor_frequency_index'] and abs(lam-meta['target_port_sampled_resonance_nm'])<=1e-12,'Actual port spectrum anchor differs')
        need(meta['monitor_sampled_lambda_nm']==float(grid[k]*1e9),'Profile sampled wavelength binding differs')
        result['profiles'][name],v=profile(eng,arrays,name,meta);result['profiles'][name].update(original_monitor_frequency_index=k,target_nm=float(lam),monitor_sampled_lambda_nm=float(grid[k]*1e9))
        for axis,key in [('x','monitor_x_m'),('y','y_m')]:need(np.array_equal(v[key],np.asarray(inventory[axis+'_m']).ravel()),'Raw spatial coordinate inventory differs')
        grids[name]=v
    peaks=[result['profiles'][n]['original_monitor_frequency_index'] for n in ('Tout','modal')]
    needed=sorted({k+d for k in peaks for d in range(-3,4)})
    need(set(map(int,s['nearby_profiles']))==set(needed),'Nearby W(lambda) support absent/incomplete/off-family')
    for k in needed:
        meta=s['nearby_profiles'][str(k)];need(meta['original_monitor_frequency_index']==k and meta['monitor_sampled_lambda_nm']==float(grid[k]*1e9),'Nearby profile wavelength binding differs')
        measured,v=profile(eng,arrays,'nearby_bin_'+str(k),meta)
        need(np.array_equal(v['monitor_x_m'],grids['Tout']['monitor_x_m']) and np.array_equal(v['y_m'],grids['Tout']['y_m']),'Nearby spatial grid differs')
        result['nearby_W_lambda'].append(dict(index=k,lambda_nm=float(grid[k]*1e9),**measured['canonical_production_N98']))
    return result,grids


def combine(stages,grids):
    need(np.array_equal(np.asarray(stages[100]['monitor_lambda_m']),np.asarray(stages[150]['monitor_lambda_m'])),'100/150 exact501 spectral grids differ')
    out=dict(status='OFFLINE_PROFILE_COMPARISON_ONLY_NO_PHYSICS_PASS',canonical='Production N98*pitch crop/envelope FWHM; supplemental crops do not replace it',
        stages=stages,changes_150_minus_100={},same_bin_W_lambda_changes=[],
        qualification=['No new solve, temporal convergence threshold or gradient approval.',
            'N80 crop is measurement truncation of the same N98 field; no physical N80 geometry or speedup has been tested.',
            'Widths are evaluated at actual separate Tout/modal tracked wavelengths; same-bin nearby tables supplement these moving-wavelength comparisons.'])
    for name in ('Tout','modal'):
        for k in ('monitor_x_m','y_m','x_um'):need(np.array_equal(grids[100][name][k],grids[150][name][k]),'100/150 spatial grids differ: '+name+'/'+k)
        a=stages[100]['profiles'][name];b=stages[150]['profiles'][name]
        out['changes_150_minus_100'][name]=dict(FWHM_um=b['canonical_production_N98']['FWHM_um']-a['canonical_production_N98']['FWHM_um'],sigma_um=b['canonical_production_N98']['sigma_um']-a['canonical_production_N98']['sigma_um'],selected_lambda_nm=b['monitor_sampled_lambda_nm']-a['monitor_sampled_lambda_nm'],target_lambda_nm=b['target_nm']-a['target_nm'],index100=a['original_monitor_frequency_index'],index150=b['original_monitor_frequency_index'])
        out['changes_150_minus_100'][name]['supplemental_measurement_crops']={k:dict(FWHM_um=b['supplemental_crops'][k]['FWHM_um']-v['FWHM_um'],sigma_um=b['supplemental_crops'][k]['sigma_um']-v['sigma_um']) for k,v in a['supplemental_crops'].items()}
    x={r['index']:r for r in stages[100]['nearby_W_lambda']};y={r['index']:r for r in stages[150]['nearby_W_lambda']}
    for k in sorted(set(x)&set(y)):
        need(x[k]['lambda_nm']==y[k]['lambda_nm'],'100/150 nearby wavelength grid differs')
        out['same_bin_W_lambda_changes'].append(dict(index=k,lambda_nm=x[k]['lambda_nm'],FWHM_change_um=y[k]['FWHM_um']-x[k]['FWHM_um'],sigma_change_um=y[k]['sigma_um']-x[k]['sigma_um']))
    return out


def mat_export(path,result,stored_arrays,eng):
    """Exclusive processed-data MAT export; no raw E keys are included."""
    from scipy.io import savemat
    need(not Path(path).exists(),'MAT destination exists; preserve original')
    payload={}
    fields=('x_um','I_y_integrated','envelope_y_integrated','y_m','wy_m','monitor_x_m','monitor_I_y_integrated')
    columns=['index','lambda_nm','FWHM_um','sigma_um','floor','peak','half_level','left_crossing_um','right_crossing_um']
    for d in (100,150):
        prefixes=['Tout','modal']+['nearby_bin_'+str(row['index']) for row in result['stages'][d]['nearby_W_lambda']]
        keep={prefix+'__'+field:stored_arrays[d][prefix+'__'+field] for prefix in prefixes for field in fields}
        for prefix in prefixes:
            full_x=np.asarray(stored_arrays[d][prefix+'__monitor_x_m']).ravel();full_I=np.asarray(stored_arrays[d][prefix+'__monitor_I_y_integrated']).ravel()
            keep[prefix+'__monitor_envelope_y_integrated']=eng.extract_envelope_peaks(full_x*1e6,full_I)
            for label,extent in [('native_N98_end',98*PITCH_NM/1000+PITCH_NM/4000),('N80_measurement_crop',80*PITCH_NM/1000)]:
                _,mask,envelope=crop_stats(eng,full_x,full_I,extent)
                keep[prefix+'__'+label+'__x_um']=full_x[mask]*1e6
                keep[prefix+'__'+label+'__I_y_integrated']=full_I[mask]
                keep[prefix+'__'+label+'__envelope_y_integrated']=envelope
        keep['monitor_lambda_m']=stored_arrays[d]['monitor_lambda_m']
        payload['profiles'+str(d)]=keep
        table=result['stages'][d]['nearby_W_lambda']
        payload['W_lambda'+str(d)]=np.asarray([[row['index'],row['lambda_nm'],row['FWHM_um'],row['sigma_um'],row['floor'],row['peak'],row['half_level'],*row['half_level_crossings_um']] for row in table],float)
    payload['W_lambda_columns']=np.asarray(columns,dtype=object)
    units=dict(x_um='um',FWHM_um='um',sigma_um='um',lambda_nm='nm',monitor_x_m='m',y_m='m',wy_m='m',monitor_lambda_m='m',
        I_y_integrated='unchanged exported integral_y of sum(abs(E_components)^2); no renormalization',envelope_y_integrated='same units as I_y_integrated')
    metadata=dict(processed_data_only=True,no_raw_E=True,units=units,report_json_excludes_own_MAT_sha256=True)
    payload['metadata_json']=json.dumps(metadata,allow_nan=False)
    payload['report_json']=json.dumps(result,allow_nan=False)
    with Path(path).open('xb') as stream:savemat(stream,payload,do_compression=True,oned_as='column',long_field_names=True)
    return dict(path=str(Path(path).resolve()),sha256=sha(Path(path).read_bytes()),**metadata)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('repo','evidence-dir','output'):p.add_argument('--'+k,required=True)
    for d in (100,150):
        for k in ('report','report-sha256','npz','npz-sha256'):p.add_argument('--'+k+str(d),required=True)
    p.add_argument('--mat-output')
    a=p.parse_args();repo=Path(a.repo).resolve();ev=Path(a.evidence_dir)
    need(not Path(a.output).exists(),'Report destination exists; preserve original')
    if a.mat_output:need(Path(a.output).resolve()!=Path(a.mat_output).resolve() and not Path(a.mat_output).exists(),'MAT/report destination exists or collides')
    need(sha((repo/'runners/lumopt2_design/lumopt2_design.py').read_bytes())==ENGINE_SHA,'Pinned engine changed')
    sys.path.insert(0,str(repo));from runners.lumopt2_design import lumopt2_design as eng
    from runners.lumopt2_design import recover_te_s2 as recovery
    stages={};grids={};pins={};rows={};stored_arrays={}
    for d in (100,150):
        report=json_pin(getattr(a,'report'+str(d)),getattr(a,'report_sha256'+str(d)))
        raw=pinned(getattr(a,'npz'+str(d)),getattr(a,'npz_sha256'+str(d)));arrays=npz(raw);stored_arrays[d]=arrays
        need(sha(raw)==report['stages'][str(d)]['profile_npz_sha256'],'Report/NPZ binding differs')
        cp=ev/('s2_temporal100_task00_original.json' if d==100 else 's2_temporal150_fetch_1434/s2_temporal150_task03_original.json')
        row=json_pin(cp,CP_SHA[d]);rows[d]=row
        for name,digest in row['identity']['code'].items():
            rel=Path(name) if name in ('config.py','bragg_device.py','simulation_config.py','sim_helpers.py') else Path('runners/lumopt2_design')/name
            need(sha((repo/rel).read_bytes())==digest,'Frozen dependency differs: '+name)
        pp=ev/('s2_temporal100_task00_ports.npz' if d==100 else 's2_temporal150_fetch_1434/s2_temporal150_task03_ports.npz')
        ports=npz(pinned(pp,row['result']['ports_sha256']));scores=recovery.score(ports)
        need(all(abs(scores[k]-row['result'][k])<=1e-12 for k in scores),'Exact original port scores not reproduced')
        stages[d],grids[d]=stage(report,d,row,arrays,ports,eng);pins[d]=dict(report_sha256=getattr(a,'report_sha256'+str(d)),profile_npz_sha256=sha(raw),original_checkpoint_sha256=CP_SHA[d],ports_sha256=row['result']['ports_sha256'])
    need(rows[100]['identity']['point']==rows[150]['identity']['point'] and rows[100]['identity']['spec']==rows[150]['identity']['spec'],'100/150 nominal geometry/spec differs')
    result=combine(stages,grids);result['source_pins']=pins
    if a.mat_output:result['MAT_export']=mat_export(a.mat_output,result,stored_arrays,eng)
    with Path(a.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
    print('Spatial comparison saved; canonical production widths retained, no physics verdict')


if __name__=='__main__':main()
