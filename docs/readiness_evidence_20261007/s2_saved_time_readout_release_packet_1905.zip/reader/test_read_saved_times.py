"""Focused offline guards and fresh-session inventory/export; no CAD/network."""
import copy,json,re,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import read_saved_times as a
OUT=Path(__file__).parent
class Fake:
 def __init__(self):
  self.data={k:np.ones((1,1,1,12))*j for j,k in enumerate(['Ex','Ey','Ez','Hx','Hy','Hz'],1)};self.data.update(t=np.arange(12.)[:,None]*1e-15,x=np.array([[1e-6]]),y=np.array([[0.]]),z=np.array([[0.]]));self.vars={};self.calls=[]
 def getdata(self,name):self.calls.append(('names',name));return '\n'.join(self.data)
 def getnamednumber(self,name):return 1
 def havedata(self,name):return 1
 def getnamed(self,obj,key):
  if key=='enabled':return 1
  if key=='sampling rate':return 1e15
  raise RuntimeError('SYNTHETIC_UNSUPPORTED:'+key)
 def getglobalsource(self,key):return 192e12
 def eval(self,script):
  self.calls.append(('eval',script));m=re.search("getdata\\('([^']+)','([^']+)',2\\)",script);value=self.data[m[2]]
  if 'tt_shape' in script:self.vars['tt_shape']=np.asarray(value.shape)
  else:self.vars['tt_value']=value
 def getv(self,name):return self.vars[name]
 def close(self):pass
class Tests(unittest.TestCase):
 def cad(self,raw=None):return a.TimeCAD(raw or Fake(),OUT/'SYNTHETIC_SOURCE.fsp')
 def test_no_solve_no_save_wrongload_and_unregistered_access(self):
  cad=self.cad()
  for method in ['run','runjobs','runanalysis','runparallel','save','setnamed','addjob','system','feval']:
   with self.assertRaises(RuntimeError):getattr(cad,method)()
  for script in ['run;','save("old.fsp");','tt_value=getdata("other","Ex");']:
   with self.assertRaises(RuntimeError):cad.eval(script)
  with self.assertRaises(RuntimeError):cad.load(OUT/'OTHER_SOURCE.fsp')
  with self.assertRaises(RuntimeError):cad.value('field_profile','Ex')
  with self.assertRaises(RuntimeError):cad.getv('tt_raw')
 def test_inventory_then_CLOSE_NEWSESSION_export_registry(self):
  old=self.cad();row=a.inventory(old,'time_cavity',1024);old.close();fresh=self.cad()
  self.assertEqual(fresh.observed,{})
  output=a.transfer(fresh,{'time_cavity':row},{'time_cavity':['Ey']});self.assertEqual(output['time_cavity__Ey'].size,12);self.assertEqual(output['time_cavity__t_s'].size,12)
  self.assertIn(('names','time_cavity'),fresh.raw.calls);self.assertFalse(any(name=='tt_raw' for name in fresh.raw.vars))
  self.assertEqual(row['properties']['minimum sampling per cycle']['available'],False)
 def test_missing_duplicate_and_oversize_time_axis(self):
  raw=Fake();raw.data.pop('t');self.assertEqual(a.inventory(self.cad(raw),'time_input',1024)['status'],'TIME_AXIS_MISSING')
  raw=Fake()
  with patch.object(raw,'getdata',return_value='t t Ex'):
   with self.assertRaises(RuntimeError):self.cad(raw).names('time_input')
  with self.assertRaises(RuntimeError):a.inventory(self.cad(),'time_input',8)
  for t in [np.array([0.,1.,1.]),np.array([0.,2.,1.]),np.array([0.,np.nan]),np.ones((2,2))]:
   with self.assertRaises(RuntimeError):a.validate_times(t)
 def test_components_shape_nonfinite_and_byte_cap(self):
  cad=self.cad();row=a.inventory(cad,'time_input',1024);rows={'100':{'time_input':row},'150':{'time_input':row},'200':{'time_input':row}}
  estimate=a.export_estimate(rows,{'time_input':['Ey']});self.assertEqual(estimate,3*12*24)
  with self.assertRaises(RuntimeError):a.need(estimate<=256,'BEFORE transfer byte cap')
  bad=copy.deepcopy(row);bad['component_shapes'].pop('Ey')
  with self.assertRaises(RuntimeError):a.export_estimate({'100':{'time_input':bad}},{'time_input':['Ey']})
  with self.assertRaises(RuntimeError):a.selection(['time_input:Ey','time_input:Ey'])
  with self.assertRaises(RuntimeError):a.selection(['time_input:all'])
  for value,shape in [(np.ones((3,4)),(3,4)),(np.full((12,),np.inf),(12,)),(np.ones((11,)),(12,))]:
   with self.assertRaises(RuntimeError):a.validate_component(value,shape,12)
 def test_wrong_checkpoint_pin_and_frozen_validator_source(self):
  path=OUT/'SYNTHETIC_BAD_CP.json';path.write_text('{}')
  with self.assertRaises(RuntimeError):a.load_center(path,200)
  self.assertEqual(a.sha(a.io.__file__),a.IO_SHA)
 def test_generated_scripts_compile_restricted_to_observed_names(self):
  import ast
  ast.parse(Path(a.__file__).read_text());cad=self.cad();cad.names('time_input');cad.shape('time_input','Ey');cad.value('time_input','Ey')
  for script in cad.scripts:
   self.assertIn("getdata('time_input','Ey',2)",script);self.assertNotIn('run(',script);self.assertNotIn('save(',script)
  with self.assertRaises(RuntimeError):cad.shape('time_input','UNOBSERVED')
  settings=a.source_settings(cad);self.assertEqual(settings['Port1']['override global source settings']['available'],False);self.assertIn('not measured trace bandwidth',settings['qualification'])
if __name__=='__main__':unittest.main(verbosity=2)
