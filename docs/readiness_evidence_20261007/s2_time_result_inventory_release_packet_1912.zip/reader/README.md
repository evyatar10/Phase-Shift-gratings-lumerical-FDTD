# Alternate time-result API inventory (preparation only)

This NEW packet answers only whether saved100/150/200 center time monitors expose E/H through `getresult` despite raw `getdata` listing no field components. Original runtime0210 and CPU171516 report are untouched. No CAD, network or solve was executed during preparation. Four focused offline groups pass, exit0 (`offline_tests.log`).

Runtime files: `inventory_time_results.py`, byte-identical released0210 copied as `frozen_time_io.py`, and unchanged994c `frozen_profile_io.py`. All original loader CP/geometry/source/vendor/artifact pins remain strict; the new main repeats before/after immutable-input and official FDTD class/constructor checks. Both loader hashes are enforced before CAD. Exact CP-declared FSP/H5/ports paths are retained.

Each hidden center session inventories the original raw names/t/coordinates and actual sampling fields, then reads `getresult(monitor)` names, `haveresult(monitor,'E'/'H')`, and six `output Ex/Ey/Ez/Hx/Hy/Hz` properties. Only if availability is exactly1 does it ask the dataset's attribute/parameter names and supported member shapes. E/H datasets and component values stay inside CAD; Python receives metadata only. The fixed whitelisted scripts use `getresult`, `getattribute`, `getparameter`, and `size`; full dataset Python getters, field transfers, arbitrary scripts, solving and saving are refused. No export CLI exists.

Shape queries cover x/y/z/t, vector E or H, and their scalar components. Unsupported members retain exact errors; result t count must match the separately finite/monotonic validated raw t if both exist. No missing result/component is silently converted to success. Exit0 means inventory collection only, including explicitly unavailable items; it is not a finite-field, sampling, convergence, calibration or causal pass. The GPU interpolation warning alone does not prove absence of fields.

## Parent-owned CPU invocation

Upload only the three runtime files to a new private helper directory. Use the exact existing vendor API/repo paths from the previous readout wrapper and fresh exclusive output. Preserve raw CP bytes (copies are allowed only with identical SHA):

```bash
python -B /work/scripts/NEW_RESULT_INVENTORY/inventory_time_results.py \
 --repo /work/scripts --lumapi ACTUAL_PINNED_LUMAPI_PATH \
 --checkpoint100 /work/results/diagnose_te_s2_temporal/results/s2_shift30_temporal_20261007/task_00.json \
 --checkpoint150 /work/results/diagnose_te_s2_temporal/results/s2_shift30_temporal_20261007/task_03.json \
 --checkpoint200 /work/results/diagnose_te_s2_temporal200/results/s2_shift30_temporal200_20261007/task_00.json \
 --output /work/results/NEW_EXCLUSIVE_TIME_RESULT_INVENTORY
```

Required NumPy/SciPy/official lumapi are unchanged; h5py is unnecessary. A CPU allocation matching the earlier readout's reviewed RAM allowance avoids guessing saved-project load cost; no GPU/FDTD request is needed. Dataset materialization stays in CAD but may cost more than raw-axis readout. Previous32-second failure is not a promised runtime for this alternate API. Parent owns preflight, release and dispatch; real API execution remains the host gate.

Offline: `python -B -m unittest -v test_inventory_time_results` in this packet. No generated LSF was executed by the fake API tests.

API basis: [getresult](https://optics.ansys.com/hc/en-us/articles/360034409854-getresult-Script-command), [getattribute](https://optics.ansys.com/hc/en-us/articles/360034409534-getattribute-Script-command), [getparameter](https://optics.ansys.com/hc/en-us/articles/360034409514-getparameter-Script-command), [GPU guidance](https://optics.ansys.com/hc/en-us/articles/17518942465811-Getting-started-with-running-FDTD-on-GPU). These document API behavior; they do not prove these particular saved datasets exist.
