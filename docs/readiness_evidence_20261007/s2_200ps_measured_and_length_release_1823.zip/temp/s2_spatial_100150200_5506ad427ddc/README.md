# Pinned100/150/200 spatial reader

NEW TEMP preparation only. No network,CAD,FDTD or repository edits. Current100/150 archived reader4cb6276f andreferenceJSONbd523d are byte-preserved from docs/readiness_evidence_20261007/s2_spatial_comparison_verified_1558.zip. Frozen extractor36ff/helper994c are copied without edits for pure metadata validation only. Engine53108 width functions remain exact.

Five focused tests and CLIhelp exit0. Actual100/150 history is reproduced EXACTLY,including every previous non-MAT metric and sourcepin; untouched original referenceJSON is retained in history100150. Old MATlocation/hash remain historical references,not a claim that the new compactMAT is byte-identical. NewMAT retains exactprocessed arrays and explicit units/no rawE; actualMAT read-back validates arrays/tables exactly.

Future200 inputs require independent CP/report/NPZ/receipt SHA256 values; original200ports NPZ is byte-bound to CP. Pure frozenextractor metadata validator ties200task00 to releasedmarker4fe3 andpinned150centerA0; complete extraction/class/constructor/input-preservation receipts are required. Allsource andvendor entries must appear in original200extractor rechecks. See RECEIPT_SCHEMA.md: lead must construct exact actualproducer/runtime/report/NPZ receipt from serverdispatch/fetch evidence,not merely declare producer identity. Original extractor remains frozen.

Reader exports same-point Tout/modal productioncrop/envelope FWHM,sigma,floor/peak/halflevel/crossings,endpoints,actualtracked wavelengths,nearbyW(lambda) tables/spread,100->150->200 trackedchanges and same-bin nearbychanges. It enforces exact501 spectral andspatial grids. Moving-wavelength comparisons are distinguished from common-bin differences. No convergence/noise/gradient pass,newwidthband orphysicalN80 conclusion is inferred.

Testspositive200fixtures explicitly copy150processeddata/ports and retag SYNTHETIC200 metadata solely for protocol/math. Those are NOT actual200physics. Outputs retain SYNTHETIC200_NOT_MEASURED in JSON/MATmetadata. Negative tests cover receiptproducer/paths/status/class/hash/CP-role/grid/intensity/nearby support. Earlier core9tests andfulloldaudits were not rerun.

Actualhistory CLI (new outputpaths):
```powershell
python -B compare_three_durations.py --repo C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes --evidence-dir C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007 --history-dir C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007/s2_saved_profiles_fetch_154823 --history-only --output C:/NEW_TEMP/history.json --mat-output C:/NEW_TEMP/history.mat
```

Foractualthree-duration analysis omit --history-only and add --checkpoint200 <actual_local_originalCP> --checkpoint-sha256200 <independent_rawCP_SHA> --ports200 <actual_originalportsNPZ> --report200 <actual_reportJSON> --report-sha256200 <independent_rawreport_SHA> --npz200 <actual_profiles200NPZ> --npz-sha256200 <independent_rawNPZ_SHA> --receipt200 <actual_receiptJSON> --receipt-sha256200 <independent_rawreceipt_SHA>. Alloutput/MAT paths must be new,absolute anddistinct. Actual200was pending during preparation; rootowns receipt,retrieval andinterpretation.
