# Measured same150ps curve check

NEW TEMP only, offline. No network, CAD, simulation, repository edits, calibration or objective change. The immutable review/spectra1601 SHA pins are in the runtime and final report. Parent's previously strict CP/NPZ provenance is retained verbatim; this bounded follow-up checks measured curves and new arithmetic, not another full ancestry audit.

Runtime: measured_curve_check.py. Output: measured_curve_report_final.json. First preliminary report remains preserved separately. Five focused tests pass exit0; tests_final.log records their actual output. The production engine SHA is checked, only its pure peak3 function is used, and make_project/import_lumopt2 are explicitly blocked.

The 42 flank bins are offsets -30..-10 and +10..+30 from each observable's own center: Tout252,modal250. Tout FD relative L2 difference is0.572626%, maximum symmetric per-bin difference1.113878%; modal0.597064%,maximum1.204043%. Every flank FD sign matches. Odd numerator scaling Nlarge/(2Nsmall) is0.988923..1.001084 Tout and0.988032..1.001736 modal. This is measured agreement on these flanks, not a new gate or validation of the small peak-height gradient.

Near-zero reporting uses5% of the global maximum FD only as a descriptive cutoff; no physics/noise threshold is inferred. The sole central small bins are Tout252:small-.00723633,large-.00780832,difference-.000571989 pernm; modal250:small+.00702417,large+.00790096,difference+.000876795 pernm. Their relative percentages and odd ratios are omitted.

Two-step Richardson (4Dsmall-Dlarge)/3 is CONDITIONAL on a smooth common h^2 leading-error model. Peak3 estimates are-.000141788 Tout and-.000134399 modal pernm. The corrections vs smaller step are7.81889% and17.89866%. Fixed-center J projections yield conditional-.000244439 Tout and+.00000706186 modal,corrections45.4844% and97.8831%. None is an error bound, measured asymptotic order or proof of nonasymptotic behavior.

Optional interpolation counterfactual translates the measured center CubicSpline by measured spline peak shifts, preserving its amplitude/shape. It uses the SAME production peak3 on the common finite domain without extrapolation; the crop is verified not to change the measured peak3. This is not ground truth or a noise diagnostic. Counterfactual Tout derivatives are-.0000119895 and-.0000135865 pernm vs measured-.000153815 and-.000189895. Modal counterfactual+.0000106987 and+.0000276001 vs measured-.000163699 and-.000251599. It does not reproduce measured peak-height derivatives. Measured shift ratios to twice the smaller-step shift range0.998629..1.001860.

No recommendation here converts an even term to a noise floor, frequency-bin spacing to linewidth, a fixed-center J projection to an adjoint, or finite-duration frequency-domain adjoints to automatically exact gradients. Temporal convergence and existing calibration status remain unresolved. No new10% gate or solve-seat count is introduced.
