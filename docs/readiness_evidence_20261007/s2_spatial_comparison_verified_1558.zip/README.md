# Saved 100/150 ps spatial-profile comparison

Final reader `compare_profiles.py`, SHA 4cb6276f2d8bb2efa20e76ce2643a34014f391758bd7ff375603d87e81b9ec35. TEMP-only offline implementation: no CAD/server/solve/repository edits. Source pin was saved before actual execution. Extractor source 994c3e9757a10b5bd8ea211aaee8425c5d3540203a4da04b0439684163baf6ca is bound in actual validation and parent's preserved transport. Actual CPU 171300 extraction completed 0:0, no FDTD; this reader generated no solver evidence.

Run in this directory:

```powershell
python -B test_profiles.py
python -B reproduce_actual.py --output-prefix C:/Users/evyat/AppData/Local/Temp/s2_spatial_duration_comparison_f42_di0g/parent_reproduction
```

This creates NEW `parent_reproduction.json` and `.mat`, refusing overwrite. The reproducer verifies parent `pins.json` SHA ea650471e70e426373a75074520d64836bd21c6d87066e6f89869187257f33cf and calls the strict reader with both report/NPZ paths and hashes supplied as CLI arguments. For other reviewed files, use `compare_profiles.py --help`; required options are `--repo --evidence-dir --report100 --report-sha256100 --npz100 --npz-sha256100 --report150 --report-sha256150 --npz150 --npz-sha256150 --output`; optional `--mat-output` must also be NEW. A combined extractor report may be used for both duration options, as in this actual case.

Actual original inputs at `docs/readiness_evidence_20261007/s2_saved_profiles_fetch_154823/`:
- report.json SHA 01a6fe6540c7cf903de67cecc42a89c6318983301364b679b9da0870dede595a
- profiles_100ps.npz SHA e23127424d3783442b14595fc054b479c8dfaa8161a7165b0e537068d6db8612
- profiles_150ps.npz SHA bbf660c8d4d2d628bd4eae0a1aac4e9a9883bb12388ed51ee2aadf71dfcc3d27
- exact 100 ps original CP 38dcd852f7bcb5e2ef7bb27cb4085257a5b70098d146e41d73b8038180d72f49 and 150 ps original CP a0ff55eacaa52e00a2aab17dcc43d0e5fff9a72566e15da371ff25279c172663 are pinned in reader.

Guards: complete no-solve report, all original inputs/rechecks preserved, unmodified FDTD identity, exact CP/task/point/family and frozen sources, actual pinned port scores/selected wavelengths, exact 501 profile/port and cross-duration wavelength grids, actual profile spatial coordinate inventory, production crop/integral/envelope and saved width/sigma reproduction, complete nearby peak+/-3-bin support. No coefficient fit, renormalization, automatic convergence threshold or scientific approval. Envelope roundoff bound 128eps and scalar reproduction tolerance 1e-12 are stated arithmetic checks, not inferred hardware noise bounds.

Canonical widths use production N98*pitch crop and production peak envelope/min-relative halflevel. Sigma uses the production second moment of integrated intensity. Supplemental nativeN98-end and N80 windows recrop the SAME full raw y-integrated intensity; they do not change physical geometry.

MAT variables: `profiles100`, `profiles150` hold full monitor x/intensity/envelope, canonical cropped x/intensity/envelope/y/weights, nativeN98-end and N80-measurement-crop x/intensity/envelope, and nearby-bin versions. `W_lambda100/150` plus `W_lambda_columns` preserve the nearby frequency-index/lambda/FWHM/sigma/floor/peak/halflevel/crossings tables. `metadata_json` records units/no-raw-E; `report_json` preserves comparison metadata and input hashes, excluding its own MAT hash to avoid circularity. x_um/FWHM/sigma/crossings are um; monitor_x/y/wy/monitor_lambda are m; tablelambda is nm. Intensity values keep extractor units without normalization. Raw E is not exported. MAT-header timestamps can vary across reproductions; validate payload/source identities.

Final outputs: `actual_comparison_v2.json`, `actual_comparison_v2.mat`, `REPORT.md`, `validation_actual_v2.json`, `package_hashes.json`. Prior tested version/results remain intact. Seven tests and actual reader exit 0; all 156 original NPZ arrays and 154 additional processed arrays roundtrip exactly, reportJSON exact and coordinate units verified. Synthetic MAT fixtures are clearly isolated under mat_roundtrip_*; they are not measured profiles.
