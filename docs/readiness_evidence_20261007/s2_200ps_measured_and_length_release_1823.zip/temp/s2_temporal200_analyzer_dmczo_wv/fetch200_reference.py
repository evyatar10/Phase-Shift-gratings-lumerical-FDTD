"""Prepared strict read-only completion fetch; actual launch inputs required.

Preparation does not contact servers. CLI later performs only accounting/read
checks, cold runner verification with CAD/solve blocked, and exclusive local
publication of original checkpoint/NPZ bytes. Only released job171390 is eligible; no dispatch or fallback.
"""
import argparse
import base64
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys

sys.dont_write_bytecode = True
TASKS = (0, 1, 2)
MODULE = 'runners.lumopt2_design.s2_temporal200_forward'
RUNNER_SHA = 'fa6a6528e34cb9c004604ec490543c3b0579d76224c936568c2e11e4f9996053'
BASE_SHA = '555f3d13b42c494171e7658cc4263c588ce418e5d937da1497d690824b41d44a'
CENTER_SHA = 'a0ff55eacaa52e00a2aab17dcc43d0e5fff9a72566e15da371ff25279c172663'
PARENT_MARKER_SHA = '6cc6d9fd8cab5419b436b433725fbb2cc88b49f538628f897929217940527f51'
PARENT_CHECKPOINT_SHA = {
    '3': CENTER_SHA,
    '4': '31ec8f2f72bfb1a5aa991240cec45c5fb515d18e82fc37d7cfac89703e75efe4',
    '5': 'a0e9d73a0f8f0162c9f7a843ca24eb4c4c29e444b1fca2b692ffd5002feb571d'}
FAMILY = 's2_shift30_temporal200_20261007'
OUTPUT_ROOT = '/work/results/diagnose_te_s2_temporal200/results/'+FAMILY
PARENT_ROOT = '/work/results/diagnose_te_s2_temporal/results/s2_shift30_temporal_20261007'
PARENT_MARKER = '/work/data/s2_temporal150_review_20261007_1257.json'
STATUS = 'APPROVED_FOR_THREE_FIXED200PS_CENTER_SHIFT30_STEP00625_FORWARDS_ONLY'
JOB_ID = '171390'
MARKER = '/work/data/s2_temporal200_review_20261007_1619.json'
MARKER_SHA = '4fe3c0e7fc37cced733ac7cf7b2ee3de3536213ee938e23a1095dffc307cd44f'
STEP_SHA = 'c41f522e8502598c4b8a3d4a4096baf094ede8a1c66763169992fbc82d696c8a'
STEP_ROOT = '/work/results/diagnose_te_s2_step150/results/s2_shift30_step150_20261007'
STEP_MARKER = '/work/data/s2_step150_review_20261007_1507.json'
STEP_MARKER_SHA = '8cc8e9da52262b19f4fd51d98c11de1a686c7e61b8c8bf2b364944922677dc0f'
PINS_SHA = 'e41306fab70bd616a53d30d656b7192d385e0f1c84c1d5bb1e859d78e6a3fa44'
PINS_RAW = Path(__file__).with_name('release_scope_pins.json').read_bytes()
if hashlib.sha256(PINS_RAW).hexdigest() != PINS_SHA:raise RuntimeError('Frozen release scope pins changed')
PINS = json.loads(PINS_RAW)
REQUIRED_ENV = {'S2_TEMP200_REPO','S2_TEMP200_OUTPUT_ROOT','S2_TEMP200_PARENT150_ROOT',
                'S2_TEMP200_PARENT150_MARKER','S2_TEMP200_STEP150_ROOT','S2_TEMP200_STEP150_MARKER',
                'S2_TEMP200_REVIEW_MARKER','S2_TEMP200_REVIEW_SHA256','KEEP_H5'}
MAX_BYTES = 67108864
METRICS = {'fom', 'peak3_tout', 'peak3_modal', 'lam_nm', 'modal_t', 'width_nm',
           'tout_at_modal_peak', 'p1_T_in'}


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def sha_string(value):
    return isinstance(value, str) and re.fullmatch(r'[a-f0-9]{64}', value) is not None


def validate_inputs(job_id, marker, marker_sha, env):
    need(job_id == JOB_ID,
         'Only released job171390 is eligible')
    need(isinstance(marker, str), 'Caller must provide the actual marker path')
    path = PurePosixPath(marker)
    need(path.is_absolute() and '..' not in path.parts and
         path.is_relative_to('/work/data') and path.suffix == '.json' and str(path) == marker,
         'Normalized absolute /work/data marker JSON path required')
    need(marker == MARKER and marker_sha == MARKER_SHA,'Exact released200 marker path/byte SHA required')
    need(isinstance(env, dict) and set(env) == REQUIRED_ENV and env['KEEP_H5'] == '1',
         'Exact S2_TEMP200 environment key set and KEEP_H5=1 required')
    expected = dict(S2_TEMP200_REPO='/work/project', S2_TEMP200_OUTPUT_ROOT=OUTPUT_ROOT,
                    S2_TEMP200_PARENT150_ROOT=PARENT_ROOT,
                    S2_TEMP200_PARENT150_MARKER=PARENT_MARKER,
                    S2_TEMP200_STEP150_ROOT=STEP_ROOT,S2_TEMP200_STEP150_MARKER=STEP_MARKER,
                    S2_TEMP200_REVIEW_MARKER=marker,
                    S2_TEMP200_REVIEW_SHA256=marker_sha, KEEP_H5='1')
    need(env == expected and marker != PARENT_MARKER,
         'Environment must equal actual new marker and exact frozen family/parent paths')
    return dict(env)


def completed_rows(accounting, job_id):
    need(isinstance(accounting, str), 'Accounting text required')
    rows = {}
    for line in accounting.splitlines():
        columns = [v.strip() for v in line.split('|')]
        if len(columns) < 3:
            continue
        key = columns[0]
        need(key not in rows, 'Duplicate accounting row: '+key)
        rows[key] = columns[1:3]
    actual_tasks = {int(match[1]) for key in rows
                    if (match := re.fullmatch(re.escape(job_id)+r'_([0-9]+)', key))}
    need(actual_tasks == set(TASKS) and
         all(rows.get(f'{job_id}_{task}') == ['COMPLETED', '0:0'] for task in TASKS),
         'All exact temporal200 array tasks0/1/2 must be COMPLETED exit0; no other array task')
    return rows


def scripts(job_id, marker, marker_sha, env):
    env = validate_inputs(job_id, marker, marker_sha, env)
    constants = dict(ENV=env, MARKER=marker, MARKER_SHA=marker_sha,
                     RUNNER_SHA=RUNNER_SHA, BASE_SHA=BASE_SHA, STEP_SHA=STEP_SHA, STATUS=STATUS, PINS=PINS)
    inner = ''.join(f'{key}={value!r}\n' for key, value in constants.items())+r'''
import os,json,sys,hashlib,pathlib
sys.dont_write_bytecode=True
if sys.flags.optimize:raise RuntimeError('Cold verification requires Python assertions enabled')
sys.path.insert(0,'/work/project');os.environ.update(ENV)
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
root=pathlib.Path(ENV['S2_TEMP200_OUTPUT_ROOT'])
for i in (0,1,2):assert (root/f'task_{i:02d}.json').is_file(),'All three completed checkpoints required before cold verification'
assert sha(MARKER)==MARKER_SHA,'Exact new review-marker byte SHA mismatch'
review=json.loads(pathlib.Path(MARKER).read_text())
assert review['family']=='s2_shift30_temporal200_20261007' and review['duration_ps']==200.
assert review['allowed_tasks']==[0,1,2] and review['status']==STATUS
assert review['step_nm']==.0625 and review['index']==149 and review['task_map']==[[.0625,0],[.0625,1],[.0625,-1]]
assert review['code']['s2_temporal200_forward.py']==RUNNER_SHA and review['base_helper_sha256']==BASE_SHA
assert sha('/work/project/runners/lumopt2_design/s2_temporal200_forward.py')==RUNNER_SHA,'Reviewed temporal200 runner changed'
assert sha('/work/project/runners/lumopt2_design/s2_temporal_forward.py')==BASE_SHA,'Frozen temporal helper changed'
assert sha('/work/project/runners/lumopt2_design/s2_temporal_step150.py')==STEP_SHA,'Frozen step150 helper changed'
assert all(review[k]==PINS[k] for k in ('family','code','vendor_api_sha256','spec','parent150','completed_step150')),'Released setup/ancestry/source/vendor pins changed'
import config
config.LUMAPI_PATH='/opt/lumerical/v261/api/python/lumapi.py';config.BASE_SAVE_DIR='/work/results'
config.NEFF_DATA_PATH='/work/data/FDE_sweep_results.mat';config.USE_GPU=True
from runners.lumopt2_design import s2_temporal200_forward as m
assert sha(m.__file__)==RUNNER_SHA
def forbid(*args,**kwargs):raise RuntimeError('Cold completion fetch cannot call main/CAD/solve')
m.main=forbid;m.forward_only=forbid;m.base.main=forbid;m.base.forward_only=forbid
m.step.main=forbid;m.step.forward_only=forbid
m.eng.make_project=forbid;m.eng.import_lumopt2=forbid
m.frozen_base();center=m.load_ancestry();assert m.root_path()==root
records=[]
for task in (0,1,2):
    cp=root/f'task_{task:02d}.json'
    checked_review=m.reviewed(task,root,center)
    identity=m.identity(task,center,checked_review)
    result=m.recovery.read_checkpoint(cp,identity)
    assert result is not None;m.verify_result(result,task,root,center,checked_review)
    assert checked_review['path']==MARKER and checked_review['sha256']==MARKER_SHA
    records.append(dict(task=task,checkpoint=str(cp),checkpoint_sha256=sha(cp),
        source=result['source'],ports=result['ports_npz'],ports_sha256=result['ports_sha256'],
        termination=result['termination'],fsp_sha256=result['fsp_sha256'],h5_sha256=result['h5_sha256'],
        metrics={key:result[key] for key in m.diag.METRICS},vendor_api_sha256=result['vendor_api_sha256'],
        control_sha256={key:result['controls'][key] for key in ('before_sha256','after_sha256','persisted_sha256')},
        parent_review=result['parent_review'],controls=result['controls'],
        cold_validation=dict(main_called=False,CAD_blocked=True,solve_blocked=True,runner_validator='read_checkpoint+verify_result')))
print(json.dumps(records))
'''
    constants = dict(INNER=inner, JOB_ID=job_id, ROOT=OUTPUT_ROOT,
                     MARKER=marker, MARKER_SHA=marker_sha, ENV=env,
                     RUNNER_SHA=RUNNER_SHA, BASE_SHA=BASE_SHA, STEP_SHA=STEP_SHA)
    remote = ''.join(f'{key}={value!r}\n' for key, value in constants.items())+r'''
import subprocess,json,pathlib,datetime,base64,hashlib,re,sys
if sys.flags.optimize:raise RuntimeError('Completion accounting requires Python assertions enabled')
b=pathlib.Path('/home/evyatarrubin/bragg_sim_athena')
r=subprocess.run(['sacct','-j',JOB_ID,'--format=JobID,State,ExitCode','-nP'],capture_output=True,text=True,timeout=20)
assert r.returncode==0,r.stderr
rows={}
for line in r.stdout.splitlines():
    v=[x.strip() for x in line.split('|')]
    if len(v)<3:continue
    assert v[0] not in rows,'Duplicate accounting row';rows[v[0]]=v[1:3]
actual={int(m[1]) for key in rows if (m:=re.fullmatch(re.escape(JOB_ID)+r'_([0-9]+)',key))}
assert actual=={0,1,2} and all(rows.get(f'{JOB_ID}_{i}')==['COMPLETED','0:0'] for i in (0,1,2)),r.stdout
def host_path(value):
    p=pathlib.PurePosixPath(value)
    assert p.is_absolute() and '..' not in p.parts and p.is_relative_to(ROOT),'Artifact outside exact temporal200 family'
    return b/pathlib.Path(str(p.relative_to('/work')))
for i in (0,1,2):assert host_path(ROOT+f'/task_{i:02d}.json').is_file(),'All three checkpoints required before container cold verification'
a=['apptainer','exec','--bind',str(b/'project')+':/work/project','--bind',str(b/'results')+':/work/results',
   '--bind',str(b/'data')+':/work/data','--bind',str(pathlib.Path.home()/'scilibs')+':/scilibs','--pwd','/work/project',
   str(pathlib.Path.home()/'containers/lumerical-2026R1.sif'),'env','LD_LIBRARY_PATH=/scilibs',
   '/opt/lumerical/v261/python/bin/python','-B','-c',INNER]
v=subprocess.run(a,capture_output=True,text=True,timeout=300);assert v.returncode==0,(v.stdout,v.stderr)
records=json.loads(v.stdout);assert [x['task'] for x in records]==[0,1,2]
data={}
for row in records:
    for role,expected_hash in [('checkpoint','checkpoint_sha256'),('ports','ports_sha256')]:
        value=row[role];p=host_path(value);assert 0<p.stat().st_size<=67108864,'Unexpected bulky artifact'
        raw=p.read_bytes();digest=hashlib.sha256(raw).hexdigest()
        assert digest==row[expected_hash],'Artifact changed after cold verification'
        data[f"{row['task']}:{role}"]=dict(path=value,sha256=digest,bytes=len(raw),data=base64.b64encode(raw).decode())
print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),job_id=JOB_ID,
    review_marker=MARKER,review_marker_sha256=MARKER_SHA,environment=ENV,
    family='s2_shift30_temporal200_20261007',runner_sha256=RUNNER_SHA,base_helper_sha256=BASE_SHA,step150_helper_sha256=STEP_SHA,
    accounting=r.stdout,verified_records=records,files=data)))
'''
    return inner, remote


def validate_payload(payload, job_id, marker, marker_sha, env):
    env = validate_inputs(job_id, marker, marker_sha, env)
    need(payload.get('job_id') == job_id and payload.get('review_marker') == marker and
         payload.get('review_marker_sha256') == marker_sha and payload.get('environment') == env,
         'Response actual job/marker/environment identity mismatch')
    need(payload.get('family') == FAMILY and payload.get('runner_sha256') == RUNNER_SHA and
         payload.get('base_helper_sha256') == BASE_SHA and payload.get('step150_helper_sha256') == STEP_SHA, 'Response frozen runner/family mismatch')
    completed_rows(payload['accounting'], job_id)
    records = payload['verified_records']
    need(all(type(r['task']) is int for r in records) and
         [r['task'] for r in records] == list(TASKS), 'Verified task list must equal0/1/2')
    expected = {f'{task}:{role}' for task in TASKS for role in ('checkpoint', 'ports')}
    need(set(payload['files']) == expected, 'Response artifacts missing/off-family')
    decoded = {}
    root = PurePosixPath(OUTPUT_ROOT)
    for key, item in payload['files'].items():
        task, role = key.split(':'); task = int(task)
        remote = PurePosixPath(item['path'])
        need(remote.is_absolute() and '..' not in remote.parts and remote.is_relative_to(root)
             and str(remote) == item['path'], 'Response artifact escaped exact family')
        if role == 'checkpoint':
            need(remote == root/f'task_{task:02d}.json', 'Response checkpoint path mismatch')
        else:
            need(remote.name == 'ports.npz' and remote.parent.name.startswith(f'task_{task:02d}_'),
                 'Response port file is outside unique task attempt')
        raw = base64.b64decode(item['data'], validate=True)
        need(type(item['bytes']) is int and 0 < len(raw) <= MAX_BYTES and
             len(raw) == item['bytes'] and digest(raw) == item['sha256'],
             'Response byte count/hash mismatch')
        decoded[key] = raw
    for record in records:
        task = record['task']; sign = (0,1,-1)[task];index=29 if task==0 else 149
        row = json.loads(decoded[f'{task}:checkpoint']); identity, result = row['identity'], row['result']
        point=list(PINS['point']);point[index]+=sign*.0625
        need(type(identity['task']) is int and type(result['task']) is int and
             identity['task'] == result['task'] == task and
             identity['duration_ps'] == result['duration_ps'] == 200. and
             identity['index'] == result['index'] == index and
             identity['sign'] == result['sign'] == sign and
             identity['delta_nm'] == result['delta_nm'] == sign*.0625 and
             identity['task_map'] == [[.0625,0],[.0625,1],[.0625,-1]] and
             identity['point'] == result['params'] == point and identity['spec'] == PINS['spec'] and
             identity['code'] == PINS['code'] and
             identity['center_checkpoint'] == PARENT_ROOT+'/task_03.json' and
             identity['center_sha256'] == result['reviewed_center_sha256'] == CENTER_SHA,
             'Transferred checkpoint point/200ps/family/source/center identity mismatch')
        review=result['parent_review']
        need(review['path']==marker and review['sha256']==marker_sha and review['allowed_tasks']==[0,1,2]
             and isinstance(review['lead_verdict'],str) and review['lead_verdict'].strip() not in ('','NOT_REVIEWED')
             and record['parent_review']==identity['parent_review']==review and
             identity['parent150']==review['parent150']==PINS['parent150'] and
             identity['completed_step150']==review['completed_step150']==PINS['completed_step150'],
             'Transferred reviewed marker/all five ancestry bindings mismatch')
        need(record['cold_validation']==dict(main_called=False,CAD_blocked=True,solve_blocked=True,runner_validator='read_checkpoint+verify_result')
             and record['controls']==result['controls'],'Transferred cold validation/actual controls mismatch')
        term=result['termination'];dt=float(result['controls']['dt_s'])
        need(term['status']==1 and term['reason']=='completed_full_simulation_time' and
             term['requested_time_s']==200e-12 and math.isfinite(term['physical_time_s']) and
             math.isfinite(dt) and dt>0 and abs(term['physical_time_s']-200e-12)<=dt and
             sha_string(term['log_sha256']),'Transferred200ps full-duration/status/log mismatch')
        after=result['controls']['after']
        need(after['timing']['simulation time']==200e-12 and after['timing']['use early shutoff']==0 and
             after['timing']['use divergence checking']==1 and after['optimization_dft_enabled']==0,
             'Transferred200ps timing/DFT/divergence changed')
        need(result['comparison_status'] == 'TEMPORAL200_DIAGNOSTIC_REVIEW_REQUIRED_NO_PHYSICS_PASS' and
             result['existing_overall_gradient_gate'] == 'FAILED_UNCHANGED',
             'Transferred result invented a physics/calibration pass')
        need(record['vendor_api_sha256'] == PINS['vendor_api_sha256'] and
             identity['vendor_api_sha256'] == result['vendor_api_sha256'] == record['vendor_api_sha256'] and
             all(sha_string(value) for value in record['vendor_api_sha256'].values()),
             'Transferred vendor API fingerprints disagree')
        need(set(record['metrics']) == METRICS and all(isinstance(value, (float, int)) and
             not isinstance(value, bool) and math.isfinite(value) and result[key] == value
             for key, value in record['metrics'].items()), 'Transferred score differs from cold verification')
        for part in ('before', 'after', 'persisted'):
            key = part+'_sha256'
            semantic = digest(json.dumps(result['controls'][part], sort_keys=True,
                                        separators=(',', ':'), allow_nan=False).encode())
            need(record['control_sha256'][key] == result['controls'][key] == semantic,
                 'Transferred control snapshot hash differs from cold verification')
        need(record['checkpoint'] == payload['files'][f'{task}:checkpoint']['path'] and
             record['checkpoint_sha256'] == digest(decoded[f'{task}:checkpoint']) and
             record['ports'] == result['ports_npz'] == payload['files'][f'{task}:ports']['path'] and
             record['ports_sha256'] == result['ports_sha256'] == digest(decoded[f'{task}:ports']) and
             record['source'] == result['source'] and record['termination'] == result['termination'] and
             record['fsp_sha256'] == result['fsp_sha256'] and record['h5_sha256'] == result['h5_sha256'],
             'Transferred record/CP/NPZ/source/termination hashes disagree')
    return decoded


def publish(payload, decoded, output):
    output = Path(output)
    need(output.is_absolute() and not output.exists(), 'NEW absolute output directory required')
    output.mkdir(exist_ok=False)
    pins = {}; receipt = dict(payload); receipt['files'] = {}
    for key, raw in decoded.items():
        task, role = key.split(':')
        name = f's2_temporal200_task{int(task):02d}_'+('original.json' if role == 'checkpoint' else 'ports.npz')
        target = output/name
        with target.open('xb') as stream:
            stream.write(raw); stream.flush(); os.fsync(stream.fileno())
        item = {k: v for k, v in payload['files'][key].items() if k != 'data'}
        pins[key] = dict(local=str(target), **item); receipt['files'][key] = item
    def write_json(name, value):
        path = output/name
        with path.open('x', encoding='utf8') as stream:
            json.dump(value, stream, indent=2); stream.flush(); os.fsync(stream.fileno())
        return digest(path.read_bytes())
    pins_sha = write_json('s2_temporal200_artifact_pins_original.json', pins)
    receipt['artifact_pins_sha256'] = pins_sha
    receipt_sha = write_json('s2_temporal200_completed_receipt.json', receipt)
    manifest = dict(job_id=payload['job_id'], family=FAMILY, verified_tasks=list(TASKS),
                    runner_sha256=RUNNER_SHA, base_helper_sha256=BASE_SHA,
                    review_marker=payload['review_marker'], review_marker_sha256=payload['review_marker_sha256'],
                    artifact_pins_sha256=pins_sha, receipt_sha256=receipt_sha,
                    fetch_helper_sha256=digest(Path(__file__).read_bytes()),
                    published_files={p.name: digest(p.read_bytes()) for p in output.iterdir()},
                    qualification='Read-only cold verification and original-byte transfer; no physics pass')
    manifest_sha = write_json('s2_temporal200_fetch_manifest.json', manifest)
    return dict(output_dir=str(output), pins_sha256=pins_sha, receipt_sha256=receipt_sha,
                manifest_sha256=manifest_sha, verified_tasks=list(TASKS))


def cli():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('job-id', 'review-marker', 'review-marker-sha256', 'environment-json', 'output-dir'):
        parser.add_argument('--'+name, required=True)
    args = parser.parse_args()
    env = validate_inputs(args.job_id, args.review_marker, args.review_marker_sha256,
                          json.loads(Path(args.environment_json).read_text()))
    output = Path(args.output_dir)
    need(output.is_absolute() and not output.exists(), 'Output must be NEW before SSH')
    _, remote = scripts(args.job_id, args.review_marker, args.review_marker_sha256, env)
    command = ['ssh', '-o', 'HostName=132.68.1.206', '-o', 'HostKeyAlias=athena.technion.ac.il',
               '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-o', 'StrictHostKeyChecking=yes',
               'evyatarrubin@athena.technion.ac.il', 'python3 -B -']
    result = subprocess.run(command, input=remote.encode(), capture_output=True, timeout=360)
    need(result.returncode == 0, 'Read-only completion fetch failed: '+result.stderr.decode(errors='replace'))
    payload = json.loads(result.stdout)
    decoded = validate_payload(payload, args.job_id, args.review_marker, args.review_marker_sha256, env)
    print(json.dumps(publish(payload, decoded, output), indent=2))


if __name__ == '__main__':
    cli()
