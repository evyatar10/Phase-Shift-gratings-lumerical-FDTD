# Selective field recording for a bounded adjoint diagnostic

Use only when the objective Jacobian has known finite frequency support and
stored-field size is a material cost. Keep the original source and port grid;
select optimization-field frequencies from the union of objective support
and deliberately chosen controls. A center shift outside that support must
fail or trigger a reviewed recorder update, never nearest-bin substitution.

A hidden-CAD check on the October7 S2 scene verified monitor-local properties:
`override global monitor settings=1`, `use source limits=0`,
`sample spacing="custom"`, and `custom frequency samples` as an explicit
frequency column vector. The list survived save/reload bitwise while501
source/global/port settings stayed unchanged. The legacy `frequency points`
property still reported501; do not infer recorded count from that property.
No solved fields were produced in this check. Before using new data, assert
actual frequency count/order/values, finite complex Ex/Ey/Ez, spatial axes,
normalization and unchanged source/port grids. Preserve actual result bytes.

The standard extractor may request all port frequencies and use nearest
field samples even where the objective weight is zero. A reduced recorder
therefore requires an explicitly reviewed selected-frequency extraction path;
zero weights do not make arbitrary missing-field substitution valid.
Existing helpers pinned to501 recorded frequencies cannot be reused unchanged.

In the inspected port-source implementation, the objective weighting and
complex correction are applied after the physical field solves. Subject to
exact identity and normalization controls, one matched forward/port-adjoint
pair can supply both raw quadratures; separate quadrature labels alone do
not justify duplicate solves. This reuse does not apply automatically to a
forward-dependent width source or to fields at another termination setting.

Reduced frequency count lowers the recorded-field component of memory/I/O;
it does not reduce propagation timesteps proportionally or prove total
runtime savings. Measure the actual job before promising a speedup.
