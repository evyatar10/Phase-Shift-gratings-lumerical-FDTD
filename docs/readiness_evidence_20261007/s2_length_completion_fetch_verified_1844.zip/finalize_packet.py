"""Local-only packet checks; no network/CAD/solve. Preserves all new artifacts."""
import ast,datetime,hashlib,json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
REF=Path('C:/Users/evyat/AppData/Local/Temp/s2_length_fixed150_candidate_n6nnepfe')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
commands=[('focused_tests',[sys.executable,'-B',str(HERE/'test_fetch_length_native.py')]),('CLI_help',[sys.executable,'-B',str(HERE/'fetch_length_native.py'),'--help']),('prepare_only',[sys.executable,'-B',str(HERE/'fetch_length_native.py'),'--prepare','--job-id','101434','--environment',str(ROOT/'docs/readiness_evidence_20261007/s2_length_two_forwards_environment_1812.json'),'--marker',str(ROOT/'docs/readiness_evidence_20261007/s2_length_two_forwards_review_original.json'),'--grids',str(REF/'reference_port_grids.json'),'--output',str(HERE/'command_packet')])]
for name,argv in commands:
 r=subprocess.run(argv,cwd=ROOT,text=True,capture_output=True,check=False)
 with (HERE/(name+'.log')).open('x',encoding='utf-8') as f:f.write('exit_code='+str(r.returncode)+'\n'+r.stdout+r.stderr)
 checks.append(dict(name=name,exit_code=r.returncode,argv=argv));assert r.returncode==0,(name,r.stderr)
for file in ['fetch_length_native.py','test_fetch_length_native.py','command_packet/remote_capture_stdin.py']:
 ast.parse((HERE/file).read_text());compile((HERE/file).read_text(),file,'exec')
checks.append(dict(name='source_and_emitted_script_AST_compile_NO_execution',exit_code=0))
files={str(p.relative_to(HERE)).replace('\\','/'):dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(HERE.rglob('*')) if p.is_file()}
manifest=dict(schema=1,at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='PREPARED_AND_OFFLINE_TESTED_NO_NETWORK_CAD_SOLVE',job_id='101434',actual_job_completion='NOT_CHECKED_PREPARATION_ONLY',synthetic_tests='Old150ps port bytes plus existing nativeCAD metadata; not measured length results',checks=checks,files=files,limitations=['No native remote execution or real accounting obtained by this worker','Lead must independently capture and pin actual remote payload bytes','Existing source/vendor/reference and all FSP/H5/log validation occurs only in explicit read-only remote capture','No convergence/noise/length recommendation from these tests'])
with (HERE/'final_manifest.json').open('x',encoding='utf-8') as f:json.dump(manifest,f,indent=2)
print(json.dumps(dict(packet=str(HERE),helper_sha256=sha(HERE/'fetch_length_native.py'),tests_sha256=sha(HERE/'test_fetch_length_native.py'),manifest_sha256=sha(HERE/'final_manifest.json'),all_exit_codes=[c['exit_code'] for c in checks]),indent=2))
