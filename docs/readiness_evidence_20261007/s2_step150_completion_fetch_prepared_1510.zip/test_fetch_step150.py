"""Offline synthetic protocol tests only: no network, container, CAD or solve."""
import ast
import base64
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
import fetch_step150 as fetch

REPO = Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
EVIDENCE = REPO/'docs/readiness_evidence_20261007/s2_temporal150_fetch_1434'
JOB = '12345'  # SYNTHETIC test input; never submitted/contacted.
MARKER = '/work/data/SYNTHETIC_step150_review.json'
MARKER_SHA = 'e'*64
ENV = dict(S2_STEP150_REPO='/work/project', S2_STEP150_OUTPUT_ROOT=fetch.OUTPUT_ROOT,
           S2_STEP150_PARENT_ROOT=fetch.PARENT_ROOT, S2_STEP150_PARENT_MARKER=fetch.PARENT_MARKER,
           S2_STEP150_REVIEW_MARKER=MARKER, S2_STEP150_REVIEW_SHA256=MARKER_SHA, KEEP_H5='1')


class FetchChecks(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix='SYNTHETIC_fetch_', dir=Path(__file__).parent))
        parent = json.loads((EVIDENCE/'s2_temporal150_task03_original.json').read_text())
        ports_raw = (EVIDENCE/'s2_temporal150_task03_ports.npz').read_bytes()
        self.payload = dict(job_id=JOB, review_marker=MARKER, review_marker_sha256=MARKER_SHA,
                            environment=ENV, family=fetch.FAMILY, runner_sha256=fetch.RUNNER_SHA,
                            base_helper_sha256=fetch.BASE_SHA, at='SYNTHETIC_NO_SERVER',
                            accounting='\n'.join(f'{JOB}_{t}|COMPLETED|0:0|' for t in fetch.TASKS),
                            verified_records=[], files={})
        for task, sign in ((0, 1), (1, -1)):
            row = copy.deepcopy(parent); identity, result = row['identity'], row['result']
            attempt = fetch.OUTPUT_ROOT+f'/task_{task:02d}_SYNTHETIC'
            cp = fetch.OUTPUT_ROOT+f'/task_{task:02d}.json'; source = attempt+'/files/fwd_default.fsp'
            ports = attempt+'/ports.npz'
            review = dict(path=MARKER, sha256=MARKER_SHA, lead_verdict='SYNTHETIC_NO_APPROVAL',
                          allowed_tasks=[0, 1], parent150=dict(
                              marker=fetch.PARENT_MARKER, marker_sha256=fetch.PARENT_MARKER_SHA,
                              checkpoints={str(t): dict(checkpoint=fetch.PARENT_ROOT+f'/task_{t:02d}.json',
                                                       sha256=fetch.PARENT_CHECKPOINT_SHA[str(t)])
                                           for t in (3, 4, 5)}))
            identity.update(task=task, duration_ps=150., index=149, sign=sign, delta_nm=sign*.125,
                            task_map=[[.125, 1], [.125, -1]], center_checkpoint=fetch.PARENT_ROOT+'/task_03.json',
                            center_sha256=fetch.CENTER_SHA, parent_review=review)
            identity['point'][149] += sign*.125
            identity['spec']['label'] = fetch.FAMILY
            identity['code']['s2_temporal_step150.py'] = fetch.RUNNER_SHA
            identity['code']['s2_temporal_forward.py'] = fetch.BASE_SHA
            result.update(task=task, duration_ps=150., index=149, sign=sign, delta_nm=sign*.125,
                          params=identity['point'], parent_review=review, source=source, ports_npz=ports,
                          ports_sha256=fetch.digest(ports_raw), reviewed_center_sha256=fetch.CENTER_SHA,
                          comparison_status='STEP150_DIAGNOSTIC_REVIEW_REQUIRED_NO_PHYSICS_PASS',
                          FDTD_version='SYNTHETIC_PROTOCOL_NO_NEW_SOLVE')
            record = dict(task=task, checkpoint=cp, source=source, ports=ports,
                          ports_sha256=result['ports_sha256'], termination=result['termination'],
                          fsp_sha256=result['fsp_sha256'], h5_sha256=result['h5_sha256'],
                          parent_review=review, metrics={k: result[k] for k in fetch.METRICS},
                          vendor_api_sha256=result['vendor_api_sha256'],
                          control_sha256={k: result['controls'][k]
                                          for k in ('before_sha256', 'after_sha256', 'persisted_sha256')})
            raw = json.dumps(row).encode()
            record['checkpoint_sha256'] = fetch.digest(raw)
            self.payload['verified_records'].append(record)
            for role, path, data in (('checkpoint', cp, raw), ('ports', ports, ports_raw)):
                self.payload['files'][f'{task}:{role}'] = dict(
                    path=path, bytes=len(data), sha256=fetch.digest(data), data=base64.b64encode(data).decode())

    def validate(self, payload=None):
        return fetch.validate_payload(self.payload if payload is None else payload, JOB, MARKER, MARKER_SHA, ENV)

    def mutate_checkpoint(self, payload, task, mutate):
        item = payload['files'][f'{task}:checkpoint']
        row = json.loads(base64.b64decode(item['data'])); mutate(row)
        raw = json.dumps(row).encode()
        item.update(bytes=len(raw), sha256=fetch.digest(raw), data=base64.b64encode(raw).decode())
        payload['verified_records'][task]['checkpoint_sha256'] = fetch.digest(raw)

    def test_explicit_inputs_and_exact_environment_without_network(self):
        with patch.object(fetch.subprocess, 'run', side_effect=AssertionError('Network forbidden')):
            for job in ('', '0', '12345_0', '-1', '12345;sbatch'):
                with self.assertRaises(RuntimeError): fetch.scripts(job, MARKER, MARKER_SHA, ENV)
            for marker in ('relative.json', '/work/data/../results/x.json', fetch.PARENT_MARKER):
                with self.assertRaises(RuntimeError): fetch.scripts(JOB, marker, MARKER_SHA, ENV)
            for key, value in (('S2_STEP150_OUTPUT_ROOT', fetch.PARENT_ROOT),
                               ('S2_STEP150_REVIEW_MARKER', '/work/data/different.json'),
                               ('S2_STEP150_REVIEW_SHA256', 'f'*64), ('KEEP_H5', '0')):
                env = dict(ENV); env[key] = value
                with self.assertRaises(RuntimeError): fetch.scripts(JOB, MARKER, MARKER_SHA, env)
            with self.assertRaises(RuntimeError): fetch.scripts(JOB, MARKER, 'NOT_SHA', ENV)
            env = dict(ENV); env['S2_TIME_OUTPUT_ROOT'] = fetch.PARENT_ROOT
            with self.assertRaises(RuntimeError): fetch.scripts(JOB, MARKER, MARKER_SHA, env)

    def test_accounting_exact_two_completed_zero_tasks(self):
        self.assertEqual(set(fetch.completed_rows(self.payload['accounting'], JOB)), {JOB+'_0', JOB+'_1'})
        for state in ('RUNNING', 'PENDING', 'FAILED', 'COMPLETED+', 'CANCELLED'):
            with self.assertRaises(RuntimeError):
                fetch.completed_rows(self.payload['accounting'].replace('COMPLETED', state, 1), JOB)
        for text in (self.payload['accounting'].replace('0:0', '1:0', 1),
                     self.payload['accounting'].replace(JOB+'_1', JOB+'_3'),
                     self.payload['accounting']+f'\n{JOB}_2|COMPLETED|0:0|',
                     self.payload['accounting']+f'\n{JOB}_0|COMPLETED|0:0|'):
            with self.assertRaises(RuntimeError): fetch.completed_rows(text, JOB)

    def test_scripts_have_cold_guards_and_prechecks_before_validator(self):
        inner, remote = fetch.scripts(JOB, MARKER, MARKER_SHA, ENV)
        for text in (inner, remote):
            tree = ast.parse(text)
            attrs = {n.func.attr for n in ast.walk(tree) if isinstance(n, ast.Call)
                     and isinstance(n.func, ast.Attribute)}
            self.assertFalse(attrs & {'main', 'forward_only', 'make_project', 'import_lumopt2',
                                      'run_forward', 'run_adjoint', 'run_campaign', 'compute_gradient',
                                      'write_bytes', 'write_text', 'mkdir', 'unlink', 'rename'})
            for command in ('sbatch', 'scancel', 'srun', 'rmtree'):
                self.assertNotIn(command, text)
        for blocked in ('m.main=forbid', 'm.forward_only=forbid', 'm.eng.make_project=forbid',
                        'm.eng.import_lumopt2=forbid', 'm.base.main=forbid', 'm.base.forward_only=forbid'):
            self.assertIn(blocked, inner)
        for operation in ('m.frozen_base()', 'm.load_ancestry()', 'm.reviewed(', 'm.identity(',
                          'm.recovery.read_checkpoint(', 'm.verify_result('):
            self.assertIn(operation, inner)
        self.assertLess(inner.index('Both completed checkpoints'), inner.index('m.load_ancestry()'))
        self.assertLess(remote.index('Both checkpoints required'), remote.index("a=['apptainer'"))
        self.assertIn("JOB_ID='12345'", remote)
        self.assertIn(fetch.RUNNER_SHA, inner)
        self.assertNotIn('m.load_center()', inner)
        self.assertIn('if sys.flags.optimize:raise RuntimeError', inner)
        self.assertIn('if sys.flags.optimize:raise RuntimeError', remote)

    def test_valid_payload_and_exclusive_original_bytes_pins_receipt_manifest(self):
        decoded = self.validate(); output = self.root/'NEW_completion'
        result = fetch.publish(self.payload, decoded, output)
        self.assertEqual(result['verified_tasks'], [0, 1])
        pins = json.loads((output/'s2_step150_artifact_pins_original.json').read_text())
        self.assertEqual(set(pins), set(decoded))
        for key, pin in pins.items(): self.assertEqual(Path(pin['local']).read_bytes(), decoded[key])
        receipt = json.loads((output/'s2_step150_completed_receipt.json').read_text())
        manifest = json.loads((output/'s2_step150_fetch_manifest.json').read_text())
        self.assertEqual(receipt['artifact_pins_sha256'], result['pins_sha256'])
        self.assertEqual(manifest['receipt_sha256'], result['receipt_sha256'])
        self.assertEqual(fetch.digest((output/'s2_step150_fetch_manifest.json').read_bytes()), result['manifest_sha256'])
        raw = {p.name: p.read_bytes() for p in output.iterdir()}
        with self.assertRaises(RuntimeError): fetch.publish(self.payload, decoded, output)
        self.assertEqual({p.name: p.read_bytes() for p in output.iterdir()}, raw)
        with self.assertRaises(RuntimeError): fetch.publish(self.payload, decoded, 'relative_output')

    def test_job_task_marker_family_missing_artifact_hash_and_path_tamper(self):
        for key, value in (('job_id', '12346'), ('review_marker', '/work/data/wrong.json'),
                           ('review_marker_sha256', 'f'*64), ('runner_sha256', 'b'*64),
                           ('base_helper_sha256', 'b'*64), ('family', 'wrong_family')):
            bad = copy.deepcopy(self.payload); bad[key] = value
            with self.assertRaises(RuntimeError): self.validate(bad)
        for key, value in (('path', fetch.PARENT_ROOT+'/task_00.json'),
                           ('path', fetch.OUTPUT_ROOT+'/../outside.json'), ('bytes', 1), ('sha256', '0'*64)):
            bad = copy.deepcopy(self.payload); bad['files']['0:checkpoint'][key] = value
            with self.assertRaises(RuntimeError): self.validate(bad)
        bad = copy.deepcopy(self.payload); bad['files'].pop('1:ports')
        with self.assertRaises(RuntimeError): self.validate(bad)
        bad = copy.deepcopy(self.payload); bad['verified_records'][1]['task'] = 3
        with self.assertRaises(RuntimeError): self.validate(bad)
        bad = copy.deepcopy(self.payload); bad['files']['1:ports']['path'] = fetch.OUTPUT_ROOT+'/task_00_OTHER/ports.npz'
        with self.assertRaises(RuntimeError): self.validate(bad)

    def test_repinned_checkpoint_semantics_scores_vendor_and_controls_reject(self):
        changes = [lambda r: r['identity']['spec'].update(label='old_temporal_family'),
                   lambda r: r['identity'].update(delta_nm=.0625),
                   lambda r: r['identity'].update(duration_ps=100.),
                   lambda r: r['identity'].update(center_sha256='b'*64),
                   lambda r: r['result'].update(peak3_tout=.123),
                   lambda r: r['result']['parent_review'].update(sha256='b'*64),
                   lambda r: r['result']['vendor_api_sha256'].update({'lumapi.py': 'b'*64}),
                   lambda r: r['result']['controls']['after']['timing'].update({'use early shutoff': 1})]
        for change in changes:
            bad = copy.deepcopy(self.payload); self.mutate_checkpoint(bad, 0, change)
            with self.assertRaises(RuntimeError): self.validate(bad)

    def test_cli_refuses_existing_output_before_network(self):
        env = self.root/'environment.json'; env.write_text(json.dumps(ENV))
        args = ['fetch_step150.py', '--job-id', JOB, '--review-marker', MARKER,
                '--review-marker-sha256', MARKER_SHA, '--environment-json', str(env),
                '--output-dir', str(self.root)]
        with patch.object(sys, 'argv', args), patch.object(fetch.subprocess, 'run',
                                                        side_effect=AssertionError('SSH forbidden')):
            with self.assertRaisesRegex(RuntimeError, 'before SSH'): fetch.cli()


if __name__ == '__main__':
    unittest.main(verbosity=2)
