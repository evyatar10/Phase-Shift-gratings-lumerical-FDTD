# Two isolated candidate peak-height estimators

Production FOM/calibration unchanged. Tested only quadratic LS7 and quartic LS11
against current peak3, using the existing scored Bragg index. The index is detached;
centered frequency-index windows are normalized to[-1,1]. Fits require exactly one
real stationary root within1bin and numerical concavity. Ambiguous, convex,
degenerate or incomplete stencils reject; there is no fallback estimator. The
already unique root is refined against the original fitted coefficients to avoid
companion-matrix loss of precision in an effectively quadratic quartic.

If c=V+T and u* is the stationary maximum, height=P(u*) and
**dheight/dT = basis(u*) @ V+**: stationarity eliminates du*/dT. Five tests verify
known height/support, amplitude/tilt/local-sample finite-difference Jacobians,
convex/out-of-cell/multiple-root and invalid-window rejection, synthetic white
noise gain and exclusive output. Tests and actual pinned-data analysis exit0.

| Model, Tout | peak3 ripple / derivative RMS | quadratic7 | quartic11 |
|---|---:|---:|---:|
|Lorentzian|1.10e-6 /5.43e-5|8.35e-6 /4.33e-4|4.92e-7 /2.55e-5|
|Measured-center cubic translation|6.71e-6 /2.02e-4|5.89e-6 /2.48e-4|1.74e-7 /6.99e-6|

Height ripple is absolute transmission; derivative RMS is per nm using conditional
speed-22.6bins/nm over801phase samples. Branchwise derivatives do not bound selector
jumps. Quartic11 cubic Tout nominal derivative changes from peak3-1.0325e-4 to
-3.0757e-6/nm, but cubic-model height bias is+9.35..9.52e-6. Lorentzian quartic
bias is-1.66..-1.17e-6, so lower ripple does not mean lower absolute height bias.

Modal results are mixed: cubic phase ripple peak3/quadratic7/quartic11 is
2.52e-6/2.24e-5/3.46e-6; derivative RMS1.18e-4/6.12e-4/8.00e-5. Quartic nominal
model derivative is-9.6244e-5 versus peak3+4.0780e-5. Lorentzian modal quartic
ripple6.39e-7 improves peak3 1.33e-6 but has-2.15..-1.52e-6 height bias.

Interpolant dependence remains substantial: PCHIP Tout derivative RMS is5.47e-3
peak3/1.61e-3 quadratic7/1.46e-3 quartic11; modal is5.09e-3/1.94e-3/1.62e-3.
These interpolants are comparison models, not exact continuous spectra.

On the actual firstwave shift30±0.5nm pair:

| Observable | peak3 even / central derivative | quadratic7 | quartic11 |
|---|---:|---:|---:|
|Tout|2.8005e-4 /-2.7033e-4|2.7732e-4 /-2.7504e-4|2.7893e-4 /-2.7238e-4|
|Modal|3.0144e-4 /-4.0065e-4|2.9772e-4 /-4.1496e-4|2.9951e-4 /-4.0447e-4|

Neither fit removes the measured even anomaly. Corr30 central Tout derivatives are
3.6950e-5/3.7660e-5/3.7244e-5; modal4.1780e-5/4.2827e-5/4.1211e-5. These compare
different estimators, not calibrated physical gradients.

At the nominal center, normalized design conditions are3.182(LS7)/16.686(LS11).
Tout fit RMS residuals6.63e-6/6.03e-6; modal2.36e-5/7.20e-6. Quartic offsets are
-0.1400bins Tout/-0.0586bins modal. Raw coefficients, all weights, curvature,
stationarity residuals and all endpoint fit diagnostics are in final_actual/report.json.
Known-model bias is separate from unknown physical bias on stored forward spectra.

For a declared independent Gaussian model sigma1e-6/sample, predicted nominal
Tout std is0.985e-6 peak3 versus0.576e-6 both fits;2000draw empirical std is
0.975e-6/0.578e-6/0.580e-6. Modal predictions0.998e-6/0.577e-6/0.577e-6 agree with
model draws. This is synthetic sensitivity only: measured FDTD errors may be
correlated and have a different distribution.

Quadratic7 does not justify a dedicated reconstruction on these comparisons.
Quartic11 is worth a bounded later stored-field check, especially for Tout, with
explicit bias/modal/interpolant review; it is not ready for adoption. Current scalar
Re/Im contractions cannot be reweighted: the candidate Jacobians have7/11sample
support (Tout247..257, modal245..255 for quartic nominal), not3. Reusing saved fields
requires explicit source/normalization/objective compatibility and fresh qualification.

With the existing selected-field assembly, raw Python forward+adjoint storage scales
from~0.290GiB(3wavelengths) to~0.677GiB(7) or~1.063GiB(11). Dense summed gradient
field remains~25MiB. CAD full-component getdata/pinch transient~8.06GiB remains;
CAD/index/sparse storage is additional. Existing bandwidth contains both windows,
but support/memory arithmetic is not a hardware memory guarantee.

Exact input NPZ/checkpoint hashes, complete grids and saved peak3 scores were checked.
Commands/logs: VALIDATION.json and validation_0/1.log. TEMP-only; no CAD, solves,
network, coefficient fit, production integration or scientific pass.
