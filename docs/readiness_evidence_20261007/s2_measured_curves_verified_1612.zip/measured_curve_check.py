"""Pinned measured same150ps curve diagnostic; purely offline, no physics pass."""
import hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
from scipy.interpolate import CubicSpline
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
PINS={'s2_step150_review_1601.json':'4b763bc8594f63fa1b4866467e0b5d593368d18ce5e6607fea1b28499a62a27b','s2_step150_spectra_1601.json':'daefcee38729acf686625b6c26fce1de92af1aa53daafd84bda7cec0cffcd5ab'}
ENGINE_SHA='53108bbd368dd699179ab65029628aa4c4b2d8ad687777f88b82f404a0952569'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(x,msg):
 if not x:raise RuntimeError(msg)
def richardson(small,large):return (4*np.asarray(small)-np.asarray(large))/3
def relative(a,b):
 denominator=abs(a)+abs(b)
 return None if denominator==0 else float(2*abs(b-a)/denominator)
def bin_row(k,anchor,wl,ds,dl,near_threshold):
 near=max(abs(ds[k]),abs(dl[k]))<=near_threshold
 return dict(index=int(k),offset=int(k-anchor),lambda_nm=float(wl[k]*1e9),small_fd_per_nm=float(ds[k]),large_fd_per_nm=float(dl[k]),large_minus_small=float(dl[k]-ds[k]),absolute_difference=float(abs(dl[k]-ds[k])),near_zero_diagnostic=bool(near),symmetric_relative_difference=None if near else relative(ds[k],dl[k]),odd_large_over_twice_small=None if near or ds[k]==0 else float(dl[k]/ds[k]))
def shifted_center(center,x,shifts):
 """T_cf(x)=T_center_spline(x-delta); no extrapolation or amplitude change."""
 spline=CubicSpline(x,center,extrapolate=False)
 valid=np.logical_and.reduce([(x-d>=x[0])&(x-d<=x[-1]) for d in shifts.values()])
 require(valid.sum()>20,'Insufficient common interpolation domain')
 curves={key:spline(x[valid]-d) for key,d in shifts.items()}
 require(all(np.isfinite(c).all() for c in curves.values()),'Counterfactual extrapolation')
 return valid,curves
def main():
 folder=ROOT/'docs/readiness_evidence_20261007';loaded={}
 for name,digest in PINS.items():
  require(sha(folder/name)==digest,'Pinned measured input changed: '+name);loaded[name]=json.loads((folder/name).read_text())
 review=loaded['s2_step150_review_1601.json'];spectra=loaded['s2_step150_spectra_1601.json']
 require(review['full_spectra_sha256']==PINS['s2_step150_spectra_1601.json'],'Report/spectra binding changed')
 require(review['center_checkpoint_sha256']=='a0ff55eacaa52e00a2aab17dcc43d0e5fff9a72566e15da371ff25279c172663','Wrong measured center')
 require(sha(ROOT/'runners/lumopt2_design/lumopt2_design.py')==ENGINE_SHA,'Frozen objective source changed')
 sys.path.insert(0,str(ROOT));from runners.lumopt2_design import lumopt2_design as eng
 def forbidden(*args,**kwargs):raise RuntimeError('Offline diagnostic refuses CAD/solve')
 eng.make_project=eng.import_lumopt2=forbidden
 wl=np.asarray(spectra['grids']['p2_lambda']);freq=np.asarray(spectra['grids']['p2_f']);df=np.diff(freq)
 require(wl.shape==freq.shape==(501,) and np.all(df>0) and np.allclose(df,df[0],rtol=1e-9,atol=0),'Actual501 uniform-frequency grid mismatch')
 x=(freq-freq[0])/df[0];score=eng.make_fct_peak(wl*1e9)
 report=dict(scope='OFFLINE_MEASURED_SAME150_CURVE_DIAGNOSTIC_NO_GATE_CHANGE',input_sha256=PINS,engine_sha256=ENGINE_SHA,checkpoint_provenance=review['provenance'],definitions=dict(flanks='offsets -30..-10 and +10..+30 from exact sampled center peak, inclusive',near_zero='max(abs(D_small),abs(D_large)) <= 5% of global max abs FD across both steps; descriptive reporting cutoff only, not a gate or noise estimate',relative='2*abs(D_large-D_small)/(abs(D_small)+abs(D_large))',odd_scaling='N_large/(2*N_small)=D_large/D_small since h_large=2*h_small',conditional_Richardson='(4*D_small-D_large)/3 ONLY conditional on common smooth h^2 leading error; not an error bound, measured order or asymptotic proof'),observables={})
 for metric,curves in spectra['observables'].items():
  pairs=review['observables'][metric]['same150ps_steps'];small=curves['h0.0625'];large=curves['h0.125'];center=np.asarray(small['center'])
  require(np.array_equal(center,np.asarray(large['center'])),'Different measured centers')
  derivatives=[]
  for label,h in [('h0.0625',.0625),('h0.125',.125)]:
   c=curves[label];p=np.asarray(c['plus']);m=np.asarray(c['minus']);d=(p-m)/(2*h);derivatives.append(d)
   require(np.array_equal(d,np.asarray(c['spectral_central_fd'])),'Stored per-bin FD changed')
   require(np.array_equal(p-m,np.asarray(c['spectral_signed_odd_numerator'])),'Stored odd changed')
   require(np.allclose([float(score(p)),float(score(m)),float(score(center))],[pairs[label][k] for k in ['plus_peak3','minus_peak3','center_peak3']],rtol=0,atol=1e-14),'Exact production peak3 mismatch')
  ds,dl=derivatives;anchor=pairs['h0.0625']['center_peak_index'];require(anchor==pairs['h0.125']['center_peak_index'],'Different anchor')
  threshold=.05*max(np.max(abs(ds)),np.max(abs(dl)));indices=np.r_[np.arange(anchor-30,anchor-9),np.arange(anchor+10,anchor+31)]
  bins=[bin_row(k,anchor,wl,ds,dl,threshold) for k in indices];core=np.arange(anchor-30,anchor+31)
  near=[bin_row(k,anchor,wl,ds,dl,threshold) for k in core if max(abs(ds[k]),abs(dl[k]))<=threshold]
  summary={}
  for side,ix in [('minus',indices[:21]),('plus',indices[21:]),('both',indices)]:
   ratios=[relative(ds[k],dl[k]) for k in ix if max(abs(ds[k]),abs(dl[k]))>threshold]
   summary[side]=dict(count=len(ix),max_abs_difference=float(np.max(abs(dl[ix]-ds[ix]))),rms_abs_difference=float(np.sqrt(np.mean((dl[ix]-ds[ix])**2))),relative_l2_difference=float(np.linalg.norm(dl[ix]-ds[ix])/np.linalg.norm(ds[ix])),symmetric_relative_min=float(min(ratios)),symmetric_relative_max=float(max(ratios)),odd_scaling_min=float(np.min(dl[ix]/ds[ix])),odd_scaling_max=float(np.max(dl[ix]/ds[ix])),signs_match=bool(np.all(np.sign(ds[ix])==np.sign(dl[ix]))))
  rich={}
  for method in ['central_derivative','exact_center_peak3_jacobian_projection','spline_primary_derivative']:
   getter=lambda label:pairs[label]['spline_observer']['windows']['25']['central_derivative'] if method=='spline_primary_derivative' else pairs[label][method]
   a,b=getter('h0.0625'),getter('h0.125');r=float(richardson(a,b));rich[method]=dict(small=a,large=b,estimate_CONDITIONAL=r,estimate_minus_small=r-a,relative_correction_vs_small=abs((r-a)/a) if a else None)
  shifts={};cf={}
  for label,h in [('h0.0625',.0625),('h0.125',.125)]:
   peaks=pairs[label]['spline_observer']['windows']['25']['peaks'];base=peaks['center']['frequency_grid_coordinate'];deltas={role:peaks[role]['frequency_grid_coordinate']-base for role in ['plus','minus']};shifts[label]=deltas
   valid,model=shifted_center(center,x,deltas);local_score=eng.make_fct_peak(wl[valid]*1e9)
   require(abs(float(local_score(center[valid]))-float(score(center)))<=1e-14,'Common-domain crop changed objective')
   vp,vm=[float(local_score(model[role])) for role in ['plus','minus']];fd=(vp-vm)/(2*h);cf[label]=dict(measured_spline_shifts_in_frequency_bins=deltas,measured_shift_Hz={k:float(v*df[0]) for k,v in deltas.items()},common_domain_indices=[int(np.flatnonzero(valid)[0]),int(np.flatnonzero(valid)[-1])],counterfactual_plus_peak3=vp,counterfactual_minus_peak3=vm,counterfactual_peak3_fd_per_nm=fd,measured_peak3_fd_per_nm=pairs[label]['central_derivative'],measured_minus_counterfactual_fd=pairs[label]['central_derivative']-fd)
  report['observables'][metric]=dict(center_index=anchor,near_zero_cutoff_per_nm=float(threshold),flank_bins=bins,flank_summary=summary,near_zero_core_bins=near,near_zero_all_grid_count=int(np.count_nonzero(np.maximum(abs(ds),abs(dl))<=threshold)),conditional_Richardson=rich,shifted_center_interpolation_counterfactual=cf,counterfactual_qualification='Measured center interpolated and translated by measured spline peak shifts only; original center amplitude/shape retained. Same production peak3 on common finite domain. This is not physical ground truth, amplitude/residual attribution or a noise measurement.',measured_shift_large_over_twice_small={k:float(shifts['h0.125'][k]/(2*shifts['h0.0625'][k])) for k in ['plus','minus']})
 return report
if __name__=='__main__':
 output=Path(__file__).with_name('measured_curve_report_final.json')
 with output.open('x') as stream:json.dump(main(),stream,indent=2,allow_nan=False)
 print(output)
