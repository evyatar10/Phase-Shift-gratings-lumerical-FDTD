# Prepared no-solve corr30 dEps-step sensitivity probe

The parent decides whether to upload/dispatch this CPU CAD diagnostic. No
repository or vendor source is changed. No FDTD forward, adjoint, optimizer or
coefficient fit is called. Existing calibration remains FAILED_UNCHANGED.

Upload these three Python files together into a new scratch directory:
probe_corr30_deps.py, no_solve_guard.py and test_probe_corr30_deps.py.
The guard helper preserves the lumapi.FDTD class symbol, wraps its constructor
to force hide=True, blocks solver commands and full E/H transfers, and permits
save only to new generated files inside the exclusive output directory.

Run separately for quadratures re and im. Each job performs all three dEps
steps1,.5,.25nm on the SAME reconstructed gradient field for that quadrature.
Use distinct NEW output directories. Example in the scheduled runtime:

```bash
python -B probe_corr30_deps.py \
  --repo /work \
  --lumapi /ACTUAL/api/python/lumapi.py \
  --quadrature re \
  --provenance /PRESERVED/s2_provenance_first_report_original.json \
  --reviewed-provenance-sha256 EXACT_SHA_OF_THAT_REVIEWED_RAW_REPORT \
  --saved-gradient /work/results/recover_te_s2_peak/results/lumopt2_te_s2_peak_calibration_20261006/task_00.json \
  --output-root /NEW/s2_corr30_deps_re
```

For im, use --quadrature im and original peak reconstruction task_01.json.
These exact saved-gradient paths follow the existing study's separate results
directory. Verify their presence rather than moving or overwriting originals.

Exact registered stored sources, beneath
/work/results/validate_te/results/validate_te_s2:

| Quadrature | Folder | Forward | Adjoint |
|---|---|---|---|
| re | lumopt2_te_s2_cport_fd_c_files | fwd_default.fsp | adj_default_Port_2.fsp |
| im | lumopt2_te_s2_cport_im_c_files | fwd_default.fsp | adj_default_Port_2.fsp |

Every FSP must retain its <stem>/<stem>_output.h5 companion and successful
solver log. FSP hashes and FSP/H5 stats must match the reviewed no-solve report;
original file identity is checked again afterward. H5 content is not rehashed
by this probe. Report this limitation when interpreting source identity.
The current vendor Python source hashes must also match that reviewed report.
The complete current spec must equal the reviewed spec except the new label
and registered quadrature phase overrides. All mesh, mesher step and recorder
keys are checked before CAD. The original h1 checkpoint's nested task/schema,
peak3 objective, exact six-index map, nominal point, physical/numerical spec,
finite vector and saved source pair are also validated before CAD. Its full
historical identity and source hashes are reported; old engine hashes are not
falsely required to equal the later optimizer-only integration.

The dynamic peak3 Jacobian is computed from EACH ORIGINAL saved forward's
Port_2 T_out. It is not the later repeated center used for finite-difference
comparisons. All nonzero Jacobian samples are selected exactly, without a
threshold. The probe refuses more than three nonzero samples. Only those raw
field wavelength slices cross lumapi. Exactly-zero samples return scalar zero
to unchanged vendor calculate_gradient_fields; its normalization, source power,
symmetry and Im phase rotation are retained. Reviewed spatial interpolation
must be none. This selection's equivalence is tested on finite synthetic fields.

The corr30 geometric Jacobian selects four affected objects. Its original
vendor bounding boxes, _d_eps_sparse_single_param and sparse remapping are
reused, with parameter29 retained in the sparse key. The full296-parameter
perturbation loop is never used. Raw gradient contractions, component totals,
sparse support/norms, field hash, and h1 difference against the original stored
corr30 contraction are reported in deps_sensitivity.json. Any difference stays
visible; nothing is renormalized or refitted. The h1 comparison is the first
hardware fidelity check for this new extraction/subset harness.

The actual FDTD mesh refinement method and meshing refinement property are
recorded in generated, saved-field and nominal-index contexts. Unsupported
queries return explicit available=false diagnostics. The script never sets this
integer or assumes the documented default as a measurement.

Memory estimates from measured coordinate shape1246x51x17x501x3:

- One full complex128 E dataset would be24.19GiB; this is not transferred.
- One full component can transiently occupy8.06GiB inside CAD while getdata is
  evaluated and pinched to one wavelength. Original CAD result/storage memory
  is additional and implementation-dependent.
- The three selected wavelengths for forward plus adjoint occupy about0.290GiB
  in Python before transient copies, plus roughly25MiB dense gradient fields,
  generated CAD and small index/sparse arrays.

Recommend a conservative128G CPU-only scheduled job after the parent's actual
resource/shared-license preflight. Run re/im serially if the per-user memory
limit cannot fit two128G jobs. No GPU is needed. Wall time is unmeasured; CAD
load/getdata copies and six cropped index perturbations dominate. This is not
a promise of a28-second run or a claim that64G is sufficient.

Offline verification:

```bash
python -B test_probe_corr30_deps.py
```

Eight groups pass: exact Jacobian support; synthetic full-versus-selected
assembly with complex phases, symmetry and zeros; solver/save/full-field guards;
single-parameter dispatch/mapping and bounds; unsupported refinement readback;
sampler slice equivalence and shifted-grid refusal; syntax/no-solve call graph
and the original vendor-style super(FDTD,self) constructor guard; actual saved
Re/Im identity acceptance and negative full-spec/task/objective/index/point
controls. The last group reads small existing JSON evidence, performs no CAD,
and requires running from the repository root or setting S2_DEPS_TEST_REPO.
Fixtures stay in this temp package.

Actual hidden local CAD validation subsequently passed exit0 in86.8seconds;
three corr30 steps exercised the installed private mesher/sparse APIs with
synthetic gradient fields. All steps returned global_shape1246x51x17x1, the
four correct corr30 objects, finite data/contractions and restored nominal
properties. Component nonzero counts were378/432/384 at each step. The local
mesh method read precise volume average and meshing refinement read5; this is
a LOCAL readback, not a measured server setting. Actual installed FOM methods
returned ndarray(shape501) Jacobian and float FOM on a synthetic spectrum.
No FDTD solve or stored-field extraction was performed. Evidence:
C:/Users/evyat/AppData/Local/Temp/s2_deps_localcad_62daf58d92ae4c4692b5cf204150fbd6/validation.json,
SHA25669ff46a2a29b7a2fe78fb6d2bbcc0529b4c65e60fb035ad05441e490d4c6fac7.
This CAD-only pass does not verify the stored-field sampler or h1 agreement.
