# Exact peak3 translation diagnostic (offline only)

The tested symmetric Lorentzian does **not** support peak3 ripple near1e-4 at this
resolution. Exact current engine make_fct_peak â†’ measure_peak/scored finder â†’
v3_step.peak3 was imported without CAD or source edits. Frequency spacing is uniform;
analytic phase scans use index space, equivalent to this actual frequency grid.

| Observable | measured FWHM, bins | HWHM, bins | ideal peak3 phase range | plain sampled-max worst loss |
|---|---:|---:|---:|---:|
| abs(T_out) |52.46727|26.23363|1.09549e-6|3.36170e-4|
| abs(S21)^2 |50.58616|25.29308|1.33046e-6|3.79619e-4|

At phase0.23, doubling HWHM gives peak3 error ratios15.96 then15.99, consistent
with fourth-order relative-grid error. Plain sampled maxima give quadratic ratios4.
This verifies the symmetric Lorentzian claim narrowly; generic asymmetric profiles
may have different leading errors, and this is not an error bound on FDTD data.

Measured-center translations use cubic spline and PCHIP independently. Translation
amount is each endpoint's subgrid peak location minus its own center's, retaining
full measured height/shape. Only common in-domain spectral overlap is evaluated;
no extrapolation. Exact pipeline scores on the overlap reproduce full-grid scores.
Neither interpolant reconstructs unknown continuous physics; offsets themselves
are estimated from peak3 vertices. PCHIP has deliberately different knot smoothness
and is a sensitivity model, not a better physical truth.

| Observable, halfstep | actual even | cubic predicted even | actual minus cubic | cubic predicted dPeak/dp | residual dPeak/dp |
|---|---:|---:|---:|---:|---:|
| Tout,0.5nm |2.80048e-4|1.86664e-6|2.78182e-4|-2.88368e-6|-2.67444e-4/nm|
| Modal,0.5nm |3.01442e-4|1.23528e-6|3.00206e-4|5.71554e-7|-4.01221e-4/nm|
| Tout,2nm (old center) |5.02256e-5|1.84507e-6|4.83806e-5|-9.76221e-7|-1.56703e-4/nm|
| Modal,2nm (old center) |5.09752e-5|2.29684e-7|5.07455e-5|-1.25575e-7|-2.87402e-4/nm|

Cubic phase-scan error ranges are6.71e-6 Tout/2.52e-6 modal at the repeated center.
PCHIP predicts negative even terms~-6.2e-5 at0.5nm; residuals become3.42e-4/3.64e-4.
Its phase ranges~1.30e-4/1.13e-4 demonstrate interpolant sensitivity, not measured
noise. Both models fail to explain the positive actual even terms by translation.
Cubic full-overlap endpoint residuals max3.65/4.17e-4 Tout and4.94/5.01e-4 modal;
height/shape differences remain beyond the modeled displacement. Their cause is
not established by this calculation.

The fixed-center spectral-FD projection can differ strongly even for pure finite
translation: at0.5nm cubic predicts+3.38341e-4/nm Tout versus moving-peak-2.88368e-6;
actual is+3.85857e-4 versus-2.70328e-4. Modal model projection+6.24497e-3 versus
moving+5.71554e-7; actual+5.83617e-3 versus-4.00649e-4. These are projections of
forward spectral differences onto a scalar peak Jacobian, **not** available full
spectral adjoint gradients. Only original scalar Re/Im contractions exist.

Measured peak motion is~11.3bins per0.5nm and45.3 per2nm, approximately22.6bins/nm.
Thus the provisional next shift30 ladder is0.125nm/0.0625nm (instead of0.25/0.125):
projected motion2.825/1.4125bins, ~10.8%/5.4% Tout HWHM (~11.2%/5.6% modal).
The observed coarse Tout derivative~-0.00027/nm would imply odd~-3.4e-5/-1.7e-5,
similar in magnitude to measured corr30 odd1.8e-5. This extrapolates a nonconverged
finite-step derivative; it does not guarantee detectable signal or establish noise.

Constant-center-shape cubic translation predicts the following fixed-center-Jacobian
spectral-FD truncation bias relative to its own infinitesimal model derivative:

| h,nm | Tout model bias,/nm | Modal model bias,/nm |
|---|---:|---:|
|0.5|2.87735e-5|5.51235e-3|
|0.25|2.31060e-4|1.78487e-3|
|0.125|2.92318e-4|3.07491e-4|
|0.0625|2.83389e-4|-5.43867e-5|

Model infinitesimal projection is-1.03250e-4/nm Tout and+4.07799e-5/nm modal.
Modal bias decreases but Tout does not across this ladder. Therefore smaller peak
motion motivates the provisional ladder, but this model cannot certify it resolves
truncation. These comparisons use speed-22.6bins/nm and unchanged center height/shape,
not a claim about geometry-dependent spectra or the true adjoint gradient. Existing
corr30 repeat changes0.76% Tout/5.23% modal remain observations, not noise bounds.
Old2nm center fingerprints a read-only export while endpoints have separately pinned
recovery creators; equal complete original-solve provenance is not claimed.

Three arithmetic/model tests and final actual analysis exit0; exact commands and
logs are in validation_final.json/validation_final_*.log. All actual input/member hashes and
saved half-step endpoint scores were checked. final_report/report.json retains
full numbers and source hashes. No solve, server action, repository edit, tolerance,
calibration fit or gate approval occurred.
