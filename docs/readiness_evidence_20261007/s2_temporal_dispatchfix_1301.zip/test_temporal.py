import copy,json,os,sys,tempfile,types,unittest
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
REPO=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');sys.path.insert(0,str(REPO))
import numpy as np
import s2_temporal_forward as r
REAL_BASELINE_BINDINGS=r.baseline_bindings

class TemporalChecks(unittest.TestCase):
    def setUp(self):
        self.temp=Path(tempfile.mkdtemp(prefix='fixture_SYNTHETIC_',dir=Path(__file__).parent));self.root=self.temp/r.LABEL
        self.first=self.temp/'first.json';self.later=self.temp/'later.json';self.centerpath=self.temp/'oldcenter/task_00.json';self.centerpath.parent.mkdir()
        wl=np.linspace(r.SPEC.scan_center_nm-1,r.SPEC.scan_center_nm+1,501)*1e-9
        line=1/(1+((wl*1e9-r.SPEC.scan_center_nm)/.1)**2)
        self.arrays=dict(p2_lambda=wl,p2_f=299792458./wl,p1_lambda=wl,p1_f=299792458./wl,p2_T_out=.93*line,p2_S=np.sqrt(.97*line),p1_T_in=np.full(501,.94))
        ports=self.centerpath.parent/'ports.npz'
        with ports.open('xb') as f:np.savez(f,**self.arrays)
        self.center=dict(sha256=r.CENTER_SHA,checkpoint=str(self.centerpath),result={'ports_npz':str(ports)})
        self.baseline=dict(marker='FIXTURE_171162_NO_SOLVE',marker_sha256='1'*64,checkpoints={})
        env=dict(S2_TIME_OUTPUT_ROOT=str(self.root),S2_SHIFT_CENTER_CHECKPOINT=str(self.centerpath),S2_TIME_PRIOR_ROOT=str(self.temp/'prior'),
            S2_TIME_FIRST_MARKER=str(self.first),S2_TIME_LATER_MARKER=str(self.later),KEEP_H5='1')
        for p in (patch.dict(os.environ,env),patch.object(r,'load_center',return_value=self.center),patch.object(r,'baseline_bindings',return_value=self.baseline)):
            p.start();self.addCleanup(p.stop)
        p=patch.object(r,'CENTER_PORT_SHA',r.sha(ports));p.start();self.addCleanup(p.stop)
        m=r.review_template(100.,self.root,self.center);self.assertEqual(m['allowed_tasks'],[]);self.assertEqual(m['status'],'NOT_REVIEWED')
        m.update(status=r.STATUS[100.],allowed_tasks=[0,1,2],lead_verdict='SYNTHETIC reviewed first-stage scope, not measured physics')
        self.first.write_text(json.dumps(m));self.builds=[]

    def project(self,spec,attempt,api,drift=None,time_error=0.,early=False,missing_h5=False):
        source=Path(attempt)/'files/fwd_default.fsp';source.parent.mkdir()
        record=dict(params=None,forwards=0,closed=False,changed=False,disabled=0);self.builds.append(record)
        timing={'simulation time':2000e-12,'use early shutoff':1.,'auto shutoff min':1e-7,'use divergence checking':1.,'auto shutoff max':1e5,'down sample time':100.,'max source time signal length':32768.,'dt':6.67466e-17}
        globals={k:0. for k in r.GLOBAL_SOURCE_PROPS};globals.update(pulselength=1.0303488659126683e-14,offset=2.921373559194767e-14,frequency=192e12,bandwidth=42e12,**{'source type':'standard','wavelength start':wl0 if (wl0:=1.559e-6) else 0.,'wavelength stop':1.561e-6,'optimize for short pulse':1.})
        class Fdtd:
            def getnamed(inner,obj,key):
                if obj=='optimization_dft':return 0. if record['disabled'] else 1.
                if obj=='FDTD':return timing[key] if key in timing else {'mesh refinement':'precise volume average','meshing refinement':5.}[key]
                prop=obj+'::'+key;geom=r.eng.make_func(r.SPEC)(record['params'])
                if prop in geom:return geom[prop]
                if obj=='FDTD::ports':return {'monitor frequency points':501.,'source port':'Port_1','source mode':'mode 1'}[key]
                return 'Forward' if key=='direction' else (1. if key=='enabled' else 0.)
            def getglobalsource(inner,k):return globals[k]+(1e-16 if drift=='source' and record['changed'] and k=='pulselength' else 0) if isinstance(globals[k],float) else globals[k]
            def getresult(inner,obj,key):
                if obj=='FDTD':return (2. if early else 1.) if key=='status' else np.arange(4.)+(1 if drift=='mesh' and record['changed'] and key=='x' else 0)
                port=2 if obj.endswith('Port_2') else 1
                return {k.split('_',1)[1]:v for k,v in self.arrays.items() if k.startswith(f'p{port}_')}
            def setnamed(inner,obj,key,value):
                if obj=='FDTD':timing[key]=value;record['changed']=True
                else:assert (obj,key,value)==('optimization_dft','enabled',0);record['disabled']+=1
            def save(inner,path):assert Path(path)==source;source.write_bytes(b'NEW_SYNTHETIC_SETUP')
            def load(inner,path):assert Path(path)==source
            def close(inner):record['closed']=True
            def version(inner):return 'SYNTHETIC_NO_ENGINE_VERSION'
        def set_fwd(p):record['params']=p.copy();source.write_bytes(b'NEW_SYNTHETIC_INITIAL_SETUP')
        def run_forward():
            record['forwards']+=1;duration=timing['simulation time'];extra='Early termination of simulation, the autoshutoff criteria are satisfied.\n' if early else ''
            source.with_name('fwd_default_p0.log').write_text(extra+f'Completed 1000000 iterations, or {duration+time_error:.12e}s of Simulation Time\nSimulation completed successfully')
            if not missing_h5:source.with_suffix('').mkdir();(source.with_suffix('')/'fwd_default_output.h5').write_bytes(b'NEW_SYNTHETIC_H5')
        def forbidden(*a,**kw):raise AssertionError('adjoint/optimizer invoked')
        return types.SimpleNamespace(set_fwd=set_fwd,run_forward=run_forward,run_adjoint=forbidden,compute_gradient=forbidden,
            fdtd_session=types.SimpleNamespace(fdtd=Fdtd(),invalidate_loaded_state=lambda:None),
            fom=types.SimpleNamespace(config_map=types.SimpleNamespace(project_folder=str(source.parent),config_map={None:{'fwd_filename':source.name}}))),None
    def run_tasks(self,tasks,**kw):
        with patch.object(r.eng,'import_lumopt2',return_value=object()),patch.object(r.eng,'make_project',side_effect=lambda *a:self.project(*a,**kw)):
            return [r.main(t) for t in tasks]
    def approve150(self):
        m=r.review_template(150.,self.root,self.center);m.update(status=r.STATUS[150.],allowed_tasks=[3,4,5],lead_verdict='SYNTHETIC lead reviewed100ps artifacts; no convergence claim')
        with self.later.open('x') as f:json.dump(m,f)

    def test_taskmap_live_indices_fullpoints(self):
        base=r.val.te_point(r.SPEC)
        for t,(duration,sign) in enumerate(r.TASK_MAP):
            p,i,d,s=r.task_params(t);self.assertEqual(d,duration);self.assertEqual(s,sign)
            np.testing.assert_array_equal(np.flatnonzero(p-base),[] if sign==0 else [149])
            self.assertEqual(i,29 if sign==0 else 149);self.assertEqual(p[29],base[29]);self.assertEqual(p[295],base[295])
        for t in (True,-1,6,1.5,'0'):
            with self.assertRaises(ValueError):r.main(t)

    def test_first_review_scope_and_keep_h5_before_cad(self):
        original=json.loads(self.first.read_text())
        with patch.object(r.eng,'import_lumopt2',side_effect=AssertionError('CAD touched')):
            for k,v in [('status','NOT_REVIEWED'),('allowed_tasks',list(range(6))),('code',{}),('timing_changes',{'use early shutoff':1})]:
                m=copy.deepcopy(original);m[k]=v;self.first.write_text(json.dumps(m))
                with self.assertRaises(RuntimeError):r.main(0)
            self.first.write_text(json.dumps(original))
            with patch.dict(os.environ,{'KEEP_H5':'0'}):
                with self.assertRaisesRegex(RuntimeError,'KEEP_H5=1'):r.main(0)

    def test_stage150_missing_incomplete_then_all_exact_stage100(self):
        with self.assertRaises(FileNotFoundError):r.main(3)
        self.run_tasks([0,1])
        with self.assertRaisesRegex(RuntimeError,'triplet missing'):self.approve150()
        self.run_tasks([2]);firstbytes=self.first.read_bytes();self.approve150();self.run_tasks([3,4,5])
        self.assertEqual(self.first.read_bytes(),firstbytes);self.assertEqual(len(self.builds),6)
        self.assertTrue(all(b['forwards']==1 and b['closed'] and b['disabled']==1 for b in self.builds))
        for t in range(6):r.verify_result(json.loads((self.root/f'task_{t:02d}.json').read_text())['result'],t,self.root)

    def test_later_provenance_tamper_and_reused_marker(self):
        self.run_tasks(range(3));self.approve150();m=json.loads(self.later.read_text());m['first_stage']['checkpoints']['1']['sha256']='0'*64;self.later.write_text(json.dumps(m))
        with patch.object(r.eng,'import_lumopt2',side_effect=AssertionError('CAD touched')):
            with self.assertRaisesRegex(RuntimeError,'100ps provenance'):r.main(3)
            with patch.dict(os.environ,{'S2_TIME_LATER_MARKER':str(self.first)}):
                with self.assertRaisesRegex(RuntimeError,'separate immutable'):r.main(3)

    def test_control_source_mesh_drift_fail_before_forward(self):
        for drift in ('mesh','source'):
            with self.assertRaisesRegex(RuntimeError,'changed frozen'):self.run_tasks([2],drift=drift)
        self.assertTrue(all(b['forwards']==0 and b['closed'] for b in self.builds));self.assertFalse((self.root/'task_02.json').exists())

    def test_wrong_termination_and_h5_preserves_incomplete_attempts(self):
        for kw,reason in [({'early':True},'fixed-time window'),({'time_error':2e-16},'one timestep'),({'missing_h5':True},'HDF5')]:
            with self.assertRaisesRegex(RuntimeError,reason):self.run_tasks([0],**kw)
        self.assertFalse((self.root/'task_00.json').exists());self.assertEqual(len(list(self.root.glob('task_00_*'))),3)

    def test_artifact_tamper_cold_resume_and_exclusive_checkpoint(self):
        result=self.run_tasks([1])[0];cp=self.root/'task_01.json';before=cp.read_bytes()
        with patch.object(r.eng,'import_lumopt2',side_effect=AssertionError('repeat solve')):self.assertEqual(r.main(1),result)
        with self.assertRaises(FileExistsError):r.recovery.checkpoint(cp,json.loads(before)['identity'],result)
        Path(result['h5']).write_bytes(b'TAMPER')
        with patch.object(r.eng,'import_lumopt2',side_effect=AssertionError('cold resume')):
            with self.assertRaisesRegex(RuntimeError,'artifact SHA mismatch'):r.main(1)
        self.assertEqual(cp.read_bytes(),before)

    def test_saved_scalar_and_timing_snapshot_tamper(self):
        result=self.run_tasks([0])[0]
        mutated=copy.deepcopy(result);mutated['peak3_tout']+=1e-8
        with self.assertRaisesRegex(RuntimeError,'scalar not reproduced'):r.verify_result(mutated,0,self.root)
        mutated=copy.deepcopy(result);mutated['controls']['after']['source']['pulselength']*=2
        mutated['controls']['after_sha256']=r.semantic(mutated['controls']['after'])
        with self.assertRaisesRegex(RuntimeError,'control snapshot changed'):r.verify_result(mutated,0,self.root)
        path=Path(result['ports_npz']);arrays=dict(self.arrays);arrays['p2_f']=arrays['p2_f']+1
        with path.open('wb') as stream:np.savez(stream,**arrays)
        mutated=copy.deepcopy(result);mutated['ports_sha256']=r.sha(path)
        with self.assertRaisesRegex(RuntimeError,'Exact port grid mismatch'):r.verify_result(mutated,0,self.root)

    def test_log_rounding_within_recorded_dt(self):
        self.run_tasks([2],time_error=3e-17)
        self.assertEqual(self.builds[0]['forwards'],1)

    def test_actual_dispatcher_task_idx_keyword_reuse_and_gate_without_cad(self):
        result=self.run_tasks([0])[0]
        with patch.object(r.eng,'import_lumopt2',side_effect=AssertionError('CAD touched during keyword dispatch')):
            self.assertEqual(r.main(task_idx=0),result)
            first=json.loads(self.first.read_text());first['status']='NOT_REVIEWED';self.first.write_text(json.dumps(first))
            with self.assertRaisesRegex(RuntimeError,'review scope'):r.main(task_idx=1)
            with self.assertRaises(ValueError):r.main(task_idx=6)

    def test_narrow_fsp_serialization_allowance_and_material_rejection(self):
        expected=dict(geometry={'object::x span':2.4552999999999916e-7},timing={'simulation time':100e-12},mesh={'x':[0.,1e-6]})
        actual=copy.deepcopy(expected);actual['geometry']['object::x span']=2.455299999999983e-7
        measured=r.persisted_check(expected,actual);self.assertEqual(measured['max_abs_geometry_delta_m'],8.470329472543003e-22)
        oneulp=copy.deepcopy(expected);oneulp['geometry']['object::x span']=float(np.nextafter(expected['geometry']['object::x span'],np.inf))
        self.assertGreater(r.persisted_check(expected,oneulp)['max_abs_geometry_delta_m'],0.)
        actual['geometry']['object::x span']+=1e-15
        with self.assertRaisesRegex(RuntimeError,'Material persisted'):r.persisted_check(expected,actual)
        actual=copy.deepcopy(expected);actual['mesh']['x'][1]=float(np.nextafter(actual['mesh']['x'][1],np.inf))
        with self.assertRaisesRegex(RuntimeError,'Persisted timing/mesh'):r.persisted_check(expected,actual)

    def test_vendor_identity_and_prior_marker_rejected_before_cad(self):
        result=self.run_tasks([0])[0];mutated=copy.deepcopy(result);mutated['vendor_api_sha256']['lumapi.py']='0'*64
        with self.assertRaisesRegex(RuntimeError,'vendor API identity'):r.verify_result(mutated,0,self.root)
        bad=self.temp/'UNREVIEWED_prior.json';bad.write_text('{}')
        with patch.dict(os.environ,{'S2_TIME_PRIOR_MARKER':str(bad)}):
            with self.assertRaisesRegex(RuntimeError,'prior marker required'):REAL_BASELINE_BINDINGS(self.center)
            original=json.loads(self.first.read_text());original['vendor_api_sha256']['lumapi.py']='0'*64;self.first.write_text(json.dumps(original))
            with patch.object(r.eng,'import_lumopt2',side_effect=AssertionError('CAD touched')):
                with self.assertRaisesRegex(RuntimeError,'review scope'):r.main(0)

if __name__=='__main__':unittest.main(verbosity=2)
