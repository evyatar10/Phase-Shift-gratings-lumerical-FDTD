import os,sys,types,runpy,ast,json
from pathlib import Path
p=Path(__file__).with_name('qualify_igum_length.py');code=p.read_text();tree=ast.parse(code)
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ('run','main','forward_only','make_project') for n in ast.walk(tree))
calls=[]
config=types.ModuleType('config');sys.modules['config']=config
parent=types.ModuleType('runners');parent.__path__=[];middle=types.ModuleType('runners.lumopt2_design');middle.__path__=[]
lane=types.ModuleType('runners.lumopt2_design.s2_length_fixed150');lane.eng=types.SimpleNamespace(make_project=lambda:None)
def paths(*,for_review):
 assert for_review is False
 assert config.LUMAPI_PATH=='/fake/native/lumapi.py' and config.USE_GPU is True
 calls.append('paths_no_solve_marker');return {'synthetic':True}
def build(p,o):
 assert p=={'synthetic':True} and o=='/fake/NEW_build_only'
 for f in (lane.main,lane.forward_only,lane.eng.make_project):
  try:f()
  except RuntimeError:pass
  else:raise AssertionError('Solve path not blocked')
 calls.append('build_only');return {'no_FDTD_solve':True,'status':'NATIVE_CAD_PAIR_CONTROLS_PASS_NO_PHYSICS_OR_SOLVE_APPROVAL'}
lane.native_paths=paths;lane.build_only=build;middle.s2_length_fixed150=lane
sys.modules['runners']=parent;sys.modules['runners.lumopt2_design']=middle;sys.modules[lane.__name__]=lane
os.environ['LUMAPI_PATH']='/fake/native/lumapi.py';os.environ['S2_LEN_CAD_OUTPUT']='/fake/NEW_build_only'
runpy.run_path(str(p),run_name='__main__');assert calls==['paths_no_solve_marker','build_only']
print('PASS: AST no direct solve, SYNTHETIC native config/bootstrap and all3 blocked entrypoints')
