import sys,json,tempfile
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,'C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
from runners.lumopt2_design import lumopt2_design as eng
import config,no_solve_guard as guard
config.LUMAPI_PATH='C:/Program Files/Lumerical/v261/api/python/lumapi.py'
eng.import_lumopt2()
import lumapi
ROOT=Path(tempfile.mkdtemp(prefix='pulse_query_',dir=Path(__file__).parent));sessions=[]
restore=guard.install_constructor_guard(lumapi.FDTD,ROOT,sessions)
try:
    f=lumapi.FDTD(hide=True)
    f.load(str(Path(__file__).parent/'property_discovery_zwx5nxwn/generated/s2_shift30_convergence_20261007_files/fwd_default.fsp'))
    data={k:guard.attempt(lambda k=k:f.getglobalsource(k)) for k in ('pulselength','pulse length','offset','time signal','time')}
    data['property_list']=guard.attempt(f.getglobalsource)
    with (ROOT/'pulse.json').open('x') as stream:json.dump(guard.plain(data),stream,indent=2)
    print(ROOT/'pulse.json');print(json.dumps({k:v for k,v in data.items() if k!='property_list'},indent=2))
finally:
    for s in sessions:guard.attempt(s.close)
    restore()
