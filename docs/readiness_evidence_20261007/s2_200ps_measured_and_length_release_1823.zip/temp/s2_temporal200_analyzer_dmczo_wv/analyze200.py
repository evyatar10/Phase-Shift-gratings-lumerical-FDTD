"""Pinned offline200ps temporal triplet comparison; never runs a solver."""
import argparse,base64,copy,dataclasses,hashlib,json,re,sys
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
REFS={'firstwave_helpers.py':'3b18b5b0663ae2350cc4e3f1fc2c787b6a5d7b4fedaacfe38ba84b92febf384c','numerical_helpers.py':'ac54418b98a196d7e9ed3d5f0adaba812dc6a829adeed6b59c48677a5445b18e','temporal_reference.py':'bbe3a22f90a418c8cadc3fc0c7b95f8843b4d83127d611bb0f4481bb7fdee3dd'}
for name,digest in REFS.items():
    if hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()!=digest:raise RuntimeError('Frozen reader reference differs: '+name)
import numpy as np
import firstwave_helpers as f
import temporal_reference as old
FETCH_SHA='0c6cb29becdcbdf20c37f71cf300f8d3181baeb997e6bb0e96f48596ca558975'
if hashlib.sha256(Path(__file__).with_name('fetch200_reference.py').read_bytes()).hexdigest()!=FETCH_SHA:raise RuntimeError('Frozen completion contract changed')
import fetch200_reference as contract
h=f.h
RUNNER_SHA='fa6a6528e34cb9c004604ec490543c3b0579d76224c936568c2e11e4f9996053'
MARKER_SHA='4fe3c0e7fc37cced733ac7cf7b2ee3de3536213ee938e23a1095dffc307cd44f'
MARKER_REMOTE='/work/data/s2_temporal200_review_20261007_1619.json'
ENV_SHA='b6ef6ac59939293f2ca8b0a78257d7c902fdc367c667f1ade8b452a2dcfd19d4'
HISTORY_SHA='929527d24122050acc41878b9e80b36d21550b2392de317120e93ac534352e8a'
HISTORY_SPECTRA_SHA='b7bf52bf22561880c0238be4adee6a23913954ac2883298b57d62293068576a0'
FAMILY='s2_shift30_temporal200_20261007'
OUTPUT_ROOT='/work/results/diagnose_te_s2_temporal200/results/'+FAMILY


def modules(repo,marker):
    old.frozen_sources(repo,marker);sys.path.insert(0,str(repo))
    from runners.lumopt2_design import s2_temporal200_forward as m
    h.require(f.sha(m.__file__)==RUNNER_SHA and m.code()==marker['code'],'Complete200ps source freeze differs')
    return m


def ancestry(evidence,marker,m):
    parent150=marker['parent150'];step=marker['completed_step150']
    h.require(parent150['marker']==m.PARENT_MARKER and parent150['marker_sha256']==m.PARENT_MARKER_SHA and step['marker']==m.STEP_MARKER and step['marker_sha256']==m.STEP_MARKER_SHA,'Exact150/step ancestry marker differs')
    parent_marker,_=h.load_json(evidence/'s2_temporal150_review_original.json',m.PARENT_MARKER_SHA)
    rows={};arrays={};bindings={}
    for task in (3,4,5):
        row,digest=h.load_json(evidence/f's2_temporal150_fetch_1434/s2_temporal150_task{task:02d}_original.json',m.PARENT_SHA[task])
        m.step.validate_parent_metadata(row,task,parent_marker,m.PARENT_MARKER)
        raw=(evidence/f's2_temporal150_fetch_1434/s2_temporal150_task{task:02d}_ports.npz').read_bytes()
        h.require(h.sha(raw)==m.PARENT_PORT_SHA[task]==row['result']['ports_sha256'],'Exact150 ancestry port bytes differ')
        data=h.load_npz(raw);f.verify_scores(row,data,m.recovery.score);z=row['result']
        rows[task]=row;arrays[task]=data;bindings[str(task)]=dict(checkpoint=m.PARENT_ROOT+f'/task_{task:02d}.json',sha256=digest,ports_sha256=z['ports_sha256'],fsp_sha256=z['fsp_sha256'],h5_sha256=z['h5_sha256'],termination=z['termination'])
    h.require(parent150==dict(marker=m.PARENT_MARKER,marker_sha256=m.PARENT_MARKER_SHA,checkpoints=bindings),'150 ancestor result/hash binding differs')
    center=dict(checkpoint=m.PARENT_ROOT+'/task_03.json',sha256=m.CENTER_SHA,result=rows[3]['result'],bindings=parent150)
    step_marker,_=h.load_json(evidence/'s2_step150_review_1507.json',m.STEP_MARKER_SHA)
    review=dict(path=m.STEP_MARKER,sha256=m.STEP_MARKER_SHA,lead_verdict=step_marker['lead_verdict'],allowed_tasks=[0,1],parent150=parent150)
    pair=[];step_bindings={}
    for task in (0,1):
        row,digest=h.load_json(evidence/f's2_step150_fetch_1600/s2_step150_task{task:02d}_original.json',m.STEP_CP_SHA[task])
        point,index,d,s=m.step.task_params(task);expected=m.step.identity(task,center,review)
        # Vendor hashes are measured on Athena and pinned in the marker; no local API substitution.
        expected['vendor_api_sha256']=step_marker['vendor_api_sha256']
        h.require(row['identity']==expected and row['result']['params']==point.tolist(),'Completed171276 full identity differs')
        raw=(evidence/f's2_step150_fetch_1600/s2_step150_task{task:02d}_ports.npz').read_bytes();h.require(h.sha(raw)==m.STEP_PORT_SHA[task]==row['result']['ports_sha256'],'Completed171276 port bytes differ')
        a=h.load_npz(raw);f.verify_scores(row,a,m.recovery.score);m.step.validate_control(row['result']['controls'],point);z=row['result']
        pair.append(a);step_bindings[str(task)]=dict(checkpoint=m.STEP_ROOT+f'/task_{task:02d}.json',sha256=digest,ports_sha256=z['ports_sha256'],fsp_sha256=z['fsp_sha256'],h5_sha256=z['h5_sha256'],termination=z['termination'])
    h.require(step==dict(marker=m.STEP_MARKER,marker_sha256=m.STEP_MARKER_SHA,checkpoints=step_bindings),'Completed171276 marker bindings differ')
    center['step150']=step
    for a in list(arrays.values())+pair:h.check_grid(a,arrays[3],501)
    return center,rows,arrays,pair


def marker_check(marker,m,center):
    expected=m.scope(Path(OUTPUT_ROOT),center)
    expected['output_root']=OUTPUT_ROOT
    expected['vendor_api_sha256']=marker['vendor_api_sha256']
    h.require(all(marker.get(k)==v for k,v in expected.items()) and marker['status']==m.APPROVAL_STATUS and isinstance(marker['lead_verdict'],str) and marker['lead_verdict'].strip() not in ('','NOT_REVIEWED'),'Exact released200ps review scope differs')
    h.require(marker['vendor_api_sha256']==center['result']['vendor_api_sha256'],'Vendor family differs from exact150 center')


def row_check(row,data,task,marker,center,m):
    review=dict(path=MARKER_REMOTE,sha256=MARKER_SHA,lead_verdict=marker['lead_verdict'],allowed_tasks=[0,1,2],parent150=center['bindings'],completed_step150=center['step150'])
    point,index,d,sign=m.task_params(task)
    expected=m.identity(task,center,review);expected['vendor_api_sha256']=marker['vendor_api_sha256']
    h.require(type(row['identity']['task']) is int and row['identity']==expected,'Full200ps checkpoint point/spec/source/marker/task identity differs')
    z=row['result'];required=dict(task=task,index=index,duration_ps=200.,sign=sign,delta_nm=sign*.0625,params=point.tolist(),parent_review=review,reviewed_center_sha256=m.CENTER_SHA,vendor_api_sha256=marker['vendor_api_sha256'],existing_overall_gradient_gate='FAILED_UNCHANGED',comparison_status=m.COMPARISON_STATUS)
    h.require(all(z.get(k)==v for k,v in required.items()),'200ps result role/parameters differ')
    m.validate_control(z['controls'],point)
    comparison=m.center_control_comparison(z['controls']['before'],center)
    h.require(z['center_control_comparison']==comparison,'Recorded exact150 nominal-control comparison differs')
    paths={k:PurePosixPath(z[k]) for k in ('source','h5','ports_npz')};root=PurePosixPath(OUTPUT_ROOT);attempt=paths['ports_npz'].parent
    h.require(all(p.is_absolute() and '..' not in p.parts and p.is_relative_to(root) for p in paths.values()) and attempt.name.startswith(f'task_{task:02d}_') and paths['ports_npz'].name=='ports.npz' and paths['source'].is_relative_to(attempt) and paths['source'].name=='fwd_default.fsp' and paths['h5']==paths['source'].with_suffix('')/'fwd_default_output.h5','200ps artifact escaped unique task family')
    for key in ('fsp_sha256','h5_sha256','ports_sha256','setup_fsp_sha256'):h.require(isinstance(z.get(key),str) and re.fullmatch('[0-9a-f]{64}',z[key]),'Artifact digest absent/invalid: '+key)
    t=z['termination'];dt=z['controls']['dt_s'];actual=t['physical_time_s'];target=200e-12
    h.require(t['requested_time_s']==target and t['recorded_dt_s']==dt and t['status']==1 and t['reason']=='completed_full_simulation_time' and np.isfinite(actual) and abs(actual-target)<=dt and t['delta_s']==actual-target and type(t['iterations']) is int and t['iterations']>0 and PurePosixPath(t['log'])==paths['source'].with_name('fwd_default_p0.log') and re.fullmatch('[0-9a-f]{64}',t['log_sha256']),'200ps full-time termination identity differs')
    h.require(isinstance(z.get('FDTD_version'),str) and z['FDTD_version']==center['result']['FDTD_version'],'FDTD version differs from exact150ps center')
    h.check_grid(data,center['arrays'],501);f.verify_scores(row,data,m.recovery.score)
    return comparison


def new_inputs(pins,folder,marker,center,m):
    h.require(set(pins)=={f'{t}:{k}' for t in range(3) for k in ('checkpoint','ports')},'Exact200 pin map must contain only complete three-task CP/NPZ pairs')
    rows=[];arrays=[];metadata=[]
    for t in range(3):
        cp,port=pins[f'{t}:checkpoint'],pins[f'{t}:ports'];expected_cp=folder/f's2_temporal200_task{t:02d}_original.json';expected_port=folder/f's2_temporal200_task{t:02d}_ports.npz'
        for pin,path in ((cp,expected_cp),(port,expected_port)):
            h.require(Path(pin['local']).is_absolute() and Path(pin['local']).resolve()==path.resolve() and path.stat().st_size==pin['bytes'] and f.sha(path)==pin['sha256'],'Transferred local bytes/path differ from parent-pinned map')
        h.require(cp['path']==OUTPUT_ROOT+f'/task_{t:02d}.json','Remote checkpoint task/root differs')
        row,_=h.load_json(expected_cp,cp['sha256']);data=h.load_npz(expected_port.read_bytes())
        h.require(port['path']==row['result']['ports_npz'] and port['sha256']==row['result']['ports_sha256'],'Remote/local NPZ identity differs')
        metadata.append(row_check(row,data,t,marker,center,m));rows.append(row);arrays.append(data)
    for a in arrays:h.check_grid(a,arrays[0],501)
    return rows,arrays,metadata


def completion_check(folder,pins,pins_sha,manifest_sha,env):
    manifest,_=h.load_json(folder/'s2_temporal200_fetch_manifest.json',manifest_sha)
    h.require(manifest['job_id']=='171390' and manifest['family']==FAMILY and manifest['verified_tasks']==[0,1,2] and manifest['runner_sha256']==RUNNER_SHA and manifest['fetch_helper_sha256']==FETCH_SHA and manifest['review_marker']==MARKER_REMOTE and manifest['review_marker_sha256']==MARKER_SHA and manifest['artifact_pins_sha256']==pins_sha,'Parent-pinned completion manifest differs')
    expected={f's2_temporal200_task{t:02d}_{suffix}' for t in range(3) for suffix in ('original.json','ports.npz')}|{'s2_temporal200_artifact_pins_original.json','s2_temporal200_completed_receipt.json'}
    h.require(set(manifest['published_files'])==expected,'Completion publication missing/off-family')
    for name,digest in manifest['published_files'].items():h.require(f.sha(folder/name)==digest,'Published original bytes differ: '+name)
    receipt,_=h.load_json(folder/'s2_temporal200_completed_receipt.json',manifest['receipt_sha256'])
    h.require(receipt['artifact_pins_sha256']==pins_sha and receipt['environment']==env,'Completion receipt pin map/released environment differs')
    payload=copy.deepcopy(receipt)
    for key,pin in pins.items():
        item=payload['files'][key];h.require(all(item[k]==pin[k] for k in ('path','sha256','bytes')),'Receipt/pin original bindings differ')
        item['data']=base64.b64encode(Path(pin['local']).read_bytes()).decode()
    contract.validate_payload(payload,'171390',MARKER_REMOTE,MARKER_SHA,env)
    return dict(completion_manifest_sha256=manifest_sha,receipt_sha256=manifest['receipt_sha256'],pins_sha256=pins_sha,job='171390',cold_validation='Pinned receipt independently revalidated locally; no CAD/solve call')


def analyze(pins,pins_sha,folder,evidence,repo,completion_manifest_sha):
    env,_=h.load_json(evidence/'s2_temporal200_environment_released_1619.json',ENV_SHA)
    completion=completion_check(folder,pins,pins_sha,completion_manifest_sha,env)
    marker,_=h.load_json(evidence/'s2_temporal200_review_original.json',MARKER_SHA);m=modules(repo,marker)
    center,parent_rows,parent_arrays,step_pair=ancestry(evidence,marker,m);center['arrays']=parent_arrays[3];marker_check(marker,m,center)
    rows,new,controls=new_inputs(pins,folder,marker,center,m)
    history,_=h.load_json(evidence/'s2_temporal150_review_1442.json',HISTORY_SHA)
    full_history,_=h.load_json(evidence/'s2_temporal150_spectra_1442.json',HISTORY_SPECTRA_SHA)
    h.require(history['status']=='DIAGNOSTIC_ONLY_CALIBRATION_FAILED_UNCHANGED' and history['no_automatic_approval'],'Wrong reviewed temporal history')
    old.frozen_sources(repo,marker)
    arrays_by_duration={'150':[parent_arrays[t] for t in (3,4,5)],'200':new};cross_controls=[]
    for task,row in enumerate(rows):cross_controls.append(m.phase_compare(parent_rows[task+3]['result']['controls']['before'],row['result']['controls']['before']))
    first_marker,_=h.load_json(evidence/'s2_temporal100_review_original.json',old.FIRST_SHA)
    for task in range(3):
        pin=history['provenance']['new_artifacts'][str(task)];cp=evidence/f's2_temporal100_task{task:02d}_original.json';row,_=h.load_json(cp,pin['checkpoint_sha256']);pp=evidence/f's2_temporal100_task{task:02d}_ports.npz';raw=pp.read_bytes();h.require(h.sha(raw)==pin['ports_sha256'],'Exact100 history NPZ bytes differ');data=h.load_npz(raw)
        binding={k:pin[k] for k in ('ports_sha256','fsp_sha256','h5_sha256','log_sha256')};stage=dict(remote_marker=old.FIRST_REMOTE,marker_sha256=old.FIRST_SHA)
        old.validate_row(row,data,task,first_marker,stage,binding,parent_arrays[3],m.base)
        arrays_by_duration.setdefault('100',[]).append(data)
        cross_controls.append(old.cross_duration_controls(row['result']['controls']['before'],parent_rows[task+3]['result']['controls']['before'],m.base.persisted_check))
    report=dict(schema=1,status='TEMPORAL200_COMPARISON_CALIBRATION_FAILED_UNCHANGED',no_automatic_approval=True,no_coefficient_fit=True,
        source_pins=dict(independently_supplied200_pinmap_sha256=pins_sha,completion=completion,released_environment_sha256=ENV_SHA,review_marker_sha256=MARKER_SHA,runner_sha256=RUNNER_SHA,history_report_sha256=HISTORY_SHA,history_spectra_sha256=HISTORY_SPECTRA_SHA,parent150=marker['parent150'],completed171276=marker['completed_step150']),
        controls_200=controls,cross_duration_controls=cross_controls,termination200={str(t):r['result']['termination'] for t,r in enumerate(rows)},observables={},
        limitations=['Fixed-center peak3-J0 times finite spectralFD is a projection, not an adjoint or infinitesimal derivative.',
            'One h and three finite durations establish no noise floor, h-order, asymptotic convergence or automatic physics pass.',
            'Local checkpoint/NPZ bytes and recorded source/API/geometry/axes/time identities are validated; remote originalFSP/H5/log rechecks belong to parent cold-fetch receipts.'])
    spectra=dict(grids={k:parent_arrays[3][k].ravel().tolist() for k in h.GRIDS},observables={},raw_ports={})
    for d,triplet in arrays_by_duration.items():
        spectra['raw_ports'][d]={role:{k:dict(real=a[k].ravel().real.tolist(),imag=a[k].ravel().imag.tolist()) for k in ('p1_T_in','p2_T_out','p2_S')} for role,a in zip(('center','plus','minus'),triplet)}
    for name,transform in h.METRICS.items():
        select=lambda curve:f.selected_peak(curve,parent_arrays[3]['p2_lambda'],m.eng)
        k150,_,w150=select(transform(parent_arrays[3]));triplets={};curves={}
        for d in ('100','150','200'):
            c,p,n=map(transform,arrays_by_duration[d]);info,fd=f.pair_report(p,n,c,.0625,select)
            info.update(same_duration_center_J0_projection=info['exact_center_peak3_jacobian_projection'],fixed150_center_J0_projection=float(w150@fd[k150-1:k150+2]),fixed150_J0_peak_index=k150,fixed150_J0_weights=w150.tolist(),fixed150_J0_checkpoint_sha256=m.CENTER_SHA,fixed_bins={str(k):float(fd[k]) for k in (244,252,260)})
            if d!='200':
                saved=history['observables'][name]['triplets'][d]
                h.require(all(info[key]==saved[key] for key in ('central_derivative','center_peak3','plus_peak3','minus_peak3','even','exact_center_peak3_jacobian_projection')),'Reviewed100/150 arithmetic differs')
                for role,y in zip(('center','plus','minus'),(c,p,n)):h.require(np.array_equal(y,np.asarray(full_history['observables'][name][d][role])),'Reviewed full history curve differs')
            triplets[d]=info;curves[d]=dict(center=c.tolist(),plus=p.tolist(),minus=n.tolist(),spectral_central_fd=fd.tolist(),spectral_odd=((p-n)/2).tolist(),spectral_even_same_duration_center=((p+n-2*c)/2).tolist())
        extra,_=f.pair_report(transform(step_pair[0]),transform(step_pair[1]),transform(parent_arrays[3]),.125,select)
        changes={}
        for left,right in [('100','150'),('150','200'),('100','200')]:
            changes[right+'_minus_'+left]=dict(central_derivative=triplets[right]['central_derivative']-triplets[left]['central_derivative'],same_duration_center_J0_projection=triplets[right]['same_duration_center_J0_projection']-triplets[left]['same_duration_center_J0_projection'],even=triplets[right]['even']-triplets[left]['even'],same_geometry={role:dict(peak3_difference=select(np.asarray(curves[right][role]))[1]-select(np.asarray(curves[left][role]))[1],spectral_difference=f.difference(curves[right][role],curves[left][role])) for role in ('center','plus','minus')})
        report['observables'][name]=dict(triplets=triplets,temporal_differences=changes,existing150_h0125_pair=extra)
        spectra['observables'][name]=curves
    return report,spectra


def mat_export(path,report,spectra):
    from scipy.io import savemat
    payload={'grids':{k:np.asarray(v) for k,v in spectra['grids'].items()},'report_json':json.dumps(report,allow_nan=False),
        'metadata_json':json.dumps(dict(processed_port_spectra_only=True,grid_frequency_units='Hz',grid_wavelength_units='m',FD_parameter_units='nm',durations_units='ps',no_raw_fields=True)),
        'curve_columns':np.asarray(['center','plus','minus','spectral_central_fd_per_nm','spectral_odd','spectral_even_same_duration_center'],dtype=object)}
    for metric,values in spectra['observables'].items():
        for duration,curves in values.items():payload[metric+'_'+duration]=np.column_stack([curves[k] for k in ('center','plus','minus','spectral_central_fd','spectral_odd','spectral_even_same_duration_center')])
    for duration,roles in spectra['raw_ports'].items():
        payload['raw_ports_'+duration]={role:{k:np.asarray(z['real'])+1j*np.asarray(z['imag']) for k,z in arrays.items()} for role,arrays in roles.items()}
    with Path(path).open('xb') as stream:savemat(stream,payload,do_compression=True,oned_as='column')


def cli():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('pins','pins-sha256','completion-dir','completion-manifest-sha256','evidence-dir','repo','output','spectra-output'):p.add_argument('--'+name,required=True)
    p.add_argument('--mat-output');a=p.parse_args();dest=[Path(x).resolve() for x in (a.output,a.spectra_output,a.mat_output) if x]
    h.require(len(set(dest))==len(dest) and all(not p.exists() for p in dest),'Distinct exclusive new outputs required')
    pins,_=h.load_json(a.pins,a.pins_sha256);report,spectra=analyze(pins,a.pins_sha256,Path(a.completion_dir).resolve(),Path(a.evidence_dir).resolve(),Path(a.repo).resolve(),a.completion_manifest_sha256)
    f.write(a.spectra_output,spectra);report['full_spectra_sha256']=f.sha(a.spectra_output)
    if a.mat_output:mat_export(a.mat_output,report,spectra);report['MAT_sha256']=f.sha(a.mat_output)
    f.write(a.output,report)


if __name__=='__main__':cli()
