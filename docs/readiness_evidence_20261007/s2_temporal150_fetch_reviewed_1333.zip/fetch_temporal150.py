"""Prepared read-only150ps completion fetch; explicit future job/marker required."""
import argparse,base64,hashlib,json,re,subprocess,sys
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
TASKS=(3,4,5)
RUNNER_SHA='555f3d13b42c494171e7658cc4263c588ce418e5d937da1497d690824b41d44a'
FAMILY='s2_shift30_temporal_20261007'
STATUS='APPROVED_AFTER_FIXED100PS_REVIEW_FOR_FIXED150PS_TRIPLET_ONLY'
REQUIRED_ENV={'S2_TIME_REPO','S2_SHIFT_CENTER_CHECKPOINT','S2_TIME_PRIOR_ROOT','S2_TIME_PRIOR_MARKER',
    'S2_TIME_OUTPUT_ROOT','S2_TIME_FIRST_MARKER','S2_TIME_LATER_MARKER','KEEP_H5'}
def need(ok,message):
    if not ok:raise RuntimeError(message)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def validate_inputs(job_id,marker,marker_sha,env):
    need(isinstance(job_id,str) and re.fullmatch(r'[1-9][0-9]*',job_id) is not None,'Explicit positive numeric future job ID required')
    p=PurePosixPath(marker);need(p.is_absolute() and '..' not in p.parts and p.is_relative_to('/work/data') and p.suffix=='.json','Exact absolute /work/data review-marker JSON path required')
    need(isinstance(marker_sha,str) and re.fullmatch(r'[a-f0-9]{64}',marker_sha) is not None,'Exact lowercase marker SHA256 required')
    need(set(env)==REQUIRED_ENV and env['KEEP_H5']=='1','Exact temporal environment key set/KEEP_H5 required')
    for k,v in env.items():
        if k=='KEEP_H5':continue
        q=PurePosixPath(v);need(q.is_absolute() and '..' not in q.parts and q.is_relative_to('/work'),'Normalized /work environment paths required: '+k)
    need(env['S2_TIME_REPO']=='/work/project' and env['S2_TIME_OUTPUT_ROOT'].startswith('/work/results/') and
        PurePosixPath(env['S2_TIME_OUTPUT_ROOT']).name==FAMILY,'Frozen project/temporal results family required')
    need(marker not in (env['S2_TIME_FIRST_MARKER'],env['S2_TIME_PRIOR_MARKER']),'Later marker must be separate from immutable prior markers')
    result=dict(env);result['S2_TIME_LATER_MARKER']=marker;return result
def completed_rows(accounting,job_id):
    rows={v[0]:v[1:3] for v in (line.strip().split('|') for line in accounting.splitlines()) if len(v)>=3}
    need(all(rows.get(f'{job_id}_{t}')==['COMPLETED','0:0'] for t in TASKS),'All exact150ps array tasks3..5 must be COMPLETED exit0')
    return rows
def scripts(job_id,marker,marker_sha,env):
    env=validate_inputs(job_id,marker,marker_sha,env)
    inner='ENV='+repr(env)+'\nMARKER='+repr(marker)+'\nMARKER_SHA='+repr(marker_sha)+'\nRUNNER_SHA='+repr(RUNNER_SHA)+'\n'+r'''
import os,json,sys,hashlib,pathlib
sys.dont_write_bytecode=True
sys.path.insert(0,'/work/project');os.environ.update(ENV)
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert sha(MARKER)==MARKER_SHA,'Exact later review-marker SHA mismatch'
review=json.loads(pathlib.Path(MARKER).read_text())
assert review['family']=='s2_shift30_temporal_20261007' and review['duration_ps']==150. and review['allowed_tasks']==[3,4,5]
assert review['status']=='APPROVED_AFTER_FIXED100PS_REVIEW_FOR_FIXED150PS_TRIPLET_ONLY'
assert review['runner_sha256']==RUNNER_SHA and review['first_stage'] is not None
assert sha('/work/project/runners/lumopt2_design/s2_temporal_forward.py')==RUNNER_SHA,'Preserve frozen555f runner'
import config
config.LUMAPI_PATH='/opt/lumerical/v261/api/python/lumapi.py';config.BASE_SAVE_DIR='/work/results'
config.NEFF_DATA_PATH='/work/data/FDE_sweep_results.mat';config.USE_GPU=True
from runners.lumopt2_design import s2_temporal_forward as m
def forbid(*args,**kwargs):raise RuntimeError('Cold fetch cannot call CAD/solve/main')
m.main=forbid;m.forward_only=forbid;m.eng.make_project=forbid;m.eng.import_lumopt2=forbid
c=m.load_center();root=m.root_path();records=[]
for i in (3,4,5):
    cp=root/f'task_{i:02d}.json';assert cp.is_file()
    r=m.recovery.read_checkpoint(cp,m.identity(i,c,m.reviewed(i,root,c)))
    assert r is not None;m.verify_result(r,i,root)
    assert r['parent_review']['path']==MARKER and r['parent_review']['sha256']==MARKER_SHA
    records.append(dict(task=i,checkpoint=str(cp),source=r['source'],ports=r['ports_npz'],termination=r['termination'],
        fsp_sha256=r['fsp_sha256'],h5_sha256=r['h5_sha256'],parent_review=r['parent_review']))
print(json.dumps(records))
'''
    remote='INNER='+repr(inner)+'\nJOB_ID='+repr(job_id)+'\nROOT='+repr(env['S2_TIME_OUTPUT_ROOT'])+'\nMARKER_SHA='+repr(marker_sha)+'\n'+r'''
import subprocess,json,pathlib,datetime,base64,hashlib
b=pathlib.Path('/home/evyatarrubin/bragg_sim_athena')
r=subprocess.run(['sacct','-j',JOB_ID,'--format=JobID,State,ExitCode','-nP'],capture_output=True,text=True,timeout=20)
assert r.returncode==0,r.stderr
rows={v[0]:v[1:3] for v in (line.strip().split('|') for line in r.stdout.splitlines()) if len(v)>=3}
assert all(rows.get(f'{JOB_ID}_{i}')==['COMPLETED','0:0'] for i in (3,4,5)),r.stdout
def host_path(value):
    p=pathlib.PurePosixPath(value);assert p.is_absolute() and '..' not in p.parts and p.is_relative_to('/work/results')
    return b/pathlib.Path(str(p.relative_to('/work')))
for i in (3,4,5):assert host_path(ROOT+f'/task_{i:02d}.json').is_file()
a=['apptainer','exec','--bind',str(b/'project')+':/work/project','--bind',str(b/'results')+':/work/results',
   '--bind',str(b/'data')+':/work/data','--bind',str(pathlib.Path.home()/'scilibs')+':/scilibs','--pwd','/work/project',
   str(pathlib.Path.home()/'containers/lumerical-2026R1.sif'),'env','LD_LIBRARY_PATH=/scilibs',
   '/opt/lumerical/v261/python/bin/python','-B','-c',INNER]
v=subprocess.run(a,capture_output=True,text=True,timeout=150);assert v.returncode==0,(v.stdout,v.stderr)
records=json.loads(v.stdout);assert [x['task'] for x in records]==[3,4,5]
data={}
for row in records:
    for role in ('checkpoint','ports'):
        value=row[role];p=host_path(value);assert p.stat().st_size<=67108864,'Unexpected bulky artifact'
        raw=p.read_bytes();data[f"{row['task']}:{role}"]=dict(path=value,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),data=base64.b64encode(raw).decode())
print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),job_id=JOB_ID,review_marker_sha256=MARKER_SHA,
    accounting=r.stdout,verified_records=records,files=data)))
'''
    return inner,remote
def validate_payload(payload,job_id,marker,marker_sha,env):
    need(payload.get('job_id')==job_id and payload.get('review_marker_sha256')==marker_sha,'Response job/marker identity mismatch')
    completed_rows(payload['accounting'],job_id)
    records=payload['verified_records'];need([r['task'] for r in records]==list(TASKS),'Verified task list is not3..5')
    expected={f'{t}:{role}' for t in TASKS for role in ('checkpoint','ports')};need(set(payload['files'])==expected,'Response files are missing/off-stage')
    decoded={};root=PurePosixPath(env['S2_TIME_OUTPUT_ROOT'])
    for key,item in payload['files'].items():
        task,role=key.split(':');task=int(task);remote=PurePosixPath(item['path'])
        need(remote.is_absolute() and '..' not in remote.parts and remote.is_relative_to(root),'Response artifact outside exact family')
        if role=='checkpoint':need(remote==root/f'task_{task:02d}.json','Response checkpoint path mismatch')
        raw=base64.b64decode(item['data'],validate=True);need(0<len(raw)<=67108864 and len(raw)==item['bytes'] and digest(raw)==item['sha256'],'Response bytes/hash mismatch')
        decoded[key]=raw
    for record in records:
        t=record['task'];row=json.loads(decoded[f'{t}:checkpoint']);i,z=row['identity'],row['result']
        need(i['task']==t and i['duration_ps']==150. and i['code']['s2_temporal_forward.py']==RUNNER_SHA and
            i['spec']['label']==FAMILY and z['task']==t and z['duration_ps']==150. and
            z['ports_sha256']==digest(decoded[f'{t}:ports']),'Transferred checkpoint family/NPZ identity mismatch')
        review=z['parent_review'];need(review['path']==marker and review['sha256']==marker_sha and review['duration_ps']==150. and
            record['parent_review']==review and i['parent_review']==review,'Transferred marker review mismatch')
        need(record['checkpoint']==payload['files'][f'{t}:checkpoint']['path'] and record['ports']==z['ports_npz']==payload['files'][f'{t}:ports']['path'] and
            record['source']==z['source'] and record['termination']==z['termination'],'Transferred record/source/termination mismatch')
        need(record['fsp_sha256']==z['fsp_sha256'] and record['h5_sha256']==z['h5_sha256'],'Transferred FSP/H5 record hash mismatch')
    return decoded
def publish(payload,decoded,output):
    output=Path(output);need(output.is_absolute() and not output.exists(),'Require NEW absolute output directory; no overwrite/reuse')
    output.mkdir(exist_ok=False);pins={};receipt=dict(payload);receipt['files']={}
    for key,raw in decoded.items():
        t,role=key.split(':');name=f's2_temporal150_task{int(t):02d}_'+('original.json' if role=='checkpoint' else 'ports.npz')
        target=output/name
        with target.open('xb') as stream:stream.write(raw)
        item={k:v for k,v in payload['files'][key].items() if k!='data'}
        pins[key]=dict(local=str(target),**item);receipt['files'][key]=item
    for name,value in [('s2_temporal150_artifact_pins_original.json',pins),('s2_temporal150_completed_receipt.json',receipt)]:
        with (output/name).open('x',encoding='utf8') as stream:json.dump(value,stream,indent=2)
    return dict(output_dir=str(output),pins_sha256=digest((output/'s2_temporal150_artifact_pins_original.json').read_bytes()),verified_tasks=list(TASKS))
def cli():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('job-id','review-marker','review-marker-sha256','environment-json','output-dir'):p.add_argument('--'+name,required=True)
    a=p.parse_args();env=json.loads(Path(a.environment_json).read_text());env=validate_inputs(a.job_id,a.review_marker,a.review_marker_sha256,env)
    out=Path(a.output_dir);need(out.is_absolute() and not out.exists(),'Output directory must be NEW before SSH')
    _,remote=scripts(a.job_id,a.review_marker,a.review_marker_sha256,env)
    command=['ssh','-o','HostName=132.68.1.206','-o','HostKeyAlias=athena.technion.ac.il','-o','BatchMode=yes',
        '-o','ConnectTimeout=10','-o','StrictHostKeyChecking=yes','evyatarrubin@athena.technion.ac.il','python3 -B -']
    result=subprocess.run(command,input=remote.encode(),capture_output=True,timeout=210)
    need(result.returncode==0,'Read-only completion fetch failed: '+result.stderr.decode(errors='replace'))
    payload=json.loads(result.stdout);decoded=validate_payload(payload,a.job_id,a.review_marker,a.review_marker_sha256,env)
    print(json.dumps(publish(payload,decoded,out),indent=2))
if __name__=='__main__':cli()
