"""CPU-only saved100/150/200 center time readout; requires independently reviewed helper SHA, no FDTD."""
import base64,hashlib,importlib.util,json,sys,argparse,re
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--expected-helper-sha256',required=True);args=parser.parse_args();assert re.fullmatch('[a-f0-9]{64}',args.expected_helper_sha256)
HERE=Path(__file__).parent;SRC=Path('C:/Users/evyat/AppData/Local/Temp/s2_saved_center_time_readout_6b39qi7t')
pins={'read_saved_times.py':args.expected_helper_sha256,'frozen_profile_io.py':'994c3e9757a10b5bd8ea211aaee8425c5d3540203a4da04b0439684163baf6ca'}
cp_sha='37fa4074d0dd5bfaa88bf6932b1ca1deed786620126b56f8a2d0c4cd44dbe029'
payload={}
for n,d in pins.items():
 raw=(SRC/n).read_bytes();assert hashlib.sha256(raw).hexdigest()==d;payload[n]=base64.b64encode(raw).decode()
wrap=(HERE/'run_saved_times.sh').read_bytes();assert hashlib.sha256(wrap).hexdigest()=='137a2d398ca286828c0d3e0112784220301f937cadc1da2a878463874d3ff896'
sp=importlib.util.spec_from_file_location('ops','C:/Users/evyat/AppData/Local/Temp/s2_step150_ops_1503.py');ops=importlib.util.module_from_spec(sp);sys.argv=['readonly','none'];sp.loader.exec_module(ops)
gui_code=ops.COMMON+"""
binary='/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261/licensingclient/linx64/lmutil'
print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),GUI=run([binary,'lmstat','-c','1055@132.68.48.51','-f','lum_fdtd_gui']),solver=run([binary,'lmstat','-c','1055@132.68.48.51','-f','lum_fdtd_solve']),queue=run(['squeue','-u','evyatarrubin']))))
"""
gui_result=ops.remote('132.68.58.101',gui_code);ops.save('s2_saved_times_seats_1900.json',gui_result);assert gui_result['rc']==0,gui_result
gui=json.loads(gui_result['out']);assert gui['GUI']['rc']==gui['solver']['rc']==gui['queue']['rc']==0
m=re.search(r'Total of (\d+) licenses issued;\s+Total of (\d+) licenses? in use',gui['GUI']['out']);assert m,'GUI seats unknown';assert int(m[1])-int(m[2])>=2,'Insufficient GUI seat reserve'
code=ops.COMMON+r'''
import base64,re
b=Path('/home/evyatarrubin/bragg_sim_athena');directory=b/'scripts/s2_saved_times_20261007_1900';output=b/'results/s2_saved_times_20261007_1900';wrap=b/'jobs/run_saved_times_20261007_1900.sh'
q=run(['squeue','-u','evyatarrubin']);assert q['rc']==0 and 's2_time' not in q['out'],q
account=run(['sacct','-j','171390','--format=JobID,State,ExitCode','--parsable2']);assert account['rc']==0
for task in range(3):assert '171390_'+str(task)+'|COMPLETED|0:0' in account['out'],account
cp=b/'results/diagnose_te_s2_temporal200/results/s2_shift30_temporal200_20261007/task_00.json';assert hashlib.sha256(cp.read_bytes()).hexdigest()==__CPSHA__
quota=run(['quota','-v']);space=run(['df','-B1','-P',str(b/'results')]);assert quota['rc']==space['rc']==0
assert int(space['out'].splitlines()[-1].split()[3])>10*1024**3
match=re.search(r'hpc-nfs1:/home\s+(\d+)\*?\s+(\d+)\s+(\d+)',quota['out']);assert match,'Unparsed Athena home quota'
used,soft,hard=map(int,match.groups());assert soft>0 and (soft-used)*1024>10*1024**3,'Less than10GiB home quota headroom'
assert not directory.exists() and not output.exists() and not wrap.exists(),'New-only extraction preparation refused existing path'
directory.mkdir()
for name,encoded in __PAYLOAD__.items():
 with (directory/name).open('xb') as f:f.write(base64.b64decode(encoded))
 assert hashlib.sha256((directory/name).read_bytes()).hexdigest()==__PINS__[name]
with wrap.open('xb') as f:f.write(base64.b64decode(__WRAP__))
assert hashlib.sha256(wrap.read_bytes()).hexdigest()=='137a2d398ca286828c0d3e0112784220301f937cadc1da2a878463874d3ff896'
syntax=run(['bash','-n',str(wrap)]);assert syntax['rc']==0,syntax
args=['sbatch','--parsable','--array=0%1','--cpus-per-task=8','--mem=128G','--time=00:30:00','--qos=2h_2g','--partition=l40s-public','--mail-type=NONE','--chdir='+str(b/'jobs'),'--export=ALL,ATHENA_LICENSE=1055@132.68.48.51,ATHENA_INTERCONNECT=2325@132.68.48.51,REQUIRE_GPU=0,KEEP_H5=1,NTFY_TOPIC=,S2_200_CP_SHA256='+__CPSHA__,str(wrap)]
test=run(args[:1]+['--test-only']+args[1:]);assert test['rc']==0,test
submission=run(args)
print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),scope='CPU_SAVED_FIELD_READ_ONLY_NO_FDTD',queue=q,source_job_accounting=account,quota=quota,df=space,args=args,test_only=test,submission=submission,requested_GPUs=0,source_hashes=__PINS__,wrapper_sha256=hashlib.sha256(wrap.read_bytes()).hexdigest(),checkpoint_sha256=__CPSHA__,output=str(output))))
'''
for key,v in dict(CPSHA=cp_sha,PAYLOAD=payload,PINS=pins,WRAP=base64.b64encode(wrap).decode()).items():code=code.replace('__'+key+'__',repr(v))
compile(code,'dispatch_saved_times','exec')
result=ops.remote('athena.technion.ac.il',code);ops.save('s2_saved_times_dispatch_1900.json',result);assert result['rc']==0,result
row=json.loads(result['out']);print(json.dumps({k:row[k] for k in ['at','scope','submission','test_only','output']},indent=2));assert row['submission']['rc']==0,row['submission']
