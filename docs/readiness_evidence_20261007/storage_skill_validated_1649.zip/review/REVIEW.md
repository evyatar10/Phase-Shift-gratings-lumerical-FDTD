# Storage helper independent validation

Scope: read-only review and six focused offline tests, plus one actual local-only snapshot. No network, CAD, solve, cleanup, dispatch, repository or skill edits. Source SHA256 `4f3ca70390c4fe1289c4f57e57dad41542fe894d42e6f80c597a9ae8cdb539ad` stayed unchanged across tests.

The helper uses bounded SSH with strict host keys and BatchMode; generated remote scripts call quota/df/squeue and IGUM lfs quota/lmutil only. No recursive scan, quota-setting, writes, moves/deletes or scheduler mutation appear. Paths match the established Athena and IGUM roots. Every command retains argv/exit code/raw output or error; SSH failures/timeouts and JSON parse failures remain distinct. Missing quota/lfs is explicitly unknown. Results JSON preserves failures; collector exit0 is not a storage pass. Output open mode x protects existing snapshots.

Six offline groups passed exit0: missing executable+timeout retain unknown; fake SSH nonJSON/nonzero and safety options; both generated scripts compile and execute using fake read-only commands with missing quota/lfs; inaccessible local path and malformed remote evidence retained; real existing-output sentinel refused before SSH and unchanged; local-only path invokes neither SSH nor subprocess. Synthetic outputs are not server measurements.

Actual snapshot: `local_storage_snapshot.json`, at 2026-10-07T13:42:10.233873+00:00, clusters={}. Repo/results/TEMP all resolve to the same C: filesystem: 99723616256 bytes free = 99.724 decimalGB = 92.875GiB. These are three path aliases for one capacity, not three amounts to add. User quota is unmeasured; remote quota/bytes/inodes/seats were not contacted. Local CLI exit0 records collection only, not approval for additional outputs.

Nonblocking review observations:
1. `Path.exists()` is false for a dangling symlink. Such a pre-existing output path can pass the pre-SSH check and later be rejected by open('x'). Data remains protected, but refusal is later than intended. This is code-review evidence, not a reproduced Windows symlink test. Proposed tiny guard change for lead review only: replace `a.output.exists()` with `os.path.lexists(a.output)`; os is already imported. No patch applied.
2. Successful SSH returning valid JSON with an unexpected scalar/list schema is stored under snapshot without a schema error. It is not a pass because qualification is explicit, but a narrow dict/checks/path type validation would improve malformed-response diagnostics. No patch applied; retain raw stdout.
3. Raw local rows repeat a shared volume, as observed. Consumers must deduplicate capacity and budget all retained FSP/H5/intermediates; references correctly forbid treating filesystem free space as user quota. The collector itself sets no launch threshold.

The storage-reference cadence is a workflow instruction, not a scheduler. It preserves unknown user/group/project limits and requires outstanding output+retry reserve before new large work. Nothing auto-cleans retained results or terminates jobs. No scope/safety blocker found for normal read-only use; optional diagnostics above remain with lead.
