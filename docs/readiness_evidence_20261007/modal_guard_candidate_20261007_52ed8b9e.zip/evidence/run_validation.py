"""Run the prior twelve candidate gates plus the opt-in modal regression."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
PRIOR=Path('C:/Users/evyat/AppData/Local/Temp/te_restart_candidate_20261007_z8uiww6_')
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
engine=HERE/'runners/lumopt2_design/lumopt2_design.py'
prior_engine=PRIOR/'runners/lumopt2_design/lumopt2_design.py'
production=ROOT/'runners/lumopt2_design/lumopt2_design.py'
data=json.loads((PRIOR/'budget_integration_gate_results.json').read_text())
before=dict(production_engine=sha(production),prior_engine=sha(prior_engine))
sources=[]
for prior in data['results']:
    source=Path(prior['gate_source'])
    if source.is_relative_to(PRIOR):
        source=HERE/source.relative_to(PRIOR)
    sources.append((prior['gate'],source))
sources.append(('gate_modal_guard.py',HERE/'runners/lumopt2_design/gates/gate_modal_guard.py'))
results=[]
for name,source in sources:
    command=[sys.executable,'-X','utf8',str(HERE/'run_gate.py'),str(source)]
    run=subprocess.run(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                       encoding='utf8',timeout=300)
    log=HERE/(name+'.modal_final.log'); log.write_text(run.stdout,encoding='utf8')
    results.append(dict(gate=name,exit_code=run.returncode,gate_source=str(source),
                        gate_sha256=sha(source),command=command,log=str(log)))
    print(f'{name}: exit {run.returncode}',flush=True)
after=dict(production_engine=sha(production),prior_engine=sha(prior_engine))
record=dict(date_utc=datetime.now(timezone.utc).isoformat(),candidate=str(HERE),
    candidate_engine_sha256=sha(engine),before=before,after=after,
    count=len(results),all_passed=all(r['exit_code']==0 for r in results),
    preserved_sources=(before==after),results=results)
(HERE/'modal_guard_gate_results.json').write_text(json.dumps(record,indent=2),encoding='utf8')
sys.exit(0 if record['all_passed'] and record['preserved_sources'] else 1)
