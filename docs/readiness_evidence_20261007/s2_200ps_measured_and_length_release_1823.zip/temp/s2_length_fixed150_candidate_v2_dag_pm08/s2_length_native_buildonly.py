"""Separate native guarded CAD-only qualification; no FDTD entrypoint here."""
import json
import numpy as np
try:
 from . import s2_length_fixed150 as candidate
except ImportError:
 import s2_length_fixed150 as candidate
IS_HELPER=True
N_TASKS=1
SPEC=candidate.SPEC
def main(task_idx):
 if isinstance(task_idx,bool) or not isinstance(task_idx,(int,np.integer)) or task_idx!=0:raise ValueError('Only CAD-only task0 exists')
 paths=candidate.native_paths(for_review=False)
 output=candidate.envpath('S2_LEN_NATIVE_BUILD_ROOT')
 report=candidate.build_only(paths,output)
 report_path=output/'native_build_only_report.json'
 print(json.dumps(dict(status=report['status'],report=str(report_path),no_FDTD_solve=True)))
 return report
if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--task',type=int,default=0);a=parser.parse_args();main(a.task)
