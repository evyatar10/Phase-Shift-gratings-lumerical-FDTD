import contextlib,hashlib,importlib.util,io,json,sys,tempfile,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
P=Path('C:/Users/evyat/.codex/skills/pi-shift-cluster-ops');S=P/'scripts/check_storage.py'
s=importlib.util.spec_from_file_location('storage',S);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Checks(unittest.TestCase):
 def test_scalar_and_list_JSON_rejected(self):
  for v in [1,[],{'checks':[]}]:
   with patch.object(m,'command',return_value=dict(exit_code=0,stdout=json.dumps(v))):r=m.cluster_snapshot('igum')
   self.assertIn('parse_error',r);self.assertNotIn('snapshot',r)
 def test_existing_or_dangling_name_refused_before_collect(self):
  with patch.object(sys,'argv',['check','--output',str(Path(tempfile.gettempdir())/'SYNTHETIC_NAME')]),patch.object(m.os.path,'lexists',return_value=True),patch.object(m,'collect',side_effect=AssertionError('Must not collect')),contextlib.redirect_stderr(io.StringIO()):
   with self.assertRaises(SystemExit) as e:m.main()
  self.assertEqual(e.exception.code,2)
if __name__=='__main__':unittest.main(verbosity=2)
