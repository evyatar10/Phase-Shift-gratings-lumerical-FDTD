# Offline temporal triplet reader

Preparation only for171216100ps results and an explicitly provided future150ps
triplet. No server access, CAD, dispatch, production source edit, coefficient fit, scientific
pass or approval generation. The reader never calls runner.main, reviewed,
verify_result, load_center or any engine method. It imports frozen arithmetic
and pure task/snapshot helpers only. Tests forbid main and import_lumopt2.

Required100ps input is the exact raw pin-map format produced by the parent's
`s2_temporal_fetch_3d1py9r7/fetch_completed.py`:

```json
{
  "0:checkpoint": {"local": "ABSOLUTE_LOCAL_JSON", "path": "REMOTE_TASK00_JSON", "sha256": "PARENT_VERIFIED_SHA", "bytes": 123},
  "0:ports": {"local": "ABSOLUTE_LOCAL_NPZ", "path": "REMOTE_TASK00_NPZ", "sha256": "PARENT_VERIFIED_SHA", "bytes": 123}
}
```

The actual file must contain all six keys0..2 checkpoint/ports, not the partial
example. Its separately recorded SHA256 is mandatory. Actual expected names
are s2_temporal100_task00..02_original.json and matching*_ports.npz, but the
reader uses actual absolute paths from the pin file. Local file sizes/byte
hashes, exact remote checkpoint paths and NPZ path/hash relationships are
checked. The first marker is hard-pinned to951c2025bf3255830a3b13e03a333b18bfb0ba59c86ee4e1c2b150ac078e2206,
remote path `/work/data/s2_temporal100_review_20261007_1257.json`, runner555f.

Every CP must match exact task/index/sign/duration/full point/spec, full frozen
dependency code and API map, parent review and temporal intervention. All local
source dependencies are byte-checked against the marker before scoring.
Controls must preserve the mesh/source/ports/refinement and only change the
documented timing properties plus forward field-storage state. The same narrow
geometry serialization rule is reused; nongeometry fields remain exact.
The completed physical time must be within one recorded dt, status1/full-time
reason, and pulse/timestep readbacks must be self-consistent. Full remote log
paths are checked per task, retaining directory identity; equal basenames do
not merge log identities. All four port wavelength/frequency grids must equal
the reference exactly. Frozen recovery.score values reproduce to1e-12.

The CP bytes pin their FSP/H5/setup/log hashes and source paths. This reader
does **not** independently reopen remote FSP/H5/log bytes or establish job
completion. The parent's completed-state retrieval and direct cold-resume
verify_result checks remain separate required evidence. No actual-result
report is generated if any required artifact is missing or inconsistent.

Existing reference inputs in `--existing-evidence-dir`:

- s2_fdstep_task00_original.json and*_ports.npz (hard-pinned exact repeated
  nominal center cd2dd4...e3be4a06 and ports4c3c526b...035e4).
- s2_shift30_task02/03_original.json and matching*_ports.npz, bound to the
  actual171162 prior checkpoint/NPZ hashes in the100ps marker.

These provide the old auto-shutoff triplet, nominal67.39992ps with endpoints
68.01979/68.34320ps from the prior termination review. The report's approximate
old67ps label does not imply a common old duration. The original-center
projection here is explicitly the cd2dd4 repeated nominal reference, **not**
the earlier saved-adjoint forward's field Jacobian. Same-duration projections
use the exact center spectrum from their own100/150ps triplet.

Run after completed, independently verified actual files are fetched:

```powershell
python -B C:/Users/evyat/AppData/Local/Temp/s2_temporal_analyzer_9dn8pm0k/analyze_temporal.py `
  --repo C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes `
  --existing-evidence-dir C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007 `
  --100-pins C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007/s2_temporal100_artifact_pins_original.json `
  --100-pins-sha256 EXACT_PARENT_RECORDED_FETCH_MANIFEST_SHA `
  --100-marker C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007/s2_temporal100_review_original.json `
  --output NEW_temporal100_review.json --spectra-output NEW_temporal100_full_grid.json
```

For optional150ps append all five arguments `--150-pins`,
`--150-pins-sha256`, `--150-marker`, `--150-marker-sha256`,
`--150-marker-remote`, using actual independently pinned paths/hashes. Partial
150ps arguments fail. Its raw map must contain3..5 checkpoint/ports. The later
marker must retain the exact frozen family and bind all three completed100ps
CP/NPZ/FSP/H5/termination records and first marker SHA. Optional absent150ps is
simply absent; no zero values, guessed completion or scientific approval appear.

Compact results report Tout and modal|S|² separately: moving peak3 FD, odd and
even against each same-duration center, exact reference-center and same-duration
peak3-Jacobian spectral-FD projections with indices/weights/provenance, and
fixed-bin244/252/260 spectral derivatives. Full output retains all501 samples:
each center/plus/minus spectrum, spectral odd/even/central FD, every grid and
same-geometry old→100/100→150/old→150 differences. Raw p1_T_in,p2_T_out and
complex p2_S are also retained; complex arrays have explicit real/imag lists.
These are spectral FD projections, not saved-field adjoint contractions.

Every output says DIAGNOSTIC_ONLY_CALIBRATION_FAILED_UNCHANGED and
no_automatic_approval=true. There are no pass thresholds. One step cannot
establish h-convergence; two times cannot certify infinite-time convergence
or identify a statistical noise bound. Changed spectra alone do not prove
unequal-window causality or diagnose PVA.

Offline: `python -B test_reader.py` here. Seven focused groups pass, using
actual pinned reference inputs and explicitly synthetic temporal NPZ/CP
fixtures retained under fixture_SYNTHETIC_*. They test the full100ps reader and
actual fetch-format CLI, optional150ps ancestry, family/task/center mismatch,
grid changes after deliberate repinning, control/termination/scalar tampering,
remote path/byte-count/missing-input guards and refusal to overwrite outputs.
The synthetic complex modal phases round-trip exactly. No measured171216
result is claimed by these tests. Copied firstwave_helpers.py and
numerical_helpers.py are reused arithmetic; no earlier test suite is rerun.
