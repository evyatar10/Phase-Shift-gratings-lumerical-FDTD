"""Explicitly SYNTHETIC200 protocol tests; no actual200 measurements/CAD/solve."""
import argparse,contextlib,copy,hashlib,importlib.util,io,json,sys,tempfile,types,unittest
from pathlib import Path,PurePosixPath
from unittest.mock import patch
sys.dont_write_bytecode=True
import numpy as np
PACKET=Path('C:/Users/evyat/AppData/Local/Temp/s2_saved200_profile_r6g42i97')
spec=importlib.util.spec_from_file_location('extract200_reviewed',PACKET/'extract200.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
REPO=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
CP150=REPO/'docs/readiness_evidence_20261007/s2_temporal150_fetch_1434/s2_temporal150_task03_original.json'
MARKER=REPO/'docs/readiness_evidence_20261007/s2_temporal200_review_original.json'
API=Path('C:/Program Files/Lumerical/v261/api/python/lumapi.py')
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
class Fixture:
 def __init__(self):
  self.root=Path(tempfile.mkdtemp(prefix='SYNTHETIC200_',dir=Path(__file__).parent));self.files={};self.marker=json.loads(MARKER.read_text());self.center=json.loads(CP150.read_text());self.calls=[]
  self.cp=m.ROOT+'/task_00.json';attempt=m.ROOT+'/task_00_SYNTHETIC';source=attempt+'/synthetic_files/fwd_default.fsp';h5=source[:-4]+'/fwd_default_output.h5';ports=attempt+'/ports.npz'
  self.files[m.MARKER]=MARKER;self.files[m.CENTER]=CP150
  for key,content in [(source,b'SYNTHETIC_FSP_NO_REAL200_RESULTS'),(h5,b'SYNTHETIC_H5_NO_REAL_FIELDS'),(ports,b'SYNTHETIC_PORT_PROTOCOL_PLACEHOLDER')]:
   p=self.root/('artifact_'+str(len(self.files)));p.write_bytes(content);self.files[key]=p
  r=copy.deepcopy(self.center['result']);review=dict(path=m.MARKER,sha256=m.MARKER_SHA,lead_verdict=self.marker['lead_verdict'],allowed_tasks=[0,1,2],parent150=self.marker['parent150'],completed_step150=self.marker['completed_step150'])
  i=dict(schema=1,task=0,spec=self.marker['spec'],point=self.center['identity']['point'],index=29,sign=0,delta_nm=0.,duration_ps=200.,task_map=self.marker['task_map'],center_checkpoint=m.CENTER,center_sha256=m.CENTER_SHA,parent150=self.marker['parent150'],completed_step150=self.marker['completed_step150'],code=self.marker['code'],vendor_api_sha256=self.marker['vendor_api_sha256'],parent_review=review,timing_changes=self.marker['timing_changes'])
  r.update(task=0,index=29,sign=0,delta_nm=0.,duration_ps=200.,parent_review=review,vendor_api_sha256=self.marker['vendor_api_sha256'],params=i['point'],source=source,h5=h5,ports_npz=ports,SYNTHETIC_TEST_ONLY=True)
  for key,field in [('source','fsp_sha256'),('h5','h5_sha256'),('ports_npz','ports_sha256')]:r[field]=digest(self.files[r[key]])
  for state in ['after','persisted']:r['controls'][state]['timing']['simulation time']=200e-12
  r['termination'].update(requested_time_s=200e-12,physical_time_s=200e-12,recorded_dt_s=r['controls']['dt_s'],delta_s=0.,status=1,iterations=3000000)
  self.row=dict(identity=i,result=r,SYNTHETIC_TEST_ONLY=True);self.files[self.cp]=self.root/'SYNTHETIC_checkpoint.json';self.write()
 def write(self):self.files[self.cp].write_text(json.dumps(self.row),encoding='utf-8');self.expected=digest(self.files[self.cp])
 def physical(self,path):return self.files.get(str(path),Path(path))
 def hashed(self,path):
  # Only vendor fingerprint is a CONTROLLED TEST DOUBLE because fakeCAD cannot
  # execute Athena Linux vendor bytes on Windows. It is NOT hardware evidence.
  p=Path(path)
  try:key=str(p.relative_to(API.parent)).replace('\\','/')
  except ValueError:key=None
  if key in self.marker['vendor_api_sha256']:return self.marker['vendor_api_sha256'][key]
  return digest(self.physical(path))
 def path_factory(self,value):
  if isinstance(value,ServerPath):return value
  return ServerPath(str(value),self) if str(value).startswith('/work/') else Path(value)
 def identity(self,path):
  p=self.physical(path);s=p.stat();return dict(path=str(path),bytes=s.st_size,mtime_ns=s.st_mtime_ns,sha256=self.hashed(path))
 def patches(self):
  stack=contextlib.ExitStack();stack.enter_context(patch.object(m,'Path',self.path_factory));stack.enter_context(patch.object(m.h,'sha',side_effect=self.hashed));stack.enter_context(patch.object(m.h,'identity',side_effect=self.identity));return stack
 def validated(self):return m.validate(self.cp,self.expected,REPO)
class ServerPath:
 """TEST filesystem adapter:exact Linux Path semantics,ownedTEMP byte storage."""
 def __init__(self,value,fixture):self.value=PurePosixPath(value);self.fixture=fixture
 def __str__(self):return str(self.value)
 def __fspath__(self):return str(self.fixture.physical(str(self)))
 def __truediv__(self,k):return ServerPath(str(self.value/k),self.fixture)
 def __eq__(self,other):return str(self)==str(other)
 @property
 def parent(self):return ServerPath(str(self.value.parent),self.fixture)
 def with_suffix(self,x):return ServerPath(str(self.value.with_suffix(x)),self.fixture)
 def read_bytes(self):return self.fixture.physical(str(self)).read_bytes()
 def read_text(self,*args,**kwargs):return self.fixture.physical(str(self)).read_text(*args,**kwargs)
 def resolve(self):return self
class Tests(unittest.TestCase):
 def setUp(self):self.f=Fixture()
 def test_positive_full_metadata_and_exact_cross_platform_path(self):
  m.validate_metadata(self.f.row,self.f.marker,self.f.center)
  self.assertEqual(str(m.server_path(self.f.cp)),self.f.cp)
  for p in [self.f.cp.replace('/task_00.json','/../task_00.json'),self.f.cp.replace('/results/','//results/',1),self.f.cp.replace('/','\\')]:
   with self.assertRaises(RuntimeError):m.server_path(p)
  with self.f.patches():self.assertEqual(self.f.validated()['identity']['duration_ps'],200.)
 def test_wrong_checkpoint_marker_role_status_source_before_CAD(self):
  cases=[lambda r:r['identity'].update(task=1),lambda r:r['identity']['parent_review'].update(sha256='0'*64),lambda r:r['result']['termination'].update(status=2),lambda r:r['result']['termination'].update(requested_time_s=150e-12),lambda r:r['result']['controls'].update(dt_s=float('inf')),lambda r:r['identity']['code'].update(lumopt2_design='wrong'),lambda r:r['identity'].update(point=[0]*296)]
  for change in cases:
   f=Fixture();change(f.row);f.write()
   with f.patches():
    with self.assertRaises((RuntimeError,KeyError)):f.validated()
  with self.f.patches():
   with self.assertRaises(RuntimeError):m.validate(self.f.cp,'0'*64,REPO)
   with self.assertRaises(RuntimeError):m.validate(m.ROOT+'/task_01.json',self.f.expected,REPO)
 def test_artifact_escape_other_task_and_missing_digest_refusal(self):
  for change in [lambda r:r['result'].update(ports_npz='/work/results/elsewhere/ports.npz'),lambda r:r['result'].update(source=r['result']['source'].replace('task_00_','task_01_')),lambda r:r['result'].update(source=r['result']['source'].replace('/synthetic_files/','/../')),lambda r:r['result'].update(fsp_sha256='0'*64)]:
   f=Fixture();change(f.row);f.write()
   with f.patches():
    with self.assertRaises(RuntimeError):f.validated()
 def test_actual_run_refuses_bad_bytes_role_marker_vendor_before_CAD(self):
  for bad in ['checkpoint_bytes','marker_bytes','role','vendor']:
   f=Fixture();called=[];fake_api=types.ModuleType('lumapi');fake_api.__file__=str(API)
   def forbidden(*args,**kwargs):called.append(True);raise AssertionError('CAD invoked on invalid evidence')
   fake_api.FDTD=forbidden
   if bad=='checkpoint_bytes':f.files[f.cp].write_bytes(f.files[f.cp].read_bytes()+b'\n')
   if bad=='marker_bytes':
    p=f.root/'SYNTHETIC_BAD_MARKER.json';p.write_bytes(MARKER.read_bytes()+b'\n');f.files[m.MARKER]=p
   if bad=='role':f.row['identity']['task']=1;f.write()
   oldhash=f.hashed
   if bad=='vendor':f.hashed=lambda p:'0'*64 if Path(p)==API else oldhash(p)
   a=argparse.Namespace(output=str(f.root/'SYNTHETIC_INVALID_OUTPUT'),repo=str(REPO),checkpoint=f.cp,checkpoint_sha256=f.expected,lumapi=str(API))
   with f.patches(),patch.dict(sys.modules,{'lumapi':fake_api}):
    with self.assertRaises(RuntimeError):m.run(a)
   self.assertEqual(called,[]);self.assertFalse(Path(a.output).exists())
 def flow(self,mutate=None):
  f=self.f;fake_api=types.ModuleType('lumapi');fake_api.__file__=str(API)
  class FakeCAD:
   def __init__(self,hide):self.assert_hide=hide;f.calls.append(('constructor',hide))
   def load(self,path):f.calls.append(('load',path))
   def getresult(self,obj,result):self.assert_status=(obj,result);return 1
   def close(self):
    f.calls.append(('close',))
    if mutate=='class':fake_api.FDTD=type('ChangedClass',(),{})
    if mutate=='constructor':FakeCAD.__init__=lambda *args,**kwargs:None
  fake_api.FDTD=FakeCAD
  def synthetic_extract(cad,eng,row,ports,out,duration,nearby,trace):
   self.assertEqual(duration,200);self.assertTrue(nearby);self.assertEqual(cad.getresult('FDTD','status'),1)
   for method in ['run','runjobs','save','runsystemcheck']:
    with self.assertRaises(RuntimeError):getattr(cad,method)()
   trace['SYNTHETIC_TEST_ONLY']=True;return dict(duration_ps=200,SYNTHETIC_TEST_ONLY=True)
  a=argparse.Namespace(output=str(f.root/'SYNTHETIC_OUTPUT'),repo=str(REPO),checkpoint=f.cp,checkpoint_sha256=f.expected,lumapi=str(API))
  # NPZ/score and core extraction are controlled protocol doubles; core994c has
  # its separate hardware-used100/150 evidence and is not re-audited here.
  class NPZ:
   files=[]
   def __enter__(self):return self
   def __exit__(self,*args):pass
  sys.path.insert(0,str(REPO));from runners.lumopt2_design import recover_te_s2 as recovery
  scores={k:f.row['result'][k] for k in ['peak3_tout','peak3_modal','lam_nm']}
  with f.patches(),patch.dict(sys.modules,{'lumapi':fake_api}),patch.object(np,'load',return_value=NPZ()),patch.object(recovery,'score',return_value=scores),patch.object(m.h,'optional_h5_inventory',return_value={'status':'UNAVAILABLE','SYNTHETIC_TEST_ONLY':True}),patch.object(m.h,'extract',side_effect=synthetic_extract),contextlib.redirect_stdout(io.StringIO()):rc=m.run(a)
  report=json.loads((Path(a.output)/'report.json').read_text());return rc,report
 def test_positive_fakeCAD_flow_explicit_synthetic200(self):
  rc,report=self.flow();self.assertEqual(rc,0);self.assertTrue(report['stages']['200']['SYNTHETIC_TEST_ONLY']);self.assertTrue(report['all_inputs_preserved']);self.assertEqual(self.f.calls[0],('constructor',True));self.assertEqual(self.f.calls[-1],('close',))
 def test_class_constructor_changed_fail_closed(self):
  for mutation in ['class','constructor']:
   self.f=Fixture();rc,report=self.flow(mutation);self.assertEqual(rc,1);self.assertEqual(report['status'],'EXTRACTION_FAILED_CLOSED')
if __name__=='__main__':unittest.main(verbosity=2)
