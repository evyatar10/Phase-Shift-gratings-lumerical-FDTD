"""IGUM101434 pinned saved N98/N80 profiles; read-only CPU CAD, no physics pass."""
import argparse, importlib, json, sys
from pathlib import Path
import numpy as np
sys.dont_write_bytecode=True
import spatial_support as s
s.need(s.sha(s.__file__)=='994c3e9757a10b5bd8ea211aaee8425c5d3540203a4da04b0439684163baf6ca','Support byte identity changed')
BASE=Path('/research/amir.r/evyatarrubin/bragg_sim_igum')
ROOT=BASE/'results/diagnose_te_s2_length/results/s2_length_N98_N80_fixed150_20261007'
PINS=['116fdc0be132d934626e5d776f4982b6cc628fdbb9d59d008591069ff34e0c83','340325ffb42980b34eadbc224c2b9ce0aa6d6f1d8d6eb3ce4d3c58a8137ec0e9']
API=Path('/research/amir.r/evyatarrubin/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261/api/python/lumapi.py')
def checkpoint(path,task):
 s.need(path.resolve()==ROOT/f'task_{task:02d}.json','Exact original native CP path required')
 s.need(s.sha(path)==PINS[task],'Original CP raw SHA mismatch')
 row=json.loads(path.read_text());validate_checkpoint_schema(row,task)
 r=row['result']
 for key,digest in [('source','fsp_sha256'),('h5','h5_sha256'),('ports_npz','ports_sha256')]:s.need(s.sha(r[key])==r[digest],'Original '+key+' SHA mismatch')
 s.need(Path(r['source']).parent.parent==ROOT and Path(r['h5'])==Path(r['source']).with_suffix('')/'fwd_default_output.h5' and Path(r['ports_npz'])==Path(r['source']).parent/'ports.npz','Original artifact binding mismatch')
 return row

def validate_checkpoint_schema(row,task):
 i,r=row['identity'],row['result'];n=[98,80][task]
 s.need(i['task']==r['task']==task and i['physical_N']==r['physical_N']==i['spec']['n_periods_side']==n,'Physical N/task mismatch')
 s.need(i['duration_ps']==r['duration_ps']==150 and i['point']==r['params'] and len(i['point'])==296,'Duration/point mismatch')
 s.need(i['spec']['polarization']=='TE' and i['spec']['n_free']==60 and i['spec']['bare'],'Family mismatch')
 term=r['termination'];s.need(term['status']==1 and term['reason']=='completed_full_simulation_time' and term['requested_time_s']==150e-12 and np.isfinite(term['recorded_dt_s']) and term['recorded_dt_s']>0 and abs(term['physical_time_s']-150e-12)<=term['recorded_dt_s'],'Saved completion mismatch')
 s.need(Path(i['scope']['API_path'])==API,'Pinned native canonical API differs')

def validate_grid(coords,shape,row,ports):
 m=row['result']['profile_metadata'];s.need(m['have_raw_data'] is True and m['have_E_result'] is True,'Saved raw E unavailable')
 s.need(list(shape)==m['E_shape'],'Actual E shape differs from CP metadata')
 for key in ['x','y','z','lambda']:s.need(np.array_equal(coords[key],m['axes'][key+'_m']),'Actual coordinate differs from CP metadata: '+key)
 wl=np.asarray(ports['p2_lambda']).ravel();s.need(wl.shape==(501,) and np.array_equal(coords['lambda'],wl),'Exact501 port/profile lambda mismatch')
 s.need(np.array_equal(np.asarray(ports['p2_f']).ravel(),m['axes']['f_Hz']),'Exact501 frequency metadata mismatch')

def profiles(cad,eng,row,ports):
 s.need(float(np.asarray(cad.getresult('FDTD','status')).squeeze())==1,'Cold saved FDTD status !=1')
 s.need(float(np.asarray(cad.getnamed('field_profile','enabled')).squeeze())==1,'Saved profile recorder disabled')
 trace={};coords,shape,selected=s.transfer_selected(cad,trace);validate_grid(coords,shape,row,ports)
 output={'monitor_lambda_m':coords['lambda']};summary={};n=row['identity']['physical_N']
 for name,values in [('Tout',abs(np.asarray(ports['p2_T_out']).ravel())),('modal',abs(np.asarray(ports['p2_S']).ravel())**2)]:
  peak,T,width=eng.measure_peak(coords['lambda']*1e9,values)
  s.need(width is not None and T>eng.DEAD_T_FLOOR,'Tracked resonance unavailable')
  k=int(np.argmin(abs(coords['lambda']-peak*1e-9)));s.need(0<=k<501,'Selected wavelength unavailable')
  e=selected(k);one={**coords,'lambda':coords['lambda'][k:k+1]}
  for crop in [80,98]:
   label=name+'_cropN'+str(crop);meta,arrays=s.processed_profile(eng,one,e,float(peak),n=crop)
   s.need(np.array_equal(arrays['x_um'],coords['x'][abs(coords['x']*1e6)<=crop*491.06/1000]*1e6),'Exact production crop mismatch')
   meta.update(physical_N=n,crop_N=crop,own_production_crop=(crop==n),diagnostic_common_crop=True,original_monitor_frequency_index=k,target_minus_monitor_nm=float(peak-coords['lambda'][k]*1e9),qualification='Own N crop production metric; both common crops diagnose metric window only; no mesh/temporal/gradient pass')
   summary[label]=meta
   for key,value in arrays.items():output[label+'__'+key]=value
 return dict(raw_profile_inventory=trace,profiles=summary,guard_audit=cad.audit),output

def run(args):
 out=Path(args.output).resolve();s.need(not out.exists(),'Exclusive NEW output required');out.mkdir()
 report={'status':'STARTED','no_solve':True,'job_id':'101434','stages':{}};snapshots=[s.identity(__file__),s.identity(s.__file__)];fdtd=None;ctor=None
 try:
  repo=BASE/'project';s.need(Path(args.repo).resolve()==repo,'Exact native repo required');s.need(Path(args.lumapi).resolve()==API,'Exact native API required')
  rows=[checkpoint(ROOT/f'task_{t:02d}.json',t) for t in [0,1]]
  for t,row in enumerate(rows):
   r=row['result'];snapshots.extend(s.identity(p) for p in [ROOT/f'task_{t:02d}.json',r['source'],r['h5'],r['ports_npz']])
   code=row['identity']['scope']['code'];s.need(len(code)==17,'Exact17 source fingerprints required')
   for name,digest in code.items():
    p=repo/name if name in ['config.py','bragg_device.py','simulation_config.py','sim_helpers.py'] else repo/'runners/lumopt2_design'/name
    s.need(s.sha(p)==digest,'Frozen source differs: '+name);snapshots.append(s.identity(p))
   vendor={str(p.relative_to(API.parent)).replace('\\','/'):s.sha(p) for p in sorted((API.parent/'lumopt2').rglob('*.py'))+[API]}
   extra=API.parent/'lumslurm.py'
   if extra.is_file():vendor['lumslurm.py']=s.sha(extra)
   s.need(vendor==row['identity']['scope']['vendor_api_sha256']==r['vendor_api_sha256'],'Vendor fingerprint differs')
   snapshots.extend(s.identity(API.parent/name) for name in vendor)
  sys.path[:0]=[str(API.parent),str(repo)];import lumapi
  s.need(Path(lumapi.__file__).resolve()==API,'Imported API differs');fdtd=lumapi.FDTD;ctor=fdtd.__init__
  from runners.lumopt2_design import lumopt2_design as eng, recover_te_s2 as recovery
  from scipy.io import savemat
  for t,row in enumerate(rows):
   r=row['result'];raw=lumapi.FDTD(hide=True);cad=s.ReadOnlyCAD(raw,r['source'])
   try:
    cad.load(r['source'])
    with np.load(r['ports_npz'],allow_pickle=False) as z:ports={k:z[k] for k in z.files}
    score=recovery.score(ports);s.need(all(abs(float(score[k])-float(r[k]))<=1e-12 for k in ['peak3_tout','peak3_modal','lam_nm']),'Pinned port scores differ')
    stage,arrays=profiles(cad,eng,row,ports)
    npz=out/f'N{r["physical_N"]}_profiles.npz';mat=out/f'N{r["physical_N"]}_profiles.mat'
    with npz.open('xb') as f:np.savez_compressed(f,**arrays)
    with mat.open('xb') as f:savemat(f,{**arrays,'metadata_json':json.dumps(s.plain(stage))},do_compression=True,long_field_names=True)
    stage.update(npz=str(npz),npz_sha256=s.sha(npz),mat=str(mat),mat_sha256=s.sha(mat));report['stages'][str(t)]=stage
   finally:cad.close()
  report['status']='SAVED_LENGTH_PROFILES_COMPLETE_NO_PHYSICS_PASS'
 except Exception as exc:report.update(status='FAILED_CLOSED',error=type(exc).__name__+': '+str(exc))
 finally:
  report['immutable_inputs_rechecked']=[]
  for x in snapshots:
   try:
    after=s.identity(x['path']);report['immutable_inputs_rechecked'].append(dict(before=x,after=after,unchanged=x==after))
   except Exception as exc:report['immutable_inputs_rechecked'].append(dict(before=x,unchanged=False,error=str(exc)))
  report['all_inputs_preserved']=bool(snapshots) and all(x['unchanged'] for x in report['immutable_inputs_rechecked'])
  if fdtd is not None:
   report['FDTD_class_unchanged']=lumapi.FDTD is fdtd;report['FDTD_constructor_unchanged']=lumapi.FDTD.__init__ is ctor
   if not (report['FDTD_class_unchanged'] and report['FDTD_constructor_unchanged']):report['status']='FAILED_CLOSED'
  if not report['all_inputs_preserved']:report['status']='FAILED_CLOSED'
  (out/'report.json').write_text(json.dumps(s.plain(report),indent=2,allow_nan=False))
 print(report['status']);return int(report['status']=='FAILED_CLOSED')
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__)
 for key in ['repo','lumapi','output']:p.add_argument('--'+key,required=True)
 raise SystemExit(run(p.parse_args()))
