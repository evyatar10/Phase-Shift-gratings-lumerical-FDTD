"""Read source normalization of exact saved centers; no solve or object mutation."""
import argparse,json,sys
from pathlib import Path
import numpy as np
from scipy.io import savemat
import read_saved_times as t
need,sha,plain,identity=t.need,t.sha,t.plain,t.identity
need(sha(t.__file__)=='b4b4944e174a2766c88ff7fa687a8fa9455805d16db6c7b120432ba67f5fc4cd','Reviewed dependency changed')
SCRIPT='sc_norm=sourcenorm(sc_f);sc_power=sourcepower(sc_f);'
PROPS=('phase','source mode','source port','frequency','bandwidth','pulselength','offset','optimize for short pulse','set time domain','set frequency','wavelength start','wavelength stop','multifrequency mode calculation','number of field profile samples')
def validate(f,norm,power):
 f,norm,power=[np.asarray(v).ravel() for v in [f,norm,power]]
 need(f.size==norm.size==power.size==501,'Exact501 samples required')
 need(np.isfinite(f).all() and np.all(f>0) and np.all(np.diff(f)>0) or np.isfinite(f).all() and np.all(f>0) and np.all(np.diff(f)<0),'Monotone positive f required')
 need(np.isfinite(norm).all() and np.isfinite(power).all() and np.isrealobj(power) and np.all(power>0) and np.all(abs(norm)>0),'Finite nonzero norm and positive real power required')
 return dict(f_Hz=f,source_norm=norm,source_power=power)
def inspect(cad,ports):
 cad.raw.putv('sc_f',ports['p2_f'])
 cad.raw.eval('sc_norm=0;sc_power=0;'+SCRIPT)
 data=validate(ports['p2_f'],cad.raw.getv('sc_norm'),cad.raw.getv('sc_power'))
 settings=t.source_settings(cad)
 for obj in ['FDTD::ports','FDTD::ports::Port_1']:
  settings[obj]={}
  for key in PROPS:
   try:settings[obj][key]=dict(available=True,value=plain(cad.getnamed(obj,key)))
   except Exception as exc:settings[obj][key]=dict(available=False,error=str(exc))
 for key in ['p1_S','p2_S','p1_T_in','p2_T_out','p1_T_out']:
  if key in ports:data[key]=ports[key]
 return data,dict(settings=settings,read_only_script=SCRIPT,qualification='Normalization returned by loaded FSP; no causal or convergence verdict')
def run(a):
 out=Path(a.output);need(out.is_absolute() and not out.exists(),'New absolute output required');out.mkdir()
 report=dict(status='STARTED',stages={},no_solve=True);snapshots=[];klass=None;ctor=None
 try:
  repo=Path(a.repo).resolve();api=Path(a.lumapi).resolve();rows={}
  for d in [100,150,200]:
   cp=Path(getattr(a,'checkpoint'+str(d)));r=t.load_center(cp,d);rows[d]=r
   deps=t.verify_sources(repo,api,r);snapshots.extend(identity(x) for x in [cp,r['result']['source'],r['result']['h5'],r['result']['ports_npz'],*deps,Path(__file__)])
  need(all(rows[d]['identity']['point']==rows[100]['identity']['point'] for d in [150,200]),'Geometry differs')
  sys.path.insert(0,str(api.parent));import lumapi;need(Path(lumapi.__file__).resolve()==api,'API differs');klass=lumapi.FDTD;ctor=klass.__init__
  for d,row in rows.items():
   r=row['result'];raw=lumapi.FDTD(hide=True);cad=t.TimeCAD(raw,r['source'])
   try:
    cad.load(r['source']);need(float(np.asarray(cad.getresult('FDTD','status')).squeeze())==1,'Saved status not1')
    with np.load(r['ports_npz'],allow_pickle=False) as z:ports={k:z[k] for k in z.files}
    data,meta=inspect(cad,ports);npz=out/f'source_{d}ps.npz';mat=out/f'source_{d}ps.mat'
    with npz.open('xb') as f:np.savez_compressed(f,**data)
    with mat.open('xb') as f:savemat(f,data,do_compression=True)
    report['stages'][str(d)]={**meta,'npz':str(npz),'npz_sha256':sha(npz),'mat':str(mat),'mat_sha256':sha(mat)}
   finally:cad.close()
  report['status']='SOURCE_READOUT_COMPLETE_NO_PHYSICS_PASS'
 except Exception as exc:report.update(status='FAILED_CLOSED',error=type(exc).__name__+': '+str(exc))
 finally:
  report['preservation']=[]
  for old in snapshots:
   try:after=identity(old['path']);report['preservation'].append(dict(before=old,after=after,unchanged=old==after))
   except Exception as exc:report['preservation'].append(dict(before=old,unchanged=False,error=str(exc)))
  report['all_inputs_preserved']=bool(snapshots) and all(x['unchanged'] for x in report['preservation'])
  if klass is not None:
   report['class_unchanged']=lumapi.FDTD is klass;report['ctor_unchanged']=klass.__init__ is ctor
   if not report['class_unchanged'] or not report['ctor_unchanged']:report['status']='FAILED_CLOSED'
  if not report['all_inputs_preserved']:report['status']='FAILED_CLOSED'
  with (out/'report.json').open('x') as f:json.dump(plain(report),f,indent=2,allow_nan=False)
 print(report['status'],report.get('error',''));return int(report['status']=='FAILED_CLOSED')
if __name__=='__main__':
 p=argparse.ArgumentParser()
 for k in ['repo','lumapi','checkpoint100','checkpoint150','checkpoint200','output']:p.add_argument('--'+k,required=True)
 raise SystemExit(run(p.parse_args()))
