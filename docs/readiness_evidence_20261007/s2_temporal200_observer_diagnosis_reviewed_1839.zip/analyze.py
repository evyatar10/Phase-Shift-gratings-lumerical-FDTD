"""Pinned saved-data200ps diagnosis only; no CAD/network/objective change."""
import argparse,hashlib,json,sys
from pathlib import Path
import numpy as np
from scipy.io import loadmat
from autograd import grad
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');sys.path.insert(0,str(ROOT))
from runners.lumopt2_design import lumopt2_design as eng
from runners.lumopt2_design import v3_step as v3
from height_estimators import estimate,UnsupportedPeak
H=.0625
PINS_SHA='82b5a5df987e366b29523d1c2807399aca09cc025fe0f1a2e030007aa58afd26'
MANIFEST_SHA='e7fdd774efebb970b87eecc61336976c607bc962f2a0b179f63b358dccbf3adf'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(x,message):
 if not x:raise RuntimeError(message)
def plain(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 if isinstance(x,dict):return {k:plain(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [plain(v) for v in x]
 return x
def peak(y,wl,f):
 lam,height,width=eng.measure_peak(wl,y);need(width is not None,'Truncated halfheight linewidth')
 k=int(np.argmin(abs(wl-lam)));weights=np.asarray(grad(eng.make_fct_peak(wl))(y));support=np.flatnonzero(weights)
 need(np.array_equal(support,np.arange(k-1,k+2)),'Actual three-bin support required')
 r=v3.peak3_r(y,k);vertex_f=f[k]+r*(f[k+1]-f[k]);window=np.flatnonzero(abs(wl-lam)<=eng.WIN_FWHM_MULT*width)
 return dict(index=k,r_bins=r,vertex_lambda_nm=299792458./vertex_f*1e9,peak3=float(eng.make_fct_peak(wl)(y)),sample_height=height,FWHM_nm=width,support=support,weights=weights[support],full_J=weights,carrier_softmax_window=[int(window[0]),int(window[-1]),int(window.size)])
def cancellation(terms):
 total=float(np.sum(terms));absolute=float(np.sum(abs(terms)))
 return dict(sum=total,sum_absolute_terms=absolute,cancellation_fraction=1-abs(total)/absolute if absolute else 0.,absolute_sum_over_absolute_projection=absolute/abs(total) if total else None)
def observer(y,k):
 fit=estimate(y,int(k),'quartic11');sensitivity=[]
 for anchor in [k-1,k+1]:
  try:q=estimate(y,int(anchor),'quartic11');sensitivity.append({'anchor_index':int(anchor),'height_delta':q['height']-fit['height'],'supported':True})
  except UnsupportedPeak as e:sensitivity.append({'anchor_index':int(anchor),'supported':False,'reason':str(e)})
 return dict(height=fit['height'],window_indices=fit['indices'],offset_bins=fit['offset_bins'],fit_residual_rms=fit['fit_residual_rms'],fit_residual_max_abs=fit['fit_residual_max_abs'],condition=fit['design_condition_number'],Jacobian_l2_white_noise_gain_MODEL_ONLY=fit['jacobian_l2'],window_anchor_sensitivity=sensitivity,height_minus_peak3=fit['height']-float(v3.peak3(y,k)),full_J=fit['jacobian'])
def triplet(curves,wl,f):
 peaks={g:peak(np.asarray(curves[g]),wl,f) for g in ['center','plus','minus']};fd=(np.asarray(curves['plus'])-np.asarray(curves['minus']))/(2*H);p=peaks['center'];J=p['full_J'];terms=J[p['support']]*fd[p['support']]
 moving=(peaks['plus']['peak3']-peaks['minus']['peak3'])/(2*H);R={g:peaks[g]['peak3']-p['peak3']-float(J@(np.asarray(curves[g])-np.asarray(curves['center']))) for g in ['plus','minus']}
 need(abs((R['plus']-R['minus'])/(2*H)-(moving-float(J@fd)))<2e-15,'Nonlinear residual identity failed')
 fits={g:observer(np.asarray(curves[g]),peaks[g]['index']) for g in ['center','plus','minus']}
 return dict(peaks=peaks,support_terms=[{'index':int(i),'J':float(J[i]),'FD_per_nm_shift30':float(fd[i]),'J_times_FD_per_nm_shift30':float(J[i]*fd[i])} for i in p['support']],cancellation=cancellation(terms),moving_peak3_FD_per_nm_shift30=moving,fixed_center_J_times_FD_per_nm_shift30=float(J@fd),exact_finite_step_nonlinear_residual_per_nm_shift30=moving-float(J@fd),nonlinear_endpoint_residuals=R,quartic11=dict(fits=fits,moving_FD_per_nm_shift30=(fits['plus']['height']-fits['minus']['height'])/(2*H),fixed_center_J_times_FD_per_nm_shift30=float(fits['center']['full_J']@fd)))
def run(output):
 output=Path(output);need(output.is_absolute() and not output.exists(),'NEW absolute output required');E=ROOT/'docs/readiness_evidence_20261007';fetch=E/'s2_temporal200_fetch_1758';pins_path=fetch/'s2_temporal200_artifact_pins_original.json';manifest=fetch/'s2_temporal200_fetch_manifest.json'
 need(sha(pins_path)==PINS_SHA and sha(manifest)==MANIFEST_SHA,'Exact200 pins/manifest required');pins=json.loads(pins_path.read_text());inputs={str(pins_path):sha(pins_path),str(manifest):sha(manifest)}
 need(set(pins)=={f'{t}:{role}' for t in [0,1,2] for role in ['checkpoint','ports']},'Exact200 task artifacts required')
 for item in pins.values():
  p=Path(item['local']);need(p.parent==fetch and p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],'Pinned raw artifact mismatch');inputs[str(p)]=sha(p)
 report_path=E/'s2_temporal200_review_1759.json';spectra_path=E/'s2_temporal200_spectra_1759.json';report=json.loads(report_path.read_text());need(sha(spectra_path)==report['full_spectra_sha256'],'Exact verified spectra JSON required');spectra=json.loads(spectra_path.read_text())
 mat_path=ROOT/'results_from_athena/te_readiness_20261007/spatial_profiles_1558/te_s2_fixed200_duration_spectra.mat';need(sha(mat_path)==report['MAT_sha256'],'Exact actual MAT required');mat=loadmat(mat_path,simplify_cells=True)
 columns=['center','plus','minus','spectral_central_fd','spectral_odd','spectral_even_same_duration_center']
 for obs in ['peak3_tout','peak3_modal']:
  for duration in ['100','150','200']:
   expected=np.column_stack([spectra['observables'][obs][duration][g] for g in columns]);need(np.array_equal(mat[obs+'_'+duration],expected),'Actual MAT roundtrip mismatch')
 wl=np.asarray(spectra['grids']['p2_lambda']).ravel()*1e9;f=np.asarray(spectra['grids']['p2_f']).ravel();result=dict(status='SAVED_DATA_DIAGNOSIS_NO_GRADIENT_CONVERGENCE_OR_NOISE_PASS',h_nm_shift30=H,MAT_roundtrip_bitwise=True,observables={})
 for task,g in enumerate(['center','plus','minus']):
  row=json.loads(Path(pins[f'{task}:checkpoint']['local']).read_text());old=json.loads((E/f's2_temporal150_fetch_1434/s2_temporal150_task{task+3:02d}_original.json').read_text());need(row['identity']['point']==old['identity']['point'] and row['result']['duration_ps']==200. and row['result']['termination']['status']==1,'Matched geometry/200ps/status required')
  with np.load(pins[f'{task}:ports']['local'],allow_pickle=False) as z:
   need(np.array_equal(np.abs(z['p2_T_out']).ravel(),spectra['observables']['peak3_tout']['200'][g]) and np.array_equal((np.abs(z['p2_S'])**2).ravel(),spectra['observables']['peak3_modal']['200'][g]),'Raw200 observable reproduction mismatch')
 for obs in ['peak3_tout','peak3_modal']:
  groups={t:triplet(spectra['observables'][obs][t],wl,f) for t in ['150','200']};drift={}
  for g in ['center','plus','minus']:
   y150=np.asarray(spectra['observables'][obs]['150'][g]);y200=np.asarray(spectra['observables'][obs]['200'][g]);delta=y200-y150;p150,p200=groups['150']['peaks'][g],groups['200']['peaks'][g];k=int(np.argmax(abs(delta)));near=abs(wl-p150['vertex_lambda_nm'])<=p150['FWHM_nm']/2
   drift[g]=dict(peak3_height_delta=p200['peak3']-p150['peak3'],quartic11_height_delta=groups['200']['quartic11']['fits'][g]['height']-groups['150']['quartic11']['fits'][g]['height'],vertex_shift_pm=(p200['vertex_lambda_nm']-p150['vertex_lambda_nm'])*1000,FWHM_change_pm=(p200['FWHM_nm']-p150['FWHM_nm'])*1000,max_absolute_spectral_drift=float(abs(delta[k])),max_drift_index=k,max_drift_offset_from150_vertex_pm=float((wl[k]-p150['vertex_lambda_nm'])*1000),max_drift_offset_over150_FWHM=float((wl[k]-p150['vertex_lambda_nm'])/p150['FWHM_nm']),fraction_squared_spectral_drift_within150_halfheight_interval=float(np.sum(delta[near]**2)/np.sum(delta**2)),support_peak_bins_150_200=[p150['index'],p200['index']],carrier_windows_150_200=[p150['carrier_softmax_window'],p200['carrier_softmax_window']])
  FD150=np.asarray(spectra['observables'][obs]['150']['spectral_central_fd']);FD200=np.asarray(spectra['observables'][obs]['200']['spectral_central_fd']);J150=groups['150']['peaks']['center']['full_J'];J200=groups['200']['peaks']['center']['full_J']
  decomposition=dict(old_J_times_FD_drift=float(J150@(FD200-FD150)),Jacobian_weight_drift_times_new_FD=float((J200-J150)@FD200),total_projection_drift=float(J200@FD200-J150@FD150),qualification='Exact algebra on saved spectral finite differences; not spectral adjoint or measured noise')
  need(abs(decomposition['old_J_times_FD_drift']+decomposition['Jacobian_weight_drift_times_new_FD']-decomposition['total_projection_drift'])<1e-16,'Projection decomposition failed')
  for t in ['150','200']:
   published=report['observables'][obs]['triplets'][t];need(abs(groups[t]['moving_peak3_FD_per_nm_shift30']-published['central_derivative'])<1e-14 and abs(groups[t]['fixed_center_J_times_FD_per_nm_shift30']-published['exact_center_peak3_jacobian_projection'])<1e-14,'Published FD/projection reproduction failed')
  result['observables'][obs]=dict(triplets=groups,drift=drift,projection_drift_decomposition=decomposition)
 for p in [report_path,spectra_path,mat_path,Path(eng.__file__),Path(v3.__file__),Path(__file__).with_name('height_estimators.py')]:inputs[str(p)]=sha(p)
 # Exclude full501 Jacobian vectors from compact JSON; support/fit weights remain reproducible.
 def compact(x):
  if isinstance(x,dict):return {k:compact(v) for k,v in x.items() if k!='full_J'}
  if isinstance(x,list):return [compact(v) for v in x]
  return plain(x)
 output.mkdir();result['input_sha256']=inputs
 with (output/'diagnosis.json').open('x',encoding='utf-8') as stream:json.dump(compact(result),stream,indent=2,allow_nan=False)
 import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
 fig,axes=plt.subplots(2,2,figsize=(10,6),constrained_layout=True)
 for row,obs in enumerate(['peak3_tout','peak3_modal']):
  nominal=result['observables'][obs]['triplets']['150']['peaks']['center']['vertex_lambda_nm'];x=(wl-nominal)*1000;mask=abs(x)<160
  for g in ['center','plus','minus']:
   delta=np.asarray(spectra['observables'][obs]['200'][g])-np.asarray(spectra['observables'][obs]['150'][g]);axes[row,0].plot(x[mask],delta[mask],label=g)
  axes[row,0].set(xlabel='Wavelength offset from150ps center vertex (pm)',ylabel='200−150 power fraction',title=obs);axes[row,0].legend()
  for t,offset in [('150',-.15),('200',.15)]:
   terms=result['observables'][obs]['triplets'][t]['support_terms'];axes[row,1].bar(np.arange(3)+offset,[v['J_times_FD_per_nm_shift30'] for v in terms],width=.3,label=t+'ps')
  axes[row,1].set_xticks(np.arange(3),[str(v['index']) for v in terms]);axes[row,1].set(xlabel='Actual center peak3 support bin',ylabel='Jᵢ FDᵢ (power fraction / nm shift30)',title='Support terms; sum is small through cancellation');axes[row,1].legend()
 fig.savefig(output/'temporal_drift_and_support.png',dpi=170);plt.close(fig)
 print(json.dumps({'output':str(output),'MAT_roundtrip':True,'status':result['status']}))
 return result
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',required=True);args=parser.parse_args();run(args.output)
