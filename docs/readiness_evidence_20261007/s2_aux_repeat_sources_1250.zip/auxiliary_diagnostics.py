"""Exact auxiliary snapshots and drift diagnostics; no tolerance/adoption policy."""
from pathlib import Path
import numpy as np
UNION=(244,251,252,253,260)

def plain(x):
    if isinstance(x,np.ndarray):return plain(x.tolist())
    if isinstance(x,np.generic):return plain(x.item())
    if isinstance(x,complex):return dict(real=x.real,imag=x.imag)
    if isinstance(x,dict):return {str(k):plain(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [plain(v) for v in x]
    return x

def array501(value,name,real=False):
    a=np.asarray(value).ravel()
    if a.shape!=(501,) or not np.all(np.isfinite(a)):raise RuntimeError('Required finite501 '+name+' unavailable')
    if real and np.iscomplexobj(a) and np.any(a.imag!=0):raise RuntimeError('Required real '+name+' unavailable')
    return a.real if real else a

def snapshot(data,source):
    f=array501(data['freqs_wls'],'frequencies',True).copy();p=array501(data['source_powers'],'sourcepower',True).copy();a=array501(data['transmittance_factor'],'mode amplitude').copy()
    if np.any(f<=0) or np.any(p<=0):raise RuntimeError('Positive auxiliary frequency/sourcepower required')
    return dict(source=str(source),arrays=dict(frequency_hz=f,sourcepower=p,direction_selected_a_or_b=a),
        selected=plain(dict(indices=list(UNION),frequency_hz=f[list(UNION)],sourcepower=p[list(UNION)],direction_selected_a_or_b=a[list(UNION)],source=str(source),
            qualification='EXACT_VENDOR_AUX_RETURNED_UNCHANGED_NO_PHASE_OR_NORMALIZATION_CORRECTION')))

def difference(before,after):
    results={}
    for key in before['arrays']:
        x=np.asarray(before['arrays'][key]);y=np.asarray(after['arrays'][key]);delta=y-x
        changed=np.flatnonzero(x!=y)
        relative=np.divide(np.abs(delta),np.abs(x),out=np.full(x.shape,np.nan),where=np.abs(x)!=0)
        def part(realx,realy):
            spacing=np.abs(np.spacing(realx))
            with np.errstate(over='ignore',divide='ignore',invalid='ignore'):
                ulp=np.divide(np.abs(realy-realx),spacing,out=np.full(realx.shape,np.nan),where=spacing!=0)
            maximum=float(np.nanmax(ulp))
            return dict(max_abs=float(np.max(np.abs(realy-realx))),max_ulp=maximum if np.isfinite(maximum) else None,ulp_exceeds_finite_float_range=bool(np.any(np.isinf(ulp))))
        item=dict(changed_indices=changed.tolist(),changed_selected_indices=[i for i in UNION if x[i]!=y[i]],
            max_abs=float(np.max(np.abs(delta))),max_relative=float(np.nanmax(relative)) if np.any(np.isfinite(relative)) else None,
            selected_before=plain(x[list(UNION)]),selected_after=plain(y[list(UNION)]))
        if np.iscomplexobj(x):item['component_ulp']=dict(real=part(x.real,y.real),imag=part(x.imag,y.imag))
        else:item['ulp']=part(x,y)
        results[key]=item
    return dict(source_equal=before['source']==after['source'],selected_equal=before['selected']==after['selected'],full_arrays_equal=all(np.array_equal(before['arrays'][k],after['arrays'][k]) for k in before['arrays']),arrays=results)

def state(session):
    info=dict(loaded_state_tracker=plain(getattr(session,'_loaded_state',None)),getresult_cache_entries=len(getattr(session,'_getresult_cache',{})))
    try:info['cad_source_port']=dict(available=True,value=plain(session.fdtd.getnamed('FDTD::ports','source port')))
    except Exception as exc:info['cad_source_port']=dict(available=False,error=type(exc).__name__+': '+str(exc))
    return info

def install_exact_trace(fom,report):
    original=fom._collect_fwd_side_aux;baseline=None
    def collect(session,entry):
        nonlocal baseline
        before=state(session)
        # Explicit forward load before collection; the vendor performs its
        # own idempotent load again. No layout, geometry, source or field edit.
        session.load_if_needed(entry['fwd_filename'])
        expected=str(Path(entry['fwd_filename']).resolve());loaded=getattr(session,'_loaded_state',None)
        if loaded is None or str(loaded[0])!=expected:raise RuntimeError('Auxiliary explicit forward loaded-state tracker mismatch')
        data=original(session,entry);current=snapshot(data,entry['fwd_filename'])
        record=dict(stage=report.get('active_objective','UNSPECIFIED'),before=before,after=state(session),snapshot=plain(current))
        report.setdefault('auxiliary_snapshot_history',[]).append(record)
        if baseline is None:
            baseline=current;report['vendor_forward_normalization']=current['selected']
        else:
            diff=difference(baseline,current);record['difference_from_initial']=plain(diff)
            if not diff['selected_equal']:
                report['auxiliary_mismatch']=dict(baseline=plain(baseline),offending=plain(current),difference=plain(diff),stage=record['stage'])
                raise RuntimeError('Vendor normalization changed across objective Jacobians; exact before/after retained')
        return data
    fom._collect_fwd_side_aux=collect
    return original
