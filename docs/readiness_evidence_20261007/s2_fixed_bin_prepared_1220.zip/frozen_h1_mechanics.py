"""No-FDTD-solve stored-field five-class h1 reconstruction, one quadrature/job.

Task/quadrature re: original cport_fd_c pair; im: original cport_im_c pair.
Reuse exact dynamic peak3 Jacobian and vendor gradient assembly. Perturb only
corr1/avg1/shift1/shift30/wcav through the CAD mesher at1nm; never fit a coefficient.
No field arrays or sparse derivative arrays are saved to output JSON.
"""
import argparse
import copy
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import types

sys.dont_write_bytecode = True
import numpy as np
import no_solve_guard as guard

STEP_NM = 1.0
EXPECTED_MAP = ((0,'corr_1'),(29,'corr_30'),(60,'avg_1'),(120,'shift_1'),(149,'shift_30'),(295,'wcav'))
SELECTED_MAP = tuple(pair for pair in EXPECTED_MAP if pair[1] != 'corr_30')
# Complete semantic bindings preserve raw server JSON formatting differences.
SAVED_CHECKPOINT_CANONICAL_SHA256 = {'re': 'd14bf54e42694e6b3c02d035bc141302479b1bbc035e41abbe750026c9fdc0ac', 'im': 'e88ca9ff52e71a6d9d07d5f75d28e60f142f3976bba88cd9ef12db3f051d6049'}


def canonical_sha256(row):
    return hashlib.sha256(json.dumps(row,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def selected_parameters(val, spec):
    indices, labels = val._indices(spec)
    if tuple(zip(indices,labels)) != EXPECTED_MAP or len(indices)!=6 or len(labels)!=6:
        raise RuntimeError('Live six-class validator map differs from registered N98/free60 map')
    return tuple((index,label) for index,label in zip(indices,labels) if label!='corr_30')


def verify_selected(index, label, step):
    if type(index) is not int or (index,label) not in SELECTED_MAP or step != STEP_NM:
        raise RuntimeError('Only the five registered non-corr30 classes at1nm are allowed')
SPEC_OVERRIDES = {'label','adj_phase_fix','adj_fix_re','adj_fix_im'}
REFERENCE_PHYSICAL_KEYS = ('polarization','n_periods_side','n_free','bare','pitch_nm',
    'avg_w_nm','corr0_nm','seed_override','corr_seed_nm','avg_seed_nm','free_comb',
    'colocate_fields','bc_patch','dp_tooth_nm','dp_comb_nm','mesh_refinement',
    'region_dx_nm','region_y_half_nm','box_y_um','box_z_mult','scan_center_nm',
    'scan_width_nm','n_wl_points','width_grad','wg_project','corr_min_nm',
    'corr_max_nm','avg_bounds_nm','wcav_bounds_nm','trust_nm')


def normalized(value):
    return json.loads(json.dumps(value))


def verify_full_spec(spec, reviewed, imaginary):
    current=normalized(dataclasses.asdict(spec))
    expected_quad=dict(adj_phase_fix=imaginary,adj_fix_re=0. if imaginary else 1.,adj_fix_im=1. if imaginary else 0.)
    if any(current.get(k)!=v for k,v in expected_quad.items()):
        raise RuntimeError('Quadrature phase overrides differ from registered reconstruction')
    old={k:v for k,v in reviewed.items() if k not in SPEC_OVERRIDES}
    new={k:v for k,v in current.items() if k not in SPEC_OVERRIDES}
    if old!=new:
        different=sorted(k for k in set(old)|set(new) if old.get(k)!=new.get(k) or (k in old)!=(k in new))
        raise RuntimeError('Complete spec differs from reviewed provenance: '+repr(different))


def validate_saved_gradient(row, imaginary, params, forward, adjoint, indices, reviewed_spec):
    identity=row.get('identity',{})
    base=identity.get('base',{})
    result=row.get('result',{})
    expected_task=1 if imaginary else 0
    if identity.get('objective')!='peak3_abs_T_out' or type(base.get('task')) is not int or base['task']!=expected_task or base.get('schema')!=1:
        raise RuntimeError('Saved-gradient task/objective/quadrature identity mismatch')
    if base.get('indices')!=list(indices) or result.get('indices')!=list(indices):
        raise RuntimeError('Saved-gradient exact probe-index map mismatch')
    if not np.array_equal(np.asarray(base.get('point'),float),params):
        raise RuntimeError('Saved-gradient nominal point mismatch')
    if result.get('forward')!=str(forward) or result.get('adjoint')!=str(adjoint):
        raise RuntimeError('Saved-gradient original field source pair mismatch')
    old_spec=base.get('spec',{})
    different=[k for k in REFERENCE_PHYSICAL_KEYS if k not in old_spec or k not in reviewed_spec or normalized(old_spec[k])!=normalized(reviewed_spec[k])]
    if different:
        raise RuntimeError('Saved-gradient physical/numerical identity mismatch: '+repr(different))
    code=identity.get('code')
    old_code=base.get('code')
    if not isinstance(code,str) or not re.fullmatch('[0-9a-f]{64}',code) or not isinstance(old_code,dict) or not old_code or any(not isinstance(v,str) or not re.fullmatch('[0-9a-f]{64}',v) for v in old_code.values()):
        raise RuntimeError('Saved-gradient source identity hashes unavailable/malformed')
    gradient=np.asarray(result.get('gradient'),float)
    if gradient.shape!=(len(indices),) or not np.all(np.isfinite(gradient)):
        raise RuntimeError('Saved-gradient finite vector shape mismatch')
    quadrature='im' if imaginary else 're'
    if canonical_sha256(row)!=SAVED_CHECKPOINT_CANONICAL_SHA256[quadrature]:
        raise RuntimeError('Saved-gradient immutable complete checkpoint binding mismatch')
    return gradient.copy()


class SelectedFieldGuard(guard.NoSolveCAD):
    def eval(self, script):
        if re.search(r'getdata\s*\([^;\n]*,[\s]*["\'](?:Ex|Ey|Ez|Hx|Hy|Hz)["\']', script, re.I):
            allowed = re.fullmatch(r"s2_deps_slice = pinch\(getdata\('optimization_dft','(?:Ex|Ey|Ez)',2\),4,[1-9][0-9]*\);", script)
            if not allowed:
                raise RuntimeError('Only an explicit single-wavelength E-component slice is allowed')
        return super().eval(script)


def exact_active(jac):
    jac = np.asarray(jac, float).ravel()
    if not np.all(np.isfinite(jac)):
        raise RuntimeError('Nonfinite peak3 Jacobian')
    active = np.flatnonzero(jac != 0)
    if not 1 <= len(active) <= 3:
        raise RuntimeError('Expected one to three EXACT nonzero peak3 Jacobian samples')
    return active


def assemble_selected(n_wl, active, slices):
    if len(active) != len(slices) or len(set(map(int,active))) != len(active):
        raise ValueError('Slice/index identity mismatch')
    result = [0.0]*n_wl
    for index, field in zip(active,slices):
        if not 0 <= int(index) < n_wl:
            raise ValueError('Out-of-range wavelength index')
        result[int(index)] = field
    return result


def mesh_refinement_readback(cad):
    return {key:guard.attempt(lambda key=key:cad.getnamed('FDTD',key))
            for key in ('mesh refinement','meshing refinement')}


def sampler(session, active, expected_axes, contexts=None):
    def get_fields(sim_result, filename=None, *, monitor_name='optimization_dft', result_name='E', value='E'):
        if (monitor_name,result_name,value) != ('optimization_dft','E','E') or filename is None:
            raise RuntimeError('Only explicit saved optimization_dft.E sampling is supported')
        session.load_if_needed(filename)
        f = session.fdtd
        if contexts is not None:
            contexts[str(filename)] = mesh_refinement_readback(f)
        xyz = {a:np.asarray(f.getdata(monitor_name,a,2)).ravel() for a in ('x','y','z')}
        for axis in xyz:
            if not np.array_equal(xyz[axis],np.asarray(expected_axes[axis])):
                raise RuntimeError('Saved field coordinate mismatch: '+axis)
        wl = 299792458.0/np.asarray(f.getdata(monitor_name,'f',2)).ravel()
        wanted = np.asarray(sim_result.wavelengths,float)
        indices = [int(np.argmin(np.abs(wl-wanted[i]))) for i in active]
        if len(set(indices)) != len(indices) or any(abs(wl[k]-wanted[i])>1e-18 for i,k in zip(active,indices)):
            raise RuntimeError('Selected wavelength mismatch/duplicate mapping')
        shape = tuple(len(xyz[a]) for a in ('x','y','z'))
        slices = []
        for k in indices:
            components = []
            for component in ('Ex','Ey','Ez'):
                f.eval("s2_deps_slice = pinch(getdata('optimization_dft','"+component+"',2),4,"+str(k+1)+");")
                array = np.asarray(f.getv('s2_deps_slice'))
                if array.shape != shape or not np.all(np.isfinite(array)):
                    raise RuntimeError('Selected component shape/nonfinite mismatch: '+component+' '+str(array.shape))
                components.append(array)
            slices.append(np.stack(components,axis=-1))
        f.eval('clear(s2_deps_slice);')
        return assemble_selected(len(wanted),active,slices)
    return get_fields


def single_deps(calc, params, index, label, step, column, prop_map):
    """Exactly one live-validated class, with full nominal restoration per call."""
    verify_selected(index,label,step)
    params=np.asarray(params,float)
    column=np.asarray(column,float)
    bounds=calc.parametrization.get_bounds()[index]
    if params[index]-step < bounds[0] or params[index]+step > bounds[1]:
        raise RuntimeError('Selected mesher FD would shift its nominal midpoint')
    if column.ndim!=1 or len(column)!=len(prop_map) or not np.all(np.isfinite(column)):
        raise RuntimeError('Selected geometric Jacobian column shape/nonfinite mismatch')
    max_col=np.max(np.abs(column))
    if max_col==0:
        raise RuntimeError(label+' geometric Jacobian column is zero')
    nz=np.flatnonzero(np.abs(column)>=max_col*np.sqrt(np.finfo(column.dtype).eps))
    objects=sorted({'::'.join(prop_map[i].split('::')[:-1]) for i in nz})
    session=calc.fdtd_session
    def restore_nominal():
        session.fdtd.switchtolayout()
        calc.parametrization.update_structure(session,params.copy())
        session.invalidate_loaded_state()
    try:
        # Bboxes must be measured from the full nominal geometry, not a
        # previous parameter's affected-object-only vendor restoration.
        restore_nominal()
        bbox=calc._combine_bounding_boxes(calc._grab_bounding_boxes(objects))
        name='params['+str(index)+']'
        sub=dict(object_name=name,property_name=name,affected_geometric_objects=objects,
                 nominal_value=params[index],h=step,bounding_box=bbox)
        calc._reset_index_monitor_size()
        session.fdtd.eval("a = getresult('optimization_index','index');\nx = a.x; y = a.y; z = a.z; lambda = a.lambda;\nglobal_shape = [length(x), length(y), length(z), length(lambda)];")
        calc._d_eps_sparse_single_param(param_ind=index,nominal_params=params.copy(),sub_dict=sub)
        raw=session.fdtd.getv('results')
        # Vendor postprocess indexes its one-element input from0; actual
        # parameter identity remains encoded in the sub-dict and sparse data.
        deps,shape,wl=calc._postprocess_d_eps_results([raw],{0:sub})
        if tuple(deps)!=(name+'::'+name,):
            raise RuntimeError('Unexpected single-parameter dEps mapping')
        return deps,shape,wl,objects
    finally:
        restore_nominal()


def contract_components(deps,shape,fields,DEC):
    value,_ = DEC.calculate_dF_dPi(deps,np.expand_dims(fields,axis=3),shape)
    components = []
    for component in range(3):
        selected = np.zeros_like(fields)
        selected[...,component] = fields[...,component]
        part,_ = DEC.calculate_dF_dPi(deps,np.expand_dims(selected,axis=3),shape)
        components.append(float(np.asarray(part).ravel()[0]))
    total = float(np.asarray(value).ravel()[0])
    if not np.isfinite(total) or not np.all(np.isfinite(components)) or not np.isclose(total,sum(components),rtol=1e-12,atol=1e-14):
        raise RuntimeError('Nonfinite or inconsistent component contraction')
    return total,components


def run(args):
    root = Path(args.output_root).resolve()
    if root.exists():
        raise RuntimeError('Output root must be NEW and exclusive')
    sys.path.insert(0,str(Path(args.repo).resolve()))
    import config
    config.LUMAPI_PATH = args.lumapi
    config.BASE_SAVE_DIR = str(root/'generated')
    config.USE_GPU = False
    from runners.lumopt2_design import recover_te_s2_peak as peak
    from runners.lumopt2_design import recover_te_s2 as recovery
    eng,val = recovery.eng,recovery.val
    provenance = Path(args.provenance)
    if guard.sha256(provenance) != args.reviewed_provenance_sha256:
        raise RuntimeError('Explicit reviewed provenance hash mismatch')
    evidence = json.loads(provenance.read_text())
    if evidence.get('critical_evidence_available') is not True or evidence.get('original_file_identity_unchanged') is not True or evidence.get('execution_error'):
        raise RuntimeError('Reviewed provenance lacks required complete/preserved evidence')
    imaginary = args.quadrature == 'im'
    spec = dataclasses.replace(peak.SPEC,label='lumopt2_te_s2_other_classes_h1_'+args.quadrature+'_20261007',
                              adj_phase_fix=imaginary,adj_fix_re=0. if imaginary else 1.,adj_fix_im=1. if imaginary else 0.)
    verify_full_spec(spec,evidence['spec'],imaginary)
    selected=selected_parameters(val,spec)
    params = val.te_point(spec)
    if not np.array_equal(params,np.asarray(evidence['params_nm'])):
        raise RuntimeError('Exact provenance parameter point mismatch')
    forward = Path(evidence['cases'][args.quadrature+'_fwd']['source'])
    adjoint = Path(evidence['cases'][args.quadrature+'_adj']['source'])
    expected_folder = Path(args.old_root or recovery.OLD)/('lumopt2_te_s2_cport_im_c_files' if imaginary else 'lumopt2_te_s2_cport_fd_c_files')
    if forward.resolve() != (expected_folder/'fwd_default.fsp').resolve() or adjoint.resolve() != (expected_folder/'adj_default_Port_2.fsp').resolve():
        raise RuntimeError('Reviewed fields are not the registered original recovery pair')
    if root.is_relative_to(expected_folder.resolve()):
        raise RuntimeError('Output would enter original evidence folder')
    reference_path=Path(args.saved_gradient)
    reference_row=json.loads(reference_path.read_text())
    reference_vector=validate_saved_gradient(reference_row,imaginary,params,forward,adjoint,recovery.INDICES,evidence['spec'])
    axes = {a:evidence['cases'][args.quadrature+'_fwd']['saved_dft'][a]['value'] for a in ('x','y','z')}
    lmpt = eng.import_lumopt2()
    import lumapi
    from lumopt2.parametrization.d_eps_calculator import DEpsCalculator as DEC
    api_root = Path(lumapi.__file__).resolve().parent
    vendor = {str(p.relative_to(api_root)):guard.sha256(p) for p in sorted((api_root/'lumopt2').rglob('*.py'))}
    if vendor != evidence['vendor_sources'] or guard.sha256(lumapi.__file__) != evidence['lumapi_sha256']:
        raise RuntimeError('Actual vendor source differs from reviewed provenance')
    originals = [forward,adjoint]+[p.parent/p.stem/(p.stem+'_output.h5') for p in (forward,adjoint)]
    before = [guard.file_identity(p,p.suffix!='.h5') for p in originals]
    if not all(item['available'] for item in before):
        raise RuntimeError('Original FSP/HDF5 pair unavailable')
    reviewed_files={item['path']:item for item in evidence.get('originals_before',[])}
    for item in before:
        reviewed=reviewed_files.get(item['path'])
        if reviewed is None or any(item.get(key)!=reviewed.get(key) for key in ('bytes','mtime_ns')) or (item['sha256'] is not None and item['sha256']!=reviewed.get('sha256')):
            raise RuntimeError('Original file identity differs from reviewed provenance: '+item['path'])
    if any(evidence['cases'][args.quadrature+'_'+role]['saved_layout']['settings']['optimization_dft::spatial interpolation'].get('value')!='none' for role in ('fwd','adj')):
        raise RuntimeError('Selected raw sampler requires reviewed spatial interpolation none')
    for p in (forward,adjoint): recovery.successful_log(p)
    root.mkdir(parents=True,exist_ok=False)
    report = dict(schema=1,quadrature=args.quadrature,step_nm=STEP_NM,selected_parameters=selected,params_nm=params.tolist(),
                  forward=str(forward),adjoint=str(adjoint),originals_before=before,
                  reviewed_provenance_sha256=args.reviewed_provenance_sha256,
                  source_sha256=guard.sha256(__file__),guard_sha256=guard.sha256(guard.__file__),
                  dependencies=recovery.identity(0)['code'],vendor_sources=vendor,
                  no_fdtd_solve=True,calibration_status='FAILED_UNCHANGED',raw_classes=[],
                  purpose='RAW_SINGLE_PARAMETER_RECONSTRUCTION_NOT_A_CALIBRATION_FIT')
    report['saved_gradient_reference']=dict(checkpoint=str(reference_path),sha256=guard.sha256(reference_path),
        identity=reference_row['identity'],validated_task=1 if imaginary else 0,
        validated_indices=recovery.INDICES,reference_full_six_vector=reference_vector.tolist(),
        canonical_sha256=canonical_sha256(reference_row),
        binding_policy='EXACT_COMPLETE_SEMANTIC_CHECKPOINT_WITH_RAW_SHA_REPORTED',
        historical_source_hash_comparison={k:dict(historical=v,current=report['dependencies'].get(k),
            equal=v==report['dependencies'].get(k)) for k,v in reference_row['identity']['base']['code'].items()},
        source_hash_policy='REPORTED_NOT_REQUIRED_EQUAL_AFTER_DOCUMENTED_OPTIMIZER_ONLY_INTEGRATION')
    sessions=[]
    original_guard = guard.NoSolveCAD
    guard.NoSolveCAD = SelectedFieldGuard
    original_class = lumapi.FDTD
    restore = guard.install_constructor_guard(lumapi.FDTD,root,sessions)
    assert lumapi.FDTD is original_class
    try:
        project,wl = eng.make_project(spec,str(root/'generated'),lmpt)
        project.fom.fct = eng.make_fct_peak(wl)
        project.generate()
        report['generated_mesh_refinement_readback']=mesh_refinement_readback(project.fdtd_session.fdtd)
        cm = project.fom.config_map
        for c in cm.config_map.values():
            c['fwd_filename']=str(forward)
            for a in c['adjoints']: a['adj_filename']=str(adjoint)
        for info in cm._sim_result_info.values():
            info['fwd_filename'],info['adj_filename']=str(forward),str(adjoint)
        jac = np.asarray(project.fom.get_jacobian(project.fdtd_session),float).ravel()
        active = exact_active(jac)
        report.update(peak3_jacobian=jac.tolist(),active_indices=active.tolist(),
                      active_weights=jac[active].tolist(),symmetry_factors=project.fom_symmetry_factors,
                      jacobian_center='EACH_ORIGINAL_SAVED_FORWARD_NOT_THE_LATER_FD_REPEAT',
                      original_center_peak3=float(project.fom.calculate_fom(project.fdtd_session)))
        report['saved_field_mesh_refinement_readbacks']={}
        project.fdtd_session.get_fields_at_wavelengths = sampler(project.fdtd_session,active,axes,report['saved_field_mesh_refinement_readbacks'])
        # Normalization, source power, adjoint source phase, Jacobian symmetry
        # and Im=i*adjoint rotation remain in unchanged vendor/FOM code.
        fields = project.fom.calculate_gradient_fields(fdtd_session=project.fdtd_session,
            parametrization=project.parametrization,symmetry_factors=project.fom_symmetry_factors)
        if not np.array_equal(jac,np.asarray(project.fom.get_jacobian(project.fdtd_session)).ravel()):
            raise RuntimeError('Peak Jacobian changed during reconstruction')
        report['gradient_field_sha256'] = hashlib.sha256(np.ascontiguousarray(fields).tobytes()).hexdigest()
        session = project.fdtd_session
        session.fdtd.switchtolayout()
        project.parametrization.update_structure(session,params)
        session.invalidate_loaded_state()
        par = project.parametrization
        if not par.directly_on_params or not par.use_jac or spec.bc_patch:
            raise RuntimeError('Probe supports unchanged direct-param/Jacobian/PVA contraction only')
        geom_jacobian = np.asarray(par.compute_params_to_lumerical_jacobian(params))
        prop_map = par.prop_to_array_map
        calc = DEC(session,par,directly_on_params=True,use_jac=True)
        for index,label in selected:
            column=geom_jacobian[:,index]
            deps,shape,index_wl,objects = single_deps(calc,params,index,label,STEP_NM,column,prop_map)
            raw,components = contract_components(deps,shape,fields,DEC)
            entry = next(iter(deps.values()))
            stats = {key:dict(nonzero_count=int(np.count_nonzero(value['data'])),
                             data_l1=float(np.sum(np.abs(value['data']))),
                             data_l2=float(np.linalg.norm(value['data'])),
                             support_sha256=hashlib.sha256(np.asarray(value['indices'],np.int64).tobytes()).hexdigest())
                     for key,value in entry.items()}
            position=list(recovery.INDICES).index(index)
            baseline=float(reference_vector[position])
            report['raw_classes'].append(dict(index=index,label=label,reference_position=position,
                step_nm=STEP_NM,raw_contraction=raw,original_1nm_raw_contraction=baseline,
                signed_difference=raw-baseline,relative_difference=(raw-baseline)/baseline if baseline else None,
                comparison_status='REVIEW_REQUIRED_NO_AUTOMATIC_CALIBRATION_PASS',
                component_contractions_xyz=components,affected_objects=objects,
                index_wavelength_m=np.asarray(index_wl).ravel().tolist(),global_shape=np.asarray(shape).ravel().tolist(),sparse_stats=stats,
                nominal_index_mesh_refinement_readback=mesh_refinement_readback(session.fdtd)))
    except Exception as exc:
        report['execution_error']=type(exc).__name__+': '+str(exc)
    finally:
        report['originals_after']=[guard.file_identity(p,p.suffix!='.h5') for p in originals]
        report['original_file_identity_unchanged']=before==report['originals_after']
        report['CAD_call_audits']=[s.audit for s in sessions]
        for s in sessions: guard.attempt(s.close)
        restore(); guard.NoSolveCAD=original_guard
        output=root/'other_classes_h1.json'
        with output.open('x',encoding='utf-8') as stream: json.dump(guard.plain(report),stream,indent=2,allow_nan=False)
        print(output,flush=True)
    return 2 if report.get('execution_error') or not report['original_file_identity_unchanged'] else 0


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True)
    parser.add_argument('--lumapi',required=True)
    parser.add_argument('--quadrature',choices=('re','im'),required=True)
    parser.add_argument('--provenance',required=True,help='Original complete reviewed no-solve provenance JSON')
    parser.add_argument('--reviewed-provenance-sha256',required=True)
    parser.add_argument('--old-root')
    parser.add_argument('--output-root',required=True,help='NEW exclusive output directory')
    parser.add_argument('--saved-gradient',required=True,help='Original peak reconstruction task00(re)/task01(im) checkpoint')
    sys.exit(run(parser.parse_args()))
