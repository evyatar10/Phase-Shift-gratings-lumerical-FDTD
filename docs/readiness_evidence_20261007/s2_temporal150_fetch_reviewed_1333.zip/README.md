# Prepared150ps completion fetch

Preparation only. No SSH, server command, container call, CAD, solve, dispatch,
upload or repository edit was executed.150ps remains unreleased. The helper is
separate from the parent's100ps helper and preserves the frozen555f runner.
The100ps source was copied byte-for-byte into a `.txt` reference to avoid
accidentally importing its top-level SSH code.

Required CLI inputs are the ACTUAL future job ID, exact later-marker path and
SHA256, the temporal environment JSON and a NEW unused absolute output
directory. No job ID or future marker SHA is inferred. Exact tasks3/4/5 must
all appear as COMPLETED exit0 in sacct, and all three task checkpoints must
already exist before cold verification. The exact later marker SHA,150ps
scope/status/tasks, first-stage ancestry and frozen555f source are checked.

Inside the existing Athena container, only load_center/root_path, reviewed,
identity, read_checkpoint and verify_result are used. main, forward_only,
make_project and import_lumopt2 are explicitly replaced by refusing guards.
No engine is launched. Existing remote FSP/H5/NPZ/log identities, controls,
timing, scores and100ps ancestry are revalidated by the production cold checks.
Only original CP+NPZ bytes are fetched. No remote files are intentionally
created, edited or deleted. The local frontend independently rechecks exact
accounting states, task list, marker identity, source records, byte counts,
hashes and container/remote path relationships before creating outputs.

Outputs are exclusive:

- s2_temporal150_task03/04/05_original.json
- s2_temporal150_task03/04/05_ports.npz
- s2_temporal150_artifact_pins_original.json
- s2_temporal150_completed_receipt.json

The pin-map format is directly compatible with the prepared temporal reader:
keys `3:checkpoint`,`3:ports`, etc; each has local,path,sha256,bytes. The helper
prints the exact emitted pin-file SHA. Log metadata retains each full source
directory path; shared fwd_default_p0.log basenames are not merged. An existing
output directory is refused before SSH, and no existing original bytes can
be overwritten. All transport validation occurs before directory creation;
an interrupted local write leaves its partial directory preserved for review.

Parent-only future command, after150ps has been separately reviewed, released,
completed and assigned an actual job ID:

```powershell
python -B C:/Users/evyat/AppData/Local/Temp/s2_temporal150_fetch_zpn4skx9/fetch_temporal150.py `
  --job-id ACTUAL_FUTURE_JOB_ID `
  --review-marker /work/data/ACTUAL_IMMUTABLE_150PS_REVIEW.json `
  --review-marker-sha256 EXACT_ACTUAL_MARKER_SHA256 `
  --environment-json C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007/s2_temporal_env_1257.json `
  --output-dir C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007/NEW_temporal150_fetch
```

The explicit later-marker argument replaces only S2_TIME_LATER_MARKER in the
supplied environment. All other canonical temporal paths are retained.
The marker must be a normalized absolute /work/data JSON path, distinct from
prior and100ps markers. The configured study output must be under/work/results
with the exact temporal family label. The source remains555f; changed production
code causes refusal rather than accepting another numerical family.

Offline: `python -B test_fetch150.py`. Six groups passed: required arguments and
environment controls; completed/exit0/tasks3..5 guards; AST parsing and no-solve
call checks on both generated scripts; exclusive original-byte publication and
pin-map shape; response job/marker/byte/path/family/missing-file tampering; CLI
existing-output refusal before any SSH. Fixtures are explicit SYNTHETIC bytes,
not150ps physics or real fetched NPZs. No remote behavior is claimed tested.

The helper validates the caller's specified job against accounting and the
exact saved artifact/marker family. The caller must select the job from the
actual150ps dispatch receipt; checkpoints do not independently record their
creating Slurm job ID. Fetching is never a calibration pass, convergence claim,
noise bound or authorization for a new solve. All scientific gates stay failed
unless separately resolved and reviewed.
