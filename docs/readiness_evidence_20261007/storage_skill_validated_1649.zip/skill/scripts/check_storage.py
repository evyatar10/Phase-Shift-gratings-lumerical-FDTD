"""Read-only local/cluster storage and queue snapshot; no cleanup or dispatch."""
import argparse, concurrent.futures, datetime, json, os, shutil, subprocess
from pathlib import Path

REPO = Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
HOSTS = {
    'athena': ('athena.technion.ac.il', '/home/evyatarrubin/bragg_sim_athena'),
    'igum': ('132.68.58.101', '/home/evyatarrubin/research/bragg_sim_igum'),
}

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def command(args, data=None, timeout=60):
    try:
        p = subprocess.run(args, input=data, capture_output=True, timeout=timeout)
        return dict(exit_code=p.returncode, stdout=p.stdout.decode('utf-8', 'replace'),
                    stderr=p.stderr.decode('utf-8', 'replace'))
    except (OSError, subprocess.TimeoutExpired) as e:
        return dict(exit_code=None, error=type(e).__name__ + ': ' + str(e))

def script(base, cluster):
    return '''import datetime,json,os,shutil,subprocess
def run(args):
 try:
  p=subprocess.run(args,capture_output=True,timeout=15)
  return dict(argv=args,exit_code=p.returncode,stdout=p.stdout.decode('utf-8','replace'),stderr=p.stderr.decode('utf-8','replace'))
 except (OSError,subprocess.TimeoutExpired) as e:return dict(argv=args,exit_code=None,error=type(e).__name__+': '+str(e))
base=BASE_VALUE
paths=[base,base+'/results','/home/evyatarrubin']
checks={k:run(a) for k,a in [('quota',['quota','-v']),('df_bytes',['df','-B1','-P']+paths),('df_inodes',['df','-iP']+paths),('queue',['squeue','-u','evyatarrubin','--noheader'])]}
if CLUSTER_VALUE=='igum':
 lfs=shutil.which('lfs')
 checks['lustre_user_quota']=run([lfs,'quota','-u',str(os.getuid()),os.path.realpath(base)]) if lfs else dict(exit_code=None,error='lfs unavailable; user quota unknown')
 checks['shared_seats']=run(['/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261/licensingclient/linx64/lmutil','lmstat','-c','1055@132.68.48.51','-f','lum_fdtd_solve'])
print(json.dumps(dict(at_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),paths=paths,real_paths=[os.path.realpath(p) for p in paths],checks=checks)))
'''.replace('BASE_VALUE', repr(base)).replace('CLUSTER_VALUE', repr(cluster))

def cluster_snapshot(name):
    host, base = HOSTS[name]
    code = script(base, name)
    compile(code, '<read-only-remote>', 'exec')
    args = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-o', 'StrictHostKeyChecking=yes']
    if name == 'athena':
        args += ['-o', 'HostName=132.68.1.206', '-o', 'HostKeyAlias=athena.technion.ac.il']
    result = command(args + ['evyatarrubin@' + host, 'python3 -'], code.encode('utf-8'), 130)
    if result.get('exit_code') == 0:
        try:
            parsed = json.loads(result['stdout'])
            if not isinstance(parsed, dict) or not isinstance(parsed.get('checks'), dict):
                raise ValueError('Unexpected remote snapshot schema')
            result['snapshot'] = parsed
        except ValueError as e:
            result['parse_error'] = str(e)
    return result

def collect(paths, clusters):
    local = []
    for p in paths:
        p = Path(p).resolve()
        try:
            d = shutil.disk_usage(p)
            local.append(dict(path=str(p),total_bytes=d.total,used_bytes=d.used,free_bytes=d.free,
                              qualification='Filesystem free space; not user quota'))
        except OSError as e:
            local.append(dict(path=str(p),error=str(e)))
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        jobs = {name:pool.submit(cluster_snapshot,name) for name in clusters}
        remote = {name:f.result() for name,f in jobs.items()}
    return dict(schema=1,at_UTC=utc(),scope='READ_ONLY_STORAGE_QUEUE_SEATS',local=local,clusters=remote,
                qualification='Collection is not a capacity approval. Inspect every exit code and quota output. Missing quota is unknown. No recursive scans, cleanup, job mutation or result movement.')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--local-path', action='append')
    p.add_argument('--clusters', nargs='*', choices=list(HOSTS), default=list(HOSTS))
    a = p.parse_args()
    if not a.output.is_absolute() or os.path.lexists(a.output) or not a.output.parent.is_dir():
        p.error('--output must be a new absolute file in an existing directory')
    paths = a.local_path or [str(REPO),str(REPO/'results_from_athena'),os.environ.get('TEMP',str(REPO))]
    report = collect(paths,list(dict.fromkeys(a.clusters)))
    with a.output.open('x',encoding='utf-8') as f:
        json.dump(report,f,indent=2)
    print(a.output)

if __name__ == '__main__':
    main()
