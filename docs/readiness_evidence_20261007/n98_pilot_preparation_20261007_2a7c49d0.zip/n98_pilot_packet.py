"""Preparation-only N98 S2 pilot skeleton; never builds CAD or runs FDTD."""
import dataclasses
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
from runners.lumopt2_design import campaign_te_s2 as s2
from runners.lumopt2_design import lumopt2_design as eng
from runners.lumopt2_design import smoke_te_s2_restart as smoke
from runners.lumopt2_design import validate_te as val
from runners.lumopt2_design import width_contract

IS_HELPER = True
N_TASKS = 1
MAX_RESTARTS = 0                 # intended future runner's explicit bound
CALIBRATION_SHA256 = None        # no approved calibration substituted
CALIBRATION_PATH = Path(__file__).parent/'n98_pilot_s2_peak3_reviewed.json'
CANDIDATE_ENGINE_SHA256 = 'd11f34db9777dd1d9deba6ab19372238c046e8d705a5c9c8c4281702e88b9559'
LABEL = 'lumopt2_te_s2_n98_pilot_preparation_20261007_2a7c49d0'


def require_candidate():
    if hashlib.sha256(Path(eng.__file__).read_bytes()).hexdigest() != CANDIDATE_ENGINE_SHA256:
        raise RuntimeError('Use the pinned modal-candidate bootstrap; production engine is frozen')


def pilot_spec(coefficients):
    """Derive the intended spec without implying coefficient approval."""
    require_candidate()
    coefficients = np.asarray(coefficients,dtype=float)
    if coefficients.shape != (2,) or not np.isfinite(coefficients).all():
        raise ValueError('Invalid proposed port coefficients')
    measured = SimpleNamespace(**vars(s2))
    measured.ADJ_FIX_PORT = tuple(coefficients)
    return val._campaign_spec(measured, '_n98_pilot_preparation_20261007_2a7c49d0',
        v3=True,label=LABEL,n_periods_side=98,n_free=60,bare=True,
        max_iter=2,max_feval=4,wgp_reuse_k=0,
        wgp_modal_guard=True,best_metric='modal_peak3')


def load_peak_calibration(path=CALIBRATION_PATH,expected_sha256=None):
    # Exactly the prepared smoke's hash/objective/rank/sign/recomputed 10%
    # per-component/held-out checks; no S1 or legacy softmax fallback.
    coefficients = smoke.load_calibration(path,expected_sha256)
    payload = json.loads(Path(path).read_bytes())
    family = payload.get('identity',{}).get('base',{}).get('spec',{})
    required = dict(n_periods_side=98,n_free=60,bare=True,polarization='TE',
                    pitch_nm=s2.SPEC_V3.pitch_nm,
                    mesh_refinement=s2.SPEC_V3.mesh_refinement)
    if any(family.get(k) != v for k,v in required.items()):
        raise RuntimeError('Calibration does not identify the retained S2 N98 family')
    return coefficients


def describe_spec(coefficients):
    spec = pilot_spec(coefficients)
    p = eng.seed_params(spec)
    bounds = np.asarray(eng.param_bounds(spec),dtype=float)
    cfg = eng.build_base_cfg(spec)  # config construction only, no lumapi/CAD
    if not np.all((p>=bounds[:,0]) & (p<=bounds[:,1])):
        raise RuntimeError('Derived S2 seed is outside its own bounds')
    return dict(status='PREPARATION_ONLY_NOT_HARDWARE_READY',
        calibration_sha256=CALIBRATION_SHA256,
        intended_max_restarts=MAX_RESTARTS,spec=dataclasses.asdict(spec),
        seed_nm=p.tolist(),bounds_nm=bounds.tolist(),
        hard_width_band_um=width_contract.hard_band(spec,eng.RHO_DN,eng.RHO_UP),
        family=dict(polarization=spec.polarization,N=spec.n_periods_side,
            free_per_side=spec.n_free,bare=spec.bare,pitch_nm=spec.pitch_nm,
            height_nm=cfg.geometry.core_height_m/eng.NM,
            mesh_refinement=spec.mesh_refinement),
        seed_source=str(Path(s2.__file__).resolve()),
        seed_kind='Unmodified live S2 SEED, not calibration te_point()',
        field_calibration_status='Qualified: stored shift_1 residual +23.8%; unresolved',
        blockers=['Reviewed exact peak3 calibration SHA unset',
                  'Corrected N70 hardware/persistence smoke pending',
                  'Field-component and directional qualification unresolved',
                  'Integrated-tree gates, hidden N98 build and Athena preflight pending'],
        code={Path(m.__file__).name:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()
              for m in (eng,s2,val,smoke,width_contract)})


def main(task_idx=0):
    if int(task_idx) != 0:
        raise ValueError(task_idx)
    coeff = load_peak_calibration(expected_sha256=CALIBRATION_SHA256)
    pilot_spec(coeff)
    # Deliberately not a launchable implementation. No invented field-review
    # schema or setting the port hash can unlock a solve through this helper.
    raise RuntimeError('N98 pilot is preparation-only: field/directional qualification '
                       'and corrected hardware validation remain unresolved')


if __name__=='__main__':
    main(0)
