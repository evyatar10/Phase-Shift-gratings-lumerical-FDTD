import unittest,ast
import numpy as np
import read_sources as r
class Tests(unittest.TestCase):
 def test_valid_both_orders(self):
  for f in [np.linspace(1,2,501),np.linspace(2,1,501)]:self.assertEqual(r.validate(f,np.ones(501)*1j,np.ones(501))['f_Hz'].size,501)
 def test_invalid(self):
  f=np.linspace(1,2,501)
  for x,y,z in [(f[:500],np.ones(501),np.ones(501)),(f,np.zeros(501),np.ones(501)),(f,np.ones(501),np.ones(501)*-1),(f,np.ones(501),np.ones(501)*1j),(np.ones(501),np.ones(501),np.ones(501)),(f,np.ones(501)*np.nan,np.ones(501))]:
   with self.assertRaises(RuntimeError):r.validate(x,y,z)
 def test_exact_script_and_no_field_mutators(self):
  self.assertEqual(r.SCRIPT,'sc_norm=sourcenorm(sc_f);sc_power=sourcepower(sc_f);')
  tree=ast.parse(open(r.__file__).read());bad={'set','setnamed','run','runjobs','save','switchtolayout','addfdtd','delete','remove'}
  self.assertFalse(any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in bad for n in ast.walk(tree)))
 def test_fake_inspection(self):
  class Raw:
   def putv(self,n,v):self.f=v
   def eval(self,s):self.script=s
   def getv(self,n):return np.ones(501,dtype=complex if n=='sc_norm' else float)
  class CAD:
   raw=Raw()
   def getglobalsource(self,k):return 1
   def getnamed(self,o,k):return 1
  a,m=r.inspect(CAD(),{'p2_f':np.linspace(1,2,501),'p2_S':np.ones(501)});self.assertEqual(a['source_norm'].size,501);self.assertIn('p2_S',a);self.assertIn('settings',m)
if __name__=='__main__':unittest.main()
