# Job171390 strict read-only completion fetch preparation

Prepared only in NEW TEMP. No SSH/container/CAD/solve/upload/dispatch was executed. Shared runners, vendor code and prior fetch packet remain untouched. Global calibration stays FAILED; a completion fetch is not physics approval.

fetch_temporal200.py accepts ONLY job171390, tasks0/1/2 all COMPLETED with exit0:0, exact released200 family and environment. The release marker must be /work/data/s2_temporal200_review_20261007_1619.json with SHA4fe3c0e7fc37cced733ac7cf7b2ee3de3536213ee938e23a1095dffc307cd44f. The runner fa6a..., temporal helper555f..., step150 helperc41f..., complete numerical spec/code/vendor map and all five ancestral checkpoints are bound through release_scope_pins.json. Pins are from the remote-generated NOT_REVIEWED setup template plus byte-pinned150 center point; those pins do not approve anything. Actual released marker bytes/status and substantive lead review are independently mandatory.

When parent chooses to execute: one SSH read-only script queries sacct. Before container validation it requires all3 completed CPs; there is no wait/retry/autolaunch/fallthrough. A new container Python process blocks main/forward_only in200/base/step150 helpers plus eng.make_project/import_lumopt2, then directly calls frozen_base/load_ancestry/reviewed/identity/read_checkpoint/verify_result. No production source files are edited. Cold validation checks actual FSP/H5/log/NPZ hashes, port-score reproduction,200ps/status1/full-time termination, exact501 grids and geometry/source/mesh/DFT/timing controls. It also revalidates all5 historical ancestors. This can read large H5 files for hashing but constructs no CAD session, uses no license and downloads no H5/FSP/full fields.

The response retains actual control snapshots/hashes, vendor identity, FSP/H5/log hashes, source/attempt paths, termination, metrics and both ancestry groups. Only original CP and ports NPZ bytes are base64 transferred, rehashed locally, and published exclusively in a NEW absolute output directory. Existing output directories are refused before SSH. No overwrites, deletes, saves, FDTD calls or dispatch operations occur. The raw CP remains byte-identical; receipt/manifest are separate JSON documents. Pinned assertions require nonoptimized Python (-B, no -O).

Output naming (tasks00/01/02):
- s2_temporal200_task00_original.json; s2_temporal200_task00_ports.npz.
- s2_temporal200_artifact_pins_original.json: keys0:checkpoint,0:ports through2, exact byte SHA/size/local+remote paths.
- s2_temporal200_completed_receipt.json: accounting, cold records, original artifact provenance and pins SHA.
- s2_temporal200_fetch_manifest.json: source/helper/release identity, pins/receipt/file hashes; no physics-pass claim.

Exact future invocation, only after parent confirms all171390 tasks completed (destination must not exist):
```powershell
python -B C:/Users/evyat/AppData/Local/Temp/s2_temporal200_completion_fetch_hm79omfm/fetch_temporal200.py --job-id 171390 --review-marker /work/data/s2_temporal200_review_20261007_1619.json --review-marker-sha256 4fe3c0e7fc37cced733ac7cf7b2ee3de3536213ee938e23a1095dffc307cd44f --environment-json C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007/s2_temporal200_environment_released_1619.json --output-dir C:/Users/evyat/AppData/Local/Temp/s2_temporal200_completion_171390_VERIFIED_NEW
```
Output name is a concrete suggested unused directory, not a default and not created by preparation. Parent may choose another NEW absolute destination. SSH uses established strict host key and BatchMode; no credentials are read/printed.

Checks:
```
python -B <packet>/test_fetch_temporal200.py
python -B <packet>/fetch_temporal200.py --help
```
Eight focused offline groups exit0. Synthetic protocol fixtures are explicitly not200ps measurement: exact inputs/env/accounting; missing/incomplete/extra task; AST no-mutation/no-dispatch/no-CAD calls; actual generated cold-loop execution with stub runner, missing results rejected and all8 unsafe paths blocked; raw byte publication with overwrite refusal; wrong marker/family/source/point/duration/vendor/ancestry/control/status and artifact size/hash/path negatives. No full13 rerun. Preparation does not establish real cold validation; that remains for completed Athena artifacts.

Protocol follows frozen step150 fetch SHAebbe44a0aba524ed22a641b33287a31c5e88d2dc52bc43c7521a72ac0d6702c9. Runtime dependencies are fetch_temporal200.py and release_scope_pins.json. released_environment.json is the exact local released-env copy for review/reproducibility. Manifest binds all files and original raw inputs.
