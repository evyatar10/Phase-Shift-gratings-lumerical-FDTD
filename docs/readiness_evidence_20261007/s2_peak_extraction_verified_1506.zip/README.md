# Same-spectra peak extraction diagnostic

TEMP-only offline package. No repository, CAD, server, solver or objective changes.

Run from this directory:

```powershell
python -B test_peak.py
python -B peak_diagnostic.py --evidence-dir C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007 --repo C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes --output C:/Users/evyat/AppData/Local/Temp/s2_peak_extraction_diagnostic_y8cz8el7/recomputed_report.json
```

Output writes exclusively and refuses an existing destination. `actual_report.json` preserves the first successful execution. Requires NumPy/SciPy and the frozen local engine. The reader hashes both artifact manifests, original checkpoint/NPZ bytes, the previously validated full temporal report/spectra and engine. It verifies exact 501-point grids and reproduces saved scores, peak3 and own-center-J projections before computing the diagnostic observer. The previously validated temporal report supplies complete task/control/parameter-family verification; no new solver evidence is generated here.

`REPORT.md` is the short interpretation; `actual_report.json` records numerical results, all individual spline maxima and windows, raw input hashes, method and limitations. Tests cover exact interior quadratic recovery, smooth constant-height translation with sparse extraction bias, reflection symmetry, absent interior maxima, off-grid windows and nonfinite samples.
