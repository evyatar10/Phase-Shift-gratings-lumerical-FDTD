#!/bin/bash
#SBATCH --job-name=s2_saved_profiles
#SBATCH --nodes=1
#SBATCH --output=logs/length_profiles-%A_%a.out
#SBATCH --error=logs/length_profiles-%A_%a.out
set -e
ulimit -s unlimited
WORK_DIR=/home/evyatarrubin/research/bragg_sim_igum
LUM_HOME=/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261
LICENSE=1055@132.68.48.51
INTERCONNECT=2325@132.68.48.51
export LANG=C
export LC_ALL=C
export ANSYSLMD_LICENSE_FILE="${LICENSE}"
export ANSYSLI_SERVERS="${INTERCONNECT}"
export ANSYS_APIP_DISABLE=1
# Headless CAD: IGUM nodes have no Xvfb; Qt offscreen verified working
# (lumapi session + geometry ops tested on igum-login1, 2026-07-05).
export QT_QPA_PLATFORM=offscreen
# athena_run_one.py derives all paths from WORK_DIR and LUMAPI_PATH.
export WORK_DIR
export LUMAPI_PATH="${LUM_HOME}/api/python/lumapi.py"
# scilibs: libgfortran.so.5 (+libquadmath) for scipy — present on igum-login1
# and ece-alecohen1 but MISSING on the part-preempt compute nodes (ece-ykasten1
# killed job 41776 in 2 s on `import scipy.io`, 2026-07-25). Staged from the
# login node into the shared research volume.
export LD_LIBRARY_PATH="${LUM_HOME}/lib:${WORK_DIR}/scilibs${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}"
# fdtd-solutions resets LD_LIBRARY_PATH to $FDTD_LD_LIBRARY_PATH:$LUMERICAL_LD_LIBRARY_PATH
# at relaunch — capture the current value so the reset restores it (same
# mechanism as run_python_gpu.sh; was missing here vs the Athena array script).
export LUMERICAL_LD_LIBRARY_PATH="${LD_LIBRARY_PATH}"
# Force-load Lumerical's TBB malloc interceptor — prevents the intermittent
# "free(): invalid pointer" crash when lumapi spawns fdtd-solutions.
export LD_PRELOAD="${LUM_HOME}/lib/libtbbmalloc.so.2:${LUM_HOME}/lib/libtbbmalloc_proxy.so.2"
# Fabric autodetect guards (same values proven in the Athena container).
export RDMAV_FORK_SAFE=1
export FI_EFA_FORK_SAFE=1
export FI_PROVIDER='^efa'
export OMPI_MCA_btl=self,tcp
export OMPI_MCA_mtl='^ofi'
export UCX_TLS=self,sm,tcp
export UCX_NET_DEVICES=lo

cd "${WORK_DIR}"
"${LUM_HOME}/python/bin/python" -B -u /home/evyatarrubin/research/bragg_sim_igum/scripts/s2_length_profiles_20261007_2216/extract_length_profiles.py --repo /home/evyatarrubin/research/bragg_sim_igum/project --lumapi "${LUMAPI_PATH}" --output /home/evyatarrubin/research/bragg_sim_igum/results/s2_length_profiles_20261007_2216
