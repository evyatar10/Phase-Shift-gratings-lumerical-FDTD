"""Isolated native IGUM hidden-CAD pair qualification; never a solve dispatcher."""
import os,sys
from pathlib import Path
sys.dont_write_bytecode=True
base=Path('/home/evyatarrubin/research/bragg_sim_igum').resolve()
repo=base/'project';sys.path.insert(0,str(repo))
import config
config.BASE_SAVE_DIR=str(base/'results')
config.NEFF_DATA_PATH=str(base/'data/FDE_sweep_results.mat')
config.LUMAPI_PATH=os.environ['LUMAPI_PATH']
config.USE_GPU=True
sys.path.insert(0,str(Path(config.LUMAPI_PATH).parent))
from runners.lumopt2_design import s2_length_fixed150 as lane
def forbidden(*args,**kwargs):raise RuntimeError('Solve and optimization entrypoints unavailable in CAD qualification')
lane.main=forbidden;lane.forward_only=forbidden
lane.eng.make_project=forbidden
report=lane.build_only(lane.native_paths(for_review=False),os.environ['S2_LEN_CAD_OUTPUT'])
assert report['no_FDTD_solve'] is True
assert report['status']=='NATIVE_CAD_PAIR_CONTROLS_PASS_NO_PHYSICS_OR_SOLVE_APPROVAL'
print(report['status'])
