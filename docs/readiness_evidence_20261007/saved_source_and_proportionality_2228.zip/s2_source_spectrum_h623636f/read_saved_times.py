"""Exact100/150/200 centers: dataset time-component readout; no solve/save."""
import argparse,hashlib,json,re,sys
from pathlib import Path
import numpy as np
from scipy.io import savemat
import frozen_profile_io as io
sys.dont_write_bytecode=True
PINS={100:io.PINS[100],150:io.PINS[150],200:'37fa4074d0dd5bfaa88bf6932b1ca1deed786620126b56f8a2d0c4cd44dbe029'}
IO_SHA='994c3e9757a10b5bd8ea211aaee8425c5d3540203a4da04b0439684163baf6ca'
MONITORS=('time_input','time_cavity','time_output')
COMPONENTS=('Ex','Ey','Ez','Hx','Hy','Hz')
PROPS=('enabled','monitor type','x','y','z','spatial interpolation','min sampling per cycle','minimum sampling per cycle','sampling rate','down sample time')
SOURCE_PROPS=('frequency','bandwidth','pulselength','offset','optimize for short pulse','set time domain','set frequency','wavelength start','wavelength stop','source type')
need,sha,plain,identity=io.need,io.sha,io.plain,io.identity

def load_center(path,duration):
 need(sha(io.__file__)==IO_SHA,'Frozen identity/guard helper changed')
 if duration in [100,150]:return io.load_checkpoint(path,duration)
 need(duration==200 and sha(path)==PINS[200],'Exact200 raw center checkpoint required');row=json.loads(Path(path).read_text());i,r=row['identity'],row['result']
 need(i['task']==r['task']==0 and i['index']==r['index']==29 and i['sign']==r['sign']==0 and i['delta_nm']==r['delta_nm']==0 and i['duration_ps']==r['duration_ps']==200.,'Exact200 nominal identity required')
 need(i['point']==r['params'] and len(i['point'])==296 and i['spec']['n_periods_side']==98 and i['spec']['n_free']==60 and i['spec']['bare'] and i['spec']['polarization']=='TE','Exact TE98/free60/point required')
 need(i['code']['lumopt2_design.py']==io.ENGINE_SHA and r['controls']['after']['optimization_dft_enabled']==0 and r['controls']['after']['timing']['use early shutoff']==0 and r['controls']['after']['timing']['use divergence checking']==1 and r['termination']['status']==1,'Frozen200 controls/status required')
 for key,digest in [('source','fsp_sha256'),('h5','h5_sha256'),('ports_npz','ports_sha256')]:need(sha(r[key])==r[digest],'Saved200 artifact hash changed:'+key)
 need(Path(r['h5']).resolve()==Path(r['source']).resolve().with_suffix('')/'fwd_default_output.h5','Saved200 FSP/H5 binding changed');return row

class TimeCAD(io.ReadOnlyCAD):
 """Dataset component readout; raw axes cross-checked against dataset times."""
 def __init__(self,raw,source):
  super().__init__(raw,source);self.observed={};self.scripts=set();self.dataset_time_checked=set()
 def names(self,monitor):
  need(monitor in MONITORS,'Unreviewed time monitor');raw=self.raw.getdata(monitor)
  tokens=re.split(r'[\s,;]+',raw) if isinstance(raw,str) else [str(x) for x in np.asarray(raw).ravel()]
  known=[t for t in tokens if t in ('t','x','y','z')]
  need(len(known)==len(set(known)),'Duplicate raw axis names')
  available=[]
  for result in ['E','H']:
   v=np.asarray(self.raw.haveresult(monitor,result))
   need(v.size==1 and np.isfinite(v).all() and float(v.ravel()[0]) in [0.,1.],'Invalid dataset availability')
   if float(v.ravel()[0])==1.:available.extend(result+c for c in 'xyz')
  self.observed[monitor]=set(known+available)
  return {'raw_names':plain(raw),'dataset_components':available,'component_API':'getresult E/H scalar member'},sorted(self.observed[monitor])
 def getnamednumber(self,monitor):need(monitor in MONITORS,'Unreviewed time monitor');return self.raw.getnamednumber(monitor)
 def availability(self,monitor):need(monitor in MONITORS,'Unreviewed time monitor');return plain(self.raw.havedata(monitor))
 def getglobalsource(self,key):need(key in SOURCE_PROPS,'Unreviewed source query');return self.raw.getglobalsource(key)
 def getv(self,name):need(name in ['tt_shape','tt_value','tt_times'],'Unreviewed/full dataset transfer refused');return self.raw.getv(name)
 def eval(self,script):
  need(script in self.scripts,'Unregistered time read-only script refused');self.audit.append({'registered_time_readonly_script':script});return self.raw.eval(script)
 def execute(self,script,name):
  allowed={}
  for m in MONITORS:
   for k in ('t','x','y','z'):
    expr=f"getdata('{m}','{k}',2)"
    allowed[f'tt_value={expr};']='tt_value'
    allowed[f'tt_raw={expr};tt_shape=size(tt_raw);']='tt_shape'
   for result in ['E','H']:
    prefix=f"tt_dataset=getresult('{m}','{result}');"
    allowed[prefix+'tt_times=tt_dataset.t;']='tt_times'
    allowed[prefix+'tt_shape=size(tt_dataset.t);']='tt_shape'
    for k in [result+c for c in 'xyz']:
     allowed[prefix+f'tt_value=tt_dataset.{k};']='tt_value'
     allowed[prefix+f'tt_raw=tt_dataset.{k};tt_shape=size(tt_raw);']='tt_shape'
  need(allowed.get(script)==name,'Non-whitelisted time read script')
  guarded=f'{name}=0;'+script
  self.scripts.add(guarded);self.eval(guarded);return np.asarray(self.getv(name))
 def expression(self,monitor,key):
  need(monitor in self.observed and key in self.observed[monitor],'Unobserved time data key')
  if key in COMPONENTS:
   result=key[0]
   if (monitor,result) not in self.dataset_time_checked:
    raw=self.value(monitor,'t');validate_times(raw)
    sh=self.execute(f"tt_dataset=getresult('{monitor}','{result}');tt_shape=size(tt_dataset.t);",'tt_shape').ravel()
    need(np.isfinite(sh).all() and np.all(sh>0) and np.all(sh==sh.astype(int)) and vector_shape(sh) and int(np.prod(sh))==raw.size,'Dataset time shape/count differs before transfer')
    t=self.execute(f"tt_dataset=getresult('{monitor}','{result}');tt_times=tt_dataset.t;",'tt_times')
    validate_times(t)
    need(np.array_equal(t.ravel(),raw.ravel()),'Dataset/raw time axes differ')
    self.dataset_time_checked.add((monitor,result))
   return f"tt_dataset=getresult('{monitor}','{result}');",f'tt_dataset.{key}'
  return '',f"getdata('{monitor}','{key}',2)"
 def shape(self,monitor,key):
  prefix,expr=self.expression(monitor,key)
  values=self.execute(prefix+f'tt_raw={expr};tt_shape=size(tt_raw);','tt_shape').ravel()
  need(values.size>0 and np.isfinite(values).all() and np.all(values==values.astype(int)) and np.all(values>0),'Invalid recorded data shape')
  return tuple(values.astype(int))
 def value(self,monitor,key):
  prefix,expr=self.expression(monitor,key)
  return self.execute(prefix+f'tt_value={expr};','tt_value')

def vector_shape(shape):return len(shape)<=4 and sum(int(n)>1 for n in shape)<=1
def validate_times(t):
 need(vector_shape(t.shape) and t.size>=2 and np.isrealobj(t) and np.isfinite(t).all(),'Finite scalar time vector required')
 t=t.ravel();delta=np.diff(t);need(np.all(delta>0),'Strictly increasing unique sample times required')
 return t,dict(samples=int(t.size),first_s=float(t[0]),last_s=float(t[-1]),interval_min_s=float(delta.min()),interval_max_s=float(delta.max()),interval_median_s=float(np.median(delta)),uniform_bitwise=bool(np.all(delta==delta[0])),qualification='Measured intervals; no assumed sampling default or Nyquist/physical adequacy pass')
def validate_component(values,shape,count):
 need(tuple(values.shape)==tuple(shape) and vector_shape(shape) and int(np.prod(shape))==count,'Component shape must be a scalar point time series aligned with t')
 need(np.isfinite(values).all(),'Nonfinite time component');return values.ravel()
def selection(items):
 selected={}
 for item in items:
  need(isinstance(item,str) and item.count(':')==1,'Component selection must be monitor:component');monitor,key=item.split(':')
  need(monitor in MONITORS and key in COMPONENTS,'Unsupported explicit component');need(key not in selected.get(monitor,[]),'Duplicate component selection');selected.setdefault(monitor,[]).append(key)
 return selected
def optional_properties(cad,monitor):
 result={}
 for key in PROPS:
  try:result[key]={'available':True,'value':plain(cad.getnamed(monitor,key))}
  except Exception as exc:result[key]={'available':False,'error':type(exc).__name__+': '+str(exc)}
 return result
def source_settings(cad):
 result={'global':{},'Port1':{},'qualification':'Recorded settings only; not measured trace bandwidth or cause of temporal drift'}
 for key in SOURCE_PROPS:
  try:result['global'][key]={'available':True,'value':plain(cad.getglobalsource(key))}
  except Exception as exc:result['global'][key]={'available':False,'error':type(exc).__name__+': '+str(exc)}
 for key in ('override global source settings','use global source settings')+SOURCE_PROPS:
  try:result['Port1'][key]={'available':True,'value':plain(cad.getnamed('FDTD::ports::Port_1',key))}
  except Exception as exc:result['Port1'][key]={'available':False,'error':type(exc).__name__+': '+str(exc)}
 return result
def inventory(cad,monitor,time_cap):
 row=dict(monitor=monitor,properties=optional_properties(cad,monitor))
 if int(float(cad.getnamednumber(monitor)))!=1:return dict(**row,status='MISSING_OR_DUPLICATE_MONITOR')
 try:raw,names=cad.names(monitor)
 except Exception as exc:return dict(**row,status='DATA_INVENTORY_UNAVAILABLE',error=type(exc).__name__+': '+str(exc))
 row.update(raw_data_names=plain(raw),observed_allowed_names=names,raw_data_available=cad.availability(monitor))
 if 't' not in names:return dict(**row,status='TIME_AXIS_MISSING')
 shape=cad.shape(monitor,'t');need(vector_shape(shape) and int(np.prod(shape))*8<=time_cap,'Missing/nonpoint/oversize time axis validation')
 t,stats=validate_times(cad.value(monitor,'t'));need(t.size==int(np.prod(shape)),'Recorded t shape/count changed');row.update(time=stats,time_raw_shape=list(shape))
 coordinates={}
 for key in ['x','y','z']:
  if key not in names:coordinates[key]={'available':False,'error':'Coordinate not in recorded names'};continue
  coord_shape=cad.shape(monitor,key);need(int(np.prod(coord_shape))==1,'Point coordinate is not scalar');v=cad.value(monitor,key);need(v.size==1 and np.isfinite(v).all(),'Finite actual point coordinate required');coordinates[key]={'available':True,'value_m':float(v.ravel()[0])}
 row['actual_recorded_coordinates']=coordinates;row['component_shapes']={key:list(cad.shape(monitor,key)) for key in COMPONENTS if key in names}
 for key,sh in row['component_shapes'].items():need(vector_shape(sh) and int(np.prod(sh))==t.size,'Recorded component/time shape mismatch:'+key)
 row.update(status='TIME_INVENTORY_VALIDATED_NO_PHYSICS_PASS',sampling_qualification='Actual t/statistics and queried monitor values only; missing properties remain unavailable; GPU interpolation warning remains unqualified')
 return row
def export_estimate(inventories,selected):
 total=0
 for duration,rows in inventories.items():
  for monitor,keys in selected.items():
   row=rows[monitor];need(row['status']=='TIME_INVENTORY_VALIDATED_NO_PHYSICS_PASS','Requested monitor inventory invalid/missing')
   need(all(key in row['component_shapes'] for key in keys),'Requested time component missing');n=row['time']['samples'];total+=n*(8+16*len(keys))
 return total
def transfer(cad,rows,selected):
 output={}
 for monitor,keys in selected.items():
  _,names=cad.names(monitor);need(names==rows[monitor]['observed_allowed_names'],'Fresh export session recorded data names changed')
  t,_=validate_times(cad.value(monitor,'t'));need(t.size==rows[monitor]['time']['samples'],'Export t count changed');output[monitor+'__t_s']=t
  for key in keys:output[monitor+'__'+key]=validate_component(cad.value(monitor,key),rows[monitor]['component_shapes'][key],t.size)
 return output
def verify_sources(repo,api,row):
 required=[]
 for name,digest in row['identity']['code'].items():
  path=repo/name if name in ['config.py','bragg_device.py','sim_helpers.py','simulation_config.py'] else repo/'runners/lumopt2_design'/name;need(sha(path)==digest,'Frozen source dependency changed:'+name);required.append(path)
 paths=sorted((api.parent/'lumopt2').rglob('*.py'))+[api]
 if (api.parent/'lumslurm.py').is_file():paths.append(api.parent/'lumslurm.py')
 vendor={str(p.relative_to(api.parent)).replace('\\','/'):sha(p) for p in paths};need(vendor==row['identity']['vendor_api_sha256'],'Exact saved-field vendor/API identity required');return required+paths+[Path(__file__),Path(io.__file__)]
def run(args):
 out=Path(args.output).resolve();need(Path(args.output).is_absolute() and not out.exists(),'NEW absolute output directory required')
 selected=selection(args.component);need(not selected or args.max_total_bytes is not None and args.max_total_bytes>0,'Explicit positive total byte budget required for components');need(args.max_time_validation_bytes>0,'Positive t validation cap required')
 report=dict(status='STARTED',no_solve=True,no_save=True,default_inventory_only=not bool(selected),stages={},inputs={},component_API='getresult E/H scalar members with exact raw/result t agreement',qualification='Point-time readout only; no transmission, causal, noise, calibration or convergence pass');out.mkdir();snapshots=[];rows={};klass=None;ctor=None
 try:
  repo=Path(args.repo).resolve();api=Path(args.lumapi).resolve()
  # Validate ALL identities/files before first CAD; reference paths are not rewritten.
  for duration in [100,150,200]:
   cp=Path(getattr(args,'checkpoint'+str(duration))).resolve();row=load_center(cp,duration);dependencies=verify_sources(repo,api,row);rows[duration]=row;r=row['result'];items=[identity(p) for p in [cp,r['source'],r['h5'],r['ports_npz']]];snapshots+=items;report['inputs'][str(duration)]=items
   known={item['path'] for item in snapshots}
   for path in dependencies:
    resolved=str(Path(path).resolve())
    if resolved not in known:snapshots.append(identity(path));known.add(resolved)
  need(all(rows[t]['identity']['point']==rows[100]['identity']['point'] for t in [150,200]),'Different center geometries refused')
  sys.path.insert(0,str(api.parent));import lumapi;need(Path(lumapi.__file__).resolve()==api,'Wrong imported official API');klass=lumapi.FDTD;ctor=klass.__init__
  def session(duration,action):
   r=rows[duration]['result'];raw=lumapi.FDTD(hide=True);cad=TimeCAD(raw,r['source'])
   try:
    cad.load(r['source']);need(float(np.asarray(cad.getresult('FDTD','status')).squeeze())==1,'Saved full-time status required');return action(cad)
   finally:cad.close()
  for duration in [100,150,200]:
   def inventories(cad):
    report.setdefault('source_settings',{})[str(duration)]=source_settings(cad)
    values={m:inventory(cad,m,args.max_time_validation_bytes) for m in MONITORS}
    report.setdefault('guard_audit',{})[str(duration)]=cad.audit;return values
   report['stages'][str(duration)]=session(duration,inventories)
  if selected:
   estimate=export_estimate(report['stages'],selected);report['conservative_export_raw_bytes']=estimate;need(estimate<=args.max_total_bytes,'Total component export exceeds explicit byte cap BEFORE transfer');actual=0
   for duration in [100,150,200]:
    data=session(duration,lambda cad:transfer(cad,report['stages'][str(duration)],selected));actual+=sum(v.nbytes for v in data.values());need(actual<=args.max_total_bytes,'Actual exported payload exceeds byte cap')
    npz=out/f'time_components_{duration}ps.npz';mat=out/f'time_components_{duration}ps.mat'
    with npz.open('xb') as stream:np.savez_compressed(stream,**data)
    with mat.open('xb') as stream:savemat(stream,data,do_compression=True,long_field_names=True)
    report.setdefault('exports',{})[str(duration)]=dict(npz=str(npz),npz_sha256=sha(npz),MAT=str(mat),MAT_sha256=sha(mat),raw_payload_bytes=sum(v.nbytes for v in data.values()),components=selected)
   report['actual_export_raw_bytes']=actual
  report['status']='INVENTORY_COLLECTED_NO_PHYSICS_PASS' if any(v['status']!='TIME_INVENTORY_VALIDATED_NO_PHYSICS_PASS' for stage in report['stages'].values() for v in stage.values()) else 'TIME_READOUT_COMPLETE_NO_PHYSICS_PASS'
 except Exception as exc:report.update(status='TIME_READOUT_FAILED_CLOSED',error=type(exc).__name__+': '+str(exc))
 finally:
  report['immutable_inputs_rechecked']=[]
  for old in snapshots:
   try:current=identity(old['path']);report['immutable_inputs_rechecked'].append({'before':old,'after':current,'unchanged':old==current})
   except Exception as exc:report['immutable_inputs_rechecked'].append({'before':old,'unchanged':False,'error':str(exc)})
  report['all_inputs_preserved']=all(v['unchanged'] for v in report['immutable_inputs_rechecked'])
  if not report['all_inputs_preserved']:report.update(status='TIME_READOUT_FAILED_CLOSED',error='Original input changed')
  if klass is not None:
   report['FDTD_class_unchanged']=lumapi.FDTD is klass;report['FDTD_constructor_unchanged']=klass.__init__ is ctor
   if not report['FDTD_class_unchanged'] or not report['FDTD_constructor_unchanged']:report.update(status='TIME_READOUT_FAILED_CLOSED',error='FDTD class/constructor changed')
  with (out/'report.json').open('x',encoding='utf-8') as stream:json.dump(plain(report),stream,indent=2,allow_nan=False)
 print(report['status'],report.get('error',''));return 1 if report['status']=='TIME_READOUT_FAILED_CLOSED' else 0
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__)
 for name in ['repo','lumapi','checkpoint100','checkpoint150','checkpoint200','output']:p.add_argument('--'+name,required=True)
 p.add_argument('--component',action='append',default=[]);p.add_argument('--max-total-bytes',type=int);p.add_argument('--max-time-validation-bytes',type=int,default=33554432)
 raise SystemExit(run(p.parse_args()))
