"""Hidden CAD property feasibility only; all solve APIs remain behind NoSolveCAD."""
import sys,json,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
import numpy as np
from no_solve_guard import NoSolveCAD,plain,attempt,file_identity
API=Path('C:/Program Files/Lumerical/v261/api/python');sys.path.insert(0,str(API));import lumapi
BASE=Path('C:/Users/evyat/AppData/Local/Temp/s2_fdstep_gate_7nhbg_jw/task_00_6l9vt3oc/files/fwd_default.fsp')
PORTS=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007/s2_fdstep_task00_ports.npz')
OUT=Path(__file__).resolve().parent
UNION=[244,251,252,253,260]
MON='optimization_dft'
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def snapshot(cad):
 return dict(global_monitor={k:plain(cad.getglobalmonitor(k)) for k in ['frequency points','sample spacing','use wavelength spacing','use source limits']},
 source={k:plain(cad.getglobalsource(k)) for k in ['wavelength start','wavelength stop','pulselength','offset','frequency','bandwidth']},
 ports={obj:{k:plain(cad.getnamed(obj,k)) for k in ['monitor frequency points','source port','source mode']} for obj in ['FDTD::ports']},
 geometry={k:plain(cad.getnamed('FDTD',k)) for k in ['x','y','z','x span','y span','z span','mesh refinement','simulation time','use early shutoff']})
def selected_properties(cad):
 cad.select(MON)
 return plain(cad.get())
def properties(cad):
 return {k:attempt(lambda key=k:cad.getnamed(MON,key)) for k in ['enabled','override global monitor settings','use source limits','sample spacing','frequency points','use wavelength spacing','custom frequency samples','wavelength start','wavelength stop','spatial interpolation']}
def main():
 class_before=lumapi.FDTD; init_before=lumapi.FDTD.__init__; report=dict(status='STARTED_CAD_ONLY',hide=True,no_solve=True,selected_original_indices=UNION,inputs=dict(base=file_identity(BASE),ports=file_identity(PORTS)),solve_calls_blocked=[])
 with np.load(PORTS,allow_pickle=False) as z: freq=z['p2_f'].ravel(); wavelengths=z['p2_lambda'].ravel()
 need(freq.shape==(501,) and np.isfinite(freq).all(),'original grid')
 wanted=freq[UNION];report['desired_frequencies_Hz']=wanted.tolist();report['desired_wavelengths_m']=wavelengths[UNION].tolist()
 try:
  raw=lumapi.FDTD(hide=True)
  with NoSolveCAD(raw,OUT) as cad:
   report['version']=plain(cad.version());cad.load(str(BASE));cad.switchtolayout()
   report['before']=snapshot(cad);need(report['before']['global_monitor']['frequency points']==501 and report['before']['ports']['FDTD::ports']['monitor frequency points']==501,'baseline501 source/port sampling')
   report['available_monitor_property_list']=attempt(lambda:selected_properties(cad));report['monitor_before']=properties(cad)
   for method in ['run','runjobs','runparallel']:
    try:getattr(cad,method)()
    except RuntimeError as e:report['solve_calls_blocked'].append(dict(method=method,error=str(e)))
    else:raise RuntimeError('no-solve guard failure '+method)
   try:cad.eval('run;')
   except RuntimeError as e:report['solve_calls_blocked'].append(dict(method='eval run;',error=str(e)))
   else:raise RuntimeError('script no-solve guard failure')
   cad.setnamed(MON,'enabled',1);cad.setnamed(MON,'override global monitor settings',1)
   cad.setnamed(MON,'use source limits',0);cad.setnamed(MON,'sample spacing','custom')
   cad.setnamed(MON,'custom frequency samples',wanted.reshape(-1,1))
   report['monitor_configured']=properties(cad);report['after']=snapshot(cad)
   need(report['after']==report['before'],'source/port/global/numerics mutation')
   actual=np.asarray(cad.getnamed(MON,'custom frequency samples')).ravel();need(np.array_equal(actual,wanted),'custom frequency readback mismatch')
   report['configured_custom_grid_exact']=True
   saved=OUT/'selective_five_frequency.fsp';cad.save(saved);cad.load(saved)
   report['monitor_reloaded']=properties(cad);report['reloaded']=snapshot(cad)
   need(report['reloaded']==report['before'],'reload changed source/port/global/numerics')
   reloaded=np.asarray(cad.getnamed(MON,'custom frequency samples')).ravel();need(np.array_equal(reloaded,wanted),'custom frequency persistence mismatch')
   report['persisted_custom_grid_exact']=True;report['monitor_frequency_data_without_solve']=attempt(lambda:cad.getdata(MON,'f',2))
   report['saved_fsp']=file_identity(saved);report['cad_guard_audit']=cad.audit;report['status']='CAD_PROPERTY_AND_PERSISTENCE_PASS_NOT_RESULT_GRID_OR_PHYSICS_PASS'
 except Exception as exc:
  report['status']='CAD_PROPERTY_CHECK_FAILED';report['error']=type(exc).__name__+': '+str(exc)
 finally:
  report['FDTD_class_symbol_unchanged']=lumapi.FDTD is class_before;report['FDTD_constructor_unchanged']=lumapi.FDTD.__init__ is init_before
  report['original_base_unchanged']=file_identity(BASE)==report['inputs']['base'];report['original_ports_unchanged']=file_identity(PORTS)==report['inputs']['ports'];report['lumapi_sha256']=sha(API/'lumapi.py')
  with (OUT/'cad_report.json').open('x',encoding='utf-8') as stream:json.dump(report,stream,indent=2,allow_nan=False)
 print(report['status']);print(report.get('error',''));print('No solve calls executed; blocked probes:',len(report['solve_calls_blocked']));print('Class unchanged',report['FDTD_class_symbol_unchanged'])
 return 0 if report['status'].startswith('CAD_PROPERTY_AND') and report['original_base_unchanged'] and report['FDTD_class_symbol_unchanged'] else 1
if __name__=='__main__':raise SystemExit(main())
