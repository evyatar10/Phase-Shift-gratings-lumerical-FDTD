import unittest,sys
from pathlib import Path
import numpy as np
sys.dont_write_bytecode=True
sys.path.insert(0,'C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
from runners.lumopt2_design import lumopt2_design as eng,v3_step as v3
import analyze_peak_translation as a

class Tests(unittest.TestCase):
    def test_exact_quadratic_peak_and_translation_removes_shape_residual(self):
        x=np.arange(101,dtype=float);wl=1600.-x*.01
        center=.9-.0001*(x-50.13)**2
        plus=.9-.0001*(x-53.39)**2;minus=.9-.0001*(x-46.87)**2
        for y in (center,plus,minus):self.assertAlmostEqual(a.score(eng,wl,y),.9,places=13)
        r=a.model_pair(eng,v3,wl,center,plus,minus,.5,'cubic')
        self.assertAlmostEqual(r['offset_bins'][0],3.26,places=10)
        self.assertAlmostEqual(r['offset_bins'][1],-3.26,places=10)
        for k,v in r['observed_minus_predicted'].items():self.assertLess(abs(v),1e-12)
        for residual in r['translated_full_overlap_spectral_residual']:self.assertLess(residual['max_abs'],1e-12)
        ladder=a.translation_ladder(eng,wl,center)
        for row in ladder['rows']:
            self.assertLess(abs(row['fixed_projection_truncation_bias']),1e-12)
            self.assertLess(abs(row['moving_peak_derivative']),1e-12)

    def test_lorentzian_corrected_error_is_quartic_not_sample_max_quadratic(self):
        x=np.arange(501,dtype=float);wl=1600.-x*.01;height=.93
        peak_errors=[];sample_errors=[]
        for gamma in (25.,50.,100.):
            y=height/(1+((x-250.23)/gamma)**2)
            peak_errors.append(height-a.score(eng,wl,y));sample_errors.append(height-max(y))
        for j in (0,1):
            self.assertTrue(15.8<peak_errors[j]/peak_errors[j+1]<16.1)
            self.assertTrue(3.99<sample_errors[j]/sample_errors[j+1]<4.01)
        y=height/(1+((x-250.)/25.)**2);self.assertEqual(a.score(eng,wl,y),height)

    def test_odd_even_units_and_no_overwrite(self):
        r=a.metrics(1.03,1.01,1.,.5)
        self.assertAlmostEqual(r['odd'],.01);self.assertAlmostEqual(r['even'],.02);self.assertAlmostEqual(r['derivative'],.02)
        with self.assertRaises(FileExistsError):a.run(Path.cwd(),Path(__file__).parent)

if __name__=='__main__':unittest.main()
