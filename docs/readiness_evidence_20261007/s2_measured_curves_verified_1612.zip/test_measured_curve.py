import sys,unittest
sys.dont_write_bytecode=True
from unittest.mock import patch
import numpy as np
import measured_curve_check as m
class MathChecks(unittest.TestCase):
 def test_conditional_h_squared_formula_only(self):
  h=.0625;d0=7.;coefficient=-12.;small=d0+coefficient*h*h;large=d0+coefficient*(2*h)**2
  self.assertEqual(float(m.richardson(small,large)),d0)
  # h^4 remainder survives: two values do not certify the h^2 premise.
  small+=8*h**4;large+=8*(2*h)**4
  self.assertNotEqual(float(m.richardson(small,large)),d0)
 def test_bin_absolute_zero_and_scaling_reporting(self):
  ds=np.array([0.,1e-8,-2.]);dl=np.array([0.,-1e-8,-2.02]);wl=np.arange(3)*1e-9
  a=m.bin_row(0,1,wl,ds,dl,.02);self.assertIsNone(a['symmetric_relative_difference']);self.assertIsNone(a['odd_large_over_twice_small'])
  a=m.bin_row(1,1,wl,ds,dl,.02);self.assertTrue(a['near_zero_diagnostic']);self.assertEqual(a['absolute_difference'],2e-8)
  a=m.bin_row(2,1,wl,ds,dl,.02);self.assertAlmostEqual(a['odd_large_over_twice_small'],1.01);self.assertAlmostEqual(a['symmetric_relative_difference'],.04/4.02)
 def test_translation_sign_finite_common_domain_non_lorentzian(self):
  x=np.arange(31.);center=2+3*x+.2*x*x;shifts={'plus':2.25,'minus':-1.75}
  valid,curves=m.shifted_center(center,x,shifts)
  self.assertEqual(np.flatnonzero(valid).tolist(),list(range(3,29)))
  for role,delta in shifts.items():np.testing.assert_allclose(curves[role],2+3*(x[valid]-delta)+.2*(x[valid]-delta)**2,rtol=1e-14,atol=1e-14)
 def test_input_pin_refusal(self):
  with patch.object(m,'sha',return_value='0'*64):
   with self.assertRaisesRegex(RuntimeError,'Pinned measured input changed'):m.main()
 def test_actual_measured_math_and_disclaimers(self):
  report=m.main();self.assertEqual(len(report['observables']),2)
  for metric,r in report['observables'].items():
   self.assertEqual([b['offset'] for b in r['flank_bins']],list(range(-30,-9))+list(range(10,31)))
   self.assertEqual(r['flank_summary']['both']['count'],42)
   self.assertIn('CONDITIONAL',str(r['conditional_Richardson']))
   self.assertIn('not physical ground truth',r['counterfactual_qualification'])
   for b in r['flank_bins']:
    self.assertAlmostEqual(b['large_minus_small'],b['large_fd_per_nm']-b['small_fd_per_nm'])
    self.assertAlmostEqual(b['odd_large_over_twice_small'],b['large_fd_per_nm']/b['small_fd_per_nm'])
if __name__=='__main__':unittest.main(verbosity=2)
