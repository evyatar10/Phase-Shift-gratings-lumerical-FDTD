"""Read-only IGUM101155_0 collector. Parent supplies embedded EXPECTED.

Only Slurm status commands and file reads. No project/API import or solver call.
JSON stdout includes original small artifacts; FSP/H5 are hashed, never copied.
"""
import base64, datetime, hashlib, json, re, subprocess
from pathlib import Path


class EvidenceError(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise EvidenceError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8*1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def command(args):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=20)
        return dict(args=args, exit_code=p.returncode, out=p.stdout, err=p.stderr)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return dict(args=args, exit_code=None, out='', err=str(exc))


def completion(accounting, control, job='101155'):
    exact = job+'_0'
    if accounting['exit_code'] == 0:
        for line in accounting['out'].splitlines():
            fields = line.split('|')
            if fields[0] == exact and fields[1:3] == ['COMPLETED', '0:0']:
                return 'sacct_exact_array_task'
    if control['exit_code'] == 0:
        for block in re.split(r'(?m)(?=^JobId=)', control['out']):
            fields = dict(re.findall(r'(\w+)=([^\s]+)', block))
            if fields.get('ArrayJobId') == job and fields.get('ArrayTaskId') == '0' and fields.get('JobState') == 'COMPLETED' and fields.get('ExitCode') == '0:0':
                return 'scontrol_exact_array_task_accounting_unavailable_or_unconfirmed'
    raise EvidenceError('No trustworthy COMPLETED exit0 exact-task record; failed/empty queue is not completion')


def small_file(path, limit=8*1024*1024):
    path = Path(path); require(path.is_file() and path.stat().st_size <= limit, 'Missing/oversized small evidence: '+str(path))
    before = path.stat(); raw = path.read_bytes(); after = path.stat()
    require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), 'Evidence changed while read')
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), mtime_ns=after.st_mtime_ns, data=base64.b64encode(raw).decode())


def run(expected):
    base = Path(expected['root']); job = expected['job']
    account = command(['sacct','-j',job,'--format=JobID,State,ExitCode,Elapsed,Start,End,NodeList','-nP'])
    control = command(['scontrol','show','job',job+'_0'])
    queue = command(['squeue','-j',job,'-h','-o','%i|%T|%R'])
    result = dict(schema=1, job=job, task=0, at=datetime.datetime.now().astimezone().isoformat(), accounting=account, control=control, queue=queue, no_solve=True)
    try:
        result['completion_evidence'] = completion(account, control, job)
        root = base/'results/diagnose_te_s2_fdstep/results/lumopt2_te_s2_fdstep_diagnostic_20261007'
        cp = root/'task_00.json'; cpfile = small_file(cp); row = json.loads(base64.b64decode(cpfile['data']))
        identity = dict(expected['identity']); identity['reference_checkpoint'] = expected['reference_path']
        require(row['identity'] == identity, 'Full checkpoint identity differs from frozen nominal family/native reference path')
        r = row['result']
        require(r['task']==r['sign']==r['delta_nm']==0 and r['index']==29 and r['params']==identity['point'], 'Non-nominal result parameters')
        require(r['reference']['path']==expected['reference_path'] and r['reference']['sha256']==identity['reference_sha256'], 'Reference identity differs')
        require(digest(expected['reference_path'])==identity['reference_sha256'], 'Original reference bytes changed')
        files = {'checkpoint':cpfile}
        artifact_stats = {}
        for role in ('source','h5','ports_npz'):
            p = Path(r[role]); require(p.is_file() and p.resolve().is_relative_to(root.resolve()), 'Artifact missing or escapes unique family: '+role)
            require(p.relative_to(root).parts[0].startswith('task_00_'), 'Artifact not from nominal unique attempt')
            before = p.stat(); sha = digest(p); after = p.stat()
            require((before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns), 'Artifact changed during hash: '+role)
            artifact_stats[role] = dict(path=str(p),sha256=sha,bytes=after.st_size,mtime_ns=after.st_mtime_ns)
        require(Path(r['source']).parent.parent==Path(r['ports_npz']).parent, 'FSP/ports attempt differs')
        require(Path(r['h5'])==Path(r['source']).with_suffix('')/(Path(r['source']).stem+'_output.h5'), 'H5 association differs')
        files['ports'] = small_file(r['ports_npz'])
        log = Path(r['source']).with_name(Path(r['source']).stem+'_p0.log')
        files['solver_log'] = small_file(log); solver = base64.b64decode(files['solver_log']['data']).decode(errors='replace')
        require('Simulation completed successfully' in solver, 'No successful solver termination')
        batch = base/f'jobs/logs/lum_array-{job}_0.out';files['batch_log']=small_file(batch)
        text = base64.b64decode(files['batch_log']['data']).decode(errors='replace')
        require(f'Array:      {job}[0]' in text and re.search(r'^Exit code:\s*0\s*$',text,re.M) and 'Finished:' in text, 'Exact-job batch completion absent')
        require('DIAGNOSTIC checkpoint, review required '+str(cp) in text and 'REUSED diagnostic checkpoint' not in text, 'Batch does not identify newly produced exact checkpoint')
        require("device type readback = 'GPU'" in text and 'FDTD threads = 8' in text, 'GPU/thread execution evidence absent')
        code = {}
        for name,sha in identity['code'].items():
            rel = Path(name) if name in ('bragg_device.py','simulation_config.py','sim_helpers.py') else Path('runners/lumopt2_design')/name
            code[name] = digest(base/'project'/rel);require(code[name]==sha,'Current frozen project source differs: '+name)
        api = Path('/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261/api/python')
        vendor = {name:dict(path=str(api/name),sha256=digest(api/name) if (api/name).is_file() else None) for name in expected['vendor_sources']}
        files['tasklist'] = small_file(base/'data/sweep_list_diagnose_te_s2_fdstep_qualification.txt')
        require(base64.b64decode(files['tasklist']['data']).decode().strip()=='0', 'Qualification manifest is not task0 only')
        require(cp.read_bytes()==base64.b64decode(cpfile['data']), 'Checkpoint changed during collection')
        require(digest(r['ports_npz'])==files['ports']['sha256'], 'Ports changed during collection')
        result.update(status='COMPLETION_EVIDENCE_COLLECTED_REVIEW_REQUIRED', files=files, artifact_hashes=artifact_stats, current_code=code,
            vendor_sources=vendor,lumapi_sha256=digest(api/'lumapi.py'),
            limitations=['Current installed source hashes do not prove unchanged install throughout the earlier solve.',
                'Stored spec/params and mesh counts are available; saved CAD properties/mesh coordinates/timing settings are not independently queried.',
                'Different A100 memory variants do not imply bitwise spectral parity; no automatic qualification or calibration pass.'])
    except (EvidenceError,OSError,KeyError,ValueError) as exc:
        result.update(status='NOT_READY_OR_INVALID_NO_COMPLETION_CLAIM',error=str(exc))
    return result


if __name__ == '__main__':
    print(json.dumps(run(EXPECTED),allow_nan=False))
