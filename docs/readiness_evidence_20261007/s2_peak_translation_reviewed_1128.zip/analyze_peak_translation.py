"""Bounded no-CAD peak3 translation models, importing exact current scoring code."""
import argparse,io,json,hashlib,sys,zipfile
from pathlib import Path
import numpy as np
from scipy.interpolate import CubicSpline, PchipInterpolator
from scipy.optimize import minimize_scalar
sys.dont_write_bytecode=True

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def metrics(a,b,c,h):
    return dict(plus=a,minus=b,center=c,odd=(a-b)/2,even=(a+b)/2-c,derivative=(a-b)/(2*h))

def score(eng,wl,y):
    return float(eng.make_fct_peak(wl)(y))

def peak_index(eng,wl,y):
    lam,_,_=eng.measure_peak(wl,y)
    return int(np.argmin(np.abs(wl-lam)))

def model_pair(eng,v3,wl,center,plus,minus,h,kind):
    n=len(center);x=np.arange(n,dtype=float)
    ic=peak_index(eng,wl,center)
    offsets=[peak_index(eng,wl,y)+v3.peak3_r(y,peak_index(eng,wl,y))-ic-v3.peak3_r(center,ic) for y in (plus,minus)]
    spline=(CubicSpline if kind=='cubic' else PchipInterpolator)(x,center,extrapolate=False)
    keep=(x-max(offsets)>=0)&(x-min(offsets)<=n-1)
    xx=x[keep];ww=wl[keep]
    pred=[spline(xx-d) for d in offsets]
    ycenter=center[keep]
    for y in (center,plus,minus):
        if not np.isclose(score(eng,ww,y[keep]),score(eng,wl,y),rtol=0,atol=1e-14):
            raise RuntimeError('Overlap restriction changed selected actual peak')
    observed=metrics(score(eng,wl,plus),score(eng,wl,minus),score(eng,wl,center),h)
    predicted=metrics(score(eng,ww,pred[0]),score(eng,ww,pred[1]),score(eng,ww,ycenter),h)
    continuous=minimize_scalar(lambda t:-float(spline(t)),bounds=(ic-1,ic+1),method='bounded',options={'xatol':1e-12})
    trueheight=-continuous.fun
    phases=np.linspace(-.5,.5,1001)
    core=x[1:-1];wcore=wl[1:-1]
    errors=np.array([score(eng,wcore,spline(core-d))-trueheight for d in phases])
    residual=[actual[keep]-model for actual,model in zip((plus,minus),pred)]
    import autograd
    jac=np.asarray(autograd.grad(eng.make_fct_peak(ww))(ycenter))
    predicted['fixed_center_peak3_jacobian_spectral_fd']=float(jac@((pred[0]-pred[1])/(2*h)))
    observed['fixed_center_peak3_jacobian_spectral_fd']=float(jac@((plus[keep]-minus[keep])/(2*h)))
    return dict(model=kind,offset_bins=offsets,observed=observed,predicted=predicted,
        observed_minus_predicted={k:observed[k]-predicted[k] for k in ('odd','even','derivative')},
        translated_full_overlap_spectral_residual=[dict(max_abs=float(np.max(np.abs(r))),rms=float(np.sqrt(np.mean(r*r)))) for r in residual],
        phase_scan_model_error=dict(min=float(errors.min()),max=float(errors.max()),range=float(np.ptp(errors)),continuous_model_peak=trueheight),
        overlap_bins=[int(xx[0]),int(xx[-1])],qualification='INTERPOLATED_CENTER_SHAPE_MODEL_NOT_EXACT_PHYSICS_OR_NOISE_BOUND')

def lorentz_scan(eng,wl,center):
    x=np.arange(len(center),dtype=float);i=peak_index(eng,wl,center)
    _,_,width=eng.measure_peak(x,center);height=score(eng,wl,center);gamma=width/2
    phases=np.linspace(-.5,.5,1001)
    errors=np.array([score(eng,wl,height/(1+((x-i-phase)/gamma)**2))-height for phase in phases])
    sampleerror=np.array([np.max(height/(1+((x-i-phase)/gamma)**2))-height for phase in phases])
    order=[]
    for scale in (1.,2.,4.):
        y=height/(1+((x-i-.23)/(gamma*scale))**2)
        order.append(abs(score(eng,wl,y)-height))
    return dict(height=height,fwhm_bins=width,hwhm_bins=gamma,grid_over_hwhm=1/gamma,
        peak3_error_min=float(errors.min()),peak3_error_max=float(errors.max()),peak3_error_range=float(np.ptp(errors)),
        sampled_max_error_min=float(sampleerror.min()),halved_grid_relative_to_width_errors=order,
        observed_error_ratios=[order[j]/order[j+1] for j in (0,1)])


def translation_ladder(eng,wl,center,speed=-22.6):
    import autograd
    x=np.arange(len(center),dtype=float)
    spline=CubicSpline(x,center,extrapolate=False)
    keep=(x>=12)&(x<=len(x)-13);xx=x[keep];ww=wl[keep];yc=center[keep]
    jac=np.asarray(autograd.grad(eng.make_fct_peak(ww))(yc))
    infinitesimal=float(jac@(-speed*spline(xx,1)))
    rows=[]
    for h in (.5,.25,.125,.0625):
        yp=spline(xx-speed*h);ym=spline(xx+speed*h)
        projection=float(jac@((yp-ym)/(2*h)))
        rows.append(dict(h_nm=h,motion_bins=abs(speed*h),fixed_jacobian_projection=projection,
            pure_translation_infinitesimal_fixed_jacobian_projection=infinitesimal,
            fixed_projection_truncation_bias=projection-infinitesimal,
            moving_peak_derivative=(score(eng,ww,yp)-score(eng,ww,ym))/(2*h)))
    return dict(speed_bins_per_nm=speed,rows=rows,qualification='CONSTANT_SHAPE_CUBIC_MODEL_ONLY_NOT_PHYSICAL_GRADIENT_OR_NOISE_BOUND')

def spectra(data):return dict(tout=np.abs(data['p2_T_out'].ravel()),modal=np.abs(data['p2_S'].ravel())**2)

def run(repo,out):
    out=Path(out);out.mkdir(exist_ok=False)
    repo=Path(repo);sys.path.insert(0,str(repo))
    from runners.lumopt2_design import lumopt2_design as eng,v3_step as v3
    e=repo/'docs/readiness_evidence_20261007'
    summary=json.loads((e/'s2_firstwave_measured_1113.json').read_text())
    for name,digest in summary['provenance']['observed_files'].items():
        if sha(e/name)!=digest:raise RuntimeError('Pinned actual evidence SHA mismatch: '+name)
    data={}
    for name in ['s2_fdstep_task00_ports.npz']+[f's2_half_classes_task{t:02d}_ports.npz' for t in range(4)]:
        with np.load(e/name,allow_pickle=False) as a:data[name]={k:a[k] for k in a.files}
    c=data['s2_fdstep_task00_ports.npz'];wl=c['p2_lambda'].ravel()*1e9;freq=c['p2_f'].ravel()
    if not np.allclose(np.diff(freq),np.diff(freq)[0],rtol=1e-10,atol=0):raise RuntimeError('Frequency grid not uniform')
    for d in data.values():
        for key in ('p2_f','p2_lambda'):
            if not np.array_equal(d[key],c[key]):raise RuntimeError('Full grids differ')
    output=dict(status='DIAGNOSTIC_MODEL_ONLY_CALIBRATION_FAILED_UNCHANGED',source_sha256=sha(__file__),measured_summary_sha256=sha(e/'s2_firstwave_measured_1113.json'),inputs_sha256=summary['provenance']['observed_files'],engine_sha256=sha(repo/'runners/lumopt2_design/lumopt2_design.py'),v3_sha256=sha(repo/'runners/lumopt2_design/v3_step.py'),cases={})
    cc=spectra(c)
    for observable in ('tout','modal'):
        y=cc[observable];target='peak3_tout' if observable=='tout' else 'peak3_modal'
        output['cases'][observable]=dict(lorentzian=lorentz_scan(eng,wl,y),pure_translation_step_ladder=translation_ladder(eng,wl,y),shift30_hhalf={})
        endpoints=[spectra(data[f's2_half_classes_task{t:02d}_ports.npz'])[observable] for t in (2,3)]
        for value,t in zip(endpoints,(2,3)):
            row=json.loads((e/f's2_half_classes_task{t:02d}_original.json').read_text())
            if not np.isclose(score(eng,wl,value),row['result'][target],rtol=0,atol=1e-12):raise RuntimeError('Saved score not reproduced')
        for kind in ('cubic','pchip'):
            output['cases'][observable]['shift30_hhalf'][kind]=model_pair(eng,v3,wl,y,*endpoints,.5,kind)
        archive=e/'s2_original_port_spectra_preserved.zip'
        oldpin=summary['provenance']['old_shift30']['source_roles']
        if sha(archive)!=oldpin['archive_sha256']:raise RuntimeError('Old archive SHA mismatch')
        with zipfile.ZipFile(archive) as z:
            old=[]
            for name in ('base_ports.npz','task_09_ports.npz','task_10_ports.npz'):
                members=[n for n in z.namelist() if n.endswith(name)]
                if len(members)!=1:raise RuntimeError('Archive member missing/ambiguous')
                raw=z.read(members[0])
                if hashlib.sha256(raw).hexdigest()!=oldpin['members'][name]:raise RuntimeError('Old member SHA mismatch')
                with np.load(io.BytesIO(raw),allow_pickle=False) as a:
                    if not np.array_equal(a['p2_f'],c['p2_f']):raise RuntimeError('Old full grid differs')
                    old.append(spectra(a)[observable])
        output['cases'][observable]['shift30_h2_native_old_center']={kind:model_pair(eng,v3,wl,*old,2.,kind) for kind in ('cubic','pchip')}
        output['cases'][observable]['shift30_h2_qualification']=oldpin['qualification'] if 'qualification' in oldpin else summary['provenance']['old_shift30']['qualification']
    output['limitations']=['Spline/PCHIP phase error is model-dependent; center interpolation is not an exact continuous spectrum.','Symmetric Lorentzian models only the ideal symmetric peak with measured height/FWHM, not all actual spectral structure.','Only scalar original Re/Im peak3 adjoint contractions exist; no full spectral adjoint Jacobian is available.','Two corr30 repeats give observed variation, not a statistical noise bound.','No parameter step convergence or gradient gate is established here.']
    with (out/'report.json').open('x') as f:json.dump(output,f,indent=2,allow_nan=False)
    return output

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--output',required=True);a=p.parse_args();r=run(a.repo,a.output)
    print(json.dumps({k:dict(lorentzian=v['lorentzian'],models={m:q['observed_minus_predicted'] for m,q in v['shift30_hhalf'].items()}) for k,v in r['cases'].items()},indent=2))
