"""Focused offline checks; bootstrap with the final isolated modal engine."""
import dataclasses
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
sys.path.insert(0,str(Path(__file__).parent))
import n98_pilot_packet as packet
from runners.lumopt2_design import evaluation_budget


class PacketChecks(unittest.TestCase):
    def setUp(self):
        self.root=Path(tempfile.mkdtemp(prefix='n98_pilot_gate_'))
        self.path=self.root/'n98_pilot_synthetic_calibration.json'
        self.coeff=(.93,.12)  # offline fixture, never approved for S2
        re=np.arange(1.,7.);im=np.array([2.,-1.,3.,1.,-2.,4.])
        self.payload=dict(identity=dict(objective='peak3_abs_T_out',
            base=dict(spec=dataclasses.asdict(packet.s2.SPEC_V3))),
            result=dict(re=re.tolist(),im=im.tolist(),
            fd=(self.coeff[0]*re+self.coeff[1]*im).tolist(),
            coefficients=list(self.coeff),passed=True))

    def write(self):
        self.path.write_text(json.dumps(self.payload),encoding='utf8')
        return hashlib.sha256(self.path.read_bytes()).hexdigest()

    def test_missing_calibration_blocks_before_cad_or_solve(self):
        with patch.object(packet.eng,'make_project',side_effect=AssertionError('CAD touched')), \
             patch.object(packet.eng,'run_campaign',side_effect=AssertionError('Solve touched')):
            with self.assertRaisesRegex(RuntimeError,'not passed review'):
                packet.main(0)

    def test_valid_port_fit_does_not_unlock_preparation_helper(self):
        digest=self.write()
        with patch.object(packet,'CALIBRATION_SHA256',digest), \
             patch.object(packet,'load_peak_calibration',return_value=self.coeff), \
             patch.object(packet.eng,'make_project',side_effect=AssertionError('CAD touched')), \
             patch.object(packet.eng,'run_campaign',side_effect=AssertionError('Solve touched')):
            with self.assertRaisesRegex(RuntimeError,'preparation-only'):
                packet.main(0)

    def test_derived_seed_bounds_family_and_modal_budget_flags(self):
        spec=packet.pilot_spec(self.coeff);p=packet.eng.seed_params(spec)
        bounds=np.asarray(packet.eng.param_bounds(spec))
        np.testing.assert_equal(p,packet.s2.SEED)
        self.assertEqual(len(p),296)
        self.assertTrue(np.all((p>=bounds[:,0]) & (p<=bounds[:,1])))
        self.assertEqual((spec.n_periods_side,spec.n_free,spec.polarization),(98,60,'TE'))
        self.assertTrue(spec.bare and not spec.free_comb)
        self.assertEqual((spec.max_iter,spec.max_feval,packet.MAX_RESTARTS),(2,4,0))
        self.assertEqual((spec.wgp_modal_guard,spec.best_metric,spec.wgp_reuse_k),
                         (True,'modal_peak3',0))
        self.assertEqual((spec.wgp_v3_dlam_nm,spec.scan_center_nm,spec.scan_width_nm,spec.n_wl_points),
                         (.05,1560.464,2.,501))
        np.testing.assert_allclose(packet.width_contract.hard_band(spec,packet.eng.RHO_DN,packet.eng.RHO_UP),
                                   (19.24328,20.02872),atol=1e-12,rtol=0)
        self.assertEqual((spec.adj_fix_field_re,spec.adj_fix_field_im),packet.s2.ADJ_FIX_FIELD)
        cfg=packet.eng.build_base_cfg(spec)
        self.assertAlmostEqual(cfg.geometry.core_height_m/packet.eng.NM,350.)
        self.assertFalse(cfg.scatterer.enabled)
        L=packet.eng.layout(60)
        self.assertEqual(p[L.SL_CORR.start],0.)
        self.assertTrue(np.all(p[L.SL_SHIFT]==0.))
        self.assertFalse(np.array_equal(p,packet.val.te_point(spec)))

    def test_calibration_hash_objective_family_and_gradient_failure(self):
        digest=self.write()
        self.assertEqual(packet.load_peak_calibration(self.path,digest),self.coeff)
        with self.assertRaisesRegex(RuntimeError,'hash mismatch'):
            packet.load_peak_calibration(self.path,'0'*64)
        self.payload['identity']['base']['spec']['n_periods_side']=70
        with self.assertRaisesRegex(RuntimeError,'retained S2 N98'):
            packet.load_peak_calibration(self.path,self.write())
        self.payload['identity']['base']['spec']['n_periods_side']=98
        self.payload['identity']['objective']='softmax'
        with self.assertRaisesRegex(RuntimeError,'different objective'):
            packet.load_peak_calibration(self.path,self.write())
        self.payload['identity']['objective']='peak3_abs_T_out'
        self.payload['result']['fd'][0]*=2
        with self.assertRaisesRegex(RuntimeError,'10% gates'):
            packet.load_peak_calibration(self.path,self.write())

    def test_forward_budget_is_four_total_and_cold_resume_does_not_refund(self):
        spec=packet.pilot_spec(self.coeff)
        ledger=evaluation_budget.ForwardEvaluationBudget(self.root,spec.label,spec.max_feval)
        for _ in range(4):
            ledger.reserve()
        resumed=evaluation_budget.ForwardEvaluationBudget(self.root,spec.label,spec.max_feval)
        self.assertEqual(resumed.used,4)
        with self.assertRaises(evaluation_budget.BudgetExhausted):
            resumed.reserve()

    def test_declared_task_and_pinned_candidate(self):
        self.assertTrue(packet.IS_HELPER)
        self.assertEqual(packet.N_TASKS,1)
        with self.assertRaises(ValueError):
            packet.main(1)
        packet.require_candidate()


if __name__=='__main__':
    unittest.main()
