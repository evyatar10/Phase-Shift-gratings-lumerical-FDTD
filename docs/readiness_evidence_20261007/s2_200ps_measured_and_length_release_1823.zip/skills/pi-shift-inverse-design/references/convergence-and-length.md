# Convergence, physical length and usable gradients

Keep distinct questions separate: solver duration, spatial mesh, transverse
domain/PML, physical mirror length, sampled spectral functional, and adjoint
agreement with finite differences on the same discretization. Passing one
does not certify the others. A solver completion code or auto-shutoff event
is not an error bound on peak height, spatial FWHM or a small derivative.

Read the current project continuation and its mesh/length evidence report.
The October 7 audit recovered raw historical MATs that a default ignored-file
search missed. Use explicit study paths or `rg --files --hidden --no-ignore`
within the relevant study when absence matters; avoid indiscriminate disk scans.
Select MAT variables rather than loading multi-GB fields for scalar questions.
Distinguish exact saved-envelope recomputation from raw-E reintegration, and
small-file byte hashes from only metadata/selected-variable checks on large files.

The working mesh is approximately 50 nm, not automatically a uniform or
mesh-converged grid. Inspect realized axes, dt, PVA/conformal settings, global
steps, native overrides and the lumopt2 locked region. The builder's accurate
option primarily refines x; it does not automatically refine every override.
Compare the tracked physical resonance as well as fixed-frequency spectra.
Monitor frequency grids are independently configured: changing CFL dt does
not by itself imply they change. Measure both rather than assuming a link.

Preserve source, monitor and PML placements and record changes caused by a
new grid. One-axis/two-level refinement establishes sensitivity, not an
asymptotic error order or a universal convergence certificate. Choose further
rungs based on measured effects and the user's accuracy needs, retaining the
unchanged design width bands. Do not adopt arbitrary new acceptance tolerances.

N is periods per side. Changing N changes mirror coupling and the physical
device; it is not merely enlarging a numerical box. A stable width alongside
changing transmission/Q is possible. A longer-N plateau does not establish a
shorter-N plateau. Keep the inner free-period vector and cavity-centered
indexing fixed; first separate physical truncation from moving ports/PML or
shrinking the domain. Do not silently reset anchors, bounds or restart vectors.

The production spatial FWHM uses a y-integrated intensity-like line, its
standing-wave envelope, and half-height relative to the envelope floor inside
the grating crop. Shortening N also changes the crop. Record the floor, end
levels and profile shape so a metric-window effect is not mistaken for physical
confinement. Supplemental common-window or alternative-floor diagnostics must
remain clearly labeled; they do not replace the production observable or band.
End intensity is neither a modal electric-field amplitude nor radiated flux.

Recover profiles from existing solved FSP/H5 before buying another baseline
solve. Disabling optimization_dft need not disable field_profile. Verify the
actual saved monitor data, wavelength, coordinates and identity; do not assume
that source code proves recording succeeded. Use hidden read-only CAD with
solve/save guards or a verified raw-data reader. Preserve original bytes.

Estimate runtime from cells, CFL steps, recording and measured same-family
jobs, plus queue risk. Shorter mirrors leave free-region field-recording costs
nearly unchanged; nominal length savings are not total runtime savings. Do
not launch a costly full transverse refinement merely because seats are free.

A bounded optimizer smoke needs reliable gradients for its exact discretized
functional and current numerical family. Fully converged continuum gradients
are a separate claim. Coarse-grid improvements require refined-grid/device
confirmation before being called physically robust. Failed global calibration
continues to block optimizer release, regardless of mesh or length progress.

Primary reference: [Ansys FDTD convergence testing](https://optics.ansys.com/hc/en-us/articles/360034915833-Convergence-testing-process-for-FDTD-simulations).
It separates mesh, PML, source and monitor errors and advocates choosing an
application-relevant accuracy target; it supplies no pass threshold for this device.


## MAT analysis preference (user, October 7)

The user normally exports, downloads and analyzes MAT files; keep that workflow.
Prefer a small MAT containing spectra, coordinates, y-integrated intensity,
envelope, production width/sigma, selected wavelengths, units and run/source
identities. Preserve enough profile data to recompute width, not only its scalar.
Keep original CP/NPZ and large solver FSP/H5 evidence; a MAT summary is a useful
analysis product, not automatically a restart or raw-adjoint substitute.
Perform heavy extraction on a scheduled server allocation and transfer compact
results. Use existing MAT evidence before requesting a new solve. Do not
install h5py or alter a container merely to inventory a saved H5: the official
hidden CAD result API can read it; record an unavailable optional inventory.
Some MAT variants themselves use HDF5 internally; file extension alone does
not determine what physical data are retained. Verify reader round trips.

A claim that N80 truncates FWHM must distinguish missing half-height crossings,
changed tails/floor within the metric window, and actual shorter-mirror physics.
Compare these explicitly; a roughly79um grating with roughly20um FWHM is not
by geometry alone proof of either adequate tails or clipped half-height points.


## Finite-duration adjoint caveat

Matching forward/adjoint stop times is necessary provenance, not a proof that
a stationary frequency-domain field-overlap formula exactly differentiates
a truncated finite-time DFT. Temporal endpoint terms can remain when fields
have not decayed adequately. Do not promise exact finite-duration agreement
without a discrete time-domain adjoint derivation or measured convergence.
Separate scalar/width stability, spectral finite differences, and actual
matched-field adjoint checks. A frozen center peak3 Jacobian multiplied by a
finite spectral difference is a diagnostic projection, not an adjoint and not
an exact spectral derivative. Two step sizes permit a conditional extrapolation,
not an automatic error estimate or proof of asymptotic behavior. Even
numerators and cross-machine differences are not stochastic noise bounds.

Ansys explicitly treats convergence testing as a prerequisite for lumopt:
https://optics.ansys.com/hc/en-us/articles/360050995394-Getting-Started-with-lumopt-Python-API

## Observer and duration lessons from the October 7 diagnostics

Small changes in transmission values do not establish accurate small peak-height
derivatives. Compare same-geometry duration differences and the full central
triplet, including odd/even terms. Quantify cancellation using the actual
objective Jacobian support and weighted terms, not unrelated opposite flanks.
A fixed-center Jacobian applied to a finite spectral difference is a projection,
not an adjoint or an exact infinitesimal derivative. Changed peak-bin indices
alone do not prove that the functional is nonsmooth at the evaluated points.

Locate spectral changes and inspect fits as diagnostics, without declaring their
physical cause from location alone. Preserve the existing objective until any
candidate fitted-height observer and its Jacobian are validated. Spectral area,
spectral width and spatial FWHM are different quantities. One repeated solve
cannot establish a universal noise floor; matching durations alone does not make
a stationary frequency-domain adjoint exact for a finite-time calculation.

Compare physical lengths with the same domain/ports/mesh first and report both
own-device and common-window profiles. Agreement between N80 and N98 establishes
sensitivity over that interval; N98 is a reference, not an automatic proof of
infinite-length saturation. Keep the user-selected production N and width bands
until a measured adoption decision is made.
