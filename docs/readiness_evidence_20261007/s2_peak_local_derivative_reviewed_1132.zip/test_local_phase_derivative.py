import unittest,sys
import numpy as np
sys.dont_write_bytecode=True
sys.path.insert(0,'C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
from runners.lumopt2_design import lumopt2_design as eng,v3_step as v3
import analyze_local_phase_derivative as a

class Tests(unittest.TestCase):
    def test_exact_quadratic_translation_has_zero_peak_derivative(self):
        x=np.arange(101,dtype=float);wl=1600.-.01*x;y=.9-.0001*(x-50.2)**2
        r=a.local_review(eng,v3,wl,y)
        self.assertLess(abs(r['model_infinitesimal_derivative']),1e-12)
        for row in r['small_translation_rows']:
            self.assertLess(abs(row['fixed_projection']),1e-9)
            self.assertLess(abs(row['moving_peak_fd']),1e-9)

    def test_asymmetric_cubic_converges_to_exact_chain_rule(self):
        x=np.arange(101,dtype=float);wl=1600.-.01*x;u=x-50.2
        y=.9-.0001*u**2+1e-7*u**3
        r=a.local_review(eng,v3,wl,y)
        i=50;vertex=v3.peak3_r(y,i)
        weights=np.array([vertex*(vertex-1)/2,1-vertex**2,vertex*(vertex+1)/2])
        dy=-.0002*u+3e-7*u**2
        exact=float(weights@(-a.SPEED*dy[i-1:i+2]))
        self.assertAlmostEqual(r['model_infinitesimal_derivative'],exact,places=11)
        self.assertGreater(abs(exact),1e-6)
        for key in ('fixed_minus_infinitesimal','moving_minus_infinitesimal'):
            self.assertLess(abs(r['small_translation_rows'][-1][key]),1e-9)
        self.assertEqual(r['small_translation_rows'][-1]['peak_branch_indices'],[50,50])

    def test_period_units_and_exclusive_output(self):
        self.assertAlmostEqual(1/abs(a.SPEED),.04424778761061947)
        from pathlib import Path
        with self.assertRaises(FileExistsError):a.run(Path.cwd(),Path(__file__).parent)

if __name__=='__main__':unittest.main()
