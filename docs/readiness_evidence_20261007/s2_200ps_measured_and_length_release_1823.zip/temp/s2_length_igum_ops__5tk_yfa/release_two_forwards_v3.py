"""Lead-reviewed release of exactly two native IGUM length diagnostic forwards."""
import base64,hashlib,importlib.util,json,sys
from pathlib import Path
sp=importlib.util.spec_from_file_location('prep',Path(__file__).with_name('prepare_native_v2.py'));p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p);ops=p.ops
report=ops.E/'s2_length_native_cad_report_original_1757.json';report_sha='d18c4661da4c10240cf59a623b7b36cb7735dc32d1c32ef149829ecd6ddfdadd';assert hashlib.sha256(report.read_bytes()).hexdigest()==report_sha
review=json.loads((ops.E/'s2_length_native_CAD_parent_review_1757.json').read_text());assert review['native_vs_Windows_final_snapshot_exact']=={'98':True,'80':True}
record=json.loads(json.loads((ops.E/'s2_length_native_preparation_1753.json').read_text())['out'])
m=json.loads((ops.E/'s2_length_native_template_1753.json').read_text());assert m['status']=='NOT_REVIEWED' and m['allowed_tasks']==[]
m.update(status='APPROVED_FOR_TWO_IGUM_FIXED150PS_N98_N80_FIXED_DOMAIN_FORWARDS_ONLY',allowed_tasks=[0,1],lead_verdict='Lead explicitly reviewed native CAD job101425 completed0:0 and original reportd18c4661da4c10240cf59a623b7b36cb7735dc32d1c32ef149829ecd6ddfdadd. Both final native snapshots equal the reviewed Windows snapshots exactly; retained geometry/free60/296point, mesh, source/ports/phase, PML and monitors unchanged. Ten focused offline groups and independent source review passed runner9076. Release ONLY same-server N98 control and physicalN80 fixed150ps forwards to measure length sensitivity with own/common crops. N98 remains production; N70 deferred. This is not temporal/mesh/global-gradient validation; globalcalibration FAILED, no coefficients or optimizer. All completed200ps results reviewed as still peak-gradient-sensitive; length study is independent. Check fresh shared seats/queues/storage below; no automatic extension, extra tasks or campaign. Preserve all original sources/results and failed attempts.')
raw=(json.dumps(m,indent=2,allow_nan=False)+'\n').encode();marker_sha=hashlib.sha256(raw).hexdigest();marker=p.DATA+'/review_two_forwards.json';tasks=p.DATA+'/two_tasks.txt'
env=json.loads((ops.E/'s2_length_native_environment_1753.json').read_text());env.update(S2_LEN_REVIEW_MARKER=marker,S2_LEN_REVIEW_SHA256=marker_sha,SWEEP_KIND='lumopt2_design',SWEEP_SPEC_MODULE='runners.lumopt2_design.s2_length_fixed150',SWEEP_LIST=tasks,ATHENA_LICENSE='1055@132.68.48.51',ATHENA_INTERCONNECT='2325@132.68.48.51',REQUIRE_GPU='1',KEEP_H5='1',NTFY_TOPIC='',WORK_DIR=p.BASE)
inner="""import os,sys,json
sys.path.insert(0,os.environ['S2_LEN_REPO']);import config
config.LUMAPI_PATH=os.environ['LUMAPI_PATH'];config.BASE_SAVE_DIR=os.environ['S2_LEN_NATIVE_BASE']+'/results';config.NEFF_DATA_PATH=os.environ['S2_LEN_NATIVE_BASE']+'/data/FDE_sweep_results.mat';config.USE_GPU=True
from runners.lumopt2_design import s2_length_fixed150 as lane
def blocked(*a,**k):raise RuntimeError('RELEASE_VALIDATION_NO_CAD_OR_SOLVE')
lane.main=lane.forward_only=lane.build_only=lane.build_case=lane.eng.make_project=lane.eng.import_lumopt2=blocked
p=lane.native_paths();ref=lane.load_reference(p)
reviews=[lane.reviewed(task,p,ref) for task in [0,1]]
print(json.dumps(dict(status='EXACT_TWO_TASK_SCOPE_VALIDATED_NO_CAD',reviews=reviews)))
"""
history_path=ops.E/'s2_length_native_cad_status_1757.json'
history=json.loads(json.loads(history_path.read_text())['out'])
assert history['job']['rc']==0 and 'JobState=COMPLETED' in history['job']['out'] and 'ExitCode=0:0' in history['job']['out'] and history['report_sha256']==report_sha
historical_complete=dict(at=history['at'],job=history['job'],report_sha256=history['report_sha256'],local_receipt_sha256=hashlib.sha256(history_path.read_bytes()).hexdigest())
code=ops.COMMON+'''
import base64,re
b=Path(__BASE__);env=__ENV__;record=__RECORD__
q=run(['squeue','-u','evyatarrubin']);assert q['rc']==0 and not q['out'].strip().splitlines()[1:],'Existing IGUM jobs need reconciliation before this release'
job=run(['scontrol','show','job','101425_0']);historical=__HISTORICAL__
if job['rc']==0:assert 'JobState=COMPLETED' in job['out'] and 'ExitCode=0:0' in job['out'],job
else:
 assert 'Invalid job id specified' in job['err'],job
 assert historical['job']['rc']==0 and 'JobState=COMPLETED' in historical['job']['out'] and 'ExitCode=0:0' in historical['job']['out']
 log=(b/'jobs/logs/lum_array-101425_0.out').read_text();assert 'NATIVE_CAD_PAIR_CONTROLS_PASS_NO_PHYSICS_OR_SOLVE_APPROVAL' in log and 'Exit code: 0' in log
 job['qualification']='Completed record aged out of scontrol; exact archived verified completion receipt and preserved log/report bind this qualification'
rep=b/'results/s2_length_native_cad_20261007/native_build_only_report.json';assert hashlib.sha256(rep.read_bytes()).hexdigest()==__REPORTSHA__
native=json.loads(rep.read_text());assert native['status']=='NATIVE_CAD_PAIR_CONTROLS_PASS_NO_PHYSICS_OR_SOLVE_APPROVAL'
for c in native['cases'].values():
 assert hashlib.sha256(Path(c['source']).read_bytes()).hexdigest()==c['setup_fsp_sha256']
 pre=c['native_saved_format_construction'];assert hashlib.sha256(Path(pre['preparatory_fsp']).read_bytes()).hexdigest()==pre['sha256']
for path,digest in {**record['existing_sources_preserved'],**record['new_hashes'],**record['existing_wrapper_hashes']}.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,(path,'Frozen source changed')
lm='/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261/licensingclient/linx64/lmutil'
seats={feature:run([lm,'lmstat','-c','1055@132.68.48.51','-f',feature]) for feature in ['lum_fdtd_solve','lum_fdtd_gui']}
for feature,reserve in [('lum_fdtd_solve',21),('lum_fdtd_gui',3)]:
 x=seats[feature];assert x['rc']==0,x;match=re.search(r'Total of ([0-9]+) licenses? issued; *Total of ([0-9]+) licenses? in use',x['out']);assert match and int(match[2])+reserve<=int(match[1]),x
space=run(['df','-B1','-P',str(b/'results')]);inodes=run(['df','-iP',str(b/'results')]);assert space['rc']==inodes['rc']==0 and int(space['out'].splitlines()[-1].split()[3])>10*1024**3
quota={k:run(['/usr/bin/lfs','quota',flag,value,str((b/'results').resolve())]) for k,flag,value in [('user','-u',str(os.getuid())),('group','-g',str((b/'results').stat().st_gid)),('project','-p','9000001')]};assert all(x['rc']==0 for x in quota.values()),quota
for x in quota.values():
 row=x['out'].splitlines()[-1].split();used,soft,hard=map(int,row[1:4]);limits=[v-used for v in [soft,hard] if v>0];assert not limits or min(limits)>10*1024**2,'Quota headroom below10GiB reserve'
nodes=run(['sinfo','-N','-p','part-preempt','-o','%N %G %m %C']);qos=run(['scontrol','show','assoc_mgr','flags=qos']);assert nodes['rc']==qos['rc']==0 and 'A100' in nodes['out']
assert not Path(__OUTPUT__).exists() and not Path(__MARKER__).exists() and not Path(__TASKS__).exists(),'Existing release/output must be reconciled'
with Path(__MARKER__).open('xb') as f:f.write(base64.b64decode(__RAW__))
assert hashlib.sha256(Path(__MARKER__).read_bytes()).hexdigest()==__MARKERSHA__
with Path(__TASKS__).open('x') as f:f.write('0\n1\n')
api=Path(env['LUMAPI_PATH']);lum=api.parents[2]
validation=run(['env','LD_LIBRARY_PATH='+str(lum/'lib')+':'+str(b/'scilibs')]+[k+'='+v for k,v in env.items()]+[str(lum/'python/bin/python'),'-B','-c',__INNER__]);assert validation['rc']==0,validation
args=['sbatch','--parsable','--account=acct-lumerical','--partition=part-preempt','--qos=qos-preempt','--array=0-1%2','--gres=gpu:A100:1','--cpus-per-task=8','--mem=256G','--time=02:00:00','--mail-type=NONE','--chdir='+str(b/'jobs'),'--export=ALL,'+','.join(k+'='+v for k,v in env.items()),str(b/'jobs/run_python_array.sh')]
test=run(args[:1]+['--test-only']+args[1:]);assert test['rc']==0,test
submission=run(args)
print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),scope='EXACT_TWO_FIXED150PS_LENGTH_DIAGNOSTICS_NO_OPTIMIZER',queue=q,native_job=job,archived_native_completion=historical,native_report_sha256=__REPORTSHA__,seats=seats,df=space,inodes=inodes,quotas=quota,nodes=nodes,qos=qos,validation=validation,marker=__MARKER__,marker_sha256=__MARKERSHA__,source_sha256=__RUNNERSHA__,args=args,test_only=test,submission=submission,environment=env,planned_solver_seats=14,additional_headroom_seats=7)))
'''
# Keep newlines in the remote source's task-list string escaped.
code=code.replace("f.write('0\n1\n')","f.write('0\\n1\\n')")
for key,v in dict(BASE=p.BASE,ENV=env,RECORD=record,HISTORICAL=historical_complete,REPORTSHA=report_sha,OUTPUT=p.OUTPUT,MARKER=marker,TASKS=tasks,RAW=base64.b64encode(raw).decode(),MARKERSHA=marker_sha,INNER=inner,RUNNERSHA=p.RUNNER_SHA).items():code=code.replace('__'+key+'__',repr(v))
compile(code,'release_exact_two_length_forwards','exec')
result=ops.remote('132.68.58.101',code);ops.save('s2_length_two_forwards_dispatch_1812.json',result);assert result['rc']==0,result
row=json.loads(result['out']);print(json.dumps({k:row[k] for k in ['at','scope','submission','test_only','marker','marker_sha256','planned_solver_seats']},indent=2));assert row['submission']['rc']==0,row['submission']
with (ops.E/'s2_length_two_forwards_review_original.json').open('xb') as f:f.write(raw)
ops.save('s2_length_two_forwards_environment_1812.json',env)
