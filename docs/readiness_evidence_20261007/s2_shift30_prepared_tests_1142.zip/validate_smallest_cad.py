"""Authorized hidden local CAD task2 shift30+0.0625nm; zero FDTD solves."""
import dataclasses
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import traceback
sys.dont_write_bytecode=True
REPO=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
sys.path.insert(0,str(REPO))
import numpy as np
import s2_shift30_convergence as runner
import no_solve_guard as guard
import config
ROOT=Path(tempfile.mkdtemp(prefix='actual_cad_smallest_',dir=Path(__file__).parent))
config.BASE_SAVE_DIR=str(ROOT/'generated')
config.LUMAPI_PATH='C:/Program Files/Lumerical/v261/api/python/lumapi.py'
config.USE_GPU=False
lmpt=runner.eng.import_lumopt2()
import lumapi
sessions=[]
original_class=lumapi.FDTD
restore=guard.install_constructor_guard(lumapi.FDTD,ROOT,sessions)
assert lumapi.FDTD is original_class
report=dict(task=2,mode='HIDDEN_LOCAL_CAD_NO_FDTD_SOLVE',
    runner_sha256=guard.sha256(runner.__file__),harness_sha256=guard.sha256(__file__),
    started=time.time(),sources=runner.dependency_hashes())
try:
    p,h,sign=runner.task_params(2);index=runner.INDEX;label='shift_30'
    base=runner.val.te_point(runner.SPEC)
    assert np.flatnonzero(p-base).tolist()==[149] and index==149 and h==.0625 and sign==1 and label=='shift_30'
    project,wl=runner.eng.make_project(runner.SPEC,str(ROOT/'generated'),lmpt)
    project.set_fwd(p) # CAD preparation/saves only; no run_forward call
    session=project.fdtd_session;f=session.fdtd
    mesh={a:np.asarray(f.getresult('FDTD',a)).copy() for a in ('x','y','z')}
    f.setnamed('optimization_dft','enabled',0)
    differences={a:guard.compare(grid,np.asarray(f.getresult('FDTD',a))) for a,grid in mesh.items()}
    assert all(v['equal'] for v in differences.values())
    expected=runner.eng.make_func(runner.SPEC)(p)
    props={}
    for key,value in expected.items():
        obj,prop=key.rsplit('::',1)
        actual=float(np.asarray(f.getnamed(obj,prop)).squeeze())
        difference=actual-float(value)
        assert abs(difference)<1e-18
        props[key]=dict(expected=float(value),actual=actual,difference_m=difference)
    report.update(passed=True,params_nm=p.tolist(),index=index,delta_nm=h*sign,class_label=label,
        mesh_after_field_disable=differences,mesh_points={a:len(v.ravel()) for a,v in mesh.items()},
        generated_geometry_property_count=len(props),max_abs_property_difference_m=max(abs(v['difference_m']) for v in props.values()),
        geometry_properties=props,optimization_dft_enabled=guard.attempt(lambda:f.getnamed('optimization_dft','enabled')),
        refinement={key:guard.attempt(lambda key=key:f.getnamed('FDTD',key)) for key in ('mesh refinement','meshing refinement')},
        FDTD_version=guard.attempt(f.version),hidden_constructor_class_preserved=lumapi.FDTD is original_class)
except Exception as exc:
    report.update(passed=False,error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc())
finally:
    report['CAD_call_audits']=[s.audit for s in sessions]
    for s in sessions:guard.attempt(s.close)
    restore()
    report['elapsed_seconds']=time.time()-report['started']
    output=ROOT/'validation.json'
    with output.open('x',encoding='utf-8') as stream:json.dump(guard.plain(report),stream,indent=2,allow_nan=False)
    print(output,flush=True);print('PASS' if report['passed'] else 'FAIL',report.get('error',''),flush=True)
sys.exit(0 if report['passed'] else 2)
