# Planning long FDTD validation stages

Use before an expensive solve group, after a decision-changing result, or when
choosing work across Athena and IGUM. This supports the user's requested
autonomy; it does not widen authorization or remove scientific review gates.

Record a compact plan in the project's current dated planning document:

1. **Decision:** what uncertainty matters, which competing explanations this
   experiment separates, and what each plausible outcome would change.
2. **Existing evidence:** exact reusable result/field identities and completed
   checks. Read data or run CPU post-processing before requesting new FDTD
   when those operations can answer the question. State unavailable artifacts.
3. **Dependency graph:** independent tasks that can run together, steps needing
   measured review, the critical path and the next prepared action for each
   outcome. Do not automatically release a physics-dependent stage after an
   exit code alone. Avoid an unfocused parameter sweep.
4. **Runtime:** use recent same-device, same-grid, same-GPU measurements. Split
   CAD/setup, engine execution, extraction/hash checks and queue delay. Fixed
   simulated duration may give a first-order engine scaling estimate; reserve
   overhead and report uncertainty. Auto-stop jobs cannot be predicted from
   their maximum time cap alone. QOS walltime is a limit, not an ETA.
5. **Total cost and parallelism:** count forward files, auxiliary/twin forwards,
   adjoints and CPU-only tasks separately. Estimate both elapsed critical-path
   time and total GPU-hours. Budget shared licenses including queued work, GPU
   type, host memory, storage, QOS and parity across clusters. More simultaneous
   jobs are useful only when independent and likely to finish sooner.
6. **Before completion:** have the result reader, artifact checks, plotting and
   applicable offline/CAD tests ready. Use focused Sol/Claude review only for
   unresolved questions; do not duplicate previous audits while waiting.
7. **After completion:** compare measured time with the estimate and update
   the plan. Record the physics verdict separately from execution success.
   Prepare the next bounded group only when its prerequisites are met.

Use existing acceptance criteria where applicable. For cancellation-dominated
small derivatives, retain absolute as well as relative differences and report
the unresolved numerical resolution; do not invent a noise floor or loosen
a failed gate to meet a schedule. Two durations or two parameter steps alone
do not establish an asymptotic error law.

A minimal table is enough: decision | inputs reused | new tasks | prerequisites
| runtime range and basis | resource budget | result-dependent next action.
Keep job IDs and evolving estimates in the dated project record. Preserve
active source fingerprints and all attempts; do not delete or cancel to make
a planning estimate come true.
