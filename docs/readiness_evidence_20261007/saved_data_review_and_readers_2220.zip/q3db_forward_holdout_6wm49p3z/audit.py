"""Saved-data forward validation. No production CSV reads/writes or solves."""
import sys,json,hashlib
from pathlib import Path
import numpy as np
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
sys.path.insert(0,str(ROOT/'python_tools'))
import calibrate_q3db as c
import predict_q3db as p

def fitted(rows,nearest=False):
    qc=c.fit_qc_exp(rows[-2:] if nearest else rows);qi=c.fit_qi_sat(rows)
    f=dict(qc_lnQ0=qc['lnQc0'],qc_rate=qc['rate'],qi_lnA=qi['lnA'],qi_p=qi['p'],qi_sat=qi.get('sat') or np.nan,n_lo=rows[0]['N'],n_hi=rows[-1]['N'],lam_nm=rows[-1]['lam'])
    if len(rows)>=4:
        w=c.fit_width(rows);f.update(w_Finf=w['Finf'],w_B=w['B'],w_c=w['c'])
    return f

def audit(name,rows,cut):
    train=[r for r in rows if r['N']<=cut];hold=[r for r in rows if r['N']>cut]
    assert len(train)>=3 and hold and set(r['file'] for r in train).isdisjoint(r['file'] for r in hold)
    anchor=train[-1];ar=dict(N=anchor['N'],T=anchor['T'],Q_L=anchor['QL'],lam_nm=anchor['lam'],width_um=anchor['fwhm_um'])
    out=[]
    for nearest in [False,True]:
        base=fitted(train,nearest);f,_,_=p.anchor_on_row(base,ar)
        assert abs(p.observables(f,ar['N'])['T']-ar['T'])<1e-12
        for r in hold:
            v=p.observables(f,r['N']);out.append(dict(family=name,training_N=[x['N'] for x in train],training_files=[x['file'] for x in train],held_out_file=r['file'],anchor_N=ar['N'],held_out_N=r['N'],qc_shape='nearest_two' if nearest else 'all_training',delta_T=v['T']-r['T'],relative_QL_error=v['Q_L']/r['QL']-1,relative_width_error=v['width_um']/r['fwhm_um']-1,predicted_T=v['T'],measured_T=r['T'],anchor_condition=f['anchor_T_condition']))
    return out
rows=c.load_family('nladder_c325',lambda r:True)+c.load_family('trench',lambda r:not r['decorated'] and r['C']==325 and r['N']!=150)
rows=sorted(rows,key=lambda r:r['N']);te=c.load_family('te_q3db',lambda r:r['pol']=='TE' and r['C']==250)
report=dict(qualification='Forward holdout: base SHAPE fit only on lower-N training rows, then latest row reanchors levels. Not independent unseen-device/core or single-measurement shape validation. No production calibration CSV imported.',results=audit('TM_c325',rows,100)+audit('TM_c325',rows,120)+audit('TE_c250',te,190),TE_N100_matching_rows=[r['file'] for r in te if r['N']<=100],source_sha256={str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [ROOT/'python_tools/calibrate_q3db.py',ROOT/'python_tools/predict_q3db.py']})
out=ROOT/'docs/readiness_evidence_20261007/q3db_forward_holdouts_2224.json'
with out.open('x') as f:json.dump(report,f,indent=2,allow_nan=False)
for r in report['results']:print(r['family'],r['anchor_N'],r['held_out_N'],r['qc_shape'],'dT',round(r['delta_T'],5),'dQL%',round(100*r['relative_QL_error'],2),'dW%',round(100*r['relative_width_error'],2))
print('TE matched N<=100 rows',len(report['TE_N100_matching_rows']))
