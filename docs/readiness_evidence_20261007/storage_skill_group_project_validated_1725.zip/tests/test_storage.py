"""Independent bounded offline tests; network and unsafe operations forbidden."""
import ast,contextlib,importlib.util,io,json,subprocess,sys,tempfile,types,unittest
from pathlib import Path
from unittest.mock import patch
SOURCE=Path('C:/Users/evyat/.codex/skills/pi-shift-cluster-ops/scripts/check_storage.py')
spec=importlib.util.spec_from_file_location('storage_under_review',SOURCE);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
OUT=Path(__file__).parent
class StorageChecks(unittest.TestCase):
 def test_missing_executable_and_timeout_are_unknown_not_zero_capacity(self):
  for error in [FileNotFoundError('quota unavailable'),subprocess.TimeoutExpired(['ssh'],130)]:
   with patch.object(m.subprocess,'run',side_effect=error):
    row=m.command(['SYNTHETIC_ONLY'])
   self.assertIsNone(row['exit_code']);self.assertIn(type(error).__name__,row['error']);self.assertNotIn('free_bytes',row)
 def test_ssh_nonJSON_failure_and_options(self):
  for code,body in [(0,b'NOT_JSON'),(255,b'')]:
   fake=types.SimpleNamespace(returncode=code,stdout=body,stderr=b'SYNTHETIC_FAILURE')
   with patch.object(m.subprocess,'run',return_value=fake) as call:
    row=m.cluster_snapshot('athena');argv=call.call_args.args[0]
    self.assertEqual(argv[0],'ssh');self.assertIn('BatchMode=yes',argv);self.assertIn('StrictHostKeyChecking=yes',argv)
    self.assertEqual(call.call_args.kwargs['timeout'],130);self.assertIn(b'checks=',call.call_args.kwargs['input'])
   self.assertNotIn('snapshot',row)
   if code==0:self.assertIn('parse_error',row)
   else:self.assertEqual(row['exit_code'],255)
 def test_generated_readonly_scripts_compile_and_retain_missing_quota(self):
  calls=[]
  def fake(args,**kw):
   calls.append(args);self.assertEqual(kw['timeout'],15)
   if args[0]=='quota':raise FileNotFoundError('SYNTHETIC missing quota')
   return types.SimpleNamespace(returncode=0,stdout=b'SYNTHETIC stdout',stderr=b'')
  for cluster,(_,base) in m.HOSTS.items():
   code=m.script(base,cluster);tree=ast.parse(code);compile(tree,'<readonly-script>','exec')
   forbidden={'unlink','remove','rmdir','rmtree','rename','replace','write_text','write_bytes','mkdir','chmod','system'}
   self.assertFalse({n.func.attr for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)} & forbidden)
   output=io.StringIO()
   with patch.object(m.subprocess,'run',side_effect=fake),patch.object(m.shutil,'which',return_value=None),contextlib.redirect_stdout(output):exec(code,{})
   row=json.loads(output.getvalue());self.assertEqual(row['paths'],[base,base+'/results','/home/evyatarrubin'])
   self.assertIsNone(row['checks']['quota']['exit_code']);self.assertIn('FileNotFoundError',row['checks']['quota']['error'])
   if cluster=='igum':self.assertIn('quota unknown',row['checks']['lustre_user_quota']['error'])
  self.assertTrue(calls);self.assertTrue(all(x[0] in ['quota','df','squeue','/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261/licensingclient/linx64/lmutil'] for x in calls))
 def test_collection_retains_errors_and_no_capacity_approval(self):
  with patch.object(m.shutil,'disk_usage',side_effect=OSError('SYNTHETIC inaccessible')),patch.object(m,'cluster_snapshot',return_value={'exit_code':0,'parse_error':'NOT_JSON'}) as remote:
   report=m.collect([OUT],['igum'])
  remote.assert_called_once_with('igum');self.assertIn('error',report['local'][0]);self.assertEqual(report['clusters']['igum']['parse_error'],'NOT_JSON')
  self.assertIn('not a capacity approval',report['qualification']);self.assertIn('Missing quota is unknown',report['qualification'])
 def test_existing_output_refused_before_SSH_and_untouched(self):
  target=OUT/'SYNTHETIC_EXISTING_DO_NOT_OVERWRITE.json';target.write_bytes(b'ORIGINAL_SENTINEL')
  with patch.object(sys,'argv',['check_storage.py','--output',str(target)]),patch.object(m.subprocess,'run',side_effect=AssertionError('NETWORK forbidden')),contextlib.redirect_stderr(io.StringIO()):
   with self.assertRaises(SystemExit) as ex:m.main()
  self.assertEqual(ex.exception.code,2);self.assertEqual(target.read_bytes(),b'ORIGINAL_SENTINEL')
 def test_local_only_collection_never_calls_SSH(self):
  with patch.object(m.subprocess,'run',side_effect=AssertionError('NETWORK forbidden')),patch.object(m,'cluster_snapshot',side_effect=AssertionError('SSH forbidden')):
   report=m.collect([OUT],[])
  self.assertEqual(report['clusters'],{});self.assertGreater(report['local'][0]['total_bytes'],0)
  self.assertEqual(report['local'][0]['qualification'],'Filesystem free space; not user quota')
if __name__=='__main__':unittest.main(verbosity=2)
