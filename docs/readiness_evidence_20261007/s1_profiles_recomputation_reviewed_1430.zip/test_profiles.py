import json,sys,tempfile,unittest
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
import recompute_profiles as r

class Checks(unittest.TestCase):
    def setUp(self):self.root=Path(tempfile.mkdtemp(prefix='negative_SYNTHETIC_',dir=Path(__file__).parent))
    def test_analytic_envelope_and_MAC(self):
        evidence=r.synthetic_checks(self.root/'valid_case');self.assertAlmostEqual(evidence['scaled_intensity_MAC'],1.,places=12)
        self.assertAlmostEqual(evidence['shifted_gaussian_MAC'],np.exp(-9/32),places=12)
        self.assertLess(abs(evidence['delta_um']),.003)
    def test_unique_latest_eval_lambda_not_filename_only(self):
        rows=[dict(eval=3,lam_pk_nm=1560.96,t=10.),dict(eval=3,lam_pk_nm=1561.04,t=20.)]
        line,row,evidence=r.match_row(rows,3,1561.04,21_000_000_000)
        self.assertEqual(line,2);self.assertEqual(evidence['profile_mtime_minus_row_time_s'],1.)
        with self.assertRaisesRegex(RuntimeError,'unique'):r.match_row(rows+rows[1:],3,1561.04,21_000_000_000)
        with self.assertRaisesRegex(RuntimeError,'unique'):r.match_row(rows,3,1550.,21_000_000_000)
    def test_nonfinite_negative_nonmonotonic_and_complex_profile_refusal(self):
        for n,(x,I) in enumerate([(np.array([0.,2.,1.,3.]),np.ones(4)),(np.arange(4.),np.array([1.,np.nan,1.,1.])),
            (np.arange(4.),np.array([1.,-1.,1.,1.])),(np.arange(4.),np.ones(4,dtype=complex))]):
            p=self.root/f'bad{n}.npz'
            with p.open('xb') as f:np.savez(f,x_um=x,I=I,lam_pk_nm=1561.)
            with self.assertRaises(RuntimeError):r.profile(p)
    def test_pin_mutation_fails_before_any_metric_output(self):
        p=self.root/'pin.json';p.write_text('{"files":[]}')
        with self.assertRaisesRegex(RuntimeError,'pin-file bytes changed'):r.analyze(self.root,p,'0'*64)

if __name__=='__main__':unittest.main(verbosity=2)
