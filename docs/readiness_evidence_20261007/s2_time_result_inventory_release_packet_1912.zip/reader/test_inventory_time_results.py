"""Small alternate API controls; fake metadata only, no CAD/network."""
import ast,re,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import inventory_time_results as a

class Raw:
 def __init__(self):self.vars={};self.calls=[]
 def getdata(self,name):return 'x y z surface_normal dimension t'
 def getnamednumber(self,name):return 1
 def havedata(self,name):return 1
 def getnamed(self,mon,key):
  if key.startswith('output '):return int(key=='output Ey')
  raise RuntimeError('synthetic unsupported property')
 def getresult(self,*args):self.calls.append(('getresult',args));return 'E H' if len(args)==1 else 1
 def haveresult(self,mon,result):return int(result=='E')
 def eval(self,script):
  self.calls.append(('eval',script))
  if 'tt_shape' in script:self.vars['tt_shape']=[10,1] if "'t'" in script else [1,1]
  elif 'tt_value' in script:self.vars['tt_value']=np.arange(10.)[:,None]*1e-15 if "'t'" in script else np.array([[0.]])
  elif 'rr_attributes' in script:self.vars['rr_attributes']='E'
  elif 'rr_parameters' in script:self.vars['rr_parameters']='t'
  elif 'rr_shape' in script:self.vars['rr_shape']=[1,1,1,10,3] if '.E)' in script else [10,1] if '.t)' in script else [1,1] if any('.'+k+')' in script for k in 'xyz') else [1,1,1,10]
 def getv(self,name):self.calls.append(('getv',name));return self.vars[name]
 def close(self):pass

class Tests(unittest.TestCase):
 def cad(self):return a.ResultCAD(Raw(),Path(__file__).parent/'SYNTHETIC.fsp')
 def test_alternate_E_exists_despite_raw_names_no_fields(self):
  cad=self.cad();row=a.alternate_inventory(cad,'time_cavity',1024)
  self.assertEqual(row['raw_inventory']['component_shapes'],{});self.assertEqual(row['datasets']['E']['member_shapes']['Ey']['value'],[1,1,1,10]);self.assertEqual(row['output_component_flags']['output Ey']['value'],1)
  self.assertEqual(row['datasets']['H']['haveresult']['value'],0);self.assertNotIn('member_shapes',row['datasets']['H'])
  self.assertTrue(all(n in ['tt_shape','tt_value','rr_shape','rr_attributes','rr_parameters'] for typ,n in cad.raw.calls if typ=='getv'))
 def test_no_solve_save_or_full_dataset_transfer(self):
  cad=self.cad()
  for name in ['run','runjobs','runanalysis','save','setnamed']:
   with self.assertRaises(RuntimeError):getattr(cad,name)()
  for obj,result in [('time_cavity','E'),('time_cavity','H')]:
   with self.assertRaises(RuntimeError):cad.getresult(obj,result)
  with self.assertRaises(RuntimeError):cad.getv('rr_dataset')
  with self.assertRaises(RuntimeError):cad.value('time_cavity','Ey')
  for script in ['run;','rr_dataset=getresult(\'time_cavity\',\'E\');run;','rr_dataset=getresult(\'other\',\'E\');rr_shape=size(rr_dataset.E);']:
   with self.assertRaises(RuntimeError):cad.read_script(script,'rr_shape')
 def test_missing_or_unsupported_result_metadata_honest(self):
  cad=self.cad()
  with patch.object(cad.raw,'haveresult',side_effect=RuntimeError('synthetic unavailable')):
   row=a.alternate_inventory(cad,'time_output',1024);self.assertFalse(row['datasets']['E']['haveresult']['available']);self.assertNotIn('member_shapes',row['datasets']['E'])
  with patch.object(cad.raw,'eval',side_effect=RuntimeError('member unsupported')):
   value=a.capture(lambda:cad.result_shape('time_output','E','Ey'));self.assertFalse(value['available']);self.assertIn('member unsupported',value['error'])
 def test_wrong_pins_shapes_time_alignment_and_source_syntax(self):
  ast.parse(Path(a.__file__).read_text());self.assertEqual(a.sha(a.base.__file__),a.BASE_SHA);self.assertEqual(a.sha(a.base.io.__file__),a.base.IO_SHA)
  with self.assertRaises(RuntimeError):a.base.load_center(Path(a.__file__),200)
  cad=self.cad()
  with patch.object(cad,'result_shape',return_value=[11,1]):
   with self.assertRaises(RuntimeError):a.alternate_inventory(cad,'time_input',1024)
  with patch.object(cad.raw,'getv',return_value=[np.nan]):
   with self.assertRaises(RuntimeError):cad.result_shape('time_cavity','E','Ey')

if __name__=='__main__':unittest.main(verbosity=2)
