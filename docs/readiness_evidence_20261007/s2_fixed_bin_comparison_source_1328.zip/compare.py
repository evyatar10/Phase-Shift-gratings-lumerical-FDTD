import json,pathlib,numpy as np,hashlib
repo=pathlib.Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');p=repo/'docs/readiness_evidence_20261007'
def read(n):
 b=(p/n).read_bytes();return json.loads(b),hashlib.sha256(b).hexdigest()
re,rsha=read('s2_fixed_bin_v3_re_original.json');im,isha=read('s2_fixed_bin_v3_im_original.json');s,ssha=read('s2_shift30_spectra_1219.json')
assert rsha=='b6a4a79816fe9a6d0de2115cc9eb03bb13a475489a32c101841f43b0ce8bc0e7' and isha=='1470c5695e08b7d939d2c4fbfa63bbbe0d6a0cdd2ea7cd36a48544ff397a9d7c'
for z in (re,im):
 assert z['execution_status']=='RAW_OPERATOR_DIAGNOSTIC_COMPLETE_NO_PHYSICAL_PASS' and z['original_file_identity_unchanged'] and z['production_dependencies_unchanged'] and z['no_fdtd_solve']
 assert z['old_peak3_control']['relative_difference']<1e-12
 assert [v['bin'] for v in z['onehot_raw']]==[244,252,260]
 for row in z['auxiliary_snapshot_history'][1:]:
  assert row['arithmetic_reuse_check']['accepted']
 assert z['dependencies_before']==z['dependencies_after']
assert re['params_nm']==im['params_nm'] and re['vendor_sources']==im['vendor_sources']
A=np.array([[r['raw_contraction'],i['raw_contraction']] for r,i in zip(re['onehot_raw'],im['onehot_raw'])]);assert np.isfinite(A).all() and np.linalg.matrix_rank(A)==2
out=dict(status='DIAGNOSTIC_FITS_ONLY_GLOBAL_CALIBRATION_FAILED',source_sha256=dict(re=rsha,im=isha,spectra=ssha),raw_matrix=A.tolist(),condition=float(np.linalg.cond(A)),bins=[244,252,260],observables={},limitations=['One parameter and three spectral bins, two fitted coefficients. No independent parameter validation.','Current FD is from geometry-dependent auto-stop durations; temporal convergence unresolved.','Coefficients are diagnostic least squares only, not an installed calibration.','Peakheight derivatives cannot be certified by flank agreement.','Tout and modal S21 squared are distinct; both reported without conversion.'])
for metric,o in s['observables'].items():
 vals={}
 for h in ['0.125','0.0625']:
  y=np.array(o['full_grid_steps'][h]['central_derivative'])[[244,252,260]];c=np.linalg.lstsq(A,y,rcond=None)[0];flank=np.linalg.solve(A[[0,2]],y[[0,2]])
  assert np.allclose(A.T@(A@c-y),0,atol=1e-14)
  loo=[]
  for leave in range(3):
   keep=[j for j in range(3) if j!=leave];cl=np.linalg.solve(A[keep],y[keep]);loo.append(dict(bin=int(out['bins'][leave]),heldout_pred=float(A[leave]@cl),heldout_fd=float(y[leave]),absolute_error=float(A[leave]@cl-y[leave]),coefficients=cl.tolist()))
  vals[h]=dict(fd=y.tolist(),ls_coefficients=c.tolist(),ls_pred=(A@c).tolist(),ls_residual=(A@c-y).tolist(),relative_l2_residual=float(np.linalg.norm(A@c-y)/np.linalg.norm(y)),flank_coefficients=flank.tolist(),heldout_center_error=float((A@flank-y)[1]),leave_one_bin_out=loo)
 out['observables'][metric]=vals
out['im_control']=im['old_peak3_control'];out['im_aux_reuse']=[dict(stage=v['stage'],check=v['arithmetic_reuse_check']) for v in im['auxiliary_snapshot_history'][1:]]
with (p/'s2_fixed_bin_comparison_1328.json').open('x') as f:json.dump(out,f,indent=2)
print(json.dumps(out,indent=2))
