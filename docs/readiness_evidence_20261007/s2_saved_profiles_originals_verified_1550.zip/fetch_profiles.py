"""Read-only capture of exact CPU171300 result and its original small artifacts."""
import base64,hashlib,importlib.util,json,sys,datetime
from pathlib import Path
sys.argv=['readonly','none'];s=importlib.util.spec_from_file_location('ops','C:/Users/evyat/AppData/Local/Temp/s2_step150_ops_1503.py');ops=importlib.util.module_from_spec(s);s.loader.exec_module(ops)
code=ops.COMMON+'''
import base64
b=Path('/home/evyatarrubin/bragg_sim_athena');root=b/'results/s2_saved_spatial_profiles_20261007_1542'
accounting=run(['sacct','-j','171300','--format=JobID,State,ExitCode,Elapsed,MaxRSS','-nP'])
files={}
for p in [root/'report.json',root/'profiles_100ps.npz',root/'profiles_150ps.npz',b/'jobs/logs/lum_array-171300_0.out']:
 if p.exists():
  assert p.stat().st_size<15000000
  data=p.read_bytes();files[p.name]=dict(path=str(p),sha256=hashlib.sha256(data).hexdigest(),data_b64=base64.b64encode(data).decode())
source=b/'scripts/s2_saved_profiles_20261007_1542/extract_saved_spatial_profiles.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='994c3e9757a10b5bd8ea211aaee8425c5d3540203a4da04b0439684163baf6ca'
print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),accounting=accounting,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),files=files)))
'''
result=ops.remote('athena.technion.ac.il',code);stamp=datetime.datetime.now().strftime('%H%M%S');out=ops.E/('s2_saved_profiles_fetch_'+stamp);out.mkdir()
with (out/'transport.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
assert result['rc']==0,result
payload=json.loads(result['out']);print(payload['accounting'])
for name,row in payload['files'].items():
 assert Path(name).name==name
 data=base64.b64decode(row['data_b64'],validate=True);assert hashlib.sha256(data).hexdigest()==row['sha256']
 with (out/name).open('xb') as f:f.write(data)
manifest={name:{k:v for k,v in row.items() if k!='data_b64'} for name,row in payload['files'].items()}
with (out/'pins.json').open('x',encoding='utf-8') as f:json.dump(manifest,f,indent=2)
print(out)
if (out/'report.json').exists():
 report=json.loads((out/'report.json').read_text());print(report['status'],report.get('error',''));print('all_inputs_preserved',report.get('all_inputs_preserved'))
 for duration,stage in report.get('stages',{}).items():
  print(duration,{k:dict(width=v['production_FWHM_um'],sigma=v['sigma_um'],lambda_nm=v['monitor_sampled_lambda_nm']) for k,v in stage.get('profiles',{}).items()})
