import copy,sys,unittest
from pathlib import Path
import numpy as np
import analyze_temporal as a
REPO=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');sys.path.insert(0,str(REPO))
from runners.lumopt2_design.s2_temporal_forward import persisted_check
class PhaseChecks(unittest.TestCase):
 def snapshot(self,phase=18.625271537954248):
  return dict(geometry={'tooth::x':1e-6},ports={'FDTD::ports::Port_1':{'phase':phase,'direction':'Forward'},'FDTD::ports::Port_2':{'phase':0.}},source={'offset':1e-14},timing={'dt':1e-17},mesh={'x':[1,2]},refinement={'mesh refinement':'precise volume average'},monitor={'points':501})
 def check(self,left,right):return a.cross_duration_controls(left,right,persisted_check)
 def test_0_1_2_ULP_accepted_and_raw_untouched(self):
  for n in [0,1,2]:
   left=self.snapshot();right=copy.deepcopy(left);value=left['ports']['FDTD::ports::Port_1']['phase']
   for _ in range(n):value=float(np.nextafter(value,np.inf))
   right['ports']['FDTD::ports::Port_1']['phase']=value;before=copy.deepcopy(right)
   self.assertEqual(self.check(left,right)['ULP_distance'],n);self.assertEqual(right,before)
 def test_more_than_2_ULP_rejected(self):
  left=self.snapshot();right=copy.deepcopy(left);value=left['ports']['FDTD::ports::Port_1']['phase']
  for _ in range(3):value=float(np.nextafter(value,np.inf))
  right['ports']['FDTD::ports::Port_1']['phase']=value
  with self.assertRaises((ValueError,RuntimeError)):self.check(left,right)
 def test_material_phase_rejected(self):
  left=self.snapshot();right=self.snapshot(18.625271538)
  with self.assertRaises((ValueError,RuntimeError)):self.check(left,right)
 def test_other_port_property_rejected(self):
  for obj,key,new in [('FDTD::ports::Port_1','direction','Backward'),('FDTD::ports::Port_2','phase',1e-30)]:
   left=self.snapshot();right=copy.deepcopy(left);right['ports'][obj][key]=new
   with self.assertRaises((ValueError,RuntimeError)):self.check(left,right)
 def test_source_timing_mesh_monitor_changes_rejected(self):
  for section,key,new in [('source','offset',2e-14),('timing','dt',2e-17),('mesh','x',[1,3]),('monitor','points',500)]:
   left=self.snapshot();right=copy.deepcopy(left);right[section][key]=new
   with self.assertRaises((ValueError,RuntimeError)):self.check(left,right)
 def test_zero_nonfinite_shape_failclosed(self):
  self.assertEqual(self.check(self.snapshot(0.),self.snapshot(0.))['ULP_distance'],0)
  for x,y in [(0.,np.nextafter(0.,np.inf)),(0.,-0.),(np.nan,1.),(1.,np.inf),(1.,[1.])]:
   with self.assertRaises((ValueError,RuntimeError)):self.check(self.snapshot(x),self.snapshot(y))
 def test_existing_geometry_check_unchanged(self):
  left=self.snapshot();right=copy.deepcopy(left);right['geometry']['tooth::x']+=5e-21
  expected=persisted_check(left,right)
  self.assertEqual(self.check(left,right)['existing_persisted_geometry_comparison'],expected)
  right['geometry']['tooth::x']+=1e-15
  with self.assertRaises((ValueError,RuntimeError)):self.check(left,right)
if __name__=='__main__':unittest.main()
