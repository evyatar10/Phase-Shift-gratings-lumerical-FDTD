"""Read-only saved100/150ps center profile extraction; no solve/save APIs."""
import argparse,contextlib,hashlib,importlib,json,os,re,sys
from pathlib import Path
import numpy as np
sys.dont_write_bytecode=True
PINS={100:'38dcd852f7bcb5e2ef7bb27cb4085257a5b70098d146e41d73b8038180d72f49',150:'a0ff55eacaa52e00a2aab17dcc43d0e5fff9a72566e15da371ff25279c172663'}
ENGINE_SHA='53108bbd368dd699179ab65029628aa4c4b2d8ad687777f88b82f404a0952569'
def need(x,msg):
 if not x:raise RuntimeError(msg)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as stream:
  for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def plain(v):
 if isinstance(v,np.ndarray):return v.tolist()
 if isinstance(v,np.generic):return v.item()
 if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [plain(x) for x in v]
 return v
def identity(p):
 p=Path(p).resolve();s=p.stat();return dict(path=str(p),bytes=s.st_size,mtime_ns=s.st_mtime_ns,sha256=sha(p))
def load_checkpoint(path,duration):
 need(sha(path)==PINS[duration],'Exact raw center checkpoint SHA mismatch');row=json.loads(Path(path).read_text());i,r=row['identity'],row['result'];task=0 if duration==100 else 3
 need(i['task']==task and i['sign']==0 and i['delta_nm']==0 and i['duration_ps']==duration and r['task']==task and r['sign']==0 and r['delta_nm']==0 and r['duration_ps']==duration,'Center task/duration identity mismatch')
 need(i['point']==r['params'] and len(i['point'])==296 and i['spec']['n_periods_side']==98 and i['spec']['n_free']==60 and i['spec']['bare'] and i['spec']['polarization']=='TE','Center full point/TE98free60 family mismatch')
 need(i['code']['lumopt2_design.py']==ENGINE_SHA and r['controls']['after']['optimization_dft_enabled']==0 and r['controls']['after']['timing']['use early shutoff']==0 and r['controls']['after']['timing']['use divergence checking']==1,'Frozen engine/temporal controls mismatch')
 for key,digest in [('source','fsp_sha256'),('h5','h5_sha256'),('ports_npz','ports_sha256')]:need(sha(r[key])==r[digest],'Saved immutable '+key+' SHA mismatch')
 need(Path(r['h5']).resolve()==Path(r['source']).resolve().with_suffix('')/'fwd_default_output.h5','Unexpected FSP/H5 companion binding')
 return row

def h5_schema(path):
 """Inspect structure only;never infer units/component/axis/symmetry from a path."""
 import h5py
 datasets=[];candidates=[]
 with h5py.File(path,'r') as h:
  def visitor(name,obj):
   if isinstance(obj,h5py.Dataset):
    datasets.append(dict(path=name,shape=list(obj.shape),dtype=str(obj.dtype),bytes_estimate=int(obj.size*obj.dtype.itemsize)))
    if 'field_profile' in name.lower():candidates.append(name)
  h.visititems(visitor)
 return dict(dataset_count=len(datasets),datasets=datasets,field_profile_named_candidates=candidates,direct_extraction_status='UNVALIDATED_INTERNAL_SCHEMA_USE_SUPPORTED_CAD_RESULT_API',qualification='Metadata only; no field dataset payload loaded. Named datasets alone do not certify component/order/coordinate/symmetry contracts.')

def optional_h5_inventory(path,schema_only=False):
 """Missing optional h5py must not block the supported official CAD reader."""
 try:return h5_schema(path)
 except ImportError as exc:
  error=type(exc).__name__+': '+str(exc)
  if schema_only:raise RuntimeError('Schema-only inventory unavailable; '+error) from exc
  return dict(status='UNAVAILABLE',error=error,direct_extraction_status='UNAVAILABLE_OPTIONAL_H5PY_IMPORT_USE_SUPPORTED_CAD_API',qualification='No HDF5 metadata or payload inventory was produced; official CAD result extraction remains available. No dependency installation or container modification.')

class ReadOnlyCAD:
 """Accidental-call guard:read-only properties and reviewed temporary CAD scripts."""
 ALLOWED={'version','getnamed','close'}
 def __init__(self,raw,source):self.raw=raw;self.source=Path(source).resolve();self.audit=[]
 def __getattr__(self,name):
  if name in self.ALLOWED:return getattr(self.raw,name)
  raise RuntimeError('Read-only CAD method refused: '+name)
 def load(self,path):
  need(Path(path).resolve()==self.source,'Unregistered saved FSP');self.audit.append({'load':str(self.source)});return self.raw.load(str(self.source))
 def getresult(self,obj,result):
  need((obj,result) in [('FDTD','status')],'Only scalar FDTD status may transfer via getresult');return self.raw.getresult(obj,result)
 def getv(self,name):
  need(name in {'sp_x','sp_y','sp_z','sp_lam','sp_shape','sp_slice'},'Unreviewed/full dataset transfer refused');return self.raw.getv(name)
 def eval(self,script):
  calls=re.findall(r'\b([A-Za-z_]\w*)\s*\(',script)
  need(all(c in {'getresult','size','pinch','clear'} for c in calls),'Read-only CAD script calls refused')
  stripped=re.sub(r"'[^']*'|\"[^\"]*\"",'',script)
  need(not re.search(r'\b(?:run\w*|save\w*|set\w*|add\w*|delete\w*|system|feval|load|export)\b',stripped,re.I),'Mutating/solve script refused')
  need(all(v.startswith('sp_') for v in re.findall(r'\b([A-Za-z_]\w*)\s*=',stripped)),'Only temporary sp_ assignments allowed')
  if 'getresult' in calls:need("getresult('field_profile','E')" in script,'Unreviewed result object')
  self.audit.append({'reviewed_temporary_script':script});return self.raw.eval(script)

def transfer_selected(cad,trace=None):
 cad.eval("sp_raw=getresult('field_profile','E');sp_x=sp_raw.x;sp_y=sp_raw.y;sp_z=sp_raw.z;sp_lam=sp_raw.lambda;sp_shape=size(sp_raw.E);")
 coords={k:np.asarray(cad.getv(v)).ravel() for k,v in [('x','sp_x'),('y','sp_y'),('z','sp_z'),('lambda','sp_lam')]};shape=tuple(int(v) for v in np.asarray(cad.getv('sp_shape')).ravel())
 if trace is not None:trace['raw_profile_coordinate_inventory']=dict(x_m=coords['x'].tolist(),y_m=coords['y'].tolist(),z_m=coords['z'].tolist(),lambda_m=coords['lambda'].tolist(),E_shape=list(shape))
 need(len(shape) in [4,5] and shape[-1]==3 and all(np.isfinite(v).all() for v in coords.values()),'Unsupported raw E shape/coordinates')
 need(len(coords['x'])==shape[0] and len(coords['y'])==shape[1] and len(coords['y'])>=2 and (np.diff(coords['x'])>0).all() and (np.diff(coords['y'])>0).all(),'Nonmonotone/mismatched spatial axes')
 lam_axis=3 if len(shape)==5 else 2;need(shape[lam_axis]==len(coords['lambda']) and (len(shape)!=5 or shape[2]==1),'Unsupported non-plane/profile frequency dimensions')
 cache={}
 def selected(k):
  if k not in cache:
   cad.eval('sp_slice=pinch(sp_raw.E,'+str(lam_axis+1)+','+str(k+1)+');')
   e=np.asarray(cad.getv('sp_slice'));nx,ny=len(coords['x']),len(coords['y']);need(e.shape in [(nx,ny,3),(nx,ny,1,3)],'Selected E axis shape mismatch;no permutation/component-major/flat reshape allowed');need(np.isfinite(e).all() and np.max(abs(e))>0,'Missing/nonfinite/zero selected E')
   cache[k]=e.reshape(len(coords['x']),len(coords['y']),1,1,3)
  return cache[k]
 return coords,shape,selected

def processed_profile(eng,coords,e,target_nm,n=98,pitch=491.06):
 """Exact production functions on a selected single-wavelength raw E plane."""
 need(np.isfinite(e).all() and e.shape==(len(coords['x']),len(coords['y']),1,1,3) and len(coords['lambda'])==1,'Selected raw E/coordinate contract invalid')
 res=dict(x=coords['x'],y=coords['y'],z=coords['z'],**{'lambda':coords['lambda']},E=e)
 x,I,aux=eng._line_from_res(res,target_nm,n,pitch);need(np.isfinite(I).all() and np.max(I)>0,'Invalid integrated profile')
 env=np.asarray(eng.extract_envelope_peaks(x,I));width=eng.fwhm_env_of_line(x,I);sigma=eng.sigma_of_line(x,I)
 need(width is not None and np.isfinite([width,sigma]).all() and width>0 and sigma>0,'Production envelope width/sigma unavailable')
 power=np.sum(abs(e[:,:,0,0,:])**2,axis=-1);full_I=np.trapz(power,coords['y'],axis=1);need(np.allclose(full_I[aux['keep']],I,rtol=0,atol=0),'Production y integral mismatch')
 peak=float(np.max(env));floor=float(np.min(env));need(peak>floor and np.isfinite(env).all(),'Flat/nonfinite envelope')
 meta=dict(target_port_sampled_resonance_nm=target_nm,monitor_sampled_lambda_nm=float(coords['lambda'][int(aux['i_lam'])]*1e9),production_FWHM_um=float(width),sigma_um=float(sigma),crop_half_extent_um=n*pitch/1000.,crop_definition='abs(x_um)<=N*pitch_nm/1000 exactly as engine; not native half-cavity-inclusive end',floor=float(floor),peak=float(peak),half_level=float(floor+.5*(peak-floor)),floor_over_peak=floor/peak,end_x_um=[float(x[0]),float(x[-1])],end_I_over_peak=[float(I[0]/peak),float(I[-1]/peak)],end_envelope_over_peak=[float(env[0]/peak),float(env[-1]/peak)],sqrt_end_I_over_peak=[float(np.sqrt(I[0]/peak)),float(np.sqrt(I[-1]/peak))],monitor_end_I_over_cropped_envelope_peak=[float(full_I[0]/peak),float(full_I[-1]/peak)],component_max_abs=[float(np.max(abs(e[...,j]))) for j in range(3)],selected_E_sha256=hashlib.sha256(np.ascontiguousarray(e).tobytes()).hexdigest(),selected_E_shape=list(e.shape),qualification='Derived from selected raw E using production y integral/N-dependent crop/floor-envelope convention; not cached processed-width scalar or single modal field amplitude')
 arrays=dict(x_um=x,I_y_integrated=I,envelope_y_integrated=env,y_m=coords['y'],wy_m=aux['wy'],monitor_x_m=coords['x'],monitor_I_y_integrated=full_I)
 return meta,arrays

def extract(cad,eng,row,ports,out,duration,nearby=False,trace=None):
 r=row['result'];need(float(np.asarray(cad.getresult('FDTD','status')).squeeze())==1,'Saved center not full-time completed')
 boundary={}
 for key in ['x min bc','x max bc','y min bc','y max bc','z min bc','z max bc','pml layers','pml profile']:
  try:boundary[key]=dict(available=True,value=plain(cad.getnamed('FDTD',key)))
  except Exception as exc:boundary[key]=dict(available=False,error=type(exc).__name__+': '+str(exc))
 if trace is not None:trace['FDTD_boundary_property_inventory']=boundary

 props=['enabled','monitor type','x','y','z','x span','y span','z span','override global monitor settings','use source limits','frequency points','spatial interpolation'];monitor={}
 for key in props:
  try:monitor[key]=dict(available=True,value=plain(cad.getnamed('field_profile',key)))
  except Exception as exc:monitor[key]=dict(available=False,error=type(exc).__name__+': '+str(exc))
 if trace is not None:trace['monitor_geometry']=monitor
 need(monitor['enabled'].get('value')==1,'field_profile enabled readback missing/disabled')
 coords,shape,selected=transfer_selected(cad,trace);wl=np.asarray(ports['p2_lambda']).ravel();need(len(coords['lambda'])==501 and np.array_equal(coords['lambda'],wl),'Exact501 profile versus pinned port lambda grid mismatch')
 profiles={};output={};peak_indices=[]
 for name,values in [('Tout',abs(np.asarray(ports['p2_T_out']).ravel())),('modal',abs(np.asarray(ports['p2_S']).ravel())**2)]:
  peak,T,width=eng.measure_peak(wl*1e9,values);need(width is not None and T>eng.DEAD_T_FLOOR,'Tracked observable resonance unavailable');k=int(np.argmin(abs(coords['lambda']-peak*1e-9)));peak_indices.append(k);e=selected(k);one={**coords,'lambda':coords['lambda'][k:k+1]};meta,arrays=processed_profile(eng,one,e,float(peak));meta.update(original_monitor_frequency_index=k,target_minus_monitor_nm=float(peak-coords['lambda'][k]*1e9));profiles[name]=meta
  for key,v in arrays.items():output[name+'__'+key]=v
 nearby_profiles={}
 if nearby:
  # Peak3's3-sample support plus2 additional bins on each side:unionk-3..k+3.
  union=sorted({k+delta for k in peak_indices for delta in range(-3,4)})
  need(min(union)>=0 and max(union)<len(coords['lambda']),'Nearby profile support touches unavailable grid')
  for k in union:
   one={**coords,'lambda':coords['lambda'][k:k+1]};meta,arrays=processed_profile(eng,one,selected(k),float(coords['lambda'][k]*1e9));meta['original_monitor_frequency_index']=k;nearby_profiles[str(k)]=meta
   for key,v in arrays.items():output['nearby_bin_'+str(k)+'__'+key]=v
 output['monitor_lambda_m']=coords['lambda'];npz=out/f'profiles_{duration}ps.npz'
 with npz.open('xb') as stream:np.savez_compressed(stream,**output)
 return dict(duration_ps=duration,FDTD_boundary_property_inventory=boundary,monitor_geometry=monitor,raw_profile_E_shape=list(shape),profiles=profiles,nearby_profiles=nearby_profiles,nearby_qualification='Optional sampled W(lambda) diagnostic only;productioncrop/floor retained,no widthadjoint validation',profile_npz=str(npz),profile_npz_sha256=sha(npz),guard_audit=cad.audit)

def run(args):
 out=Path(args.output).resolve();need(not out.exists(),'Exclusive NEW output directory required');out.mkdir();report=dict(status='STARTED_READ_ONLY',no_solve=True,inputs={},stages={});snapshots=[];fdtd_class=None;ctor=None
 try:
  repo=Path(args.repo).resolve();sys.path.insert(0,str(repo));from runners.lumopt2_design import lumopt2_design as eng
  need(sha(eng.__file__)==ENGINE_SHA,'Frozen production engine SHA changed')
  for duration,key in [(100,'checkpoint100'),(150,'checkpoint150')]:
   if args.duration not in ('both',str(duration)):continue
   cp=Path(getattr(args,key)).resolve();row=load_checkpoint(cp,duration);r=row['result'];paths=[cp,Path(r['source']),Path(r['h5']),Path(r['ports_npz'])];before=[identity(p) for p in paths];snapshots.extend(before);report['inputs'][str(duration)]=before
   need(np.array_equal(np.asarray(row['identity']['point']),np.asarray(r['params'])),'Point identity changed')
   schema=optional_h5_inventory(r['h5'],args.schema_only);report['stages'][str(duration)]={'h5_schema':schema}
   if args.schema_only:continue
   for name,digest in row['identity']['code'].items():
    p=repo/name if name in ['config.py','bragg_device.py','simulation_config.py','sim_helpers.py'] else repo/'runners/lumopt2_design'/name;need(sha(p)==digest,'Frozen extraction dependency differs: '+name)
   api=Path(args.lumapi).resolve();tree=api.parent/'lumopt2';vendor={str(p.relative_to(api.parent)).replace('\\','/'):sha(p) for p in sorted(tree.rglob('*.py'))+[api]};extra=api.parent/'lumslurm.py'
   if extra.is_file():vendor['lumslurm.py']=sha(extra)
   need(vendor==row['identity']['vendor_api_sha256'],'Actual configured vendor byte identity differs from center; no silent substitution')
   sys.path.insert(0,str(api.parent));import lumapi;need(Path(lumapi.__file__).resolve()==api,'Imported lumapi differs from pinned requested path');fdtd_class=lumapi.FDTD;ctor=fdtd_class.__init__
   raw=lumapi.FDTD(hide=True);cad=ReadOnlyCAD(raw,r['source'])
   try:
    cad.load(r['source'])
    with np.load(r['ports_npz'],allow_pickle=False) as z:ports={k:z[k] for k in z.files}
    from runners.lumopt2_design import recover_te_s2 as recovery
    scores=recovery.score(ports);need(all(abs(float(scores[k])-float(r[k]))<=1e-12 for k in ['peak3_tout','peak3_modal','lam_nm']),'Pinned port scores not reproduced')
    report['stages'][str(duration)].update(extract(cad,eng,row,ports,out,duration,getattr(args,'nearby_profiles',False),report['stages'][str(duration)]))
   finally:cad.close()
  report['status']='READ_ONLY_H5_SCHEMA_INVENTORY_ONLY' if args.schema_only else 'SAVED_RAW_PROFILE_EXTRACTION_COMPLETE_NO_PHYSICS_PASS'
 except Exception as exc:report['status']='EXTRACTION_FAILED_CLOSED';report['error']=type(exc).__name__+': '+str(exc)
 finally:
  after=[]
  for before in snapshots:
   try:
    current=identity(before['path']);after.append(dict(before=before,after=current,unchanged=current==before))
   except Exception as e:after.append(dict(before=before,unchanged=False,error=str(e)))
  report['immutable_inputs_rechecked']=after;report['all_inputs_preserved']=all(x['unchanged'] for x in after)
  if not report['all_inputs_preserved']:report['status']='EXTRACTION_FAILED_CLOSED';report['error']='Original artifact changed during read-only extraction'
  if fdtd_class is not None:report['FDTD_class_unchanged']=lumapi.FDTD is fdtd_class;report['FDTD_constructor_unchanged']=lumapi.FDTD.__init__ is ctor
  with (out/'report.json').open('x',encoding='utf-8') as stream:json.dump(plain(report),stream,indent=2,allow_nan=False)
 print(report['status'],report.get('error',''));return 0 if report['status']!='EXTRACTION_FAILED_CLOSED' and report['all_inputs_preserved'] else 1
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__)
 for key in ['repo','lumapi','checkpoint100','checkpoint150','output']:p.add_argument('--'+key,required=True)
 p.add_argument('--duration',choices=['100','150','both'],default='both');p.add_argument('--schema-only',action='store_true');p.add_argument('--nearby-profiles',action='store_true');args=p.parse_args();raise SystemExit(run(args))
