import tempfile,unittest
from pathlib import Path
from no_solve_guard import NoSolveCAD
class FakeCAD:
 def __init__(self):self.calls=[]
 def eval(self,s):self.calls.append(('eval',s))
 def save(self,p):self.calls.append(('save',p))
 def run(self):self.calls.append(('run',))
 def runjobs(self):self.calls.append(('runjobs',))
class GuardChecks(unittest.TestCase):
 def test_direct_solves_never_reach_raw(self):
  f=FakeCAD();g=NoSolveCAD(f,Path(tempfile.gettempdir()))
  for n in ['run','runjobs','runparallel','runsweep','runanalysis']:
   with self.assertRaises(RuntimeError):getattr(g,n)()
  self.assertEqual(f.calls,[])
 def test_script_solves_never_reach_raw(self):
  f=FakeCAD();g=NoSolveCAD(f,Path(tempfile.gettempdir()))
  for s in ['run;','runjobs;','runparallel();']:
   with self.assertRaises(RuntimeError):g.eval(s)
  self.assertEqual(f.calls,[])
 def test_harmless_quoted_run_allowed(self):
  f=FakeCAD();g=NoSolveCAD(f,Path(tempfile.gettempdir()));g.eval('select("run");')
  self.assertEqual(f.calls,[('eval','select("run");')])
 def test_existing_save_refused(self):
  f=FakeCAD();g=NoSolveCAD(f,Path(__file__).parent)
  with self.assertRaises(RuntimeError):g.save(__file__)
  self.assertEqual(f.calls,[])
if __name__=='__main__':unittest.main()
