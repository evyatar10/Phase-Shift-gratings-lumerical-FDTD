# Saved center time-monitor readout (preparation only)

Frozen runtime: `read_saved_times.py` and `frozen_profile_io.py`. No repository, server, CAD or FDTD execution occurred during preparation. Six focused offline tests pass (exit 0; `offline_tests.log`). A real host readout remains unvalidated.

The three byte-pinned checkpoints select only the original 100/150/200 ps centers. Their exact CP-declared FSP/H5/ports paths are required; paths are never rewritten. All three artifact families, geometry identity, frozen source and complete vendor identities are checked before opening any hidden official CAD session. CP/FSP/H5/ports/source/vendor/helper identities (path, byte count, mtime, SHA) are rechecked afterward. The FDTD class and constructor remain unchanged. No calibration is loaded.

Inventory is the default. Each of `time_input`, `time_cavity`, `time_output` must resolve uniquely for useful data. Available raw names, actual t/sample intervals, recorded point coordinates, component shapes, monitor sampling properties and source/global/Port1 settings are recorded. Unsupported optional property names retain their errors. Missing recorded data produces an explicitly incomplete inventory; collection exit 0 is not a data, storage, sampling or physics pass. Invalid/nonfinite/nonmonotone time axes fail closed.

Shape queries read one component into CAD workspace at a time; component arrays do not transfer to Python in inventory mode. Time vectors do transfer for finite/monotonic validation, with the separate default **32 MiB per time record** validation cap. This inventory cost is separate from optional export payload accounting. Full point component arrays remain in CAD unless explicitly selected.

Optional export inventories all nine records first, then estimates total uncompressed payload conservatively as 8 bytes/sample for t plus 16 bytes/sample per selected component. It refuses oversized or missing data before component transfer. Fresh export sessions refresh and verify the observed names registry before reading. Actual payload bytes are also checked. The cap is a raw-array budget, not a promise of compressed-file size or RAM use. NPZ and MAT retain each selected component and its actual time vector on the executing server; metadata can be fetched first. Exclusive output paths refuse reuse.

## Invocation on Athena (parent owns release)

Place only the two frozen runtime files in a new helper directory. The execution environment needs NumPy, SciPy and the exact official lumapi/vendor tree; h5py is unnecessary. `--repo` must point to the original code tree matching every saved checkpoint source hash. Run under a CPU allocation and the existing licensed/container environment, never a login-node heavy CAD session. Example inventory command (substitute the reviewed new helper/output paths and existing official API path):

```bash
python -B /work/scripts/NEW_TIME_HELPER/read_saved_times.py \
  --repo /work/scripts \
  --lumapi /opt/lumerical/api/python/lumapi.py \
  --checkpoint100 /work/results/diagnose_te_s2_temporal/results/s2_shift30_temporal_20261007/task_00.json \
  --checkpoint150 /work/results/diagnose_te_s2_temporal/results/s2_shift30_temporal_20261007/task_03.json \
  --checkpoint200 /work/results/diagnose_te_s2_temporal200/results/s2_shift30_temporal200_20261007/task_00.json \
  --output /work/results/NEW_EXCLUSIVE_TIME_READOUT
```

The container API example must be replaced with the actual pinned path if different; the helper refuses a mismatched vendor tree. Parent may instead supply unchanged raw CP copies in a new provenance directory; their exact byte SHA must match the manifest. Do not pretty-reserialize JSON.

For the proposed bounded Ey export, append:

```bash
--component time_input:Ey --component time_cavity:Ey --component time_output:Ey \
--max-total-bytes 268435456
```

Proposed CPU resources: 8 CPU, 64 GiB, a bounded 30-minute allocation pending host preflight. This is a planning allowance, not measured runtime/RAM: loading large saved FSP/H5 and repeated streamed hash reads may dominate; optional export adds a second serial hidden session per center. There is no new solve and no GPU request. Existing outputs and original sources remain immutable.

## Limits and host gate

The fake API tests verify the adapter and actual inventory-close/new-session-export flow, not vendor syntax or stored time-record availability. Actual names, supported properties, point-series shapes, decimation and sample counts remain unknown until the CPU readout. A cap refusal preserves the inventory report and launches nothing. No prefix comparison, point FFT, causal attribution, inferred noise floor, convergence claim or port/transmission proof is produced. Recorded short-pulse settings are not measured time-trace bandwidth. Unsupported GPU point spatial interpolation remains a qualification.

Offline test command: `python -B -m unittest -v test_read_saved_times` from this packet directory. Generated LSF snippets are restricted fixed read-only `getdata`/`size` assignments; no real LSF/CAD execution was performed.
