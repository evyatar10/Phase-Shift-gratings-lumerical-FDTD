"""Explicit bounded CPU-only native CAD qualification; zero FDTD solves."""
import importlib.util,json,sys
from pathlib import Path
sp=importlib.util.spec_from_file_location('prep',Path(__file__).with_name('prepare_native_v2.py'));p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p)
ops=p.ops
env=json.loads((ops.E/'s2_length_native_environment_1753.json').read_text())
record=json.loads(json.loads((ops.E/'s2_length_native_preparation_1753.json').read_text())['out'])
template=json.loads((ops.E/'s2_length_native_template_1753.json').read_text())
assert template['status']=='NOT_REVIEWED' and template['allowed_tasks']==[]
assert template['code']['s2_length_fixed150.py']==p.RUNNER_SHA
env.update(ATHENA_LICENSE='1055@132.68.48.51',ATHENA_INTERCONNECT='2325@132.68.48.51',REQUIRE_GPU='0',KEEP_H5='1',NTFY_TOPIC='')
code=ops.COMMON+'''
import re
b=Path(__BASE__);new=__NEW__;old=__OLD__;env=__ENV__
for path,digest in {**old,**new}.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,(path,'Changed since metadata preparation')
assert not Path(__CADOUT__).exists(),'Build output exists; reconcile instead of redispatch'
queue=run(['squeue','-u','evyatarrubin']);assert queue['rc']==0 and 's2_len_' not in queue['out'],queue
lm='/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261/licensingclient/linx64/lmutil'
gui=run([lm,'lmstat','-c','1055@132.68.48.51','-f','lum_fdtd_gui']);solve=run([lm,'lmstat','-c','1055@132.68.48.51','-f','lum_fdtd_solve']);assert gui['rc']==solve['rc']==0
m=re.search(r'Total of ([0-9]+) licenses issued; *Total of ([0-9]+) licenses in use',gui['out']);assert m and int(m[2])<int(m[1]),gui
space=run(['df','-B1','-P',str(b/'results')]);assert space['rc']==0 and int(space['out'].splitlines()[-1].split()[3])>10*1024**3,space
inodes=run(['df','-iP',str(b/'results')]);assert inodes['rc']==0
quota={k:run(['/usr/bin/lfs','quota',flag,value,str((b/'results').resolve())]) for k,flag,value in [('user','-u',str(os.getuid())),('group','-g',str((b/'results').stat().st_gid)),('project','-p','9000001')]}
assert all(v['rc']==0 for v in quota.values()),quota
wrap=b/'jobs/run_length_cad_only_20261007.sh'
args=['sbatch','--parsable','--account=acct-lumerical','--partition=part-preempt','--qos=qos-preempt','--array=0%1','--cpus-per-task=8','--mem=64G','--time=00:20:00','--mail-type=NONE','--chdir='+str(b/'jobs'),'--export=ALL,'+','.join(k+'='+v for k,v in env.items()),str(wrap)]
test=run(args[:1]+['--test-only']+args[1:]);assert test['rc']==0,test
submission=run(args)
print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),scope='GUARDED_NATIVE_CAD_ONLY_NO_FDTD',requested_GPUs=0,queue=queue,GUI_seats=gui,solve_seats=solve,df=space,inodes=inodes,quotas=quota,args=args,test_only=test,submission=submission,source_sha256=__RUNNERSHA__,wrapper_sha256=hashlib.sha256(wrap.read_bytes()).hexdigest(),environment=env,output=__CADOUT__)))
'''
for key,value in dict(BASE=p.BASE,NEW=record['new_hashes'],OLD=record['existing_sources_preserved'],ENV=env,CADOUT=p.CADOUT,RUNNERSHA=p.RUNNER_SHA).items():code=code.replace('__'+key+'__',repr(value))
compile(code,'native_CAD_only_dispatch','exec')
result=ops.remote('132.68.58.101',code);ops.save('s2_length_native_cad_dispatch_1755.json',result);assert result['rc']==0,result
row=json.loads(result['out']);print(json.dumps({k:row[k] for k in ['at','scope','requested_GPUs','test_only','submission','output']},indent=2));assert row['submission']['rc']==0,row['submission']
