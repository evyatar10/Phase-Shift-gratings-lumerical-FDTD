"""No-FDTD stored-field fixed-bin shift30 v3 arithmetic-reuse diagnostic, one quadrature/job.
Five cached wavelengths, original peak3 control then three one-hot raw contractions.
No fitted calibration, phase correction, modal-derivative claim or quartic objective.
"""
import argparse,dataclasses,hashlib,json,sys
from pathlib import Path
import numpy as np
sys.dont_write_bytecode=True
import frozen_h1_mechanics as base
guard=base.guard
CONTROL_SUPPORT=(251,252,253)
FIXED_BINS=(244,252,260)
UNION=(244,251,252,253,260)
INDEX=149
CONTROL_RTOL=1e-12
CONTROL_ATOL=1e-14
EXPECTED_MECHANICS_SHA256='0be8299d6607388f373876bf16b5f15e3d894220efcd770b9cccedd6f46d526d'
EXPECTED_GUARD_SHA256='40dd487831da68080b29813cdbef2e1ce9e6629528dccd3d7c431dfc1229e99d'

def verify_helper_sources():
    if guard.sha256(base.__file__)!=EXPECTED_MECHANICS_SHA256 or guard.sha256(guard.__file__)!=EXPECTED_GUARD_SHA256:
        raise RuntimeError('Frozen mechanics/guard source identity mismatch')

def plain(x):
    if isinstance(x,np.ndarray):return plain(x.tolist())
    if isinstance(x,np.generic):return plain(x.item())
    if isinstance(x,complex):return dict(real=x.real,imag=x.imag)
    if isinstance(x,dict):return {str(k):plain(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [plain(v) for v in x]
    return x

def verified_support(jac,wl_m,reviewed_wl_m,values,eng):
    jac=np.asarray(jac,float).ravel();wl=np.asarray(wl_m,float).ravel();review=np.asarray(reviewed_wl_m,float).ravel()
    if jac.shape!=(501,) or wl.shape!=(501,) or review.shape!=(501,) or not np.all(np.isfinite(jac)) or not np.all(np.isfinite(wl)):
        raise RuntimeError('Exact501-sample control/grid required')
    if np.max(np.abs(wl-review))>1e-18:raise RuntimeError('Registered original wavelength grid/order mismatch')
    if tuple(np.flatnonzero(jac!=0))!=CONTROL_SUPPORT:raise RuntimeError('Original peak3 support differs from pinned251/252/253')
    values=np.asarray(values,float).ravel()
    if values.shape!=(501,) or not np.all(np.isfinite(values)):raise RuntimeError('Control scalar spectrum missing/nonfinite')
    lam,_,_=eng.measure_peak(wl*1e9,values)
    if int(np.argmin(np.abs(wl*1e9-lam)))!=252:raise RuntimeError('Original tracked Tout peak is not pinned252')
    return UNION

def onehot(index,n=501):
    if type(index) is not int or index not in FIXED_BINS or n!=501:raise RuntimeError('Only registered fixed one-hot bins allowed')
    result=np.zeros(n);result[index]=1.;return result

def check_control(value,reference):
    if not np.isfinite(value) or not np.isfinite(reference) or not np.isclose(value,reference,rtol=CONTROL_RTOL,atol=CONTROL_ATOL):
        raise RuntimeError('Original shift30 peak3 h1 control failed numerical reproduction')
    return dict(reference=float(reference),measured=float(value),difference=float(value-reference),
        relative_difference=float((value-reference)/reference) if reference else None,
        arithmetic_rtol=CONTROL_RTOL,arithmetic_atol=CONTROL_ATOL,
        status='NUMERICAL_REPRODUCTION_ONLY_NOT_SCIENTIFIC_GRADIENT_PASS')

def required_vector(value,count,name,complex_ok=True):
    array=np.asarray(value).ravel()
    if array.shape!=(count,) or not np.all(np.isfinite(array)):raise RuntimeError('Required finite '+name+' vector unavailable')
    if not complex_ok and np.iscomplexobj(array) and np.any(array.imag!=0):raise RuntimeError('Required real '+name+' contains complex values')
    return array

def source_metadata(cad,wanted):
    wanted=np.asarray(wanted,float);freq=299792458./wanted
    meta=dict(settings={},globals={},ports={},qualification='READONLY_METADATA_NO_UNIVERSAL_OBSERVABLE_CONVERSION')
    for prop in ('source port','source mode'):
        meta['settings']['FDTD::ports::'+prop]=guard.attempt(lambda prop=prop:cad.getnamed('FDTD::ports',prop))
    for port in ('Port_1','Port_2'):
        for prop in ('amplitude','phase','mode selection','selected mode number','injection axis','direction','theta','phi','number of field profile samples','frequency dependent profile','wavelength start','wavelength stop'):
            meta['settings'][port+'::'+prop]=guard.attempt(lambda port=port,prop=prop:cad.getnamed('FDTD::ports::'+port,prop))
    for prop in ('wavelength start','wavelength stop','frequency start','frequency stop','center frequency','bandwidth','pulse length','offset'):
        meta['globals'][prop]=guard.attempt(lambda prop=prop:cad.getglobalsource(prop))
    power=required_vector(cad.sourcepower(freq),len(wanted),'sourcepower',complex_ok=False).real
    if np.any(power<=0):raise RuntimeError('Required positive sourcepower unavailable')
    meta['sourcepower']=dict(wavelengths_m=wanted.tolist(),frequency_hz=freq.tolist(),values=power.tolist())
    for port in ('Port_1','Port_2'):
        expansion=cad.getresult('FDTD::ports::'+port,'expansion for port monitor')
        if 'lambda' in expansion:available=required_vector(expansion['lambda'],501,port+' expansion wavelength',complex_ok=False).real
        elif 'f' in expansion:available=299792458./required_vector(expansion['f'],501,port+' expansion frequency',complex_ok=False).real
        else:raise RuntimeError('Required port expansion frequency metadata unavailable')
        selected=[int(np.argmin(np.abs(available-w))) for w in wanted]
        if len(set(selected))!=len(selected) or any(abs(available[k]-w)>1e-18 for k,w in zip(selected,wanted)):
            raise RuntimeError('Required port expansion exact wavelength mapping mismatch')
        info=dict(selected_monitor_indices=selected,wavelengths_m=available[selected].tolist())
        for key in ('a','b','N'):
            if key not in expansion:raise RuntimeError('Required '+port+' expansion '+key+' absent')
            info[key]=required_vector(expansion[key],501,port+' '+key)[selected]
        for key in ('S','P','T_out','T_in','T_total'):
            info[key]=guard.attempt(lambda key=key:required_vector(expansion[key],501,port+' '+key)[selected])
        raw_powers={key:np.abs(info[key])**2*np.real(info['N'])/power for key in ('a','b')}
        info['uncorrected_mode_powers']=dict(values={key:v.tolist() for key,v in raw_powers.items()},
            qualification='UNCORRECTED_CONTINUUM_ALGEBRA_NOT_ANSYS_GRID_DISPERSION_CORRECTED_TRANSMISSION')
        direction=meta['settings'][port+'::direction']
        if direction.get('available') and direction.get('value') in ('Forward','Backward'):
            outgoing='a' if direction['value']=='Backward' else 'b'
            incoming='b' if outgoing=='a' else 'a'
            info['directional_normalization_comparisons']=dict(available=True,direction=direction['value'],outgoing_amplitude=outgoing,incoming_amplitude=incoming)
            for metric,amplitude in [('T_out',outgoing),('T_in',incoming)]:
                if info[metric]['available']:
                    reported=np.abs(np.asarray(info[metric]['value']))
                    info['directional_normalization_comparisons'][metric]=dict(reported_abs=reported.tolist(),
                        uncorrected_mode_power=raw_powers[amplitude].tolist(),
                        difference=(raw_powers[amplitude]-reported).tolist())
        else:
            info['directional_normalization_comparisons']=dict(available=False,
                error='Recorded direction missing or unsupported; no outgoing/incoming normalization comparison inferred')
        if info['T_out']['available'] and info['S']['available']:
            reported=np.abs(np.asarray(info['T_out']['value']))
            modal=np.abs(np.asarray(info['S']['value'],complex))**2
            info['separate_observables']=dict(abs_Tout=reported.tolist(),abs_S_squared=modal.tolist(),
                Tout_over_modal=[float(t/m) if m else None for t,m in zip(reported,modal)])
        meta['ports'][port]=info
    return meta

def install_normalization_trace(fom,report):
    from auxiliary_diagnostics_v3 import install_arithmetic_trace
    return install_arithmetic_trace(fom,report)


class FieldCache:
    """Cache only finite five-slice E arrays per explicit identity-checked FSP.

    It never uses the FOM/Jacobian as a cache key. Vendor normalization and current
    FOM Jacobian remain downstream and are recomputed for each objective.
    """
    def __init__(self,session,axes,reviewed_wl,sources,contexts=None):
        self.session=session;self.axes={k:np.asarray(v) for k,v in axes.items()}
        self.reviewed_wl=np.asarray(reviewed_wl,float).ravel();self.sources=sources
        self.contexts=contexts if contexts is not None else {}
        self.cache={};self.request_grid=None;self.audit=[]
    def __call__(self,sim_result,filename=None,*,monitor_name='optimization_dft',result_name='E',value='E'):
        if filename is None or (monitor_name,result_name,value)!=('optimization_dft','E','E'):raise RuntimeError('Explicit original saved E sampling only')
        key=str(Path(filename).resolve())
        if key not in self.sources:raise RuntimeError('Unregistered source FSP')
        if guard.file_identity(key,True)!=self.sources[key]:raise RuntimeError('Original source FSP changed during cache reuse')
        wanted=required_vector(sim_result.wavelengths,501,'requested wavelengths',complex_ok=False).real
        if self.reviewed_wl.shape!=(501,) or np.max(np.abs(wanted-self.reviewed_wl))>1e-18:raise RuntimeError('Requested wavelength grid/order mismatch')
        if self.request_grid is not None and not np.array_equal(wanted,self.request_grid):raise RuntimeError('Cache request wavelength grid changed')
        self.session.load_if_needed(filename)
        if key in self.cache:
            self.audit.append(dict(source=key,event='CACHE_HIT_NO_FIELD_READ'))
            return base.assemble_selected(501,UNION,self.cache[key])
        cad=self.session.fdtd
        xyz={a:np.asarray(cad.getdata(monitor_name,a,2)).ravel() for a in ('x','y','z')}
        if any(not np.array_equal(xyz[a],self.axes[a]) for a in xyz):raise RuntimeError('Saved field coordinate mismatch')
        available=299792458./required_vector(cad.getdata(monitor_name,'f',2),501,'DFT frequency',complex_ok=False).real
        if np.max(np.abs(available-self.reviewed_wl))>1e-18:raise RuntimeError('Actual original full DFT wavelength grid/order mismatch')
        indices=[int(np.argmin(np.abs(available-wanted[k]))) for k in UNION]
        if tuple(indices)!=UNION:raise RuntimeError('Actual original selected DFT indices differ from pinned union')
        meta=source_metadata(cad,wanted[list(UNION)])
        shape=tuple(len(xyz[a]) for a in ('x','y','z'));slices=[]
        for k in indices:
            components=[]
            for component in ('Ex','Ey','Ez'):
                cad.eval("s2_deps_slice = pinch(getdata('optimization_dft','"+component+"',2),4,"+str(k+1)+");")
                array=np.asarray(cad.getv('s2_deps_slice'))
                if array.shape!=shape or not np.all(np.isfinite(array)):raise RuntimeError('Required selected E shape/nonfinite mismatch')
                components.append(array)
            block=np.stack(components,axis=-1);block.setflags(write=False);slices.append(block)
        cad.eval('clear(s2_deps_slice);')
        self.contexts[key]=dict(source_metadata=meta,mesh=base.mesh_refinement_readback(cad),
            selected_indices=list(UNION),selected_wavelengths_m=wanted[list(UNION)].tolist(),
            field_sha256_by_index={str(k):hashlib.sha256(np.ascontiguousarray(v).tobytes()).hexdigest() for k,v in zip(UNION,slices)})
        self.cache[key]=tuple(slices);self.request_grid=wanted.copy()
        self.audit.append(dict(source=key,event='READ_FIVE_FINITE_E_SLICES',component_reads=15))
        return base.assemble_selected(501,UNION,slices)


def run(args):
    root=Path(args.output_root).resolve()
    if root.exists():raise RuntimeError('Output root must be NEW and exclusive')
    verify_helper_sources()
    sys.path.insert(0,str(Path(args.repo).resolve()))
    import config
    config.LUMAPI_PATH=args.lumapi;config.BASE_SAVE_DIR=str(root/'generated');config.USE_GPU=False
    from runners.lumopt2_design import recover_te_s2_peak as peak,recover_te_s2 as recovery
    eng,val=recovery.eng,recovery.val
    provenance=Path(args.provenance)
    if guard.sha256(provenance)!=args.reviewed_provenance_sha256:raise RuntimeError('Reviewed provenance SHA mismatch')
    evidence=json.loads(provenance.read_text())
    if evidence.get('critical_evidence_available') is not True or evidence.get('original_file_identity_unchanged') is not True or evidence.get('execution_error'):raise RuntimeError('Incomplete/preservation-failed original provenance')
    imaginary=args.quadrature=='im'
    spec=dataclasses.replace(peak.SPEC,label='lumopt2_te_s2_fixed_bins_'+args.quadrature+'_20261007',adj_phase_fix=imaginary,adj_fix_re=0. if imaginary else 1.,adj_fix_im=1. if imaginary else 0.)
    base.verify_full_spec(spec,evidence['spec'],imaginary)
    if (INDEX,'shift_30') not in base.selected_parameters(val,spec):raise RuntimeError('Live shift30 class mapping changed')
    params=val.te_point(spec)
    if not np.array_equal(params,np.asarray(evidence['params_nm'])):raise RuntimeError('Original point mismatch')
    forward=Path(evidence['cases'][args.quadrature+'_fwd']['source']);adjoint=Path(evidence['cases'][args.quadrature+'_adj']['source'])
    folder=Path(args.old_root or recovery.OLD)/('lumopt2_te_s2_cport_im_c_files' if imaginary else 'lumopt2_te_s2_cport_fd_c_files')
    if forward.resolve()!=(folder/'fwd_default.fsp').resolve() or adjoint.resolve()!=(folder/'adj_default_Port_2.fsp').resolve():raise RuntimeError('Original field source pair mismatch')
    if root.is_relative_to(folder.resolve()):raise RuntimeError('Output enters original evidence folder')
    reference_path=Path(args.saved_gradient);reference=json.loads(reference_path.read_text())
    vector=base.validate_saved_gradient(reference,imaginary,params,forward,adjoint,recovery.INDICES,evidence['spec'])
    control_reference=float(vector[list(recovery.INDICES).index(INDEX)])
    lmpt=eng.import_lumopt2()
    import lumapi
    from lumopt2.parametrization.d_eps_calculator import DEpsCalculator as DEC
    api_root=Path(lumapi.__file__).resolve().parent
    vendor={str(p.relative_to(api_root)):guard.sha256(p) for p in sorted((api_root/'lumopt2').rglob('*.py'))}
    if vendor!=evidence['vendor_sources'] or guard.sha256(lumapi.__file__)!=evidence['lumapi_sha256']:raise RuntimeError('Actual vendor source differs from reviewed original provenance')
    originals=[forward,adjoint]+[p.parent/p.stem/(p.stem+'_output.h5') for p in (forward,adjoint)]
    before=[guard.file_identity(p,p.suffix!='.h5') for p in originals]
    reviewed={item['path']:item for item in evidence['originals_before']}
    if any(not item['available'] or item['path'] not in reviewed or any(item.get(k)!=reviewed[item['path']].get(k) for k in ('bytes','mtime_ns','sha256')) for item in before):raise RuntimeError('Original FSP/HDF5 identity mismatch')
    for role in ('fwd','adj'):
        if evidence['cases'][args.quadrature+'_'+role]['saved_layout']['settings']['optimization_dft::spatial interpolation'].get('value')!='none':raise RuntimeError('Raw sampler requires original spatial interpolation none')
    for p in (forward,adjoint):recovery.successful_log(p)
    axes={a:evidence['cases'][args.quadrature+'_fwd']['saved_dft'][a]['value'] for a in ('x','y','z')}
    dependencies=recovery.identity(0)['code']
    root.mkdir(parents=True,exist_ok=False)
    report=dict(schema=1,quadrature=args.quadrature,index=INDEX,class_label='shift_30',step_nm=1.,union=list(UNION),fixed_bins=list(FIXED_BINS),
        params_nm=params.tolist(),forward=str(forward),adjoint=str(adjoint),originals_before=before,dependencies_before=dependencies,vendor_sources=vendor,
        spec=base.normalized(dataclasses.asdict(spec)),source_sha256=guard.sha256(__file__),frozen_mechanics_sha256=guard.sha256(base.__file__),guard_sha256=guard.sha256(guard.__file__),
        reviewed_provenance_sha256=args.reviewed_provenance_sha256,saved_gradient_reference=dict(path=str(reference_path),sha256=guard.sha256(reference_path),canonical_sha256=base.canonical_sha256(reference)),
        no_fdtd_solve=True,calibration_status='FAILED_UNCHANGED',operator_status='RAW_VENDOR_QUADRATURE_NOT_CERTIFIED_TOUT_OR_MODAL_DERIVATIVE',onehot_raw=[])
    sessions=[];oldguard=guard.NoSolveCAD;guard.NoSolveCAD=base.SelectedFieldGuard
    fdtd_class=lumapi.FDTD
    restore=guard.install_constructor_guard(lumapi.FDTD,root,sessions)
    assert lumapi.FDTD is fdtd_class
    try:
        project,wl_nm=eng.make_project(spec,str(root/'generated'),lmpt);project.fom.fct=eng.make_fct_peak(wl_nm);project.generate()
        cm=project.fom.config_map
        for c in cm.config_map.values():
            c['fwd_filename']=str(forward)
            for a in c['adjoints']:a['adj_filename']=str(adjoint)
        for info in cm._sim_result_info.values():info['fwd_filename'],info['adj_filename']=str(forward),str(adjoint)
        session=project.fdtd_session;fom=project.fom
        control_fct=fom.fct;jac=np.asarray(fom.get_jacobian(session),float).ravel()
        values=fom._load_and_extract_monitor_values(session)
        verified_support(jac,np.asarray(wl_nm)*1e-9,evidence['requested_wavelengths_m'],values,eng)
        report.update(peak3_jacobian=jac.tolist(),control_support=list(CONTROL_SUPPORT),original_center_peak3=float(fom.calculate_fom(session)),symmetry_factors=project.fom_symmetry_factors)
        report['saved_field_metadata']={}
        sources={str(p.resolve()):guard.file_identity(p,True) for p in (forward,adjoint)}
        cache=FieldCache(session,axes,evidence['requested_wavelengths_m'],sources,report['saved_field_metadata'])
        session.get_fields_at_wavelengths=cache
        install_normalization_trace(fom,report)
        report['active_objective']='old_peak3_control'
        fields=fom.calculate_gradient_fields(session,project.parametrization,project.fom_symmetry_factors)
        if not np.all(np.isfinite(fields)) or not np.array_equal(jac,np.asarray(fom.get_jacobian(session)).ravel()):raise RuntimeError('Control gradient field nonfinite or Jacobian changed')
        report['control_gradient_field_sha256']=hashlib.sha256(np.ascontiguousarray(fields).tobytes()).hexdigest()
        par=project.parametrization
        if not par.directly_on_params or not par.use_jac or spec.bc_patch:raise RuntimeError('Unchanged direct-param/PVA contraction required')
        session.fdtd.switchtolayout();par.update_structure(session,params);session.invalidate_loaded_state()
        column=np.asarray(par.compute_params_to_lumerical_jacobian(params))[:,INDEX]
        deps,shape,index_wl,objects=base.single_deps(DEC(session,par,directly_on_params=True,use_jac=True),params,INDEX,'shift_30',1.,column,par.prop_to_array_map)
        raw,components=base.contract_components(deps,shape,fields,DEC)
        report['old_peak3_control']=check_control(raw,control_reference);report['old_peak3_control']['component_contractions_xyz']=components
        del fields
        entry=next(iter(deps.values()))
        report['deps']=dict(global_shape=np.asarray(shape).ravel().tolist(),index_wavelength_m=np.asarray(index_wl).ravel().tolist(),affected_objects=objects,
            sparse_stats={k:dict(nonzero=int(np.count_nonzero(v['data'])),support_sha256=hashlib.sha256(np.asarray(v['indices'],np.int64).tobytes()).hexdigest()) for k,v in entry.items()})
        for k in FIXED_BINS:
            fom.fct=lambda x,k=k:x[k]
            expected=onehot(k);current=np.asarray(fom.get_jacobian(session),float).ravel()
            if not np.array_equal(current,expected):raise RuntimeError('One-hot FOM Jacobian mismatch')
            report['active_objective']='onehot_'+str(k)
            fields=fom.calculate_gradient_fields(session,par,project.fom_symmetry_factors)
            if not np.all(np.isfinite(fields)):raise RuntimeError('One-hot gradient field nonfinite')
            raw,parts=base.contract_components(deps,shape,fields,DEC)
            report['onehot_raw'].append(dict(bin=k,wavelength_m=float(np.asarray(wl_nm)[k]*1e-9),objective_jacobian='ONE_HOT_ON_PORTRESULTS_ABS_TOUT_SLOT',
                raw_contraction=raw,component_contractions_xyz=parts,gradient_field_sha256=hashlib.sha256(np.ascontiguousarray(fields).tobytes()).hexdigest(),
                operator_status=report['operator_status']))
            del fields
        fom.fct=control_fct
        report['cache_audit']=cache.audit
        report['execution_status']='RAW_OPERATOR_DIAGNOSTIC_COMPLETE_NO_PHYSICAL_PASS'
    except Exception as exc:report['execution_error']=type(exc).__name__+': '+str(exc)
    finally:
        report['originals_after']=[guard.file_identity(p,p.suffix!='.h5') for p in originals]
        report['original_file_identity_unchanged']=before==report['originals_after']
        report['dependencies_after']=recovery.identity(0)['code'];report['production_dependencies_unchanged']=dependencies==report['dependencies_after']
        report['CAD_call_audits']=[s.audit for s in sessions]
        for s in sessions:guard.attempt(s.close)
        restore();guard.NoSolveCAD=oldguard
        with (root/'fixed_bin_shift30.json').open('x',encoding='utf-8') as f:json.dump(plain(report),f,indent=2,allow_nan=False)
        print(root/'fixed_bin_shift30.json',flush=True)
    return 2 if report.get('execution_error') or not report['original_file_identity_unchanged'] or not report['production_dependencies_unchanged'] else 0

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ('repo','lumapi','provenance','reviewed-provenance-sha256','output-root','saved-gradient'):p.add_argument('--'+arg,required=True)
    p.add_argument('--quadrature',required=True,choices=('re','im'));p.add_argument('--old-root')
    sys.exit(run(p.parse_args()))
