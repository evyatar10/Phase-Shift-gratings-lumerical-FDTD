from pathlib import Path
import re,numpy as np,json,hashlib
root=Path('C:/Users/evyat/AppData/Local/Temp/te_original_remote_inventory_q8_9_zk0')
def arrays(file,marker):
 t=(root/file).read_text();s=t[t.index(marker):];s=s.split('[athena_run_one]')[0]
 return [np.fromstring(m.replace('\n',''),sep=',') for m in re.findall(r'array\(\[([^]]+)\]\)',s)]
def calc(fd,re,im):
 A=np.column_stack([re,im]);c=np.linalg.lstsq(A,fd,rcond=None)[0];pred=A@c
 loo=[]
 for i in range(len(fd)):
  mask=np.arange(len(fd))!=i;ci=np.linalg.lstsq(A[mask],fd[mask],rcond=None)[0];loo.append(float((A[i]@ci-fd[i])/fd[i]))
 return {'coefficients':c.tolist(),'condition':float(np.linalg.cond(A)),'relative_residuals':((pred-fd)/fd).tolist(),'vector_residual':float(np.linalg.norm(pred-fd)/np.linalg.norm(fd)),'leave_one_out_relative_errors':loo,'fd':fd.tolist(),'re':re.tolist(),'im':im.tolist()}
A=np.array([[1.,0],[0,1],[1,1],[2,1]]);c=np.array([.9,.12]);t=calc(A@c,A[:,0],A[:,1]);assert np.max(np.abs(t['relative_residuals']))<1e-12 and np.max(np.abs(t['leave_one_out_relative_errors']))<1e-12
results={}
for name,fdjob,imjob,stored in [('s1_port','168581_4','168582_5',[.945335,.117012]),('s1_field','168641_6','168642_7',[.966720,.036560]),('s2_field','170201_16','170201_17',[.983623,-.088013])]:
 fd,re_=arrays('lum_array-'+fdjob+'.out','[validate_gradient')[:2];im=arrays('lum_array-'+imjob+'.out','[adjoint_only')[0];assert len(fd)==len(re_)==len(im)
 r=calc(fd,re_,im);r['stored_coefficients']=stored;r['stored_coefficient_relative_residuals']=((np.column_stack([re_,im])@stored-fd)/fd).tolist();results[name]=r
report={'scope':'Refit of rounded arrays printed in original hash-verified remote job logs, NOT full-precision stored-field reconstruction, new physics, or current peak3 qualification. Two fitted coefficients; leave-one-out is diagnostic and can be ill-conditioned. Field fits below use exact LSQ while historical helper used a phase grid.','synthetic_exact_fit_test':'passed','results':results}
(root/'rounded_original_calibration_refit.json').write_text(json.dumps(report,indent=2),encoding='utf8')
for k,r in results.items():print(k,'C',r['coefficients'],'cond',r['condition'],'resid%',np.array(r['relative_residuals'])*100,'LOO%',np.array(r['leave_one_out_relative_errors'])*100)
