"""Offline pinned temporal triplet reader. No runner main/solve/approval calls."""
import argparse,json,sys,copy
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
import numpy as np
import firstwave_helpers as f
h=f.h
RUNNER_SHA='555f3d13b42c494171e7658cc4263c588ce418e5d937da1497d690824b41d44a'
FIRST_SHA='951c2025bf3255830a3b13e03a333b18bfb0ba59c86ee4e1c2b150ac078e2206'
FIRST_REMOTE='/work/data/s2_temporal100_review_20261007_1257.json'
FAMILY='s2_shift30_temporal_20261007'
OLD_CENTER_PORT_SHA='4c3c526b51973a2c8889608c69958b6d60e4dc27ddcf638c9932598629a035e4'

def path(value):
    p=Path(value);h.require(p.is_absolute(),'Actual local artifact paths must be absolute');return p
def frozen_sources(repo,marker):
    for name,digest in marker['code'].items():
        h.require(Path(name).name==name,'Invalid code basename')
        p=repo/name if name in ('config.py','bragg_device.py','simulation_config.py','sim_helpers.py') else repo/'runners/lumopt2_design'/name
        h.require(f.sha(p)==digest,'Frozen local scoring/dependency source changed: '+name)
def load_artifact(binding):
    row,digest=h.load_json(path(binding['checkpoint']),binding['checkpoint_sha256'])
    raw=path(binding['ports']).read_bytes();h.require(h.sha(raw)==binding['ports_sha256'],'Pinned transferred NPZ hash mismatch')
    return row,h.load_npz(raw),digest
def stage_from_fetch_pins(pins,marker_path,marker_sha,remote_marker,duration):
    h.require(PurePosixPath(remote_marker).is_absolute() and '..' not in PurePosixPath(remote_marker).parts,'Remote marker must be absolute and normalized')
    marker,_=h.load_json(marker_path,marker_sha);tasks=list(range(3)) if duration==100 else list(range(3,6))
    expected_keys={f'{t}:{role}' for t in tasks for role in ('checkpoint','ports')}
    h.require(set(pins)==expected_keys,'Fetched triplet pins are missing/off-stage')
    bindings={}
    for t in tasks:
        cp,ports=pins[f'{t}:checkpoint'],pins[f'{t}:ports']
        for b in (cp,ports):
            local=path(b['local']);h.require(local.stat().st_size==b['bytes'],'Pinned artifact byte count mismatch')
            h.require(f.sha(local)==b['sha256'],'Pinned fetched byte hash mismatch')
        h.require(cp['path']==marker['output_root']+f'/task_{t:02d}.json','Fetched checkpoint remote path mismatch')
        row,_=h.load_json(cp['local'],cp['sha256']);z=row['result']
        h.require(z['ports_npz']==ports['path'] and z['ports_sha256']==ports['sha256'],'Fetched ports remote identity mismatch')
        bindings[str(t)]=dict(checkpoint=cp['local'],checkpoint_sha256=cp['sha256'],ports=ports['local'],ports_sha256=ports['sha256'],
            fsp_sha256=z['fsp_sha256'],h5_sha256=z['h5_sha256'],log_sha256=z['termination']['log_sha256'])
    return dict(marker=str(Path(marker_path).resolve()),marker_sha256=marker_sha,remote_marker=remote_marker,tasks=bindings)
def old_triplet(evidence,marker,r):
    center,_=h.load_json(evidence/'s2_fdstep_task00_original.json',f.CENTER_SHA)
    h.require(center['identity']['task']==0 and center['identity']['index']==29 and center['identity']['sign']==0,
              'Old exact nominal-center metadata mismatch')
    nominal=r.val.te_point(r.SPEC);h.match_point(center['identity']['point'],nominal,'Old nominal point changed')
    h.match_point(center['result']['params'],nominal,'Old nominal result point changed')
    raw=(evidence/'s2_fdstep_task00_ports.npz').read_bytes();h.require(h.sha(raw)==OLD_CENTER_PORT_SHA,'Old center port byte identity mismatch')
    rows=[center];arrays=[h.load_npz(raw)];pins={'center_checkpoint':f.CENTER_SHA,'center_ports':OLD_CENTER_PORT_SHA}
    for task,sign in ((2,1),(3,-1)):
        bound=marker['prior']['checkpoints'][str(task)];cp=evidence/f's2_shift30_task{task:02d}_original.json'
        row,digest=h.load_json(cp,bound['sha256']);raw=(evidence/f's2_shift30_task{task:02d}_ports.npz').read_bytes()
        i,z=row['identity'],row['result'];p=nominal.copy();p[149]+=sign*.0625
        h.require(i['task']==task and i['index']==149 and i['sign']==sign and i['perturbation_nm']==.0625 and
            z['task']==task and z['sign']==sign and z['index']==149 and z['delta_nm']==sign*.0625 and
            i['center_sha256']==f.CENTER_SHA and h.spec_equal(i['spec'],center['identity']['spec']), 'Old same-geometry endpoint family mismatch')
        h.match_point(i['point'],p,'Old endpoint full point mismatch');h.match_point(z['params'],p,'Old endpoint result point mismatch')
        h.require(z['source']==bound['source'] and z['h5']==bound['h5'] and h.sha(raw)==bound['ports_sha256']==z['ports_sha256'],
            'Old endpoint source/ports identity mismatch')
        rows.append(row);arrays.append(h.load_npz(raw));pins[cp.name]=digest;pins[cp.name.replace('original.json','ports.npz')]=h.sha(raw)
    for row,a in zip(rows,arrays):h.check_grid(a,arrays[0],r.SPEC.n_wl_points);f.verify_scores(row,a,r.recovery.score)
    return center,rows,arrays,pins
def check_marker(marker,duration,first,r):
    tasks=list(range(3)) if duration==100 else list(range(3,6))
    expected=dict(schema=1,family=FAMILY,duration_ps=float(duration),center_sha256=f.CENTER_SHA,runner_sha256=RUNNER_SHA,
        spec=r.plain(__import__('dataclasses').asdict(r.SPEC)),task_map=r.plain(r.TASK_MAP),allowed_tasks=tasks,
        status=r.STATUS[float(duration)],timing_changes={'simulation time':duration*1e-12,'use early shutoff':0})
    h.require(all(marker.get(k)==v for k,v in expected.items()),'Exact temporal marker scope/family mismatch')
    h.require(marker.get('code')==first['code'] and marker.get('vendor_api_sha256')==first['vendor_api_sha256'] and
        marker.get('prior')==first['prior'] and marker.get('output_root')==first['output_root'],'Temporal frozen code/API/prior/root mismatch')
    h.require(isinstance(marker.get('lead_verdict'),str) and marker['lead_verdict'].strip() not in ('','NOT_REVIEWED'),'Lead marker verdict missing')
def validate_row(row,a,task,marker,stage,binding,center,r):
    i,z=row['identity'],row['result'];p,index,duration,sign=r.task_params(task)
    review=dict(path=stage['remote_marker'],sha256=stage['marker_sha256'],duration_ps=duration,
        lead_verdict=marker['lead_verdict'],allowed_tasks=marker['allowed_tasks'],first_stage=marker['first_stage'])
    expected=dict(schema=1,task=task,spec=marker['spec'],point=p.tolist(),index=index,sign=sign,delta_nm=sign*.0625,
        duration_ps=duration,task_map=marker['task_map'],center_checkpoint=f.CENTER_REMOTE,center_sha256=f.CENTER_SHA,
        code=marker['code'],vendor_api_sha256=marker['vendor_api_sha256'],parent_review=review,timing_changes=marker['timing_changes'])
    h.require(type(i.get('task')) is int and i==expected,'Full temporal checkpoint/task/point/spec/review identity mismatch')
    for k,v in dict(task=task,index=index,duration_ps=duration,sign=sign,delta_nm=sign*.0625,params=p.tolist(),
        parent_review=review,reviewed_center_sha256=f.CENTER_SHA,vendor_api_sha256=marker['vendor_api_sha256'],
        comparison_status='TEMPORAL_DIAGNOSTIC_REVIEW_REQUIRED_NO_PHYSICS_PASS',existing_overall_gradient_gate='FAILED_UNCHANGED').items():
        h.require(z.get(k)==v,'Temporal result identity mismatch: '+k)
    for key in ('fsp_sha256','h5_sha256','ports_sha256'):
        h.require(z.get(key)==binding.get(key),'Parent-pinned artifact hash mismatch: '+key)
    for digest in (z['fsp_sha256'],z['h5_sha256'],z['ports_sha256'],z['termination']['log_sha256']):
        h.require(isinstance(digest,str) and len(digest)==64 and all(c in '0123456789abcdef' for c in digest),'Invalid saved artifact content digest')
    h.require(isinstance(z.get('setup_fsp_sha256'),str) and len(z['setup_fsp_sha256'])==64 and isinstance(z.get('FDTD_version'),str) and z['FDTD_version'], 'Saved setup/FDTD version identity missing')
    paths={k:PurePosixPath(z[k]) for k in ('source','h5','ports_npz')};root=PurePosixPath(marker['output_root']);attempt=paths['ports_npz'].parent
    h.require(all(q.is_absolute() and '..' not in q.parts and q.is_relative_to(root) for q in paths.values()) and
        attempt.name.startswith(f'task_{task:02d}_') and paths['ports_npz'].name=='ports.npz' and
        paths['source'].is_relative_to(attempt) and paths['source'].name=='fwd_default.fsp' and
        paths['h5']==paths['source'].with_suffix('')/'fwd_default_output.h5','Temporal artifact paths escaped task/family')
    c=z['controls'];before,after,persisted=c['before'],c['after'],c['persisted']
    h.require(c['changed_properties']=={'FDTD::simulation time':[2000e-12,duration*1e-12],
        'FDTD::use early shutoff':[1,0],'optimization_dft::enabled':[1,0]},'Recorded changed timing properties mismatch')
    h.require(c['before_sha256']==r.semantic(before) and c['after_sha256']==r.semantic(after) and c['persisted_sha256']==r.semantic(persisted), 'Control snapshot hash mismatch')
    expected_after=json.loads(json.dumps(before));expected_after['timing'].update({'simulation time':duration*1e-12,'use early shutoff':0});expected_after['optimization_dft_enabled']=0
    h.require(after==expected_after and r.persisted_check(after,persisted)==c['serialization'],'Saved control intervention/persistence mismatch')
    h.require(before['timing']['simulation time']==2000e-12 and before['timing']['use early shutoff']==1 and
        before['timing']['auto shutoff min']==1e-7 and before['timing']['use divergence checking']==1 and before['optimization_dft_enabled']==1,'Baseline timing/divergence/monitor controls mismatch')
    geometry=r.eng.make_func(r.SPEC)(p)
    h.require(set(before['geometry'])==set(geometry) and all(abs(float(np.asarray(before['geometry'][k]).squeeze())-v)<1e-18 for k,v in geometry.items()),'Saved scene does not match geometry point')
    dt=float(c['dt_s']);pulse=float(c['source_pulse_length_s']);offset=float(c['source_offset_s'])
    h.require(np.isfinite([dt,pulse,offset]).all() and dt>0 and dt==after['timing']['dt'] and
        pulse==after['source']['pulselength'] and offset==after['source']['offset'] and offset>=2*pulse and
        pulse>0 and offset+10*pulse<duration*1e-12,'Pulse/timestep readback mismatch')
    t=z['termination'];actual=t['physical_time_s'];target=duration*1e-12
    h.require(t['requested_time_s']==target and t['recorded_dt_s']==dt and t['status']==1 and t['reason']=='completed_full_simulation_time' and
        np.isfinite(actual) and abs(actual-target)<=dt and t['delta_s']==actual-target and type(t['iterations']) is int and t['iterations']>0 and
        t['log_sha256']==binding['log_sha256'] and PurePosixPath(t['log'])==paths['source'].with_name('fwd_default_p0.log'),'Saved full-time termination identity mismatch')
    h.check_grid(a,center,r.SPEC.n_wl_points);f.verify_scores(row,a,r.recovery.score)
def cross_duration_controls(left,right,persisted_check):
    """Only recorded cross-run Port_1 phase roundoff may differ by<=2ULP.

    Raw snapshots remain untouched. Existing geometry serialization comparison
    remains delegated unchanged; every other snapshot property stays exact.
    This is recorded cross-run phase roundoff,not an established cause or physics/noise qualification.
    """
    def phase(snapshot):
        value=snapshot['ports']['FDTD::ports::Port_1']['phase']
        h.require(np.asarray(value).shape==() and not isinstance(value,(bool,str)),'Scalar phase required')
        x=np.float64(value);h.require(np.isfinite(x),'Finite phase required')
        return x,int(x.view(np.uint64))
    a,ab=phase(left);b,bb=phase(right)
    if a==0 or b==0:
        h.require(ab==bb,'Zero phase must match exactly');distance=0
    else:
        def ordered(bits):return (~bits)&((1<<64)-1) if bits&(1<<63) else bits|(1<<63)
        distance=abs(ordered(ab)-ordered(bb))
        h.require(distance<=2,'Cross-duration Port_1 phase exceeds measured2ULP allowance')
    checked_right=copy.deepcopy(right)
    checked_right['ports']['FDTD::ports::Port_1']['phase']=left['ports']['FDTD::ports::Port_1']['phase']
    geometry=persisted_check(left,checked_right)
    return dict(phase_property='/ports/FDTD::ports::Port_1/phase',left_phase_deg=float(a),right_phase_deg=float(b),
        signed_difference_deg=float(b-a),absolute_difference_deg=float(abs(b-a)),ULP_distance=int(distance),
        maximum_allowed_ULP=2,zeros_must_match_bitwise=True,existing_persisted_geometry_comparison=geometry,
        qualification='Recorded cross-run Port_1 phase roundoff arithmetic only; cause not established; all other controls exact except unchanged original geometry serialization check; not physics or noise tolerance')

def analyze(manifest,evidence,repo):
    h.require(manifest.get('schema')==1 and manifest.get('family')==FAMILY and manifest.get('runner_sha256')==RUNNER_SHA and
        set(manifest.get('stages',{})) in ({'100'},{'100','150'}),'Manifest requires exact100ps and optional150ps family')
    stages=manifest['stages'];stage100=stages['100'];h.require(stage100['marker_sha256']==FIRST_SHA and stage100['remote_marker']==FIRST_REMOTE,'Pinned submitted100ps marker mismatch')
    first,_=h.load_json(path(stage100['marker']),FIRST_SHA);frozen_sources(repo,first)
    sys.path.insert(0,str(repo));from runners.lumopt2_design import s2_temporal_forward as r
    h.require(f.sha(r.__file__)==RUNNER_SHA,'Frozen runner differs');check_marker(first,100,first,r)
    h.require(first['first_stage'] is None,'100ps marker has unexpected later-stage ancestry')
    oldcenter,oldrows,oldarrays,oldpins=old_triplet(evidence,first,r);arrays_by_duration={};rows_by_duration={};newpins={}
    for label in ('100','150'):
        if label not in stages:continue
        stage=stages[label]
        duration=int(label);tasks=list(range(3)) if duration==100 else list(range(3,6))
        h.require(set(stage['tasks'])==set(map(str,tasks)),'Triplet manifest is incomplete or off-stage')
        marker,digest=h.load_json(path(stage['marker']),stage['marker_sha256']);check_marker(marker,duration,first,r)
        if duration==150:
            wave=dict(marker=FIRST_REMOTE,marker_sha256=FIRST_SHA,checkpoints={})
            for t,row in enumerate(rows_by_duration['100']):
                z=row['result'];wave['checkpoints'][str(t)]=dict(checkpoint=first['output_root']+f'/task_{t:02d}.json',sha256=stages['100']['tasks'][str(t)]['checkpoint_sha256'],
                    ports_sha256=z['ports_sha256'],fsp_sha256=z['fsp_sha256'],h5_sha256=z['h5_sha256'],termination=z['termination'])
            h.require(stage['remote_marker']!=FIRST_REMOTE and marker['first_stage']==wave,'150ps exact completed100ps ancestry mismatch')
        rows=[];arrays=[]
        for t in tasks:
            binding=stage['tasks'][str(t)];row,a,sha=load_artifact(binding)
            validate_row(row,a,t,marker,stage,binding,oldarrays[0],r);rows.append(row);arrays.append(a);newpins[str(t)]=dict(checkpoint_sha256=sha,**{k:binding[k] for k in ('ports_sha256','fsp_sha256','h5_sha256','log_sha256')})
        for row in rows[1:]:
            for key in ('mesh','source','refinement','monitor'):
                h.require(row['result']['controls']['before'][key]==rows[0]['result']['controls']['before'][key],'Triplet baseline mesh/source/grid settings differ')
        arrays_by_duration[label]=arrays;rows_by_duration[label]=rows
    cross_duration=[]
    if '150' in stages:
        for left,right in zip(rows_by_duration['100'],rows_by_duration['150']):
            comparison=cross_duration_controls(left['result']['controls']['before'],right['result']['controls']['before'],r.persisted_check)
            cross_duration.append(dict(left_task=left['identity']['task'],right_task=right['identity']['task'],comparison=comparison))
    report=dict(schema=1,status='DIAGNOSTIC_ONLY_CALIBRATION_FAILED_UNCHANGED',no_automatic_approval=True,step_nm=.0625,
        duration_labels=['old_autoshutoff_67ps_approx']+list(stages),cross_duration_control_comparisons=cross_duration,provenance=dict(first_marker_sha256=FIRST_SHA,runner_sha256=RUNNER_SHA,old_files=oldpins,new_artifacts=newpins),
        termination={str(row['identity']['task']):row['result']['termination'] for rows in rows_by_duration.values() for row in rows},observables={},
        limitations=['No physical pass, coefficient fit, noise bound or automatic150ps approval.','One parameter step does not establish h-convergence.',
            'Old67ps is an approximate label; actual old times differ by geometry.','Remote FSP/H5/log completion and cold-resume verification stay with parent; this reader validates pinned saved metadata and local CP/NPZ bytes.',
            'Original-center and same-duration peak3 Jacobian projections are fixed spectral-FD projections, not adjoint gradients.'])
    full=dict(grids={k:oldarrays[0][k].ravel().tolist() for k in h.GRIDS},observables={})
    alltriplets={'old_autoshutoff_67ps_approx':oldarrays,**arrays_by_duration}
    def encode(v):
        v=np.asarray(v).ravel()
        return dict(real=v.real.tolist(),imag=v.imag.tolist()) if np.iscomplexobj(v) else v.tolist()
    full['raw_port_spectra']={label:{role:{k:encode(a[k]) for k in ('p1_T_in','p2_T_out','p2_S')}
        for role,a in zip(('center','plus','minus'),triplet)} for label,triplet in alltriplets.items()}
    for metric,transform in h.METRICS.items():
        select=lambda s:f.selected_peak(s,oldarrays[0]['p2_lambda'],r.eng)
        original=transform(oldarrays[0]);original_peak=select(original);steps={};curves={};changes={}
        for label,triplet in alltriplets.items():
            c,p,m=map(transform,triplet);rep,d=f.pair_report(p,m,c,.0625,select)
            k,height,w=original_peak;rep['original_center_jacobian_projection']=float(w@d[k-1:k+2]);rep['original_center_peak_index']=k
            rep['original_center_peak3_weights']=w.tolist();rep['same_duration_center_jacobian_projection']=rep['exact_center_peak3_jacobian_projection']
            rep['original_center_jacobian_provenance']=dict(role='Exact_repeated_nominal_67.39992ps_reference_not_original_stored_adjoint_field_center',
                checkpoint_sha256=f.CENTER_SHA,ports_sha256=OLD_CENTER_PORT_SHA)
            rep['fixed_bins']={str(k):float(d[k]) for k in (244,252,260)};rep['center_role']='same_duration_'+label
            steps[label]=rep;curves[label]=dict(center=c.tolist(),plus=p.tolist(),minus=m.tolist(),spectral_central_fd=d.tolist(),
                spectral_odd=((p-m)/2).tolist(),spectral_even_with_same_duration_center=((p+m-2*c)/2).tolist())
        for left,right in [('old_autoshutoff_67ps_approx','100')]+([('100','150'),('old_autoshutoff_67ps_approx','150')] if '150' in stages else []):
            change={};spectral_change={}
            for role in ('center','plus','minus'):
                delta=np.asarray(curves[right][role])-np.asarray(curves[left][role]);spectral_change[role]=delta.tolist()
                change[role]=dict(spectral_difference=f.difference(curves[right][role],curves[left][role]),moving_peak3_difference=select(np.asarray(curves[right][role]))[1]-select(np.asarray(curves[left][role]))[1])
            change.update(central_derivative_difference=steps[right]['central_derivative']-steps[left]['central_derivative'],even_difference=steps[right]['even']-steps[left]['even'])
            key=right+'_minus_'+left;changes[key]=change;curves[key]=dict(same_geometry_spectral_differences=spectral_change)
        report['observables'][metric]=dict(triplets=steps,same_geometry_temporal_differences=changes)
        full['observables'][metric]=curves
    return report,full
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ('100-pins','100-pins-sha256','100-marker','existing-evidence-dir','repo','output','spectra-output'):p.add_argument('--'+arg,required=True)
    for arg in ('150-pins','150-pins-sha256','150-marker','150-marker-sha256','150-marker-remote'):p.add_argument('--'+arg)
    a=p.parse_args();firstpins,_=h.load_json(vars(a)['100_pins'],vars(a)['100_pins_sha256'])
    stages={'100':stage_from_fetch_pins(firstpins,vars(a)['100_marker'],FIRST_SHA,FIRST_REMOTE,100)}
    if any(vars(a)[k] is not None for k in ('150_pins','150_pins_sha256','150_marker','150_marker_sha256','150_marker_remote')):
        h.require(all(vars(a)[k] for k in ('150_pins','150_pins_sha256','150_marker','150_marker_sha256','150_marker_remote')),'Optional150ps requires all pins/marker identities')
        laterpins,_=h.load_json(vars(a)['150_pins'],vars(a)['150_pins_sha256'])
        stages['150']=stage_from_fetch_pins(laterpins,vars(a)['150_marker'],vars(a)['150_marker_sha256'],vars(a)['150_marker_remote'],150)
    m=dict(schema=1,family=FAMILY,runner_sha256=RUNNER_SHA,stages=stages)
    h.require(not Path(a.output).exists() and not Path(a.spectra_output).exists() and Path(a.output).resolve()!=Path(a.spectra_output).resolve(),'Exclusive distinct output files required')
    report,full=analyze(m,Path(a.existing_evidence_dir),Path(a.repo).resolve());report['artifact_manifest_sha256']={'100':vars(a)['100_pins_sha256']}
    if '150' in stages:report['artifact_manifest_sha256']['150']=vars(a)['150_pins_sha256']
    f.write(a.spectra_output,full);report['full_spectra_sha256']=f.sha(a.spectra_output);report['full_spectra_file']=str(Path(a.spectra_output).resolve());f.write(a.output,report)
