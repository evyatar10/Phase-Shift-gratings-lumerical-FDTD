# Bounded200ps extractor review and fixes

Root explicitly transferred ownership of TEMP/s2_saved200_profile_r6g42i97/extract200.py for these fixes. Original913914a479b38b75f9ee81e11fcbb39b1f2a64938fff80ea58598646478f2356 is preserved byte-identically as extract200_original_913914.py. Frozen reader994c3e9757a10b5bd8ea211aaee8425c5d3540203a4da04b0439684163baf6ca is unchanged. No repository/server/network/CAD/FDTD action.

Final extractor SHA36ff78a1c567a911c84d707682e9dfa0e0e3e51c740e142a8be4d43f65e4f9f3.

Implemented fail-closed changes:
-Exact/work checkpoint identity uses PurePosixPath plus canonical string/no traversal checks; host filesystem I/O staysPath. The exact server task00 path is unchanged,notrelaxed forWindows.
-Rawcaller checkpoint pin, released4fe3marker and independenta0ff150center bytes are required beforeCAD. Fullidentity must exactly match marker spec/code/vendor/taskmap/ancestor/review/timing metadata and thatcenter's full296point.
-FSP,H5,ports must occupy the SAME exacttask00attempt directlyunder the releasedfamily; sourcebasename and H5companion arechecked,alloriginalartifacthashes verified.
-Finitepositive dt must equal after/persisted/referencecenter dt. Full200ps requested/actualduration,status,reason,iterations,recordeddt/delta and after/persisted physicalcontrols are checked.
-Importedengine path/bytes arechecked. CP,FSP,H5,NPZ,marker,parentcenter andallactualcode/vendorfiles are snapshotted/rechecked afterclose.
-OriginalFDTDclass/constructor changes now force failure/nonzeroexit,not merely a reportedfalseflag.

Sixfocused tests exit0; CLIhelp exit0. They exercise fullmetadata acceptance, exact POSIX/no traversal,wrongcheckpoint/marker/role/status/duration/dt/point/code,offfamily/othertask/missingartifacthash,actualrunrefusalbeforeCAD,explicitfakeCAD200postprocessing/close, andclass/constructor mutation failure. Shared core's earliernine tests/100/150hardwareuse were NOT repeated.

ALLtestfixtures andpositiveoutputs are SYNTHETIC200 protocol evidence,not completed171390data. Coreextract,NPZ/score/H5inventory andvendorfingerprint are controlledtestdoubles in the fakeCADpositiveflow; the sourcevendorstub supplies expectedLinuxfingerprints because WindowscannotexecuteAthena APIbytes. The actualmetadata/hash/pathrefusal logic is tested separately andbefore fakeCADconstruction. LinuxPath filesystem behavior is modeled by a TESTONLY adapter mapping exactserverstrings to ownedTEMPfixturebytes. No fake data is installed in docs/results or reported asmeasuredphysics.

Actualreleased200checkpoint SHA is not known here yet. Root must independently record completedtask00 rawCPbytes after171390 success, retainexactmarker/source/vendor/artifacts, then run this reader through the proper scheduledCPUwrapper. Real200rawfieldavailability/shapes/runtime remain unmeasured; sourcecontrols have no newphysicsapproval. No solve/save entry exists in extractor; coreReadOnlyCAD/extract handlesonly savedfieldpostprocessing and exclusiveoutput.
