import unittest,tempfile,types,copy,json,sys,re,ast,hashlib
from pathlib import Path
import numpy as np
sys.dont_write_bytecode=True
import probe_fixed_bin_shift30 as probe

class FakeCAD:
    def __init__(self):
        self.axes={a:np.array([0.,1.]) for a in ('x','y','z')}
        self.freq=np.linspace(1.9e14,2.1e14,501);self.wl=299792458./self.freq
        rng=np.random.default_rng(71)
        self.fields={k:rng.normal(size=(2,2,2,501,3))+1j*rng.normal(size=(2,2,2,501,3)) for k in ('fwd','adj')}
        self.kind='fwd';self.reads=0;self.missing=None;self.component=0;self.index=0
    def getdata(self,obj,key,option):return self.freq if key=='f' else self.axes[key]
    def eval(self,text):
        if text.startswith('clear'):return
        match=re.fullmatch(r"s2_deps_slice = pinch\(getdata\('optimization_dft','(Ex|Ey|Ez)',2\),4,(\d+)\);",text)
        if not match:raise AssertionError('Unexpected field script')
        self.component=('Ex','Ey','Ez').index(match[1]);self.index=int(match[2])-1;self.reads+=1
    def getv(self,key):return self.fields[self.kind][:,:,:,self.index,self.component]
    def getnamed(self,obj,key):
        if key=='mode selection':raise RuntimeError('synthetic unsupported property')
        if key=='direction':return 'Forward' if obj.endswith('Port_1') else 'Backward'
        return 'precise volume average' if key=='mesh refinement' else ('Port_2' if key=='source port' else 1.)
    def getglobalsource(self,key):
        if key=='bandwidth':raise RuntimeError('synthetic unsupported global property')
        return 1.
    def sourcepower(self,freq):return np.ones(len(freq))*3.
    def getresult(self,obj,result):
        data=dict(lambda_=self.wl,a=np.ones(501)*(1.+.3j),b=np.ones(501)*(.2-.1j),N=np.ones(501)*2.,S=np.ones(501)*(.8+.1j),P=np.ones(501)*4.,T_out=np.ones(501)*.7,T_in=np.ones(501)*.9,T_total=np.ones(501)*.6)
        data['lambda']=data.pop('lambda_')
        if self.missing in data:del data[self.missing]
        return data

class Tests(unittest.TestCase):
    def fixture(self):
        root=Path(tempfile.mkdtemp(prefix='fixed_fields_test_',dir=Path(__file__).parent))
        paths={k:root/(k+'.fsp') for k in ('fwd','adj')}
        for k,p in paths.items():p.write_text('synthetic '+k)
        cad=FakeCAD();session=types.SimpleNamespace(fdtd=cad,load_if_needed=lambda path:setattr(cad,'kind',Path(path).stem))
        sources={str(p.resolve()):probe.guard.file_identity(p,True) for p in paths.values()}
        cache=probe.FieldCache(session,cad.axes,cad.wl,sources)
        sim=types.SimpleNamespace(wavelengths=cad.wl.copy())
        return root,paths,cad,session,cache,sim

    def test_exact_support_grid_and_onehot_controls(self):
        cad=FakeCAD();jac=np.zeros(501);jac[list(probe.CONTROL_SUPPORT)]=[.08,.98,-.06]
        eng=types.SimpleNamespace(measure_peak=lambda wl,y:(float(wl[252]),float(y[252]),1.))
        self.assertEqual(probe.verified_support(jac,cad.wl,cad.wl,np.ones(501),eng),probe.UNION)
        for bad in (np.roll(jac,1),np.full(501,np.nan),jac[:500]):
            with self.assertRaises(RuntimeError):probe.verified_support(bad,cad.wl,cad.wl,np.ones(501),eng)
        with self.assertRaises(RuntimeError):probe.verified_support(jac,np.roll(cad.wl,1),cad.wl,np.ones(501),eng)
        wrong=types.SimpleNamespace(measure_peak=lambda wl,y:(float(wl[250]),1.,1.))
        with self.assertRaises(RuntimeError):probe.verified_support(jac,cad.wl,cad.wl,np.ones(501),wrong)
        for k in probe.FIXED_BINS:
            j=probe.onehot(k);self.assertEqual(np.flatnonzero(j).tolist(),[k]);self.assertEqual(j[k],1.)
        for k in (True,251,243):
            with self.assertRaises(RuntimeError):probe.onehot(k)

    def test_actual_vendor_onehot_normalization_and_cache_jacobian_independence(self):
        _,paths,cad,session,cache,sim=self.fixture()
        api='C:/Program Files/Lumerical/v261/api/python'
        sys.path.insert(0,api)
        from lumopt2.fom.port_fom import PortFom
        class VendorFom(PortFom):
            def get_jacobian(self,session):return self.current_jac
        fom=VendorFom.__new__(VendorFom)
        sim.monitor_name='Port_2'
        fom._port_aux_cache={'Port_2':dict(axis_letter='x',direction='Backward',sign=-1,baseline_position=0.,resolution=50e-9,k_num=1.)}
        session.get_dict_values_at_wavelengths=lambda sim_result,value_keys,**kwargs:{key:(cad.freq if key=='f' else cad.getresult('FDTD::ports::Port_2','expansion for port monitor')[key]) for key in value_keys}
        from lumopt2.utils.common import eps0
        entry=dict(sim_result=sim,fwd_filename=str(paths['fwd']),adj_filename=str(paths['adj']))
        fom.config_map=types.SimpleNamespace(get_filenames_in_order=lambda:[entry])
        par=types.SimpleNamespace(structure={'mesh_cells':{'nx':2,'ny':2,'nz':2},'actual_mesh_sizes':dict(dx=50e-9,dy=40e-9,dz=60e-9)})
        scale=2*eps0*50e-9*40e-9*60e-9
        session.get_fields_at_wavelengths=cache
        normalization_report={}
        probe.install_normalization_trace(fom,normalization_report)
        old=np.zeros(501);old[list(probe.CONTROL_SUPPORT)]=[.08,.98,-.06]
        for jac in [old]+[probe.onehot(k) for k in probe.FIXED_BINS]:
            fom.current_jac=jac
            actual=fom.calculate_gradient_fields(session,par)
            expected=np.zeros((2,2,2,3),complex)
            for k in probe.UNION:
                factor=1j*(2*np.pi*cad.freq[k])*.25*np.conj(1.+.3j)/3.
                expected+=scale*jac[k]*cad.fields['fwd'][:,:,:,k,:]*cad.fields['adj'][:,:,:,k,:]*factor
            np.testing.assert_allclose(actual,expected.real,rtol=1e-12,atol=1e-30)
        self.assertEqual(cad.reads,30) # five wavelengths times3components times2files, once
        self.assertEqual(sum(a['event']=='CACHE_HIT_NO_FIELD_READ' for a in cache.audit),6)
        self.assertFalse(cache.cache[str(paths['fwd'].resolve())][0].flags.writeable)
        meta=cache.contexts[str(paths['fwd'].resolve())]['source_metadata']
        self.assertFalse(meta['settings']['Port_2::mode selection']['available'])
        self.assertFalse(meta['globals']['bandwidth']['available'])
        self.assertEqual(meta['ports']['Port_1']['directional_normalization_comparisons']['outgoing_amplitude'],'b')
        self.assertEqual(meta['ports']['Port_1']['directional_normalization_comparisons']['incoming_amplitude'],'a')
        self.assertEqual(meta['ports']['Port_2']['directional_normalization_comparisons']['outgoing_amplitude'],'a')
        self.assertEqual(meta['ports']['Port_2']['directional_normalization_comparisons']['incoming_amplitude'],'b')
        self.assertEqual(normalization_report['vendor_forward_normalization']['indices'],list(probe.UNION))
        self.assertEqual(normalization_report['vendor_forward_normalization']['sourcepower'],[3.]*5)
        cad.sourcepower=lambda f:np.full(len(f),4.)
        with self.assertRaisesRegex(RuntimeError,'normalization changed'):fom.calculate_gradient_fields(session,par)
        json.dumps(probe.plain(meta),allow_nan=False)

    def test_missing_data_identity_coordinate_and_grid_fail_closed(self):
        for missing_direction in (False,True):
            cad=FakeCAD();original=cad.getnamed
            def getnamed(obj,key):
                if key=='direction':
                    if missing_direction:raise RuntimeError('Direction property unavailable')
                    return 'Unrecognized'
                return original(obj,key)
            cad.getnamed=getnamed
            metadata=probe.source_metadata(cad,cad.wl[list(probe.UNION)])
            for port in ('Port_1','Port_2'):
                self.assertFalse(metadata['ports'][port]['directional_normalization_comparisons']['available'])
                self.assertNotIn('T_out',metadata['ports'][port]['directional_normalization_comparisons'])
        for missing in ('a','b','N'):
            _,paths,cad,session,cache,sim=self.fixture();cad.missing=missing
            with self.assertRaisesRegex(RuntimeError,'Required'):cache(sim,str(paths['fwd']))
            self.assertEqual(cad.reads,0)
        _,paths,cad,session,cache,sim=self.fixture();cad.sourcepower=lambda f:np.full(len(f),np.nan)
        with self.assertRaisesRegex(RuntimeError,'sourcepower'):cache(sim,str(paths['fwd']))
        _,paths,cad,session,cache,sim=self.fixture();cad.fields['fwd'][0,0,0,244,0]=np.nan
        with self.assertRaisesRegex(RuntimeError,'E shape/nonfinite'):cache(sim,str(paths['fwd']))
        self.assertEqual(len(cache.cache),0)
        _,paths,cad,session,cache,sim=self.fixture();cache(sim,str(paths['fwd']))
        with paths['fwd'].open('a') as f:f.write('changed')
        with self.assertRaisesRegex(RuntimeError,'changed'):cache(sim,str(paths['fwd']))
        _,paths,cad,session,cache,sim=self.fixture();cad.axes['x']=np.array([1.,2.])
        with self.assertRaisesRegex(RuntimeError,'coordinate'):cache(sim,str(paths['fwd']))
        _,paths,cad,session,cache,sim=self.fixture();sim.wavelengths=np.roll(sim.wavelengths,1)
        with self.assertRaisesRegex(RuntimeError,'grid/order'):cache(sim,str(paths['fwd']))
        with self.assertRaisesRegex(RuntimeError,'Unregistered'):cache(sim,str(paths['adj'].parent/'unknown.fsp'))

    def test_old_control_rejection_and_actual_saved_reference_identity(self):
        repo=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');sys.path.insert(0,str(repo))
        from runners.lumopt2_design import recover_te_s2 as r
        provenance=json.loads((repo/'docs/readiness_evidence_20261007/s2_provenance_first_report_original.json').read_text())
        for q,t in [('re',0),('im',1)]:
            row=json.loads((repo/f'results_from_athena/recover_te_s2_20261006/watch/recover_te_s2_peak/task_{t:02d}.json').read_text())
            vector=probe.base.validate_saved_gradient(row,t==1,r.val.te_point(r.SPEC),row['result']['forward'],row['result']['adjoint'],r.INDICES,provenance['spec'])
            ref=float(vector[list(r.INDICES).index(149)])
            report=json.loads((repo/f'docs/readiness_evidence_20261007/s2_other_classes_{q}_report_original.json').read_text())
            measured=next(v['raw_contraction'] for v in report['raw_classes'] if v['index']==149)
            probe.check_control(measured,ref)
            for bad in (ref+1e-8,float('nan'),float('inf')):
                with self.assertRaisesRegex(RuntimeError,'control failed'):probe.check_control(bad,ref)
            bad=copy.deepcopy(row);bad['result']['gradient'][4]+=1e-8
            with self.assertRaisesRegex(RuntimeError,'checkpoint binding'):probe.base.validate_saved_gradient(bad,t==1,r.val.te_point(r.SPEC),row['result']['forward'],row['result']['adjoint'],r.INDICES,provenance['spec'])

    def test_no_solve_guards_and_exclusive_output(self):
        probe.verify_helper_sources()
        class Fake:
            def __getattr__(self,name):return lambda *a,**k:None
        root=Path(__file__).parent;g=probe.base.SelectedFieldGuard(Fake(),root)
        for action in (lambda:g.run(),lambda:g.eval('run;'),lambda:g.getresult('optimization_dft','E'),lambda:g.getdata('optimization_dft','Ex'),lambda:g.eval("a=getdata('optimization_dft','Ex',2);"),lambda:g.save(root.parent/'old.fsp')):
            with self.assertRaises(RuntimeError):action()
        tree=ast.parse(Path(probe.__file__).read_text());calls=[n.func.attr for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)]
        for forbidden in ('run_forward','run_adjoint','compute_gradient','set_fwd','_run_perturbation_loop'):self.assertNotIn(forbidden,calls)
        with self.assertRaisesRegex(RuntimeError,'NEW and exclusive'):probe.run(types.SimpleNamespace(output_root=str(root)))

if __name__=='__main__':unittest.main()
