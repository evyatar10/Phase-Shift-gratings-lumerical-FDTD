import argparse,contextlib,copy,io,json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import extract_saved_spatial_profiles as a
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');sys.path.insert(0,str(ROOT));from runners.lumopt2_design import lumopt2_design as eng
class FakeRaw:
 def __init__(self):self.calls=[]
 def eval(self,s):self.calls.append(s)
 def save(self,*x):self.calls.append('SAVE')
 def run(self,*x):self.calls.append('RUN')
 def getv(self,n):self.calls.append(n);return 1
 def load(self,p):self.calls.append(p)
class ProfileChecks(unittest.TestCase):
 def test_guard_all_solve_save_and_full_transfer_paths(self):
  raw=FakeRaw();cad=a.ReadOnlyCAD(raw,'/exact.fsp')
  for n in ['run','runjobs','runparallel','runsweep','runanalysis','save','savejob','addjob','switchtolayout','setnamed']:
   with self.assertRaises(RuntimeError):getattr(cad,n)()
  for script in ['run;','save("x");','setnamed("field_profile","enabled",0);','sp_raw=getresult("other","E");','bad=1;']:
   with self.assertRaises(RuntimeError):cad.eval(script)
  with self.assertRaises(RuntimeError):cad.getv('sp_raw')
  with self.assertRaises(RuntimeError):cad.getresult('field_profile','E')
  self.assertEqual(raw.calls,[])
  cad.eval("sp_raw=getresult('field_profile','E');sp_shape=size(sp_raw.E);");self.assertEqual(len(raw.calls),1)
 def test_y_integral_nonuniform_grid_and_production_width(self):
  x=np.linspace(-60,60,2401)*1e-6;y=np.array([-.4,-.1,.6])*1e-6;I=(.025+np.exp(-((x*1e6)/8)**2))*(1+.2*np.cos(2*np.pi*x/.258e-6));e=np.zeros((len(x),len(y),1,1,3),complex);e[:,:,0,0,0]=np.sqrt(I[:,None]);coords=dict(x=x,y=y,z=np.array([0.]),**{'lambda':np.array([1560.878e-9])})
  with contextlib.redirect_stdout(io.StringIO()):meta,z=a.processed_profile(eng,coords,e,1560.878)
  keep=abs(x*1e6)<=98*491.06/1000;np.testing.assert_allclose(z['I_y_integrated'],np.trapz(np.tile(I[:,None],(1,3)),y,axis=1)[keep],rtol=4*np.finfo(float).eps,atol=0);self.assertGreater(meta['production_FWHM_um'],0);self.assertTrue(0<meta['floor_over_peak']<1);self.assertEqual(meta['monitor_sampled_lambda_nm'],coords['lambda'][0]*1e9)
  self.assertAlmostEqual(z['wy_m'].sum(),y[-1]-y[0]);self.assertEqual(meta['crop_half_extent_um'],48.12388)
  bad=e.copy();bad[0,0,0,0,0]=np.nan
  with self.assertRaises(RuntimeError):a.processed_profile(eng,coords,bad,1560.878)
 def test_selected_E_axes_4D_5D_and_cache_no_full_transfer(self):
  for nd in [4,5]:
   class FakeSlices:
    def __init__(self):self.k=0;self.reads=0
    def eval(self,s):
     if 'pinch' in s:self.k=int(s.split(',')[-1].split(')')[0])-1
    def getv(self,n):
     if n=='sp_shape':return np.array([4,3,1,2,3] if nd==5 else [4,3,2,3])
     if n=='sp_x':return np.arange(4)*1e-6
     if n=='sp_y':return np.array([0.,.2,.6])*1e-6
     if n=='sp_z':return np.array([0.])
     if n=='sp_lam':return np.array([1560e-9,1561e-9])
     if n=='sp_slice':self.reads+=1;return np.full((4,3,1,3),1+self.k,complex)
     raise AssertionError('Unselected/full transfer')
   fake=FakeSlices();coords,shape,select=a.transfer_selected(fake);self.assertEqual(select(1).shape,(4,3,1,1,3));self.assertTrue((select(1)==2).all());self.assertEqual(fake.reads,1);select(0);self.assertEqual(fake.reads,2)
 def test_h5py_missing_optional_CAD_continues_schema_only_fails(self):
  import builtins
  original=builtins.__import__
  def importing(name,*args,**kwargs):
   if name=='h5py':raise ModuleNotFoundError("No module named 'h5py'")
   return original(name,*args,**kwargs)
  with patch('builtins.__import__',side_effect=importing):
   report=a.optional_h5_inventory('NEVER_OPENED_MISSING_H5',schema_only=False)
   self.assertEqual(report['status'],'UNAVAILABLE');self.assertEqual(report['error'],"ModuleNotFoundError: No module named 'h5py'");self.assertNotIn('dataset_count',report)
   # The nonblocking normal return allows the unchanged guarded CAD path.
   self.assertIn('CAD',report['direct_extraction_status'])
   with self.assertRaisesRegex(RuntimeError,"Schema-only inventory unavailable; ModuleNotFoundError: No module named 'h5py'"):a.optional_h5_inventory('NEVER_OPENED_MISSING_H5',schema_only=True)
 def test_H5_metadata_only_never_reads_payload(self):
  import h5py
  p=Path(tempfile.mkdtemp(dir=Path(__file__).parent))/'SYNTHETIC.h5'
  with h5py.File(p,'w') as f:f.create_dataset('field_profile/E',data=np.ones((4,3,1,5,3)))
  with patch.object(h5py.Dataset,'__getitem__',side_effect=AssertionError('field payload read')):r=a.h5_schema(p)
  self.assertEqual(r['dataset_count'],1);self.assertEqual(r['field_profile_named_candidates'],['field_profile/E']);self.assertIn('UNVALIDATED',r['direct_extraction_status'])
 def test_selected_plane_permuted_componentmajor_and_flat_rejected(self):
  for bad in [np.ones((3,4,1,3)),np.ones((3,4,3,1)),np.ones(36),np.ones((4,3,3,1))]:
   class FakeBad:
    def eval(self,s):pass
    def getv(self,n):
     if n=='sp_shape':return np.array([4,3,1,2,3])
     if n=='sp_x':return np.arange(4)*1e-6
     if n=='sp_y':return np.array([0.,.2,.6])*1e-6
     if n=='sp_z':return np.array([0.])
     if n=='sp_lam':return np.array([1560e-9,1561e-9])
     if n=='sp_slice':return bad
   coords,shape,selected=a.transfer_selected(FakeBad())
   with self.assertRaises(RuntimeError):selected(0)
 def test_optional_nearby_union_actual_port_grid_synthetic_E(self):
  with np.load(ROOT/'docs/readiness_evidence_20261007/s2_temporal100_task00_ports.npz') as z:ports={k:z[k] for k in z.files}
  lam=ports['p2_lambda'].ravel();x=np.linspace(-60,60,2401)*1e-6;y=np.array([-.4,-.1,.6])*1e-6
  class FakeProfileCAD:
   audit=[]
   def __init__(self):self.k=0;self.reads=[]
   def getresult(self,obj,key):return 1
   def getnamed(self,obj,key):
    if key=='enabled':return 1
    if key=='z span':raise RuntimeError('Optional unsupported property')
    return 0
   def eval(self,script):
    if 'pinch' in script:self.k=int(script.split(',')[-1].split(')')[0])-1
   def getv(self,key):
    if key=='sp_x':return x
    if key=='sp_y':return y
    if key=='sp_z':return np.array([0.])
    if key=='sp_lam':return lam
    if key=='sp_shape':return np.array([len(x),len(y),1,len(lam),3])
    if key=='sp_slice':
     self.reads.append(self.k);width=8*(1+.001*(self.k-250));power=(.025+np.exp(-((x*1e6)/width)**2))*(1+.2*np.cos(2*np.pi*x/.258e-6));e=np.zeros((len(x),len(y),1,3),complex);e[:,:,0,0]=np.sqrt(power[:,None]);return e
    raise AssertionError('full E transfer')
  fake=FakeProfileCAD();out=Path(tempfile.mkdtemp(dir=Path(__file__).parent))
  with contextlib.redirect_stdout(io.StringIO()):r=a.extract(fake,eng,{'result':{}},ports,out,100,nearby=True)
  peaks=[r['profiles'][k]['original_monitor_frequency_index'] for k in ['Tout','modal']];union=sorted({k+d for k in peaks for d in range(-3,4)})
  self.assertEqual(sorted(map(int,r['nearby_profiles'])),union);self.assertEqual(sorted(fake.reads),union);self.assertEqual(len(fake.reads),len(union));self.assertFalse(r['monitor_geometry']['z span']['available'])
  self.assertLess(r['nearby_profiles'][str(union[0])]['production_FWHM_um'],r['nearby_profiles'][str(union[-1])]['production_FWHM_um'])
  with np.load(r['profile_npz']) as z:self.assertFalse(any(k=='E' or k.endswith('__E') for k in z.files));self.assertTrue(np.array_equal(z['monitor_lambda_m'],lam))
 def test_actual_checkpoint_metadata_hash_and_missing_artifacts(self):
  cp=ROOT/'docs/readiness_evidence_20261007/s2_temporal150_fetch_1434/s2_temporal150_task03_original.json';row=json.loads(cp.read_text());self.assertEqual(a.sha(cp),a.PINS[150]);sha_original=a.sha
  def hashes(p):
   if Path(p)==cp:return a.PINS[150]
   for key,d in [('source','fsp_sha256'),('h5','h5_sha256'),('ports_npz','ports_sha256')]:
    if str(p)==row['result'][key]:return row['result'][d]
   return sha_original(p)
  with patch.object(a,'sha',side_effect=hashes):self.assertEqual(a.load_checkpoint(cp,150)['identity']['task'],3)
  with self.assertRaises((FileNotFoundError,RuntimeError)):a.load_checkpoint(cp,150)
  with self.assertRaises(RuntimeError):a.load_checkpoint(cp,100)
 def test_missing_input_main_never_imports_CAD_and_exclusive_output(self):
  import builtins
  original=builtins.__import__
  def importing(name,*args,**kw):
   if name=='lumapi':raise AssertionError('CAD imported on missing input')
   return original(name,*args,**kw)
  root=Path(tempfile.mkdtemp(dir=Path(__file__).parent));out=root/'new_output';args=argparse.Namespace(repo=str(ROOT),lumapi='MISSING_LUMAPI',checkpoint100=str(root/'MISSING.json'),checkpoint150='MISSING',output=str(out),duration='100',schema_only=False)
  with patch('builtins.__import__',side_effect=importing):self.assertEqual(a.run(args),1)
  self.assertEqual(json.loads((out/'report.json').read_text())['status'],'EXTRACTION_FAILED_CLOSED')
  with self.assertRaises(RuntimeError):a.run(args)
if __name__=='__main__':unittest.main(verbosity=2)
