import unittest,sys
from pathlib import Path
import numpy as np
sys.dont_write_bytecode=True
from height_estimators import estimate,UnsupportedPeak,CANDIDATES

class Tests(unittest.TestCase):
    def spectrum(self,fn):
        y=np.full(101,.1);u=np.arange(-7,8,dtype=float);y[43:58]=fn(u);return y

    def test_known_quadratic_height_and_localized_support(self):
        y=self.spectrum(lambda u:.87-.01*(u-.35)**2)
        for name in CANDIDATES:
            r=estimate(y,50,name)
            self.assertAlmostEqual(r['height'],.87,places=12)
            self.assertAlmostEqual(r['offset_bins'],.35,places=11)
            self.assertAlmostEqual(sum(r['weights']),1.,places=12)
            self.assertEqual(len(r['indices']),7 if name=='quadratic7' else 11)
            self.assertTrue(np.all(r['jacobian'][:r['indices'][0]]==0))
            self.assertLess(r['fit_residual_max_abs'],1e-12)
            self.assertLess(r['design_condition_number'],30.)

    def test_envelope_jacobian_real_amplitude_tilt_and_sample_perturbations(self):
        y=self.spectrum(lambda u:.91-.0008*(u-.22)**2+2e-7*(u-.22)**3+1e-8*(u-.22)**4)
        for name in CANDIDATES:
            r=estimate(y,50,name);directions=[]
            amp=np.zeros(101);amp[r['indices']]=1.;directions.append(amp)
            tilt=np.zeros(101);tilt[r['indices']]=np.linspace(-1,1,len(r['indices']));directions.append(tilt)
            impulse=np.zeros(101);impulse[49]=1.;directions.append(impulse)
            for d in directions:
                for h in (1e-6,2e-7):
                    fd=(estimate(y+h*d,50,name)['height']-estimate(y-h*d,50,name)['height'])/(2*h)
                    self.assertAlmostEqual(fd,float(r['jacobian']@d),delta=2e-7)
            self.assertLess(r['fit_residual_max_abs'],1e-12 if name=='quartic11' else 1e-5)

    def test_unsupported_branches_and_invalid_windows_fail_closed(self):
        for name in CANDIDATES:
            for y in (self.spectrum(lambda u:.8+.001*u*u),self.spectrum(lambda u:.8+.001*u),self.spectrum(lambda u:.8-.001*(u-1.25)**2)):
                with self.assertRaises(UnsupportedPeak):estimate(y,50,name)
            for index in (0,2,100,True):
                with self.assertRaises(UnsupportedPeak):estimate(np.ones(101),index,name)
            bad=np.ones(101);bad[50]=np.nan
            with self.assertRaises(UnsupportedPeak):estimate(bad,50,name)
        multipeak=self.spectrum(lambda u:.9-.0001*(u*u-.25)**2)
        with self.assertRaisesRegex(UnsupportedPeak,'exactly one stationary'):estimate(multipeak,50,'quartic11')

    def test_small_white_model_agrees_with_jacobian_l2(self):
        rng=np.random.default_rng(71);y=self.spectrum(lambda u:.9-.0008*(u-.2)**2)
        for name in CANDIDATES:
            r=estimate(y,50,name);values=[];sigma=1e-7
            for _ in range(1000):
                noise=np.zeros(101);noise[r['indices']]=rng.normal(0,sigma,len(r['indices']))
                values.append(estimate(y+noise,50,name)['height']-r['height'])
            ratio=np.std(values,ddof=1)/(sigma*r['jacobian_l2'])
            self.assertTrue(.9<ratio<1.1)

    def test_no_overwrite(self):
        import compare_estimators as compare
        with self.assertRaises(FileExistsError):compare.run(Path.cwd(),Path(__file__).parent)

if __name__=='__main__':unittest.main()
