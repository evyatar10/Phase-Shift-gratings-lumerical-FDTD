import importlib.util,sys,json,base64,hashlib
from pathlib import Path
sys.argv=['readonly','none'];sp=importlib.util.spec_from_file_location('ops','C:/Users/evyat/AppData/Local/Temp/s2_step150_ops_1503.py');o=importlib.util.module_from_spec(sp);sp.loader.exec_module(o)
e=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007')
pre=json.loads(json.loads((e/'length_profiles_preflight_2215.json').read_text())['out'])
assert pre['gui']['rc']==pre['solve']['rc']==pre['queue']['rc']==0 and 'Total of 0 licenses in use' in pre['gui']['out']
b='/home/evyatarrubin/research/bragg_sim_igum';d=b+'/scripts/s2_length_profiles_20261007_2216';out=b+'/results/s2_length_profiles_20261007_2216';wp=b+'/jobs/run_length_profiles_20261007_2216.sh'
source=Path('C:/Users/evyat/AppData/Local/Temp/s2_length_profiles_final_101434')
pins={'extract_length_profiles.py':'bd5577e09d587ef3c921fa4da35de6526b3e60e5afab71dfc91f0c4e534b1eb5','spatial_support.py':'994c3e9757a10b5bd8ea211aaee8425c5d3540203a4da04b0439684163baf6ca'}
files={}
for name,digest in pins.items():
 raw=(source/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==digest;files[d+'/'+name]=base64.b64encode(raw).decode()
old=pre['wrapper'];start=old.index('export LANG=C');end=old.index('export SWEEP_KIND SWEEP_LIST',start)
wrapper='#!/bin/bash\n#SBATCH --job-name=s2_saved_profiles\n#SBATCH --nodes=1\n#SBATCH --output=logs/length_profiles-%A_%a.out\n#SBATCH --error=logs/length_profiles-%A_%a.out\nset -e\nulimit -s unlimited\nWORK_DIR=/home/evyatarrubin/research/bragg_sim_igum\nLUM_HOME=/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261\nLICENSE=1055@132.68.48.51\nINTERCONNECT=2325@132.68.48.51\n'+old[start:end]+f'''
cd "${{WORK_DIR}}"
"${{LUM_HOME}}/python/bin/python" -B -u {d}/extract_length_profiles.py --repo {b}/project --lumapi "${{LUMAPI_PATH}}" --output {out}
'''
assert 'run(' not in wrapper and 'qualify_igum' not in wrapper
Path(__file__).with_suffix('.sh').write_text(wrapper,newline='\n')
files[wp]=base64.b64encode(wrapper.encode()).decode()
code=o.COMMON+f"""
import base64
b=Path({b!r});d=Path({d!r});assert not d.exists() and not Path({out!r}).exists() and not Path({wp!r}).exists()
q=run(['squeue','-u','evyatarrubin','--noheader']);assert q['rc']==0 and not q['out'].strip(),q
d.mkdir()
files={files!r}
for name,data in files.items():
 with Path(name).open('xb') as f:f.write(base64.b64decode(data))
syntax=run(['bash','-n',{wp!r}]);assert syntax['rc']==0,syntax
args=['sbatch','--parsable','--account=acct-lumerical','--partition=part-preempt','--qos=qos-preempt','--array=0%1','--cpus-per-task=8','--mem=64G','--time=00:20:00','--mail-type=NONE','--chdir='+str(b/'jobs'),'--export=ALL,NTFY_TOPIC=',{wp!r}]
test=run(args[:1]+['--test-only']+args[1:]);assert test['rc']==0,test
submission=run(args)
print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),scope='CPU_SAVED_PROFILES_NO_FDTD',queue=q,args=args,test_only=test,submission=submission,output={out!r},uploaded_sha256={{name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in files}})))
"""
r=o.remote('132.68.58.101',code);o.save('length_profiles_dispatch_2216.json',r);assert r['rc']==0,r
print(r['out']);assert json.loads(r['out'])['submission']['rc']==0
