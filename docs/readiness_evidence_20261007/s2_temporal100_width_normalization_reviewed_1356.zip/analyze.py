"""Pinned offline old-auto-stop versus 100ps same-geometry spectra. No physics gate."""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
C = 299792458.0
PINS_SHA = '94b062900bd3765dd4a3ef78543dd6998378720ed429264e5aa7833339d5e919'
RUNNER_SHA = '555f3d13b42c494171e7658cc4263c588ce418e5d937da1497d690824b41d44a'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(ok,msg):
    if not ok: raise ValueError(msg)
def halfheight(f,y):
    f,y=np.asarray(f,float),np.asarray(y,float)
    require(f.ndim==1 and f.shape==y.shape and len(f)>4,'shape')
    require(np.isfinite(f).all() and np.isfinite(y).all(),'nonfinite')
    require((np.diff(f)>0).all() or (np.diff(f)<0).all(),'nonmonotone grid')
    if f[0]>f[-1]: f,y=f[::-1],y[::-1]
    j=int(np.argmax(y)); h=y[j]/2
    peaks=np.flatnonzero((y[1:-1]>y[:-2])&(y[1:-1]>y[2:])&(y[1:-1]>=h))+1
    require(y[j]>0 and len(peaks)==1 and peaks[0]==j,'multipeak/flat/edge unsupported')
    left=np.flatnonzero(y[:j]<h); right=np.flatnonzero(y[j+1:]<h)+j+1
    require(len(left)>0 and len(right)>0,'truncated halfheight')
    l,r=int(left[-1]),int(right[0])
    a=f[l]+(h-y[l])*(f[l+1]-f[l])/(y[l+1]-y[l])
    b=f[r-1]+(h-y[r-1])*(f[r]-f[r-1])/(y[r]-y[r-1])
    return dict(sampled_peak_height=float(y[j]),peak_f_Hz=float(f[j]),half_height=float(h),crossings_f_Hz=[float(a),float(b)],crossings_lambda_nm=[float(C/b*1e9),float(C/a*1e9)],width_GHz=float((b-a)/1e9),width_nm=float((C/a-C/b)*1e9),reference='half of sampled peak; linear crossing interpolation in frequency')
def decompose_ratio(n0,d0,n1,d1):
    inv0,inv1=1/d0,1/d1
    return (n1-n0)*(inv0+inv1)/2,(n0+n1)/2*(inv1-inv0)
def vals(z):
    v=lambda k:np.asarray(z[k]).ravel()
    T=abs(v('p2_T_out')); M=abs(v('p2_S'))**2
    A1=abs(v('p1_a'))**2*np.real(v('p1_N')); A2=abs(v('p2_a'))**2*np.real(v('p2_N'))
    require(np.all(A1>0),'nonpositive incoming amplitude normalization')
    return dict(Tout=T,modal=M,Tin=np.real(v('p1_T_in')),A1=A1,A2=A2,R=T/M,ratio_identity_abs_error=np.max(abs(M-A2/A1)))
def load(evidence):
    evidence=Path(evidence); pinsfile=evidence/'s2_temporal100_artifact_pins_original.json'
    require(sha(pinsfile)==PINS_SHA,'manifest SHA'); pins=json.loads(pinsfile.read_text())
    reviewfile=evidence/'s2_temporal100_review_1339.json'; review=json.loads(reviewfile.read_text())
    old=review['provenance']['old_files']; names=['s2_fdstep_task00','s2_shift30_task02','s2_shift30_task03']; out={}; hashes={pinsfile.name:sha(pinsfile),reviewfile.name:sha(reviewfile)}
    for mode in ['old','100']:
        out[mode]=[]
        for i in range(3):
            name=names[i] if mode=='old' else f's2_temporal100_task{i:02d}'
            cp=evidence/(name+'_original.json'); ports=evidence/(name+'_ports.npz')
            if mode=='old':
                expected_cp=old['center_checkpoint'] if i==0 else old[cp.name]
                expected_ports=old['center_ports'] if i==0 else old[ports.name]
            else:
                expected_cp=pins[f'{i}:checkpoint']['sha256']; expected_ports=pins[f'{i}:ports']['sha256']
            require(sha(cp)==expected_cp and sha(ports)==expected_ports,'artifact hash '+name)
            c=json.loads(cp.read_text())
            if 'ports_sha256' in c['result']: require(c['result']['ports_sha256']==expected_ports,'checkpoint ports binding')
            else: require(mode=='old' and i==0,'missing checkpoint ports hash'); require(sha(ports)==old['center_ports'],'independent pinned old center ports')
            if mode=='100':
                require(c['identity']['code']['s2_temporal_forward.py']==RUNNER_SHA,'runner SHA')
                require(c['identity']['duration_ps']==100 and c['identity']['timing_changes']=={'simulation time':1e-10,'use early shutoff':0},'timing identity')
                require(c['result']['termination']['physical_time_s']==1e-10,'completed duration')
            with np.load(ports,allow_pickle=False) as z: data={k:z[k].ravel().copy() for k in z.files}
            require(all(np.isfinite(a).all() for a in data.values()),'nonfinite saved data')
            v=vals(data)
            for key,metric in [('peak3_tout','Tout'),('peak3_modal','modal')]:
                yy=v[metric]; jj=int(np.argmax(yy)); require(0<jj<len(yy)-1,'peak3 edge')
                a,b,d=yy[jj-1:jj+2]; height=b-(d-a)**2/(8*(a-2*b+d))
                require(abs(height-c['result'][key])<1e-12,'saved peak3 reproduction '+key)
            out[mode].append((c,data,v)); hashes[cp.name]=sha(cp); hashes[ports.name]=sha(ports)
    ref=out['old'][0][1]; p0=np.array(out['old'][0][0]['result']['params'])
    for mode in out:
        for i,(c,z,v) in enumerate(out[mode]):
            require(len(z['p2_f'])==501,'501 grid')
            for k in ['p1_f','p2_f','p1_lambda','p2_lambda']: require(np.array_equal(z[k],ref[k]),'exact grids '+k)
            expected=p0.copy(); expected[149]+=[0,.0625,-.0625][i]
            require(np.array_equal(np.array(c['result']['params']),expected),'point/sign/step')
            require(c['identity']['sign']==[0,1,-1][i],'identity sign')
            if i: require(c['identity']['index']==149,'identity parameter')
            require(v['ratio_identity_abs_error']<2e-14,'observed S21 amplitude ratio not reproduced')
    return out,hashes

def analyze(evidence,dest):
    dest=Path(dest); require(not dest.exists(),'exclusive output directory exists'); 
    data,hashes=load(evidence); dest.mkdir(); f=data['old'][0][1]['p2_f']; wl=data['old'][0][1]['p2_lambda']*1e9
    result=dict(status='DIAGNOSTIC_ONLY_NO_CALIBRATION_OR_CONVERGENCE_PASS',input_sha256=hashes,grid_samples=501,widths={},comparisons={},fixed_bin_spectral_FD={})
    for mode in ['old','100']:
        result['widths'][mode]={k:halfheight(f,data[mode][0][2][k]) for k in ['Tout','modal']}
        result['fixed_bin_spectral_FD'][mode]={k:((data[mode][1][2][k]-data[mode][2][2][k])/.125)[[244,252,260]].tolist() for k in ['Tout','modal']}
    for i,label in enumerate(['nominal','shift30_plus_0.0625nm','shift30_minus_0.0625nm']):
        a,b=data['old'][i][2],data['100'][i][2]; rows=[]
        for j in [244,252,260]:
            num,den=decompose_ratio(a['A2'][j],a['A1'][j],b['A2'][j],b['A1'][j])
            dM=b['modal'][j]-a['modal'][j]; dR=b['R'][j]-a['R'][j]
            rows.append(dict(bin=j,lambda_nm=float(wl[j]),old={k:float(a[k][j]) for k in ['Tout','modal','Tin','R','A1','A2']},new100={k:float(b[k][j]) for k in ['Tout','modal','Tin','R','A1','A2']},delta={k:float(b[k][j]-a[k][j]) for k in ['Tout','modal','Tin','R']},modal_numerator_term=float(num),modal_denominator_term=float(den),Tout_modal_term=float((a['R'][j]+b['R'][j])/2*dM),Tout_ratio_term=float((a['modal'][j]+b['modal'][j])/2*dR)))
        result['comparisons'][label]=dict(fixed_bins=rows,whole_grid_max_abs_change={k:float(np.max(abs(b[k]-a[k]))) for k in ['Tout','modal','Tin']},amplitude_ratio_reproduction_max_abs_error=[float(a['ratio_identity_abs_error']),float(b['ratio_identity_abs_error'])])
    (dest/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(2,2,figsize=(10,7),sharex=True); x=wl-1560.8782189638007; mask=abs(x)<.25
    for col,k in enumerate(['Tout','modal']):
        for mode,label,style in [('old','Earlier auto-stop','--'),('100','100 ps fixed duration','-')]:
            axes[0,col].plot(x[mask],data[mode][0][2][k][mask],style,label=label)
            derivative=(data[mode][1][2][k]-data[mode][2][2][k])/.125
            axes[1,col].plot(x[mask],derivative[mask],style,label=label)
        axes[0,col].set_title('Nominal '+('abs(T_out)' if k=='Tout' else '|S21| squared'))
        axes[0,col].set_ylabel('Transmission (dimensionless)'); axes[0,col].legend(fontsize=9)
        axes[1,col].set_title('shift30 central spectral FD; h = 0.0625 nm')
        axes[1,col].set_ylabel('Derivative per parameter nm'); axes[1,col].set_xlabel('Wavelength minus 1560.878219 nm (nm)')
        for row in range(2): axes[row,col].grid(alpha=.25)
    fig.suptitle('Saved S2 spectra: identical geometry pairs and exact 501-frequency grid',fontsize=12)
    fig.text(.5,.015,'Earlier runs stopped automatically at geometry-dependent durations; no convergence or calibration pass inferred.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.045,1,.95)); fig.savefig(dest/'spectra_comparison.png',dpi=180); plt.close(fig)
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--evidence',required=True); p.add_argument('--output',required=True); a=p.parse_args(); analyze(a.evidence,a.output)
