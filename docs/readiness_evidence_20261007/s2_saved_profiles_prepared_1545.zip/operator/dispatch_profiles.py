"""One explicit reviewed CPU-only saved-field extraction dispatch; new files only."""
import base64,hashlib,importlib.util,json,sys
from pathlib import Path
HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('prior_ops','C:/Users/evyat/AppData/Local/Temp/s2_step150_ops_1503.py')
ops=importlib.util.module_from_spec(spec)
saved_argv=sys.argv;sys.argv=['readonly','none'];spec.loader.exec_module(ops);sys.argv=saved_argv
expected=sys.argv[1]
source=Path('C:/Users/evyat/AppData/Local/Temp/s2_saved_spatial_profiles_noh5_43140f77b35e/extract_saved_spatial_profiles.py').read_bytes()
assert hashlib.sha256(source).hexdigest()==expected
wrapper=(HERE/'run_saved_profiles.sh').read_bytes()
assert hashlib.sha256(wrapper).hexdigest()=='cce7823ea89d856a84563b68fd4f42d2a18a6ddc075045034cff34f8c8784eba'
code=ops.COMMON+f'''
import base64
b=Path('/home/evyatarrubin/bragg_sim_athena')
q=run(['squeue','-u','evyatarrubin']);assert q['rc']==0,q
assert 's2_profi' not in q['out'],'Existing profile job requires reconciliation'
assert hashlib.sha256((b/'project/runners/lumopt2_design/lumopt2_design.py').read_bytes()).hexdigest()=='53108bbd368dd699179ab65029628aa4c4b2d8ad687777f88b82f404a0952569'
directory=b/'scripts/s2_saved_profiles_20261007_1542';directory.mkdir(exist_ok=False)
assert not (b/'results/s2_saved_spatial_profiles_20261007_1542').exists()
src=directory/'extract_saved_spatial_profiles.py';wrap=b/'jobs/run_saved_profiles_20261007_1542.sh'
for p,data in [(src,base64.b64decode({base64.b64encode(source).decode()!r})),(wrap,base64.b64decode({base64.b64encode(wrapper).decode()!r}))]:
 with p.open('xb') as stream:stream.write(data)
assert hashlib.sha256(src.read_bytes()).hexdigest()=={expected!r}
syntax=run(['bash','-n',str(wrap)]);assert syntax['rc']==0,syntax
args=['sbatch','--parsable','--array=0%1','--cpus-per-task=8','--mem=128G','--time=00:30:00','--qos=2h_2g','--partition=l40s-public','--mail-type=NONE','--chdir='+str(b/'jobs'),'--export=ALL,ATHENA_LICENSE=1055@132.68.48.51,ATHENA_INTERCONNECT=2325@132.68.48.51,REQUIRE_GPU=0,KEEP_H5=1,NTFY_TOPIC=',str(wrap)]
test=run(args[:1]+['--test-only']+args[1:]);assert test['rc']==0,test
submission=run(args)
print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),queue=q,syntax=syntax,test_only=test,submission=submission,args=args,source_sha256={expected!r},wrapper_sha256=hashlib.sha256(wrap.read_bytes()).hexdigest(),no_fdtd_solve=True,requested_gpus=0,old_files_overwritten=False)))
'''
result=ops.remote('athena.technion.ac.il',code)
ops.save('s2_saved_profiles_dispatch_1542.json',result)
assert result['rc']==0,result
payload=json.loads(result['out']);print(json.dumps(payload));assert payload['submission']['rc']==0
