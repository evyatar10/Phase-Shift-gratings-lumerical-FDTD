import ast,base64,copy,json,sys,unittest
from pathlib import Path
sys.dont_write_bytecode=True
import compare as c
from collect_body import completion,EvidenceError
HERE=Path(__file__).parent
REPO=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
EV=REPO/'docs/readiness_evidence_20261007'
sys.path.insert(0,str(REPO))
from runners.lumopt2_design import recover_te_s2 as recovery


def item(path,raw):
    return dict(path=path,bytes=len(raw),sha256=c.sha(raw),data=base64.b64encode(raw).decode())


def fixture():
    e=json.loads((HERE/'expected.json').read_text());a=json.loads((EV/'s2_fdstep_task00_original.json').read_text());ports=(EV/'s2_fdstep_task00_ports.npz').read_bytes()
    row=copy.deepcopy(a);row['identity']['reference_checkpoint']=e['reference_path'];row['result']['reference']['path']=e['reference_path']
    for key in ('source','h5','ports_npz'):row['result'][key]=row['result'][key].replace('/work/',e['root']+'/')
    root=e['root']+'/results/diagnose_te_s2_fdstep/results/lumopt2_te_s2_fdstep_diagnostic_20261007';cp=root+'/task_00.json'
    batch=f"Array:      101155[0]\ndevice type readback = 'GPU'\nFDTD threads = 8\nDIAGNOSTIC checkpoint, review required {cp}\nFinished: synthetic test\nExit code: 0\n"
    source=row['result']['source'];log=str(c.PurePosixPath(source).with_name('fwd_default_p0.log'))
    files={'checkpoint':item(cp,json.dumps(row).encode()),'ports':item(row['result']['ports_npz'],ports),'solver_log':item(log,e['athena_termination']['tail'].encode()),'batch_log':item(e['root']+'/jobs/logs/lum_array-101155_0.out',batch.encode()),'tasklist':item(e['root']+'/data/sweep_list_diagnose_te_s2_fdstep_qualification.txt',b'0\n')}
    pins={key:dict(path=row['result'][key],bytes=files['ports']['bytes'] if key=='ports_npz' else 1,sha256=files['ports']['sha256'] if key=='ports_npz' else '0'*64) for key in ('source','h5','ports_npz')}
    b=dict(status='COMPLETION_EVIDENCE_COLLECTED_REVIEW_REQUIRED',job='101155',task=0,no_solve=True,
        accounting=dict(exit_code=0,out='101155_0|COMPLETED|0:0|\n',err=''),control=dict(exit_code=0,out='',err=''),
        completion_evidence='sacct_exact_array_task',files=files,artifact_hashes=pins,current_code=e['identity']['code'],
        lumapi_sha256=e['lumapi_sha256'],vendor_sources={k:{'sha256':v} for k,v in e['vendor_sources'].items()},limitations=[])
    return b,e,a,c.arrays(ports)


class Tests(unittest.TestCase):
    def test_actual_athena_arithmetic_roundtrip_as_explicit_synthetic_receipt(self):
        b,e,a,p=fixture();r,_=c.analyze(b,e,a,p,recovery.score)
        self.assertTrue(r['no_automatic_qualification'])
        self.assertEqual(r['spectra']['Tout']['max_abs_difference'],0.)
        self.assertTrue(all(v['signed_delta']==0 for v in r['scalar_differences'].values()))
        self.assertIn('UNAVAILABLE',r['actual_mesh_coordinates'])
    def test_accounting_failure_does_not_mean_completion_but_exact_control_can_establish_it(self):
        bad=dict(exit_code=1,out='',err='slurmdbd down');empty=dict(exit_code=0,out='',err='')
        with self.assertRaises(EvidenceError):completion(bad,empty)
        ctl=dict(exit_code=0,out='JobId=123 ArrayJobId=101155 ArrayTaskId=0 JobState=COMPLETED ExitCode=0:0',err='')
        self.assertIn('scontrol',completion(bad,ctl))
        ctl['out']=ctl['out'].replace('COMPLETED','RUNNING')
        with self.assertRaises(EvidenceError):completion(bad,ctl)
    def test_wrong_array_task_or_exit_does_not_establish_completion(self):
        empty=dict(exit_code=0,out='',err='')
        for text in ('101155_1|COMPLETED|0:0|','101155_0|COMPLETED|1:0|','101155|COMPLETED|0:0|'):
            with self.assertRaises(EvidenceError):completion(dict(exit_code=0,out=text,err=''),empty)
    def test_full_point_spec_mutation_and_grid_mutation_refuse(self):
        b,e,a,p=fixture();row=json.loads(c.decode(b['files']['checkpoint']))
        for field in ('point','spec'):
            changed=copy.deepcopy(row)
            if field=='point':changed['identity']['point'][29]+=.5
            else:changed['identity']['spec']['dp_tooth_nm']=.5
            with self.assertRaises(EvidenceError):c.family(changed,e)
        q={k:v.copy() for k,v in p.items()};q['p2_lambda'].ravel()[252]+=1e-18
        with self.assertRaises(EvidenceError):c.grid(q,p)
    def test_mutated_original_transport_refuses(self):
        b,e,a,p=fixture();b['files']['ports']['sha256']='0'*64
        with self.assertRaises(EvidenceError):c.analyze(b,e,a,p,recovery.score)
    def test_solver_incomplete_and_reused_checkpoint_refuse(self):
        with self.assertRaises(EvidenceError):c.termination('Completed 1 iterations, or 1e-12s of Simulation Time')
        b,e,a,p=fixture();text=c.decode(b['files']['batch_log'])+b'REUSED diagnostic checkpoint\n';b['files']['batch_log']=item(b['files']['batch_log']['path'],text)
        with self.assertRaises(EvidenceError):c.analyze(b,e,a,p,recovery.score)
    def test_remote_AST_no_CAD_project_import_or_solver_dispatch(self):
        tree=ast.parse((HERE/'collect_remote.py').read_text())
        imported=[];commands=[]
        for node in ast.walk(tree):
            if isinstance(node,ast.Import):imported += [x.name for x in node.names]
            elif isinstance(node,ast.ImportFrom):imported.append(node.module)
            elif isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='command':commands.append(ast.literal_eval(node.args[0].elts[0]))
            elif isinstance(node,ast.Attribute):self.assertNotIn(node.attr,('main','run_forward','runjobs','FDTD','make_project','set_fwd','save','load'))
        self.assertTrue(set(imported)<=set(('base64','datetime','hashlib','json','re','subprocess','pathlib')))
        self.assertEqual(sorted(commands),['sacct','scontrol','squeue'])


if __name__=='__main__':unittest.main(verbosity=2)
