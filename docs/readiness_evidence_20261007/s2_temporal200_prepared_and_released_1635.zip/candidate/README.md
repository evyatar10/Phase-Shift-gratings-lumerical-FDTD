# Fixed200ps diagnostic preparation (not released)

NEW TEMP only. Three forwards: task0 exact recovered nominal te_point (identity index29, no delta), task1 shift30 index149 +0.0625nm, task2 index149 -0.0625nm. All296 parameters, N98/side, free60/side and bare TE are retained. No optimizer, calibration fit or coefficient installation. Existing global gradient gate stays FAILED.

The frozen150 helpers are imported, never edited or assigned new globals. New200 result/control/termination validators explicitly require200ps, early shutoff OFF, divergence checking ON and optimization_dft OFF; source/ports501, mesh/PVA and all other controls stay inherited. Full field_profile remains enabled as in the temporal family. New outputs preserve exclusive FSP/H5/log/port spectra NPZ plus byte-pinned atomic checkpoints. Cold resume validates full identity, source/vendor/control/termination hashes and reproduced port scores before returning without CAD or solve.

Ancestry is exact: original150 tasks3/4/5 AND completed150 +/-0.125nm tasks0/1, including both historical review markers, CP byte SHA, FSP/H5/log/ports hashes, exact501 grids, mapped points, numerical specs, source and vendor identities. No dependency is auto-launched. Each task invocation re-reads the saved artifacts (including potentially large H5 hashes); this is I/O overhead, not extra FDTD. Windows vendor bytes differ from recorded Athena bytes: offline metadata tests explicitly substitute the recorded vendor map only for those tests. Production vendor comparison remains exact, and local hidden CAD is not Athena identity evidence.

New review marker is mandatory and byte-pinned. --review-template returns NOT_REVIEWED/allowed_tasks=[]; it cannot approve a run. Lead must bind all scope fields and supply substantive review text, exact status APPROVED_FOR_THREE_FIXED200PS_CENTER_SHIFT30_STEP00625_FORWARDS_ONLY and allowed_tasks=[0,1,2]. There is no default approval or future task.

Environment prefix S2_TEMP200:
- REPO: repository root (otherwise cwd).
- OUTPUT_ROOT: /work/results/diagnose_te_s2_temporal200/results/s2_shift30_temporal200_20261007.
- PARENT150_ROOT: /work/results/diagnose_te_s2_temporal/results/s2_shift30_temporal_20261007.
- PARENT150_MARKER: /work/data/s2_temporal150_review_20261007_1257.json (6cc6d9fd...).
- STEP150_ROOT: /work/results/diagnose_te_s2_step150/results/s2_shift30_step150_20261007.
- STEP150_MARKER: /work/data/s2_step150_review_20261007_1507.json (8cc8e9da...).
- REVIEW_MARKER and REVIEW_SHA256: explicitly required NEW reviewed marker path and byte SHA.
- KEEP_H5=1 before any fresh CAD/solve; not required for validated completed reuse.

Roots cannot overlap historical outputs. Parent paths may be configured but still must satisfy immutable historical metadata; copied/relabelled checkpoints are not accepted. Original150 CP SHA task3=a0ff55eacaa52e00a2aab17dcc43d0e5fff9a72566e15da371ff25279c172663; completed step150 SHA task0=8d49988494fd09323821029a9e88adc96b06dec9e586da032278cb2e8c7dd5e6, task1=5d88d683852591d48d0a06b62ba763d3483c035be42d4f2467dbde591e5f692f. Full constants and input hashes are in source/manifest.

Cross-run comparison permits ONLY recorded Port_1 phase roundoff <=2 ordered float64 ULP, finite scalar, exact signed zero, raw values retained, introduction cause unknown. This is an arithmetic reuse check, not a physics/noise tolerance. Other port/source/timing/mesh properties remain exact; existing bounded persisted geometry roundoff convention is unchanged. Intentional full mapped geometry changes are verified independently.

Verification: ten focused offline groups exit0 (test_temporal200.py/tests.log), covering actual ancestor bytes/metadata and negative identities,200 mapping/bounds/spec, missing/wrong stage/family/source/ancestry reviews, incompatible completed CP, score/NPZ tamper, cold reuse with CAD/solve forbidden, source/termination controls, exact grids, phase0/1/2ULP and >2ULP/other property negatives, no-CAD import, tasklist and AST. Synthetic FSP/H5/log fixtures are explicitly NOT simulation evidence. No broad13 rerun.

Bounded local hidden CAD: hidden_cad/check_hidden_cad.py exit0. Actual preserved local prepared CAD base loaded with hide=True/raw FDTD class; all3 points mapped exactly, baseline source/grid/locked mesh unchanged,200ps/early-off/divergence-on/DFT-off saved and reloaded under existing persistence checks. Four solve paths blocked. Original saved base, runner, FDTD class and constructor preserved. No local FDTD and no remote actions. This checks build mechanics, not measured200ps output or Athena vendor compatibility.

Discovery/checks:
```
python -B <packet>/s2_temporal200_forward.py --tasklist
python -B <packet>/test_temporal200.py
```
After parent review/integration ONLY, signature main(task_idx) matches athena/scripts/athena_run_one.py:368-380; N_TASKS=3 and IS_HELPER=True match discovery. Explicit --lumopt2-design=runners.lumopt2_design.s2_temporal200_forward --array-tasks=0,1,2 is compatible after parent registers the module. IS_HELPER hides interactive menus. This is not authorization to upload or dispatch.

Parent planning estimate: ~70min per fixed200ps A100 forward,8CPU/256G; three solves. Based on actual150 durations/scaled200 planning, not measured200 runtime. Licence/quota/queue/QOS preflight, remote source/vendor identity and substantive lead review remain before dispatch. No convergence/pass threshold is inferred.

candidate_vs_step150.diff is a review comparison only, not an instruction to patch frozen150 source. manifest.json binds final runner/tests/README/CAD evidence, frozen helpers and actual raw inputs.
