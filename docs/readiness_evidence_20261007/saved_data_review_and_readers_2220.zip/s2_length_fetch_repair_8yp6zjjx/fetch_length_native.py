"""Read-only completion protocol for IGUM101434. No SSH, CAD, solve or scheduler writes.

--prepare creates a new LOCAL command packet. Its emitted script is executed only
by the lead operator, using the native bundled Python/environment. --ingest checks
that captured payload and exclusively publishes original checkpoint/port bytes.
"""
import argparse,base64,copy,datetime,hashlib,io,json,math,os,re,subprocess,sys
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
JOB='101434'
ENV_SHA='61d9134df698b49eb3ca2bf05f3fc99244a4498010a5363dfcda4ca24f74eec0'
MARKER_SHA='d824bf5632c52defad99bf95be170d4921b011fea9dc455a50fdc29fb878f23a'
GRID_SHA='9aaaee8efe7d6017869b02705895ba1342c53175870dbcf46c8892b54241d6f4'
LANE_SHA='9076fb3d693604048df40f465d0987310651ebb92c39105979aa43a12a662490'
CP_REFERENCE_SHA='a0ff55eacaa52e00a2aab17dcc43d0e5fff9a72566e15da371ff25279c172663'
PROFILE_REFERENCE_SHA='01a6fe6540c7cf903de67cecc42a89c6318983301364b679b9da0870dede595a'
QUAL='FINITE_DURATION_LENGTH_SENSITIVITY_ONLY_NO_TEMPORAL_MESH_OR_GRADIENT_PASS'
APPROVAL='APPROVED_FOR_TWO_IGUM_FIXED150PS_N98_N80_FIXED_DOMAIN_FORWARDS_ONLY'
FAMILY='s2_length_N98_N80_fixed150_20261007'
CANON_BASE='/research/amir.r/evyatarrubin/bragg_sim_igum'
CANON_ROOT=CANON_BASE+'/results/diagnose_te_s2_length/results/'+FAMILY
CANON_MARKER=CANON_BASE+'/data/s2_length_native_20261007/review_two_forwards.json'
MAX_FILE_BYTES=64*1024*1024

def need(ok,message):
 if not ok:raise RuntimeError(message)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def raw(path):return Path(path).read_bytes()
def semantic(item):return digest(json.dumps(item,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def canonical(value):
 need(isinstance(value,str) and value.startswith('/') and '\\' not in value and not any(x in ('','.','..') for x in value.split('/')[1:]),'Noncanonical server path')
 need(str(PurePosixPath(value))==value,'Noncanonical server path');return PurePosixPath(value)
def load_pinned(path,pin):
 b=raw(path);need(digest(b)==pin,'Raw byte pin mismatch: '+str(path));return json.loads(b)
def context(job,env_path,marker_path,grid_path):
 need(type(job) is str and job==JOB,'Explicit actual released job101434 required')
 env=load_pinned(env_path,ENV_SHA);marker=load_pinned(marker_path,MARKER_SHA);grid=load_pinned(grid_path,GRID_SHA)
 need(marker['output_root']==CANON_ROOT and marker['task_map']==[98,80] and marker['allowed_tasks']==[0,1] and marker['status']==APPROVAL and marker['qualification']==QUAL,'Wrong released family/task scope')
 need(marker['code']['s2_length_fixed150.py']==LANE_SHA,'Wrong released runner')
 scope={k:v for k,v in marker.items() if k not in ('status','lead_verdict')}
 review=dict(path=CANON_MARKER,sha256=MARKER_SHA,lead_verdict=marker['lead_verdict'],scope_sha256=semantic(scope),allowed_tasks=[0,1])
 return dict(job_id=job,env=env,marker=marker,grid=grid,scope=scope,review=review)

def completion(accounting,task,log,env):
 """Live failure/running evidence always vetoes logs. Missing accounting isn't completion."""
 need(type(task) is int and task in (0,1),'Wrong completion task')
 successes=[];unavailable=[];sacct=accounting['sacct'];need(type(sacct['rc']) is int,'Missing sacct exit code')
 rows=[]
 if sacct['rc']==0:
  for line in sacct['out'].splitlines():
   fields=line.strip().split('|')
   if fields and fields[0]==JOB+'_'+str(task):
    need(len(fields)>=3,'Malformed exact sacct task record');rows.append(fields[:3])
  need(len(rows)<=1,'Duplicate exact sacct task records')
 if rows:
  need(rows[0][1]=='COMPLETED' and rows[0][2]=='0:0','Exact sacct task not COMPLETED0:0');successes.append('sacct')
 else:unavailable.append('sacct: error or no exact task record')
 ctl=accounting['scontrol'][str(task)];need(type(ctl['rc']) is int,'Missing scontrol exit code')
 if ctl['rc']==0:
  fields=dict(re.findall(r'(\w+)=([^\s]+)',ctl['out']))
  need(fields.get('ArrayJobId')==JOB and fields.get('ArrayTaskId')==str(task),'Wrong scontrol array identity')
  need(fields.get('JobState')=='COMPLETED' and fields.get('ExitCode')=='0:0','Exact scontrol task not COMPLETED0:0');successes.append('scontrol')
 else:unavailable.append('scontrol: rc'+str(ctl['rc'])+' '+ctl.get('err','').strip())
 # Even when live accounting is available, require the last wrapper segment to
 # bind this CP publication to the exact dispatched array task, not just a path.
 starts=list(re.finditer(r'^Array:\s+(\d+)\[(\d+)\]\s*$',log,re.M))
 need(bool(starts),'Missing wrapper array header');last=starts[-1]
 need(last.group(1)==JOB and last.group(2)==str(task),'Last wrapper segment belongs to other job/task')
 segment=log[last.start():]
 def header(name,value):need(re.search(r'^'+re.escape(name)+r':\s*'+re.escape(value)+r'\s*$',segment,re.M) is not None,'Wrong wrapper '+name)
 header('SWEEP_KIND','lumopt2_design');header('SWEEP_INDEX',str(task));header('SWEEP_LIST',env['SWEEP_LIST'])
 checkpoint=CANON_ROOT+f'/task_{task:02d}.json'
 published=list(re.finditer(r'^New length diagnostic; no convergence pass (\S+)\s*$',segment,re.M))
 need(len(published)==1 and published[0].group(1)==checkpoint,'Missing exact new checkpoint publication')
 finished=list(re.finditer(r'^Finished:\s+(.+)\s*$',segment,re.M));exits=list(re.finditer(r'^Exit code:\s*(\d+)\s*$',segment,re.M))
 need(len(finished)==1 and len(exits)==1 and exits[0].group(1)=='0' and published[0].end()<finished[0].start()<exits[0].start(),'Wrapper did not finish0 after publication')
 return dict(mode='LIVE_COMPLETED0:0' if successes else 'LIVE_ACCOUNTING_UNAVAILABLE_WRAPPER_PLUS_COLD_CP_AND_TERMINAL_ENGINE',live_sources=successes,live_accounting_unavailable=unavailable,wrapper_sha256=digest(log.encode()),task=task)

def blocked(*args,**kwargs):raise RuntimeError('READ_ONLY_FETCH_FORBIDS_CAD_BUILD_SAVE_SOLVE_PUBLICATION')
def install_blocks(lane):
 for module,names in [(lane,['main','forward_only','build_only','build_case','profile_metadata']),(lane.eng,['make_project','import_lumopt2']),(lane.base,['main','forward_only']),(lane.recovery,['checkpoint']),(lane.build,['configure','restore_retained_outer_and_feed_joins'])]:
  for name in names:
   if hasattr(module,name):setattr(module,name,blocked)

class NoCADImports:
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in {'lumapi','bragg_device','lumopt2','lumslurm'}:
   raise RuntimeError('READ_ONLY_FETCH_FORBIDS_CAD_IMPORT: '+fullname)
  return None

def install_metadata_code(lane,repo,expected):
 """Hash frozen source bytes without diag.identity's eager builder/API import."""
 repo=Path(repo).resolve()
 need(Path(lane.__file__).resolve()==repo/'runners/lumopt2_design/s2_length_fixed150.py','Imported lane source path differs')
 def code():
  actual={}
  for name in expected:
   need(Path(name).name==name and name.endswith('.py'),'Invalid released source basename')
   choices=[repo/name,repo/'runners/lumopt2_design'/name]
   found=[p for p in choices if p.is_file()]
   need(len(found)==1,'Released source path unavailable/ambiguous: '+name)
   actual[name]=digest(raw(found[0]))
  need(actual==expected,'Changed released source bytes')
  return actual
 code()
 # Equivalent prior.dependency_hashes output: diag.identity code's nine
 # sources, then prior/config/firstwave. Preserve original base/lane wrappers.
 names=['diagnose_te_s2_fdstep.py','lumopt2_design.py','recover_te_s2.py',
        'validate_te.py','campaign_te_s2.py','bragg_device.py',
        'simulation_config.py','sim_helpers.py','v3_step.py',
        's2_shift30_convergence.py','config.py','s2_fdhalf_classes.py']
 need(set(names).issubset(expected),'Incomplete released diagnostic dependencies')
 def dependency_hashes():
  actual=code()
  return {name:actual[name] for name in names}
 lane.base.prior.dependency_hashes=dependency_hashes
 need(lane.code()==expected,'Equivalent nested code map differs')
 need(not any(n.split('.')[0] in {'lumapi','bragg_device','lumopt2','lumslurm'} for n in sys.modules),'CAD modules already loaded')
 guard=NoCADImports();sys.meta_path.insert(0,guard)
 return guard

def query(argv):
 try:
  r=subprocess.run(argv,capture_output=True,text=True,timeout=30,check=False)
  return dict(rc=r.returncode,out=r.stdout,err=r.stderr,argv=argv)
 except (OSError,subprocess.TimeoutExpired) as exc:return dict(rc=127,out='',err=type(exc).__name__+': '+str(exc),argv=argv)
def snapshot(paths):
 out={}
 for value in sorted(set(str(x) for x in paths)):
  p=Path(value);need(p.is_file(),'Missing retained artifact '+value)
  stat=p.stat();h=hashlib.sha256()
  with p.open('rb') as f:
   for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
  out[value]=dict(sha256=h.hexdigest(),bytes=stat.st_size,mtime_ns=stat.st_mtime_ns)
 return out
def artifact_paths(r):
 paths=[r['source'],r['h5'],r['ports_npz'],str(PurePosixPath(r['source']).with_name('fwd_default_p0.log')),r['build_case']['immutable_setup_fsp'],r['build_case']['native_saved_format_construction']['preparatory_fsp']]
 if r['task']==1:
  anchor=r['fresh_N98_anchor'];paths += [anchor['source'],anchor['native_saved_format_construction']['preparatory_fsp']]
 return paths
def remote_capture(ctx):
 """Only called by explicit --remote operator command, never by prepare/ingest."""
 need(sys.platform.startswith('linux'),'Remote capture requires native Linux')
 os.environ.update(ctx['env']);sys.path.insert(0,ctx['env']['S2_LEN_REPO'])
 import config
 config.LUMAPI_PATH=ctx['env']['LUMAPI_PATH']
 config.BASE_SAVE_DIR=str(Path(ctx['env']['S2_LEN_NATIVE_BASE'])/'results')
 config.NEFF_DATA_PATH=str(Path(ctx['env']['S2_LEN_NATIVE_BASE'])/'data/FDE_sweep_results.mat');config.USE_GPU=True
 from runners.lumopt2_design import s2_length_fixed150 as lane
 install_blocks(lane)
 install_metadata_code(lane,ctx['env']['S2_LEN_REPO'],ctx['marker']['code'])
 need('lumapi' not in sys.modules,'Unexpected CAD API import')
 paths=lane.native_paths();need(str(paths['root'])==CANON_ROOT and str(paths['marker'])==CANON_MARKER,'Wrong resolved native paths')
 need(lane.code()==ctx['marker']['code'] and lane.base.vendor_sources()==ctx['marker']['vendor_api_sha256'],'Changed released code/vendor')
 # BOTH CPs must exist before even metadata-only cold reference/identity calls.
 cps=[paths['root']/f'task_{t:02d}.json' for t in (0,1)]
 need(all(p.is_file() for p in cps),'Both original task checkpoints required; no fallback solve')
 accounting=dict(sacct=query(['sacct','-j',JOB,'--format=JobID,State,ExitCode','-n','-P']),scontrol={str(t):query(['scontrol','show','job',JOB+'_'+str(t),'-o']) for t in (0,1)})
 logs={str(t):(paths['host']/f'jobs/logs/lum_array-{JOB}_{t}.out').read_text() for t in (0,1)}
 completions={str(t):completion(accounting,t,logs[str(t)],ctx['env']) for t in (0,1)}
 reference=lane.load_reference(paths)
 records=[];files=[]
 retained=[*cps,paths['cp'],paths['profile'],paths['grid'],paths['marker'],paths['api']]
 for name in ctx['marker']['code']:
  choices=[paths['repo']/name,paths['repo']/'runners/lumopt2_design'/name]
  found=[p for p in choices if p.is_file()];need(len(found)==1,'Released source path unavailable/ambiguous: '+name);retained+=found
 for name in ctx['marker']['vendor_api_sha256']:retained.append(paths['api'].parent/name)
 for t in (0,1):
  b=raw(cps[t]);need(len(b)<=MAX_FILE_BYTES,'Checkpoint exceeds transfer limit')
  cp=json.loads(b);retained+=artifact_paths(cp['result']);retained.append(paths['host']/f'jobs/logs/lum_array-{JOB}_{t}.out')
 before=snapshot(retained)
 for t in (0,1):
  review=lane.reviewed(t,paths,reference);ident=lane.identity(t,paths,reference,review)
  result=lane.recovery.read_checkpoint(cps[t],ident);need(result is not None,'Missing cold checkpoint')
  lane.verify_result(result,t,paths,reference,review)
  records.append(dict(task=t,identity_sha256=semantic(ident),profile_metadata_sha256=result['profile_metadata']['metadata_sha256'],completion=completions[str(t)]))
  for kind,p in [('checkpoint',cps[t]),('ports',Path(result['ports_npz']))]:
   b=raw(p);need(len(b)<=MAX_FILE_BYTES,'Transfer exceeds limit')
   files.append(dict(task=t,kind=kind,path=str(p),sha256=digest(b),bytes=len(b),base64=base64.b64encode(b).decode()))
 need(snapshot(retained)==before,'Retained input/artifact changed during cold validation')
 need('lumapi' not in sys.modules,'Cold capture unexpectedly imported CAD API')
 need(lane.code()==ctx['marker']['code'] and lane.base.vendor_sources()==ctx['marker']['vendor_api_sha256'],'Cold validation source/vendor changed')
 return dict(schema=1,status='NATIVE_PAIR_COLD_VERIFIED_READ_ONLY',job_id=JOB,at=datetime.datetime.now(datetime.timezone.utc).isoformat(),env_sha256=ENV_SHA,marker_sha256=MARKER_SHA,helper_sha256=ctx['helper_sha256'],accounting=accounting,wrapper_logs=logs,records=records,files=files,retained_artifacts=before,all_inputs_preserved=True,no_CAD=True,no_solve=True,qualification=QUAL)

def verify_payload(payload,ctx,reference,lane,expected_helper_sha):
 import numpy as np
 need(payload['schema']==1 and payload['status']=='NATIVE_PAIR_COLD_VERIFIED_READ_ONLY' and payload['job_id']==JOB and payload['env_sha256']==ENV_SHA and payload['marker_sha256']==MARKER_SHA and payload['helper_sha256']==expected_helper_sha,'Wrong capture identity')
 need(payload['all_inputs_preserved'] is True and payload['no_CAD'] is True and payload['no_solve'] is True and payload['qualification']==QUAL,'Wrong capture qualification')
 need([r['task'] for r in payload['records']]==[0,1] and len(payload['files'])==4,'Wrong exact task/artifact set')
 decoded={}
 for f in payload['files']:
  key=(f['task'],f['kind']);need(type(f['task']) is int and f['task'] in (0,1) and f['kind'] in ('checkpoint','ports') and key not in decoded,'Wrong/duplicate transfer artifact')
  b=base64.b64decode(f['base64'],validate=True);need(0<len(b)<=MAX_FILE_BYTES and len(b)==f['bytes'] and digest(b)==f['sha256'],'Original transfer hash/size mismatch')
  canonical(f['path']);decoded[key]=(f,b)
 pins=payload['retained_artifacts'];need(bool(pins),'Missing preservation inventory')
 def pinned(path,sha):need(path in pins and pins[path]['sha256']==sha and pins[path]['bytes']>0,'Missing/changed retained release input: '+path)
 pinned(CANON_MARKER,MARKER_SHA)
 for path_key,sha_key in [('checkpoint_metadata','checkpoint_sha256'),('profile_metadata','profile_sha256'),('port_grid_metadata','port_grid_sha256')]:pinned(ctx['marker']['reference'][path_key],ctx['marker']['reference'][sha_key])
 for name,sha in ctx['marker']['code'].items():
  choices=[ctx['marker']['repo']+'/'+name,ctx['marker']['repo']+'/runners/lumopt2_design/'+name]
  found=[path for path in choices if path in pins];need(len(found)==1,'Missing/ambiguous retained source: '+name);pinned(found[0],sha)
 api_dir=str(canonical(ctx['marker']['API_path']).parent)
 for name,sha in ctx['marker']['vendor_api_sha256'].items():pinned(api_dir+'/'+name,sha)
 for t in (0,1):
  rec=payload['records'][t];proof=completion(payload['accounting'],t,payload['wrapper_logs'][str(t)],ctx['env']);need(rec['completion']==proof,'Completion evidence differs')
  pinned(CANON_BASE+f'/jobs/logs/lum_array-{JOB}_{t}.out',digest(payload['wrapper_logs'][str(t)].encode()))
  f,b=decoded[(t,'checkpoint')];need(f['path']==CANON_ROOT+f'/task_{t:02d}.json','Wrong checkpoint path')
  cp=json.loads(b);i,r=cp['identity'],cp['result'];spec=ctx['marker']['specs'][str(t)]
  expected_i=dict(schema=1,task=t,physical_N=(98,80)[t],point=ctx['marker']['point'],spec=spec,duration_ps=150.,task_map=[98,80],scope=ctx['scope'],parent_review=ctx['review'],overall_gradient_gate='FAILED_UNCHANGED')
  need(type(i['task']) is int and type(r['task']) is int and i==expected_i and semantic(i)==rec['identity_sha256'],'Exact cold identity mismatch')
  need(r['task']==t and r['physical_N']==(98,80)[t] and r['duration_ps']==150. and r['params']==i['point'] and r['parent_review']==ctx['review'] and r['vendor_api_sha256']==ctx['marker']['vendor_api_sha256'] and r['qualification']==QUAL and r['overall_gradient_gate']=='FAILED_UNCHANGED','Result family mismatch')
  lane.validate_case(r['build_case'],reference,(98,80)[t]);lane.validate_profile_metadata(r['profile_metadata'],reference)
  if t==1:
   lane.validate_case(r['fresh_N98_anchor'],reference,98);need(r['pair_comparison']==lane.compare_pair(r['fresh_N98_anchor'],r['build_case']),'Physical pair mismatch')
  else:need(r['fresh_N98_anchor'] is None and r['pair_comparison'] is None,'Extra nominal case')
  pf,pb=decoded[(t,'ports')];ports=canonical(pf['path']);source=canonical(r['source']);h5=canonical(r['h5']);root=canonical(CANON_ROOT)
  need(ports.is_relative_to(root) and ports.parent.name.startswith(f'task_{t:02d}_') and ports.name=='ports.npz' and r['ports_npz']==pf['path'] and source==ports.parent/'fwd_default.fsp' and h5==source.with_suffix('')/'fwd_default_output.h5','Wrong exclusive artifact family')
  need(r['ports_sha256']==pf['sha256'] and r['build_case']['source']==r['source'],'Port/prepared source binding differs')
  meta=r['profile_metadata'];need(meta['source']==r['source'] and meta['h5']==r['h5'] and meta['fsp_sha256']==r['fsp_sha256'] and meta['h5_sha256']==r['h5_sha256'] and meta['metadata_sha256']==semantic({k:v for k,v in meta.items() if k!='metadata_sha256'})==rec['profile_metadata_sha256'],'Profile source/metadata binding differs')
  termination=r['termination'];dt=r['build_case']['reloaded']['timing']['dt']
  need(type(dt) in (int,float) and math.isfinite(dt) and dt>0 and termination['status']==1 and termination['requested_time_s']==150e-12 and math.isfinite(termination['physical_time_s']) and abs(termination['physical_time_s']-150e-12)<=dt and termination['reason']=='completed_full_simulation_time','Incomplete/nonfinite terminal engine time')
  need(r['resource']['device_type']=='GPU' and float(r['resource']['threads'])>0,'Wrong resource metadata')
  with np.load(io.BytesIO(pb),allow_pickle=False) as z:arrays={k:z[k] for k in z.files}
  need(all(np.isfinite(v).all() for v in arrays.values()),'Nonfinite spectra');scores=lane.recovery.score(arrays)
  need(all(math.isfinite(r[k]) and abs(float(scores[k])-float(r[k]))<=1e-12 for k in lane.diag.METRICS),'Port scores do not reproduce')
  for k,g in ctx['grid']['grids'].items():need(list(arrays[k].shape)==g['shape'] and np.array_equal(arrays[k].ravel(),g['values']),'Exact port grid changed:'+k)
  for path in [f['path']]+artifact_paths(r):
   p=canonical(path);need(p.is_relative_to(root),'Retained artifact escaped result root');need(path in pins and pins[path]['bytes']>0 and re.fullmatch('[a-f0-9]{64}',pins[path]['sha256']) is not None,'Missing retained artifact byte pin')
  for path,key in [(f['path'],f['sha256']),(r['source'],r['fsp_sha256']),(r['h5'],r['h5_sha256']),(r['ports_npz'],r['ports_sha256']),(termination['log'],termination['log_sha256'])]:need(pins[path]['sha256']==key,'Retained artifact digest mismatch')
  need(termination['log']==str(source.with_name('fwd_default_p0.log')) and termination['recorded_dt_s']==dt,'Terminal log/dt binding differs')
  setup=canonical(r['build_case']['immutable_setup_fsp']);need(setup==ports.parent/'prepared_forward_before_solve.fsp' and pins[str(setup)]['sha256']==r['build_case']['setup_fsp_sha256'],'Prepared FSP binding changed')
  for c in [r['build_case']]+([r['fresh_N98_anchor']] if t==1 else []):
   pre=c['native_saved_format_construction'];need(canonical(pre['preparatory_fsp']).is_relative_to(ports.parent) and pins[pre['preparatory_fsp']]['sha256']==pre['sha256'],'Preparatory FSP changed')
  if t==1:need(canonical(r['fresh_N98_anchor']['source']).parent==ports.parent/'fresh_N98_anchor' and pins[r['fresh_N98_anchor']['source']]['sha256']==r['fresh_N98_anchor']['setup_fsp_sha256'],'Fresh N98 anchor binding differs')
 return decoded

def write_new(path,b):
 with Path(path).open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def new_dir(path):
 p=Path(path);need(p.is_absolute() and not p.exists(),'NEW absolute local output directory required');p.mkdir(parents=True,exist_ok=False);return p
def publish(payload,ctx,reference,lane,outdir,expected_helper_sha):
 # Validate everything before creating output. Never overwrite partial attempts.
 decoded=verify_payload(payload,ctx,reference,lane,expected_helper_sha);out=new_dir(outdir);manifest=[]
 for (task,kind),(f,b) in sorted(decoded.items()):
  name=f'task_{task:02d}.json' if kind=='checkpoint' else f'task_{task:02d}_ports.npz';write_new(out/name,b);manifest.append(dict(file=name,source_path=f['path'],sha256=digest(b),bytes=len(b)))
 receipt={k:v for k,v in payload.items() if k not in ('files','wrapper_logs')};receipt['files']=manifest
 receipt['wrapper_log_hashes']={k:digest(v.encode()) for k,v in payload['wrapper_logs'].items()}
 rb=json.dumps(receipt,indent=2,allow_nan=False).encode();write_new(out/'receipt.json',rb)
 mb=json.dumps(dict(schema=1,job_id=JOB,receipt_sha256=digest(rb),files=manifest,qualification=QUAL),indent=2).encode();write_new(out/'manifest.json',mb)
 return dict(status='ORIGINAL_CP_PORT_BYTES_EXCLUSIVELY_PUBLISHED',output=str(out),receipt_sha256=digest(rb),manifest_sha256=digest(mb),qualification=QUAL)

def main():
 p=argparse.ArgumentParser(description=__doc__);mode=p.add_mutually_exclusive_group(required=True)
 mode.add_argument('--prepare',action='store_true');mode.add_argument('--remote',action='store_true');mode.add_argument('--ingest',action='store_true')
 p.add_argument('--job-id',required=True);p.add_argument('--environment',required=True);p.add_argument('--marker',required=True);p.add_argument('--grids',required=True)
 p.add_argument('--output');p.add_argument('--payload');p.add_argument('--payload-sha256');p.add_argument('--reference-cp');p.add_argument('--reference-profile');p.add_argument('--repo')
 a=p.parse_args();ctx=context(a.job_id,a.environment,a.marker,a.grids);ctx['helper_sha256']=digest(raw(__file__))
 if a.prepare:
  out=new_dir(a.output);write_new(out/'fetch_length_native.py',raw(__file__))
  for source,name in [(a.environment,'environment.json'),(a.marker,'review_original.json'),(a.grids,'reference_port_grids.json')]:write_new(out/name,raw(source))
  source=raw(__file__).decode();script='import hashlib,json\nSOURCE='+repr(source)+'\nCONTEXT='+repr(json.dumps(ctx,separators=(',',':')))+'\nassert hashlib.sha256(SOURCE.encode()).hexdigest()==json.loads(CONTEXT)["helper_sha256"]\nns={"__name__":"readonly_fetch_protocol","__file__":"<operator_stdin_readonly>"}\nexec(compile(SOURCE,"<readonly_fetch>","exec"),ns)\nprint(json.dumps(ns["remote_capture"](json.loads(CONTEXT)),allow_nan=False))\n'
  write_new(out/'remote_capture_stdin.py',script.encode())
  print(json.dumps(dict(status='PREPARED_NO_NETWORK_CAD_OR_SOLVE',output=str(out),helper_sha256=digest(raw(__file__)),job_id=JOB,qualification=QUAL)));return
 if a.remote:print(json.dumps(remote_capture(ctx),allow_nan=False));return
 need(a.repo and a.reference_cp and a.reference_profile and a.payload and a.payload_sha256 and a.output,'Explicit ingest inputs/payload SHA/NEW output required')
 sys.path.insert(0,a.repo)
 from runners.lumopt2_design import s2_length_fixed150 as lane
 install_blocks(lane);install_metadata_code(lane,a.repo,ctx['marker']['code']);need(lane.code()==ctx['marker']['code'],'Local released code changed')
 reference=lane.ref.load(a.reference_cp,a.reference_profile,a.grids)
 payload=load_pinned(a.payload,a.payload_sha256)
 print(json.dumps(publish(payload,ctx,reference,lane,a.output,digest(raw(__file__))),allow_nan=False))
if __name__=='__main__':main()
