"""Pure-translation local peak3 derivative; no CAD or physical-gradient claim."""
import argparse,json,sys,io,zipfile,hashlib
from pathlib import Path
import numpy as np
from scipy.interpolate import CubicSpline
import autograd
import translation_models as m
sys.dont_write_bytecode=True
SPEED=-22.6
STEPS=tuple(.0625/(2**k) for k in range(15))

def local_review(eng,v3,wl,center,speed=SPEED):
    x=np.arange(len(center),dtype=float);spline=CubicSpline(x,center,extrapolate=False)
    keep=(x>=4)&(x<=len(x)-5);xx=x[keep];ww=wl[keep];yc=center[keep]
    fct=eng.make_fct_peak(ww);grad=autograd.grad(fct)
    jac=np.asarray(grad(yc));active=np.flatnonzero(jac)
    local=float(jac@(-speed*spline(xx,1)))
    i=m.peak_index(eng,ww,yc);r=v3.peak3_r(yc,i)
    rows=[]
    for h in STEPS:
        yp=spline(xx-speed*h);ym=spline(xx+speed*h)
        fixed=float(jac@((yp-ym)/(2*h)));moving=float((fct(yp)-fct(ym))/(2*h))
        rows.append(dict(h_nm=h,motion_bins=abs(speed*h),fixed_projection=fixed,moving_peak_fd=moving,
            fixed_minus_infinitesimal=fixed-local,moving_minus_infinitesimal=moving-local,
            peak_branch_indices=[m.peak_index(eng,ww,yp)+int(xx[0]),m.peak_index(eng,ww,ym)+int(xx[0])]))
    phases=np.linspace(-.4999,.4999,1001)
    heights=[];derivatives=[];branch_changes=0
    for phase in phases:
        y=spline(xx-phase)
        heights.append(float(fct(y)))
        derivatives.append(float(np.asarray(grad(y))@(-speed*spline(xx-phase,1))))
    values=np.array(heights);derivatives=np.array(derivatives)
    return dict(speed_bins_per_nm=speed,phase_period_nm=1/abs(speed),nominal_peak_index=i+int(xx[0]),
        nominal_vertex_offset_bins=r,exact_nominal_jacobian_indices=(active+int(xx[0])).tolist(),
        exact_nominal_jacobian_weights=jac[active].tolist(),model_infinitesimal_derivative=local,
        small_translation_rows=rows,phase_scan=dict(height_range=float(np.ptp(values)),
            height_range_over_period_scale=float(np.ptp(values)*abs(speed)),
            conditional_derivative_min=float(derivatives.min()),conditional_derivative_max=float(derivatives.max()),
            qualification='SAMPLED_BRANCHWISE_MODEL_DERIVATIVES_NOT_GLOBAL_BOUND_AT_BRANCH_SWITCHES'),
        qualification='CUBIC_CENTER_INTERPOLANT_AND_CONSTANT_TRANSLATION_ONLY')

def run(repo,output):
    output=Path(output);output.mkdir(exist_ok=False)
    repo=Path(repo);sys.path.insert(0,str(repo))
    from runners.lumopt2_design import lumopt2_design as eng,v3_step as v3
    e=repo/'docs/readiness_evidence_20261007'
    measured=json.loads((e/'s2_firstwave_measured_1113.json').read_text())
    centerpath=e/'s2_fdstep_task00_ports.npz';expected=measured['provenance']['observed_files'][centerpath.name]
    if m.sha(centerpath)!=expected:raise RuntimeError('Repeated center SHA mismatch')
    with np.load(centerpath,allow_pickle=False) as a:
        repeat=m.spectra(a);wl=a['p2_lambda'].ravel()*1e9;freq=a['p2_f'].copy()
    pin=measured['provenance']['old_shift30']['source_roles'];archive=e/'s2_original_port_spectra_preserved.zip'
    if m.sha(archive)!=pin['archive_sha256']:raise RuntimeError('Original archive SHA mismatch')
    with zipfile.ZipFile(archive) as z:
        names=[n for n in z.namelist() if n.endswith('base_ports.npz')]
        if len(names)!=1:raise RuntimeError('Original center member missing/ambiguous')
        raw=z.read(names[0])
        if hashlib.sha256(raw).hexdigest()!=pin['members']['base_ports.npz']:raise RuntimeError('Original center SHA mismatch')
        with np.load(io.BytesIO(raw),allow_pickle=False) as a:
            original=m.spectra(a)
            if not np.array_equal(a['p2_f'],freq):raise RuntimeError('Full frequency grid differs')
    report=dict(status='MODEL_LOCAL_DERIVATIVE_DIAGNOSTIC_ONLY',source_sha256=m.sha(__file__),
        repeated_center_sha256=expected,original_center_npz_sha256=pin['members']['base_ports.npz'],
        original_center_qualification='Pinned original stored-forward export; not fresh original-solve creation proof',cases={})
    for source,data in [('repeat',repeat),('original_stored_export',original)]:
        report['cases'][source]={key:local_review(eng,v3,wl,y) for key,y in data.items()}
    probe_path=e/'s2_deps_re_report_original.json'
    probe=json.loads(probe_path.read_text())
    original_tout=report['cases']['original_stored_export']['tout']
    saved_jac=np.asarray(probe['peak3_jacobian'],float)
    original_spline=CubicSpline(np.arange(len(wl)),original['tout'],extrapolate=False)
    reported_indices=np.asarray(original_tout['exact_nominal_jacobian_indices'],int)
    reported_weights=np.asarray(original_tout['exact_nominal_jacobian_weights'])
    if not np.allclose(saved_jac[reported_indices],reported_weights,rtol=0,atol=1e-12):raise RuntimeError('Saved Re original peak Jacobian differs arithmetically')
    report['saved_Re_original_crosscheck']=dict(report_sha256=m.sha(probe_path),
        saved_source_forward=probe['forward'],saved_center_peak3=probe['original_center_peak3'],
        weights_max_abs_difference=float(np.max(np.abs(saved_jac[reported_indices]-reported_weights))),
        saved_weights_model_infinitesimal_derivative=float(saved_jac@(-SPEED*original_spline(np.arange(len(wl)),1))),
        qualification='Original saved Re weights compared to pinned stored-forward export; no new solver evidence')
    report['limitations']=['Small height ripple can have a non-negligible local parameter derivative; amplitude rejection does not reject that mechanism.','A measured grid does not identify its exact continuous interpolant derivative; changing interpolation changes the model.','These are constant-shape translations, not proof of actual geometry-dependent spectral derivatives.','No full spectral adjoint Jacobian exists here; original Re/Im outputs are scalar peak3 contractions.','No production objective change, noise bound, coefficients or scientific pass.']
    with (output/'report.json').open('x') as f:json.dump(report,f,indent=2,allow_nan=False)
    print(json.dumps({s:{o:dict(local=v['model_infinitesimal_derivative'],phase=v['phase_scan'],last=v['small_translation_rows'][-1]) for o,v in values.items()} for s,values in report['cases'].items()},indent=2))
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--output',required=True);a=p.parse_args();run(a.repo,a.output)
