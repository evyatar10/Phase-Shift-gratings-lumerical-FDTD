"""Independent offline recomputation of recovered S1 profile metrics, no solves."""
import argparse,hashlib,json,re,sys,tempfile
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
REPO=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');sys.path.insert(0,str(REPO))
from runners.lumopt2_design import lumopt2_design as eng
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,message):
    if not ok:raise RuntimeError(message)
def profile(p):
    with np.load(p,allow_pickle=False) as z:
        need(set(z.files)=={'x_um','I','lam_pk_nm'},'Profile schema changed/missing')
        need(z['x_um'].dtype.kind in 'iuf' and z['I'].dtype.kind in 'iuf','Profile coordinate/intensity must be real numeric arrays')
        x=np.asarray(z['x_um'],float).ravel();I=np.asarray(z['I'],float).ravel();lam=np.asarray(z['lam_pk_nm'],float)
    need(x.size==I.size and x.size>=4 and np.isfinite(x).all() and np.isfinite(I).all() and
        np.all(np.diff(x)>0) and np.min(I)>=0 and np.max(I)>0 and lam.size==1 and np.isfinite(lam).all(), 'Invalid profile/grid/intensity/wavelength')
    return x,I,float(lam.squeeze())
def match_row(rows,eval_idx,lam,mtime_ns):
    candidates=[(n,row) for n,row in enumerate(rows,1) if row.get('eval')==eval_idx and
        np.isfinite(row.get('lam_pk_nm',np.nan)) and abs(float(row['lam_pk_nm'])-lam)<=1e-9]
    need(len(candidates)==1,'Profile does not have a unique label/eval/wavelength row')
    line,row=candidates[0]
    return line,row,dict(matched_by='label + exact eval + wavelength within1e-9nm; unique row',
        wavelength_delta_nm=lam-float(row['lam_pk_nm']),remote_profile_mtime_ns=mtime_ns,
        profile_mtime_minus_row_time_s=mtime_ns/1e9-float(row['t']),parameter_identity='NPZ_has_no_parameters; row association is indirect')
def synthetic_checks(output):
    output=Path(output);output.mkdir(exist_ok=False)
    x=np.arange(-50.,50.0001,.01);W=20.
    I=.2+np.exp(-4*np.log(2)*x*x/(W*W))*(1+.5*np.cos(2*np.pi*x/.5))
    measured=eng.fwhm_env_of_line(x,I);need(measured is not None and abs(measured-W)<.003,'Synthetic envelope FWHM failed')
    xg=np.arange(-100.,100.0001,.01);sigma=4.;shift=3.
    a=np.exp(-xg*xg/(2*sigma*sigma));b=3*a;c=np.exp(-(xg-shift)**2/(2*sigma*sigma))
    files=[]
    for label,line in [('a',a),('scaled',b),('shifted',c)]:
        p=output/(label+'.npz')
        with p.open('xb') as f:np.savez(f,x_um=xg,I=line,lam_pk_nm=1561.)
        files.append(p)
    same=eng.profile_mac(files[0],files[1]);shifted=eng.profile_mac(files[0],files[2]);expected=np.exp(-shift*shift/(2*sigma*sigma))
    need(abs(same-1.)<1e-12 and abs(shifted-expected)<1e-10,'Synthetic analytic MAC failed')
    return dict(envelope_FWHM_expected_um=W,measured_um=measured,delta_um=measured-W,
        scaled_intensity_MAC=same,shifted_gaussian_MAC=shifted,analytic_shifted_MAC=expected,
        scope='Synthetic arithmetic validation only, not physics convergence')
def analyze(root,pins_path,pins_sha):
    raw=Path(pins_path).read_bytes();need(hashlib.sha256(raw).hexdigest()==pins_sha,'Trusted recovered pin-file bytes changed')
    pins=json.loads(raw);lookup={item['relative']:item for item in pins['files']}
    for item in lookup.values():
        p=Path(item['local']);need(p.resolve()==(Path(root)/item['relative']).resolve(),'Recovered pin path does not match declared root/relative identity')
        need(p.is_file() and p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],'Recovered input identity changed: '+item['relative'])
    reports=[];groups={}
    for rel,item in lookup.items():
        name=Path(rel).name;match=re.fullmatch(r'(.+)_ev(\d+)\.npz',name)
        if not match:continue
        label,index=match[1],int(match[2]);logrel=str(Path(rel).parent.parent/(label+'_evals.jsonl')).replace('\\','/')
        need(logrel in lookup,'Matching pinned eval JSONL missing')
        rows=[json.loads(s) for s in Path(lookup[logrel]['local']).read_text().splitlines() if s.strip()]
        x,I,lam=profile(item['local']);line,row,identity=match_row(rows,index,lam,item['mtime_ns'])
        width=eng.fwhm_env_of_line(x,I);sigma=eng.sigma_of_line(x,I)
        need(width is not None and np.isfinite([width,sigma]).all(),'Production profile width extraction failed')
        expected=float(row['fwhm_env_um']);need(np.isfinite(expected),'Logged spatial width missing/nonfinite')
        p=np.asarray(row['params'],dtype='<f8');need(p.size==296 and np.isfinite(p).all(),'S1 row parameter vector invalid')
        report=dict(label=label,eval=index,matched_line_1based=line,row_time=row['t'],profile_sha256=item['sha256'],
            profile_local=item['local'],profile_remote=item['path'],row_file_sha256=lookup[logrel]['sha256'],identity=identity,
            row_parameter_sha256_le_f64=hashlib.sha256(p.tobytes()).hexdigest(),shape=list(x.shape),
            grid=dict(min_um=float(x[0]),max_um=float(x[-1]),min_dx_um=float(np.min(np.diff(x))),max_dx_um=float(np.max(np.diff(x)))),
            intensity=dict(min=float(np.min(I)),max=float(np.max(I)),integral=float(np.trapz(I,x))),
            lam_pk_nm=lam,recorded_FWHM_um=expected,recomputed_FWHM_um=width,FWHM_delta_um=width-expected,
            recorded_sigma_um=row.get('sigma_um'),recomputed_sigma_um=sigma,
            sigma_delta_um=sigma-float(row['sigma_um']) if row.get('sigma_um') is not None else None)
        reports.append(report);groups.setdefault(label,[]).append(report)
    need(bool(reports),'No pinned original profiles found')
    mac=[];campaign='lumopt2_te_s1_v3';cpgroup=sorted(groups[campaign],key=lambda item:item['eval'])
    need([p['eval'] for p in cpgroup]==[0,1,2,3],'Recovered campaign lacks exact0..3 profiles')
    projection=REPO/'results_from_athena/campaign_te_s1/lumopt2_te_s1_v3_proj.jsonl';projrows=[json.loads(s) for s in projection.read_text().splitlines() if s.strip()]
    for previous,current in zip(cpgroup[:-1],cpgroup[1:]):
        xa,_,_=profile(previous['profile_local']);xb,_,_=profile(current['profile_local']);value=eng.profile_mac(previous['profile_local'],current['profile_local'])
        matching=[(n,row) for n,row in enumerate(projrows,1) if row.get('it')==current['eval'] and abs(float(row.get('W',np.nan))-current['recorded_FWHM_um'])<=1e-10]
        need(len(matching)==1 and value is not None and np.isfinite(value),'Campaign MAC projection-row association failed')
        line,row=matching[0];stored=float(row['mac'])
        mac.append(dict(previous_eval=previous['eval'],current_eval=current['eval'],previous_profile_sha256=previous['profile_sha256'],
            current_profile_sha256=current['profile_sha256'],same_x_grid=bool(np.array_equal(xa,xb)),recomputed_MAC=value,
            recorded_MAC=stored,MAC_delta=value-stored,projection_line_1based=line,projection_time=row['t'],
            orientation='previous accepted intensity profile; current profile interpolated onto previous x'))
    final=cpgroup[-1]
    return dict(schema=1,scope='OFFLINE_ORIGINAL_1D_PROFILE_ARITHMETIC_RECOMPUTATION_NO_NEW_SOLVE',
        input_pins_sha256=pins_sha,engine_sha256=sha(eng.__file__),sim_helpers_sha256=sha(REPO/'sim_helpers.py'),
        projection_source_sha256=sha(projection),profile_count=len(reports),all_profiles=reports,campaign_MAC=mac,final_candidate=final,
        limitations=['Profile NPZs do not contain parameter vectors; row association uses label/eval/unique wavelength and recorded mtime.',
            'These saved1D intensities cannot independently verify original full-E y integration, source normalization, CAD geometry or solve convergence.',
            'Reproduced FWHM/MAC validates saved-profile arithmetic, not adjoint gradients, strict no-width-increase or full optimization readiness.'])
def write(path,value):
    with Path(path).open('x',encoding='utf8') as f:json.dump(value,f,indent=2,allow_nan=False)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('root','pins','pins-sha256','output','synthetic-dir'):p.add_argument('--'+name,required=True)
    a=p.parse_args();checks=synthetic_checks(a.synthetic_dir);report=analyze(Path(a.root),a.pins,a.pins_sha256)
    report['synthetic_checks']=checks;write(a.output,report)
    print(json.dumps(dict(profile_count=report['profile_count'],final_FWHM_um=report['final_candidate']['recomputed_FWHM_um'],
        final_width_delta_um=report['final_candidate']['FWHM_delta_um'],campaign_MAC=report['campaign_MAC']),indent=2))
