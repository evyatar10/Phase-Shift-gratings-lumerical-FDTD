import unittest,numpy as np
from autograd import grad
from analyze import v3,cancellation,estimate,UnsupportedPeak
class Arithmetic(unittest.TestCase):
 def test_actual_peak3_support_and_weighted_FD(self):
  x=np.arange(21.)-10;y=1-.002*(x-.17)**2;J=grad(lambda t:v3.peak3(t,10))(y)
  self.assertTrue(np.array_equal(np.flatnonzero(J),[9,10,11]));self.assertAlmostEqual(J.sum(),1.)
  direction=np.sin(x*.61);eps=1e-6
  finite=(v3.peak3(y+eps*direction,10)-v3.peak3(y-eps*direction,10))/(2*eps)
  self.assertAlmostEqual(float(J@direction),float(finite),places=9)
  c=cancellation(np.array([.003,-.007,.0035]));self.assertAlmostEqual(c['sum'],-.0005);self.assertAlmostEqual(c['absolute_sum_over_absolute_projection'],27.)
 def test_quartic_stationary_height_jacobian_and_rejection(self):
  x=np.arange(31.)-15;y=1-.003*(x-.23)**2+.000001*(x-.23)**4
  q=estimate(y,15,'quartic11');direction=np.cos(x*.71);eps=1e-6
  finite=(estimate(y+eps*direction,15,'quartic11')['height']-estimate(y-eps*direction,15,'quartic11')['height'])/(2*eps)
  self.assertAlmostEqual(float(q['jacobian']@direction),finite,places=8);self.assertLess(q['fit_residual_max_abs'],1e-14)
  with self.assertRaises(UnsupportedPeak):estimate(np.ones(31),15,'quartic11')
 def test_nonlinear_endpoint_residual_identity_units(self):
  x=np.arange(21.)-10;y=1-.002*(x-.17)**2;h=.0625;plus=1+.001*h-.002*(x-.17-2*h)**2;minus=1-.001*h-.002*(x-.17+2*h)**2
  J=grad(lambda t:v3.peak3(t,10))(y);moving=(v3.peak3(plus,int(np.argmax(plus)))-v3.peak3(minus,int(np.argmax(minus))))/(2*h);fd=(plus-minus)/(2*h)
  rp=v3.peak3(plus,int(np.argmax(plus)))-v3.peak3(y,10)-J@(plus-y);rm=v3.peak3(minus,int(np.argmax(minus)))-v3.peak3(y,10)-J@(minus-y)
  self.assertAlmostEqual(float((rp-rm)/(2*h)),float(moving-J@fd),places=14);self.assertAlmostEqual(float(moving),.001,places=13)
if __name__=='__main__':unittest.main(verbosity=2)
