# Bounded150ps shift30 +/-0.125nm forward-only candidate

Preparation only. Source lives solely in this NEW TEMP packet; no repository/server/vendor edits,upload,dispatch,CAD or FDTD solve. Parent owns hidden CAD,integration,immutable lead marker and any dispatch. Current scientific calibration remains FAILED; no optimizer or coefficient installation.

s2_temporal_step150.py exposes SPEC,N_TASKS=2,IS_HELPER=True,main(task_idx). Tasks0/1 change ONLY recovered te_point parameter149 by +0.125/-0.125nm respectively; fixed150ps,early shutoff disabled,divergence checking enabled,optimization_dft disabled. Field/source/port501 sampling/PVA/locked mesh/timing helpers come from frozen s2_temporal_forward.py SHA555f3d13b42c494171e7658cc4263c588ce418e5d937da1497d690824b41d44a; that runner is unchanged. New result verification is written explicitly for the0/1,.125nm,150ps family,not delegated to its hardcoded .0625 task validator.

Exact reuse center is completed150ps task03 at:
/work/results/diagnose_te_s2_temporal/results/s2_shift30_temporal_20261007/task_03.json
SHAa0ff55eacaa52e00a2aab17dcc43d0e5fff9a72566e15da371ff25279c172663.

New marker binds all three completed150ps checkpoints,each raw SHA,FSP/H5/NPZ/log digest,full point/spec/code/vendor/control/termination metadata and parent marker SHA6cc6d9fd8cab5419b436b433725fbb2cc88b49f538628f897929217940527f51. Each invocation rechecks their actual saved files/scores before accepting ancestry. Frozen helper/dependency hashes must match. New exact review status is APPROVED_FOR_TWO_FIXED150PS_SHIFT30_STEP0125_FORWARDS_ONLY; allowed_tasks=[0,1]; substantive leadreview and marker byte SHA are mandatory. --review-template emits NOT_REVIEWED with no allowed tasks. Nothing creates approval or launches dependencies automatically.

|Environment |Default / requirement |
|---|---|
|S2_STEP150_REPO |Optional repository root; otherwise cwd |
|S2_STEP150_OUTPUT_ROOT |/work/results/diagnose_te_s2_step150/results/s2_shift30_step150_20261007 |
|S2_STEP150_PARENT_ROOT |/work/results/diagnose_te_s2_temporal/results/s2_shift30_temporal_20261007 |
|S2_STEP150_PARENT_MARKER |/work/data/s2_temporal150_review_20261007_1257.json |
|S2_STEP150_REVIEW_MARKER |Required absolute path to NEW reviewed marker |
|S2_STEP150_REVIEW_SHA256 |Required actual byte SHA of NEW marker |
|KEEP_H5 |Must equal1 before any new CAD/solve; completed reuse does not need CAD |

Output root must end in the unique new family and cannot overlap parent evidence. Parent ancestry retains original remote metadata; override paths must still satisfy that identity,not silently rewrite checkpoints for local copies. Each new attempt uses task_00/01_<unique>/; FSP,H5,log,ports.npz preserved. Atomic hard-link checkpoint publication cannot replace an existing completed result. Completed reuse checks identity,artifact hashes,reproduced scores,all501 frequencies,full-time termination and exact controls before returning.

Cross-run control check accepts only the already-reviewed Port_1 phase difference<=2 orderedfloat64 ULPs,finite scalar,zero bitwise exact,no absolute floor. Raw phases,degree delta and qualification retained. Cause is not localized; this is arithmetic roundoff reuse,not a physical tolerance. The intentional mapped index149 geometry step is validated separately; other nominal controls remain exact. Existing same-attempt persisted geometry check is unchanged. No extra source/global-grid relaxation.

Offline verification: seven focused groups passed exit0. Exactpoints/bounds/tasks; missing/wrongstage/ancestry/source markers; all three actual150 byte-pinned checkpoint metadata and negative source/point controls; completed synthetic reuse with CAD/solve forbidden; score/file tampering; source/control/termination tampering; phase0/1/2ULP pass,>2ULP/other-port/mesh/timing changes reject; no-CAD import/tasklist and AST/syntax. Synthetic fake FSP/H5/log fixtures are marked SYNTHETIC and establish logic only. No full13 rerun.

Current local base.code() matches the exact150 marker. Windows local vendor byte hashes differ from all42 Athena-recorded files (same keys),retained in local_vendor_identity_gap.json. Therefore production load_ancestry correctly refuses a full local replay under those bytes; native hidden CAD can check scene mechanics without asserting Athena vendor identity. No vendor equality was relaxed. Parent must verify the actual Athena tree before marker release.

Direct safe discovery (no CAD):
```powershell
python -B C:/Users/evyat/AppData/Local/Temp/s2_temporal_step150_55c15e58102f/s2_temporal_step150.py --tasklist
python -B C:/Users/evyat/AppData/Local/Temp/s2_temporal_step150_55c15e58102f/test_step150.py
```

After parent-reviewed registration ONLY: existing athena/deploy_athena.sh:1048-1054 invokes build_sweep_list --kind lumopt2_design --module <module>; athena/scripts/athena_run_one.py:368-380 imports the module and calls main(task_idx=idx). This candidate matches that signature. IS_HELPER=True excludes interactive menus but does not block an explicitly named module. Parent may later use --lumopt2-design=runners.lumopt2_design.s2_temporal_step150 with explicit --array-tasks=0,1. This report is not a command to upload or dispatch.

Hidden-CAD remaining gate: use actual nominal mapped point and each +/-0.125 endpoint; verify controls150/grid/mesh/source and persisted snapshots under no-solve guard. No new monitor construction is introduced. Parent's runtime planning budget is50-65min per150ps forward based on actual150 family; two forwards,not guaranteed elapsed walltime. Inspect task0 result before continuing if its compatibility evidence fails. Both completed endpoints need measured directional/time interpretation; no h-convergence/global calibration pass assumed.

Files: runner,test_step150.py,tests.log,tasklist.json,manifest.json. manifest includes source/helper/pinned parent identity and output/test exits. Frozen original runner and prior candidate packets preserved.
