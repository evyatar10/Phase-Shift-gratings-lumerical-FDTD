"""Read-only optional LOCAL original build-only FSP outer/feed check; no save/run."""
import hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
import build_hidden_pair_v6 as builder
ORIGINAL=Path('C:/Users/evyat/AppData/Local/Temp/s2_fdstep_hidden_build_nsak9n13/task_00_2pogl0a4/lumopt2_te_s2_fdstep_diagnostic_20261007_files/fwd_default.fsp')
ORIGINAL_SHA='fd51cd57304fa436cffda085f56ba43d453e07ffb3838e87839950ccf3f7947b'
def identity():
 s=ORIGINAL.stat();return dict(path=str(ORIGINAL),bytes=s.st_size,mtime_ns=s.st_mtime_ns,sha256=builder.sha(ORIGINAL))
def main():
 out=Path(__file__).parent;before=identity();builder.need(before['sha256']==ORIGINAL_SHA,'Original LOCAL reference FSP changed')
 reference=json.loads((out/'attempt06/cad_pair_report.json').read_text());builder.need(reference['status']=='CAD_PAIR_CONTROLS_PASS_NO_PHYSICS_PASS','Corrected hiddenCAD pair not ready')
 sys.path.insert(0,str(builder.ROOT));from runners.lumopt2_design import lumopt2_design as eng
 sys.path.insert(0,str(builder.API));import lumapi
 klass,ctor=lumapi.FDTD,lumapi.FDTD.__init__;report=dict(scope='READ_ONLY_ORIGINAL_LOCAL_BUILD_ONLY_GEOMETRY_NOT_REMOTE_SOLVED_OUTER_PROVENANCE',original_before=before)
 try:
  raw=lumapi.FDTD(hide=True)
  with builder.NoSolveCAD(raw,out) as f:
   f.load(ORIGINAL);actual=builder.all_teeth(f,eng,98);expected=reference['cases']['98']['reloaded']['all_teeth_and_feeds']
   # Read ONLY retained outer physicald61..98 and feedobjects,not rewritten point.
   keys=[k for k in expected if 'feed' in k or (k!='cavity' and int(k.split('_')[-1])>=61)]
   left_num,left_text=builder.flatten_numeric_geometry({k:actual[k] for k in keys});right_num,right_text=builder.flatten_numeric_geometry({k:expected[k] for k in keys})
   report.update(checked_canonical_object_count=len(keys),local_original_geometry={k:actual[k] for k in keys},numeric_comparison=builder.geometry_comparison(left_num,right_num),text_differences=builder.differences(left_text,right_text),audit=f.audit)
  report['status']='LOCAL_ORIGINAL_OUTER_AND_FEEDS_EXACT' if not report['numeric_comparison']['nonbitwise'] and not report['text_differences'] else 'LOCAL_ORIGINAL_OUTER_DIFFERENCES_REQUIRE_REVIEW'
 except Exception as e:report['status']='FAILED_CLOSED';report['error']=type(e).__name__+': '+str(e)
 finally:
  report['original_after']=identity();report['original_preserved']=report['original_after']==before;report['FDTD_class_unchanged']=lumapi.FDTD is klass;report['FDTD_constructor_unchanged']=klass.__init__ is ctor
  with (out/'local_original_outer_report.json').open('x',encoding='utf-8') as f:json.dump(report,f,indent=2,allow_nan=False)
 print(report['status'],report.get('error',''));return 0 if report['status']=='LOCAL_ORIGINAL_OUTER_AND_FEEDS_EXACT' and report['original_preserved'] else 1
if __name__=='__main__':raise SystemExit(main())
