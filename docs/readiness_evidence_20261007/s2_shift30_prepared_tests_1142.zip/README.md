# Prepared shift30 translation-step ladder

Provisional preparation only. Global calibration remains FAILED. The parent
owns the next scientific decision, new immutable review marker, resource/shared-
seat preflight, upload and dispatch. This package launches nothing by itself.
It does not release the eight held FD class legs or fit coefficients.

| Task | Live parameter index | Delta nm |
|---|---:|---:|
| 0 | shift30=149 | +0.125 |
| 1 | shift30=149 | -0.125 |
| 2 | shift30=149 | +0.0625 |
| 3 | shift30=149 | -0.0625 |

The center is the ORIGINAL exact recovered nominal point. Its task00 metadata
is index29 (corr30 diagnostic center), not149; the runner checks this distinction.
No new nominal solve is included. Native bounds/spec/source hashes are unchanged
apart from the new label s2_shift30_convergence_20261007.

Configure the existing server runtime/wrapper before importing this module:

```bash
export S2_SHIFT_REPO=/work/project
export S2_SHIFT_CENTER_CHECKPOINT=/work/results/diagnose_te_s2_fdstep/results/lumopt2_te_s2_fdstep_diagnostic_20261007/task_00.json
export S2_SHIFT_FIRSTWAVE_ROOT=/work/results/diagnose_te_s2_fdhalf_classes/results/lumopt2_te_s2_fdhalf_classcheck_20261007
export S2_SHIFT_FIRSTWAVE_MARKER=/work/data/s2_half_classes_first_review_20261007.json
export S2_SHIFT_OUTPUT_ROOT=/work/results/diagnose_te_s2_shift30_convergence/results/s2_shift30_convergence_20261007
export S2_SHIFT_REVIEW_MARKER=/NEW/shift30_translation_lead_review.json
export KEEP_H5=1
```

Use the existing wrapper's actual config.LUMAPI_PATH, GPU resource and thread
configuration. No changes to those production settings are inferred from this
local preparation. Import s2_shift30_convergence.py, then call main(integer_task).

In that configured runtime, obtain the review template without CAD/solve:

```python
template = module.review_template(module.output_root(), module.load_center())
```

It has status NOT_REVIEWED, no allowed tasks, and lead_verdict=NOT_REVIEWED.
It authenticates the completed original170962 wave before returning anything:
exact first-marker SHA, frozen first-wave source/spec scope, original reviewed
provenance, all four ORIGINAL checkpoint SHAs, task/point identity, source/H5
paths, successful solve logs, NPZ hashes and scalar reproduction. Missing,
changed or incomplete evidence refuses before any CAD session/solve.

Only after actual lead review of the provisional step choice may the parent
publish a NEW, SEPARATE, immutable marker with status
APPROVED_FOR_BOUNDED_SHIFT30_TRANSLATION_STEP_DIAGNOSTIC,
allowed_tasks=[0,1,2,3], and a substantive lead_verdict. All template identities
and first-wave records must remain exact. The runner never creates an approval
marker; it refuses reuse of the immutable first-wave marker. First-wave and
nominal results remain untouched.

Pinned original170962 checkpoint SHAs, task order0..3:

```text
823ab4a4dd5d3e412a1b6a806d8ea76f058f5c640701dd5c01c604f89f35e33f
3821b3b1c2b6dc6f3adf9337252b2eb7040d55b8125d31f42ef74e7b11fb31b1
5e096a013ba9d2a5660fd3c46f8e90fa958de9a9999376ebe5b3e2b76acfd37b
bd0406be1a52ef986173c77c73017dca83d0d67d0c8eb021baefca5f5aafec81
```

The original reviewed center SHA is
cd2dd4a58be7b83c46ef6a6ac90a874e5fc33edda884edfc8ac50ce5e3be4a06;
first marker SHA6722e1883338c0259b6fd2aa7386a2d12f1c5124708f590c1ce30a7c266f8d02.
Historical data are retained; no old half-step or first-wave result is replaced.

Each authorized task creates a unique attempt, prepares one forward, checks
the locked x/y/z mesh unchanged before disabling optimization_dft, and executes
exactly one forward. FSP/H5/NPZ are retained. NPZ and checkpoint publication are
exclusive; completed cold resumes verify full metadata/artifact paths/logs/NPZ
hash and score reproduction before reuse. Failed attempts remain intact.
Do not dispatch concurrent copies of the same task: publication guards are
not a scheduler lock against duplicate solves.

Offline checks:

```powershell
python -B test_shift30_steps.py
python -B no_solve_guard.py --self-test
```

Five focused groups pass: exact149-only deltas and native29-center distinction;
immutable first-wave/new-marker tampering; NPZ tampering and marker reuse;
four one-forward mock tasks with exclusive checkpoints/cold resume; KEEP_H5,
mesh/H5/interruption failures and frozen-family preservation. Fixtures stay
in this package. They patch synthetic checkpoint hashes only inside tests;
runtime has no environment override for the actual pinned center/first wave.
fixture_helpers.py is a copied test scaffold and is not a production dependency.

validate_smallest_cad.py is the explicitly authorized hidden local CAD-only
smallest positive step (task2, shift30+0.0625nm) harness. Its copied private guard
preserves the lumapi.FDTD class symbol, forces hide=True, resolves relative
saves using CAD pwd, and blocks solver calls/saves outside its unique output.
The old guard and production/vendor files are never modified. A CAD-only pass
is not a new FDTD solve, convergence result or scientific calibration pass.

Actual hidden local CAD smallest-step check passed exit0. Evidence is retained
at actual_cad_smallest_zoego0wf/validation.json. It confirms the149-only+0.0625nm
point, all723 exact mapped properties and identical locked grids after field
storage is disabled; local PVA meshing refinement read5. No FDTD solve or
stored-field extraction was performed. This does not approve dispatch.
