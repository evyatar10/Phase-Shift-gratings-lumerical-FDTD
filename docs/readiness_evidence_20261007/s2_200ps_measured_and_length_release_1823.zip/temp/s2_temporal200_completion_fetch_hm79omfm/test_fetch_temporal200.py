"""Offline synthetic protocol tests only: no network, container, CAD or solve."""
import ast
import base64
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
import fetch_temporal200 as fetch

REPO = Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
EVIDENCE = REPO/'docs/readiness_evidence_20261007/s2_temporal150_fetch_1434'
JOB = fetch.JOB_ID  # Exact release ID used only offline; no network.
MARKER = fetch.MARKER
MARKER_SHA = fetch.MARKER_SHA
ENV = json.loads((Path(__file__).parent/'released_environment.json').read_text())


class FetchChecks(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix='SYNTHETIC_fetch_', dir=Path(__file__).parent))
        parent = json.loads((EVIDENCE/'s2_temporal150_task03_original.json').read_text())
        ports_raw = (EVIDENCE/'s2_temporal150_task03_ports.npz').read_bytes()
        self.payload = dict(job_id=JOB, review_marker=MARKER, review_marker_sha256=MARKER_SHA,
                            environment=ENV, family=fetch.FAMILY, runner_sha256=fetch.RUNNER_SHA,
                            base_helper_sha256=fetch.BASE_SHA,step150_helper_sha256=fetch.STEP_SHA, at='SYNTHETIC_NO_SERVER',
                            accounting='\n'.join(f'{JOB}_{t}|COMPLETED|0:0|' for t in fetch.TASKS),
                            verified_records=[], files={})
        for task, sign in ((0,0),(1,1),(2,-1)):
            row=copy.deepcopy(parent);identity,result=row['identity'],row['result'];index=29 if task==0 else 149
            attempt=fetch.OUTPUT_ROOT+f'/task_{task:02d}_SYNTHETIC';cp=fetch.OUTPUT_ROOT+f'/task_{task:02d}.json'
            source=attempt+'/files/fwd_default.fsp';ports=attempt+'/ports.npz'
            review=dict(path=MARKER,sha256=MARKER_SHA,lead_verdict='SYNTHETIC_NO_APPROVAL',allowed_tasks=[0,1,2],parent150=copy.deepcopy(fetch.PINS['parent150']),completed_step150=copy.deepcopy(fetch.PINS['completed_step150']))
            point=list(fetch.PINS['point']);point[index]+=sign*.0625
            identity.update(task=task,duration_ps=200.,index=index,sign=sign,delta_nm=sign*.0625,task_map=[[.0625,0],[.0625,1],[.0625,-1]],center_checkpoint=fetch.PARENT_ROOT+'/task_03.json',center_sha256=fetch.CENTER_SHA,parent_review=review,point=point,spec=copy.deepcopy(fetch.PINS['spec']),code=copy.deepcopy(fetch.PINS['code']),vendor_api_sha256=copy.deepcopy(fetch.PINS['vendor_api_sha256']),parent150=review['parent150'],completed_step150=review['completed_step150'])
            result.update(task=task,duration_ps=200.,index=index,sign=sign,delta_nm=sign*.0625,params=point,parent_review=review,source=source,ports_npz=ports,ports_sha256=fetch.digest(ports_raw),reviewed_center_sha256=fetch.CENTER_SHA,comparison_status='TEMPORAL200_DIAGNOSTIC_REVIEW_REQUIRED_NO_PHYSICS_PASS',FDTD_version='SYNTHETIC_PROTOCOL_NO_NEW_SOLVE',vendor_api_sha256=copy.deepcopy(fetch.PINS['vendor_api_sha256']))
            result['controls']['after']['timing'].update({'simulation time':200e-12,'use early shutoff':0,'use divergence checking':1});result['controls']['after']['optimization_dft_enabled']=0
            result['controls']['persisted']=copy.deepcopy(result['controls']['after'])
            for part in ('before','after','persisted'):result['controls'][part+'_sha256']=fetch.digest(json.dumps(result['controls'][part],sort_keys=True,separators=(',',':'),allow_nan=False).encode())
            result['termination'].update(status=1,requested_time_s=200e-12,physical_time_s=200e-12,reason='completed_full_simulation_time')
            record = dict(task=task, checkpoint=cp, source=source, ports=ports,
                          ports_sha256=result['ports_sha256'], termination=result['termination'],
                          fsp_sha256=result['fsp_sha256'], h5_sha256=result['h5_sha256'],
                          parent_review=review, metrics={k: result[k] for k in fetch.METRICS},
                          vendor_api_sha256=result['vendor_api_sha256'],controls=result['controls'],cold_validation=dict(main_called=False,CAD_blocked=True,solve_blocked=True,runner_validator='read_checkpoint+verify_result'),
                          control_sha256={k: result['controls'][k]
                                          for k in ('before_sha256', 'after_sha256', 'persisted_sha256')})
            raw = json.dumps(row).encode()
            record['checkpoint_sha256'] = fetch.digest(raw)
            self.payload['verified_records'].append(record)
            for role, path, data in (('checkpoint', cp, raw), ('ports', ports, ports_raw)):
                self.payload['files'][f'{task}:{role}'] = dict(
                    path=path, bytes=len(data), sha256=fetch.digest(data), data=base64.b64encode(data).decode())

    def validate(self, payload=None):
        return fetch.validate_payload(self.payload if payload is None else payload, JOB, MARKER, MARKER_SHA, ENV)

    def mutate_checkpoint(self, payload, task, mutate):
        item = payload['files'][f'{task}:checkpoint']
        row = json.loads(base64.b64decode(item['data'])); mutate(row)
        raw = json.dumps(row).encode()
        item.update(bytes=len(raw), sha256=fetch.digest(raw), data=base64.b64encode(raw).decode())
        payload['verified_records'][task]['checkpoint_sha256'] = fetch.digest(raw)

    def test_explicit_inputs_and_exact_environment_without_network(self):
        with patch.object(fetch.subprocess, 'run', side_effect=AssertionError('Network forbidden')):
            for job in ('', '0', '171390_0', '-1', '12345', '171390;sbatch'):
                with self.assertRaises(RuntimeError): fetch.scripts(job, MARKER, MARKER_SHA, ENV)
            for marker in ('relative.json', '/work/data/../results/x.json', fetch.PARENT_MARKER):
                with self.assertRaises(RuntimeError): fetch.scripts(JOB, marker, MARKER_SHA, ENV)
            for key, value in (('S2_TEMP200_OUTPUT_ROOT', fetch.PARENT_ROOT),
                               ('S2_TEMP200_REVIEW_MARKER', '/work/data/different.json'),
                               ('S2_TEMP200_REVIEW_SHA256', 'f'*64), ('KEEP_H5', '0')):
                env = dict(ENV); env[key] = value
                with self.assertRaises(RuntimeError): fetch.scripts(JOB, MARKER, MARKER_SHA, env)
            with self.assertRaises(RuntimeError): fetch.scripts(JOB, MARKER, 'NOT_SHA', ENV)
            env = dict(ENV); env['S2_TIME_OUTPUT_ROOT'] = fetch.PARENT_ROOT
            with self.assertRaises(RuntimeError): fetch.scripts(JOB, MARKER, MARKER_SHA, env)

    def test_accounting_exact_three_completed_zero_tasks(self):
        self.assertEqual(set(fetch.completed_rows(self.payload['accounting'], JOB)), {JOB+'_0', JOB+'_1',JOB+'_2'})
        for state in ('RUNNING', 'PENDING', 'FAILED', 'COMPLETED+', 'CANCELLED'):
            with self.assertRaises(RuntimeError):
                fetch.completed_rows(self.payload['accounting'].replace('COMPLETED', state, 1), JOB)
        for text in (self.payload['accounting'].replace('0:0', '1:0', 1),
                     self.payload['accounting'].replace(JOB+'_1', JOB+'_3'),
                     self.payload['accounting']+f'\n{JOB}_3|COMPLETED|0:0|',
                     self.payload['accounting']+f'\n{JOB}_0|COMPLETED|0:0|'):
            with self.assertRaises(RuntimeError): fetch.completed_rows(text, JOB)

    def test_scripts_have_cold_guards_and_prechecks_before_validator(self):
        inner, remote = fetch.scripts(JOB, MARKER, MARKER_SHA, ENV)
        for text in (inner, remote):
            tree = ast.parse(text)
            attrs = {n.func.attr for n in ast.walk(tree) if isinstance(n, ast.Call)
                     and isinstance(n.func, ast.Attribute)}
            self.assertFalse(attrs & {'main', 'forward_only', 'make_project', 'import_lumopt2',
                                      'run_forward', 'run_adjoint', 'run_campaign', 'compute_gradient',
                                      'write_bytes', 'write_text', 'mkdir', 'unlink', 'rename'})
            for command in ('sbatch', 'scancel', 'srun', 'rmtree'):
                self.assertNotIn(command, text)
        for blocked in ('m.main=forbid', 'm.forward_only=forbid', 'm.eng.make_project=forbid',
                        'm.eng.import_lumopt2=forbid', 'm.base.main=forbid', 'm.base.forward_only=forbid','m.step.main=forbid','m.step.forward_only=forbid'):
            self.assertIn(blocked, inner)
        for operation in ('m.frozen_base()', 'm.load_ancestry()', 'm.reviewed(', 'm.identity(',
                          'm.recovery.read_checkpoint(', 'm.verify_result('):
            self.assertIn(operation, inner)
        self.assertLess(inner.index('All three completed checkpoints'), inner.index('m.load_ancestry()'))
        self.assertLess(remote.index('All three checkpoints required'), remote.index("a=['apptainer'"))
        self.assertIn("JOB_ID='171390'", remote)
        self.assertIn(fetch.RUNNER_SHA, inner);self.assertIn(fetch.STEP_SHA,inner)
        self.assertIn("m.step.main=forbid",inner)
        self.assertIn("review[k]==PINS[k]",inner)
        self.assertNotIn('m.load_center()', inner)
        self.assertIn('if sys.flags.optimize:raise RuntimeError', inner)
        self.assertIn('if sys.flags.optimize:raise RuntimeError', remote)

    def test_valid_payload_and_exclusive_original_bytes_pins_receipt_manifest(self):
        decoded = self.validate(); output = self.root/'NEW_completion'
        result = fetch.publish(self.payload, decoded, output)
        self.assertEqual(result['verified_tasks'], [0, 1, 2])
        pins = json.loads((output/'s2_temporal200_artifact_pins_original.json').read_text())
        self.assertEqual(set(pins), set(decoded))
        for key, pin in pins.items(): self.assertEqual(Path(pin['local']).read_bytes(), decoded[key])
        receipt = json.loads((output/'s2_temporal200_completed_receipt.json').read_text())
        manifest = json.loads((output/'s2_temporal200_fetch_manifest.json').read_text())
        self.assertEqual(receipt['artifact_pins_sha256'], result['pins_sha256'])
        self.assertEqual(manifest['receipt_sha256'], result['receipt_sha256'])
        self.assertEqual(fetch.digest((output/'s2_temporal200_fetch_manifest.json').read_bytes()), result['manifest_sha256'])
        raw = {p.name: p.read_bytes() for p in output.iterdir()}
        with self.assertRaises(RuntimeError): fetch.publish(self.payload, decoded, output)
        self.assertEqual({p.name: p.read_bytes() for p in output.iterdir()}, raw)
        with self.assertRaises(RuntimeError): fetch.publish(self.payload, decoded, 'relative_output')

    def test_job_task_marker_family_missing_artifact_hash_and_path_tamper(self):
        for key, value in (('job_id', '171391'), ('review_marker', '/work/data/wrong.json'),
                           ('review_marker_sha256', 'f'*64), ('runner_sha256', 'b'*64),
                           ('base_helper_sha256', 'b'*64), ('family', 'wrong_family')):
            bad = copy.deepcopy(self.payload); bad[key] = value
            with self.assertRaises(RuntimeError): self.validate(bad)
        for key, value in (('path', fetch.PARENT_ROOT+'/task_00.json'),
                           ('path', fetch.OUTPUT_ROOT+'/../outside.json'), ('bytes', 1), ('sha256', '0'*64)):
            bad = copy.deepcopy(self.payload); bad['files']['0:checkpoint'][key] = value
            with self.assertRaises(RuntimeError): self.validate(bad)
        bad = copy.deepcopy(self.payload); bad['files'].pop('1:ports')
        with self.assertRaises(RuntimeError): self.validate(bad)
        bad = copy.deepcopy(self.payload); bad['verified_records'][1]['task'] = 3
        with self.assertRaises(RuntimeError): self.validate(bad)
        bad = copy.deepcopy(self.payload); bad['files']['1:ports']['path'] = fetch.OUTPUT_ROOT+'/task_00_OTHER/ports.npz'
        with self.assertRaises(RuntimeError): self.validate(bad)

    def test_repinned_checkpoint_semantics_scores_vendor_and_controls_reject(self):
        changes = [lambda r: r['identity']['spec'].update(label='old_temporal_family'),
                   lambda r: r['identity'].update(delta_nm=.125),
                   lambda r: r['identity'].update(duration_ps=100.),
                   lambda r: r['identity'].update(center_sha256='b'*64),
                   lambda r: r['result'].update(peak3_tout=.123),
                   lambda r: r['result']['parent_review'].update(sha256='b'*64),
                   lambda r: r['result']['vendor_api_sha256'].update({'lumapi.py': 'b'*64}),
                   lambda r: r['result']['controls']['after']['timing'].update({'use early shutoff': 1}),
                   lambda r: r['identity']['code'].update({'s2_temporal_step150.py':'b'*64}),
                   lambda r: r['result']['termination'].update(status=2),
                   lambda r: r['result']['parent_review']['completed_step150']['checkpoints']['0'].update(sha256='b'*64),
                   lambda r: r['identity']['point'].__setitem__(149,r['identity']['point'][149]+.125)]
        for change in changes:
            bad = copy.deepcopy(self.payload); self.mutate_checkpoint(bad, 0, change)
            with self.assertRaises(RuntimeError): self.validate(bad)

    def test_cold_loop_missing_completed_and_all_CAD_guards_executed(self):
        # Execute the actual generated guard+read/verify loop with a stub runner;
        # no production module, filesystem artifact or server is touched.
        import types
        inner,_=fetch.scripts(JOB,MARKER,MARKER_SHA,ENV);tree=ast.parse(inner)
        start=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.FunctionDef) and n.name=='forbid')
        end=next(i for i,n in enumerate(tree.body[start:],start) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='print')
        code=compile(ast.Module(body=tree.body[start:end],type_ignores=[]),'<actual_generated_cold_loop>','exec')
        class FakePath:
            def __init__(self,value):self.value=str(value)
            def __truediv__(self,value):return FakePath(self.value+'/'+value)
            def __str__(self):return self.value
            def __eq__(self,other):return str(self)==str(other)
        rows={t:json.loads(base64.b64decode(self.payload['files'][f'{t}:checkpoint']['data']))['result'] for t in fetch.TASKS}
        checked=[];fallback=[]
        def unsafe(*args,**kwargs):fallback.append('unsafe');raise AssertionError('Unblocked unsafe path')
        def make(missing=None):
            m=types.SimpleNamespace(main=unsafe,forward_only=unsafe,base=types.SimpleNamespace(main=unsafe,forward_only=unsafe),step=types.SimpleNamespace(main=unsafe,forward_only=unsafe),eng=types.SimpleNamespace(make_project=unsafe,import_lumopt2=unsafe),frozen_base=lambda:None,load_ancestry=lambda:{},root_path=lambda:FakePath(fetch.OUTPUT_ROOT),reviewed=lambda t,r,c:rows[t]['parent_review'],identity=lambda t,c,r:{'task':t},diag=types.SimpleNamespace(METRICS=fetch.METRICS))
            m.recovery=types.SimpleNamespace(read_checkpoint=lambda cp,i:None if i['task']==missing else rows[i['task']])
            def verify(r,t,root,c,review):
                checked.append(t)
                for fn in [m.main,m.forward_only,m.base.main,m.base.forward_only,m.step.main,m.step.forward_only,m.eng.make_project,m.eng.import_lumopt2]:
                    with self.assertRaisesRegex(RuntimeError,'cannot call main/CAD/solve'):fn()
            m.verify_result=verify
            return m
        for missing in [0,1,2,None]:
            checked.clear();m=make(missing);context=dict(m=m,root=FakePath(fetch.OUTPUT_ROOT),MARKER=MARKER,MARKER_SHA=MARKER_SHA,sha=lambda cp:'a'*64)
            if missing is not None:
                with self.assertRaises(AssertionError):exec(code,context)
                self.assertEqual(checked,list(range(missing)))
            else:
                exec(code,context);self.assertEqual(checked,[0,1,2]);self.assertEqual([r['task'] for r in context['records']],[0,1,2])
        self.assertEqual(fallback,[])

    def test_cli_refuses_existing_output_before_network(self):
        env = self.root/'environment.json'; env.write_text(json.dumps(ENV))
        args = ['fetch_temporal200.py', '--job-id', JOB, '--review-marker', MARKER,
                '--review-marker-sha256', MARKER_SHA, '--environment-json', str(env),
                '--output-dir', str(self.root)]
        with patch.object(sys, 'argv', args), patch.object(fetch.subprocess, 'run',
                                                        side_effect=AssertionError('SSH forbidden')):
            with self.assertRaisesRegex(RuntimeError, 'before SSH'): fetch.cli()


if __name__ == '__main__':
    unittest.main(verbosity=2)
