"""Strict offline shift30 h2,.5,.125,.0625 comparison; no fit or approval."""
import argparse
import json
from pathlib import Path,PurePosixPath
import sys
sys.dont_write_bytecode=True
import numpy as np
import firstwave_helpers as f
h=f.h

MARKER_SHA='50ef62531e338f57b5cbc78d05905a2cd5d805297407a4ba0913cedf3a5404df'
RUNNER_SHA='7f0500a8a037961a3d72e3aa5d58ae2cd52ebbab2a8505f5395097adfac5c857'
FAMILY='s2_shift30_convergence_20261007'
TASK_MAP=[[.125,1],[.125,-1],[.0625,1],[.0625,-1]]
PREFIX='s2_shift30_task'
MARKER_REMOTE='/work/data/s2_shift30_review_20261007_1142.json'


def validate_new_pins(pins,prefix=PREFIX):
    expected=dict(schema=1,family=FAMILY,marker_sha256=MARKER_SHA,runner_sha256=RUNNER_SHA,marker_remote=MARKER_REMOTE)
    h.require(all(pins.get(k)==v for k,v in expected.items()),'New artifact pin family/marker/runner mismatch')
    names={f'{prefix}{t:02d}_{suffix}' for t in range(4) for suffix in ('original.json','ports.npz')}
    files=pins.get('files',{})
    h.require(set(files)==names and all(isinstance(v,str) and len(v)==64 and all(c in '0123456789abcdef' for c in v)
              for v in files.values()),'Exact four checkpoint/NPZ byte pins are required')


def validate_local_sources(repo,marker):
    root=Path(repo).resolve();verified={}
    for name,digest in marker['code'].items():
        h.require(Path(name).name==name,'Unsafe frozen source basename')
        path=root/name if name in ('config.py','bragg_device.py','simulation_config.py','sim_helpers.py') else root/'runners/lumopt2_design'/name
        h.require(f.sha(path)==digest,'Current local frozen dependency hash mismatch: '+name)
        verified[name]=digest
    return verified


def validate_marker(marker,first_report,evidence):
    expected=dict(schema=1,family=FAMILY,status='APPROVED_FOR_BOUNDED_SHIFT30_TRANSLATION_STEP_DIAGNOSTIC',
        center_sha256=f.CENTER_SHA,runner_sha256=RUNNER_SHA,task_map=TASK_MAP,allowed_tasks=[0,1,2,3])
    h.require(all(marker.get(k)==v for k,v in expected.items()),'Shift30 exact marker scope mismatch')
    h.require(marker.get('code',{}).get('s2_shift30_convergence.py')==RUNNER_SHA,'Shift30 frozen runner hash mismatch')
    wave=marker.get('first_wave',{})
    h.require(wave.get('first_marker')==f.MARKER_REMOTE and wave.get('first_marker_sha256')==f.MARKER_SHA,
        'Original first-wave marker binding mismatch')
    firstmarker,_=h.load_json(Path(evidence)/'s2_half_classes_first_review_original.json',f.MARKER_SHA)
    h.require(wave.get('provenance_report')==firstmarker['provenance_report'] and
              wave.get('provenance_report_sha256')==firstmarker['provenance_report_sha256'] and
              all(marker['code'].get(k)==v for k,v in firstmarker['code'].items()),'Frozen first-wave provenance/code mismatch')
    for task in range(4):
        row,digest=h.load_json(Path(evidence)/f's2_half_classes_task{task:02d}_original.json')
        result=row['result'];bound=wave.get('checkpoints',{}).get(str(task),{})
        expected_bound=dict(checkpoint=firstmarker['output_root']+f'/task_{task:02d}.json',sha256=digest,
            ports_sha256=result['ports_sha256'],source=result['source'],h5=result['h5'],
            peak3_tout=result['peak3_tout'],peak3_modal=result['peak3_modal'],lam_nm=result['lam_nm'])
        h.require(bound==expected_bound,'Exact completed first-wave checkpoint binding mismatch')
    h.require(first_report['provenance']['center_sha256']==f.CENTER_SHA and
              isinstance(marker.get('lead_verdict'),str) and marker['lead_verdict'].strip() not in ('','NOT_REVIEWED'),
              'Lead review/center binding missing')


def validate_new(row,task,center,marker,ports_sha,marker_remote):
    ident,result=row['identity'],row['result'];step,sign=TASK_MAP[task]
    expected=dict(schema=1,task=task,index=149,class_label='shift_30',sign=sign,perturbation_nm=step,
                  task_map=TASK_MAP,center_sha256=f.CENTER_SHA,center_checkpoint=f.CENTER_REMOTE,code=marker['code'])
    h.require(type(ident.get('task')) is int and all(ident.get(k)==v for k,v in expected.items()),
              'Shift30 full task/index/step/source/center identity mismatch')
    for key,value in dict(task=task,index=149,class_label='shift_30',sign=sign,perturbation_nm=step,delta_nm=step*sign,
        reviewed_center_sha256=f.CENTER_SHA,comparison_status='REVIEW_REQUIRED_NO_AUTOMATIC_PHYSICS_PASS',
        existing_overall_gradient_gate='FAILED_UNCHANGED',ports_sha256=ports_sha).items():
        h.require(result.get(key)==value,'Shift30 result metadata mismatch: '+key)
    h.require(ident['spec'].get('label')==FAMILY and h.spec_equal(ident['spec'],center['identity']['spec']),
              'Shift30 complete numerical-family spec mismatch')
    review=dict(path=marker_remote,sha256=MARKER_SHA,first_wave=marker['first_wave'],lead_verdict=marker['lead_verdict'],allowed_tasks=[0,1,2,3])
    h.require(ident.get('parent_review')==review and result.get('parent_review')==review,'Shift30 parent-marker identity mismatch')
    point=np.asarray(center['identity']['point'],float).copy();point[149]+=step*sign
    h.match_point(ident.get('point'),point,'Shift30 full parameter delta mismatch')
    h.match_point(result.get('params'),point,'Shift30 full result parameter mismatch')
    paths={k:PurePosixPath(result[k]) for k in ('source','h5','ports_npz')};root=PurePosixPath(marker['output_root']);attempt=paths['ports_npz'].parent
    h.require(all(p.is_absolute() and '..' not in p.parts and p.is_relative_to(root) for p in paths.values()) and
        attempt.name.startswith(f'task_{task:02d}_') and paths['source'].is_relative_to(attempt) and
        paths['source'].name=='fwd_default.fsp' and paths['ports_npz'].name=='ports.npz' and
        paths['h5']==paths['source'].with_suffix('')/(paths['source'].stem+'_output.h5'),
        'Shift30 source/H5/NPZ path identity mismatch')


def peak_location(spectrum,baseline,eng):
    k,height,weights=f.selected_peak(spectrum,baseline['p2_lambda'],eng)
    wl=np.asarray(baseline['p2_lambda']).ravel();freq=np.asarray(baseline['p2_f']).ravel()
    df=np.diff(freq)
    h.require(np.all(df>0) and np.allclose(df,df[0],rtol=1e-10,atol=0),'Expected uniform frequency sampling')
    offset=float(weights[2]-weights[0])
    return dict(index=k,sampled_lambda_nm=float(wl[k]*1e9),vertex_offset_samples=offset,
                fitted_index_vertex_lambda_nm=float(299792458./(freq[k]+offset*df[k])*1e9),peak3=height)


def analyze(evidence,pins,repo,new_pins,prefix=PREFIX):
    evidence=Path(evidence)
    validate_new_pins(new_pins,prefix);marker_remote=new_pins['marker_remote']
    marker,marker_sha=h.load_json(evidence/'s2_shift30_review_original.json',MARKER_SHA)
    local_sources=validate_local_sources(repo,marker)
    # Reuse already-tested first-wave validation/role bindings/arithmetic.
    first_report,first_spectra=f.analyze(evidence,pins,repo)
    validate_marker(marker,first_report,evidence)
    h.require(PurePosixPath(marker_remote).is_absolute() and '..' not in PurePosixPath(marker_remote).parts,
              'Declared remote shift-marker path must be absolute')
    center,_=h.load_json(evidence/'s2_fdstep_task00_original.json',f.CENTER_SHA)
    baseline=h.load_npz((evidence/'s2_fdstep_task00_ports.npz').read_bytes())
    sys.path.insert(0,str(Path(repo).resolve()))
    from runners.lumopt2_design import recover_te_s2 as recovery
    arrays=[];provenance={}
    for task in range(4):
        cp=f'{prefix}{task:02d}_original.json';npz=f'{prefix}{task:02d}_ports.npz'
        row,digest=h.load_json(evidence/cp,new_pins['files'][cp]);raw=(evidence/npz).read_bytes()
        h.require(h.sha(raw)==new_pins['files'][npz],'Independent transferred NPZ byte pin mismatch')
        validate_new(row,task,center,marker,h.sha(raw),marker_remote)
        a=h.load_npz(raw);h.check_grid(a,baseline,center['identity']['spec']['n_wl_points'])
        f.verify_scores(row,a,recovery.score);arrays.append(a)
        provenance[cp]=digest;provenance[npz]=h.sha(raw)
    report=dict(schema=1,status='DIAGNOSTIC_ONLY_CALIBRATION_FAILED_UNCHANGED',no_automatic_approval=True,
        steps_nm=[2.,.5,.125,.0625],center_sha256=f.CENTER_SHA,marker_sha256=marker_sha,
        marker_remote=marker_remote,runner_sha256=RUNNER_SHA,firstwave_provenance=first_report['provenance'],
        local_frozen_dependency_sha256=local_sources,
        new_original_bytes=provenance,grid_equality='ALL_REQUIRED_NEW_AND_EXISTING_GRIDS_MATCH_EXACTLY',observables={},
        limitations=['No new fit, scientific pass or approval marker is produced.',
            'Step differences do not certify convergence order or a statistical noise bound.',
            'All common-center projections use the exact repeated nominal center; historical native h2 center is retained separately.',
            'Fixed-center spectral-Jacobian FD and moving-peak FD may differ at finite steps.',
            'Offline identity/NPZ/scalar checks do not re-open remote FSP/H5 or certify server solve completion. Parent verifies artifacts.',
            'Old h2 export and FD creator roles retain their qualified historical provenance.'])
    oldinfo,oldarrays=f.old_shift_inputs(pins,center,baseline,recovery.score)
    halfarrays=[h.load_npz((evidence/f's2_half_classes_task{t:02d}_ports.npz').read_bytes()) for t in (2,3)]
    spectral=dict(grids={key:baseline[key].ravel().tolist() for key in h.GRIDS},observables={})
    for metric,transform in h.METRICS.items():
        select=lambda s:f.selected_peak(s,baseline['p2_lambda'],recovery.eng)
        common=transform(baseline);half=first_report['observables'][metric]['shift30_half_step']
        records={'0.5':half};derivatives={'0.5':first_spectra[metric]['shift30_half_spectral_fd']}
        old=first_report['observables'][metric]['shift30_old_h2']
        if old.get('available') is False:
            records['2']=old
        else:
            records['2']=old['repeated_center_even_terms']
            derivatives['2']=first_spectra[metric]['shift30_h2_spectral_fd']
        locations={}
        for step,plus,minus in ((.125,arrays[0],arrays[1]),(.0625,arrays[2],arrays[3])):
            p,m=transform(plus),transform(minus)
            result,derivative=f.pair_report(p,m,common,step,select);records[str(step)]=result
            derivatives[str(step)]=derivative.tolist()
            locations[str(step)]=dict(plus=peak_location(p,baseline,recovery.eng),
                                      minus=peak_location(m,baseline,recovery.eng),center=peak_location(common,baseline,recovery.eng))
        # Existing endpoint wavelengths are computed from actual arrays, not
        # confused with the runner's separately recorded sampled modal lambda.
        locations['0.5']=dict(plus=peak_location(transform(halfarrays[0]),baseline,recovery.eng),
                minus=peak_location(transform(halfarrays[1]),baseline,recovery.eng),center=peak_location(common,baseline,recovery.eng))
        # Historical h2 lambda/indices are already recorded and validated by
        # the first-wave helper; preserve its source roles explicitly.
        if oldarrays is not None:
            locations['2']=dict(plus=peak_location(transform(oldarrays[1]),baseline,recovery.eng),
                minus=peak_location(transform(oldarrays[2]),baseline,recovery.eng),center=peak_location(common,baseline,recovery.eng))
        else:locations['2']=oldinfo
        ordered=['2','0.5','0.125','0.0625'];differences=[]
        for left,right in zip(ordered[:-1],ordered[1:]):
            if 'central_derivative' not in records[left]:continue
            d0,d1=records[left]['central_derivative'],records[right]['central_derivative']
            differences.append(dict(steps=[float(left),float(right)],central_derivative_difference=d1-d0,
                relative_difference=(d1-d0)/d0 if d0 else None,
                spectral_fd_difference=f.difference(derivatives[right],derivatives[left])))
        # Full fixed-bin arrays preserve comparison data independently of the
        # moving peak's changing sample index. No center delta is a noise bound.
        pairs={.5:halfarrays,.125:arrays[:2],.0625:arrays[2:]}
        original=transform(oldarrays[0]) if oldarrays is not None else None
        if oldarrays is not None:pairs[2.]=oldarrays[1:]
        full={};two_centers={};oldlocation=None
        if original is not None:oldlocation=peak_location(original,baseline,recovery.eng)
        for step,endpoints in pairs.items():
            p,m=map(transform,endpoints);d=(p-m)/(2*step);key='2' if step==2. else str(step)
            full[key]=dict(plus=p.tolist(),minus=m.tolist(),odd=((p-m)/2).tolist(),central_derivative=d.tolist(),
                even_with_repeated_center=((p+m-2*common)/2).tolist(),
                even_with_original_center=((p+m-2*original)/2).tolist() if original is not None else None)
            repeat,_=f.pair_report(p,m,common,step,select)
            native,_=f.pair_report(p,m,original,step,select) if original is not None else (None,None)
            two_centers[key]=dict(repeated=repeat,original=native)
        spectral['observables'][metric]=dict(full_grid_steps=full,repeated_center_spectrum=common.tolist(),
            original_center_spectrum=original.tolist() if original is not None else None,
            center_difference=(common-original).tolist() if original is not None else None,
            center_provenance=dict(repeated_checkpoint_sha256=f.CENTER_SHA,original=oldinfo))
        report['observables'][metric]=dict(common_center_steps=records,peak_locations=locations,
            historical_h2_native=old.get('native_old_center',old),successive_observed_differences=differences,
            scalar_and_jacobian_by_center=two_centers,original_center_peak_location=oldlocation,
            center_provenance=spectral['observables'][metric]['center_provenance'])
    return report,spectral


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True);parser.add_argument('--evidence-dir',required=True)
    parser.add_argument('--pins',required=True);parser.add_argument('--pins-sha256',required=True)
    parser.add_argument('--new-pins',required=True);parser.add_argument('--new-pins-sha256',required=True)
    parser.add_argument('--new-prefix',default=PREFIX)
    parser.add_argument('--output',required=True);parser.add_argument('--spectra-output',required=True)
    args=parser.parse_args();pins,_=h.load_json(args.pins,args.pins_sha256)
    new_pins,_=h.load_json(args.new_pins,args.new_pins_sha256)
    h.require(not Path(args.output).exists() and not Path(args.spectra_output).exists(),'Outputs require exclusive new paths')
    h.require(Path(args.output).resolve()!=Path(args.spectra_output).resolve(),'Report and spectra require distinct paths')
    report,spectral=analyze(args.evidence_dir,pins,args.repo,new_pins,args.new_prefix)
    report['pins_sha256']=args.pins_sha256;f.write(args.spectra_output,spectral)
    report['new_pins_sha256']=args.new_pins_sha256
    report['spectra_file']=str(Path(args.spectra_output).resolve());report['spectra_sha256']=f.sha(args.spectra_output)
    f.write(args.output,report)
