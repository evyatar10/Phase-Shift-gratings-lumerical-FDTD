"""Readable plot of frozen diagnosis; mathematical analyzer remains unchanged."""
from pathlib import Path
import json,hashlib,numpy as np
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');OUT=Path(__file__).parent
r=json.loads((OUT/'actual/diagnosis.json').read_text());p=ROOT/'docs/readiness_evidence_20261007/s2_temporal200_spectra_1759.json'
assert hashlib.sha256(p.read_bytes()).hexdigest()==r['input_sha256'][str(p)]
s=json.loads(p.read_text());wl=np.asarray(s['grids']['p2_lambda']).ravel()*1e9
fig,axes=plt.subplots(2,2,figsize=(11,6),constrained_layout=True)
for row,obs in enumerate(['peak3_tout','peak3_modal']):
 v=r['observables'][obs];x=(wl-v['triplets']['150']['peaks']['center']['vertex_lambda_nm'])*1000;mask=abs(x)<160
 for g in ['center','plus','minus']:
  d=np.asarray(s['observables'][obs]['200'][g])-np.asarray(s['observables'][obs]['150'][g]);axes[row,0].plot(x[mask],d[mask],label=g)
 axes[row,0].set(xlabel='Offset from150ps nominal vertex (pm wavelength)',ylabel='200−150 power fraction',title='Outgoing Tout' if row==0 else 'Modal |S21|²');axes[row,0].legend(fontsize=9)
 for t,offset in [('150',-.15),('200',.15)]:
  terms=v['triplets'][t]['support_terms'];axes[row,1].bar(np.arange(3)+offset,[q['J_times_FD_per_nm_shift30'] for q in terms],width=.3,label=t+'ps')
 axes[row,1].set_xticks(np.arange(3),[str(q['index']) for q in terms]);axes[row,1].set(xlabel='Actual nominal peak3 support bin',ylabel='Jᵢ FDᵢ (power fraction / nm shift30)',title='Three support terms; sum cancels');axes[row,1].legend(fontsize=9)
fig.savefig(OUT/'support_diagnostic_readable.png',dpi=180);plt.close(fig)
