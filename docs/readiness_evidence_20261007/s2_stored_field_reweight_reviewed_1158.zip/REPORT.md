# Stored broadband port-field reweighting feasibility

**Yes: objective Jacobian weights are applied after the solve.** Changing the
Tout height Jacobian to quartic11, or to one-hot fixed-frequency weights, does not
by itself require new adjoint solves at the same original geometry/source/band.
This is computational feasibility, not a physical-gradient qualification. Original
scalar Re/Im contractions cannot be reweighted, but preserved broadband E datasets
can supply a new weighted contraction. No implementation or CAD/server action here.

## Exact source trace

Local vendor source text, normalized CRLF→LF, SHA256-matches the recorded original
Athena provenance for all six inspected files: fom.py, port_fom.py, base_fom.py,
simulation_results.py, project.py and fdtd_session.py. Raw Windows hashes differ
only by newline conversion; do not relax the runtime vendor byte-hash guard.
Recorded LF port_fom SHA8384f90c7df452169ab3ff922059e16e1a9eb954690c81090137ad466d4c33b5;
base_fom SHA4f411de2a13c356b862172c42cde0f789f898d6b8537d2051aadf6308362d3f1.

- engine lumopt2_design.py:1651 creates PortResults('Port_2','transmission',501λ);
  1662–1676 uses PortFom and applies Im=i only to already computed adjoint fields.
  Saved recovery spec has width_grad=False, wg_project=False, bc_patch=False.
- vendor fom/fom.py:65–69 resolves PortResults to PortFom.
- PortFom.setup_adjoint_simulation:72–127 selects source port Port_2 and calls port
  offset correction. No self.fct/get_jacobian/J weights appear in source setup.
  _update_port_positions:848–863 changes source position/phase from direction,
  local cell size and numerical wavevector; it does not insert spectral weights.
  Project.set_adj:619 calls that method then saves the adjoint file at627.
- PortFom._collect_fwd_side_aux:599–621 reads forward a/b/f and sourcepower;
  _compute_adjoint_fields_phased:707–717 reads raw saved adjoint E, then multiplies
  each λ by i*omega*0.25*conj(a_or_b)/P_source. Again no FOM Jacobian is inserted.
- BaseFom.get_jacobian:268–288 differentiates the current callable. At454 and461
  it obtains J and divides by monitor symmetry. At511 it accumulates
  (2*eps0*dV)*J[k]*E_fwd[k]*E_adj_scaled[k], then returns real part at515.
  dEps contraction is linear in that summed field. Negative quartic weights are
  therefore legitimate algebraic weights; they do not require a different source.
- engine2553–2559 already assembles one-hot abs(x[j]) selector gradients from the
  same solved port fields for wavelength-chain terms.
- recover_te_s2_peak.py:30–59 already changed legacy objective to peak3 and reused
  the original files without solves. Existing corr30 controls reproduced original
  peak3 raw Re/Im contractions to4.1e-14/5.25e-16 relative difference.

## Operator/observable qualification

PortResults.get_transmission_results:244–251 explicitly reads abs(T_out), an outgoing
mode-expansion transmission. It is **not general total-flux transmission**. The
vendor field formula uses outgoing mode amplitude a (Backward Port_2) and forward
sourcepower; it never reads S21 or differentiates an input-amplitude denominator.
Thus code intends a source-power-normalized port-overlap derivative. It does not
explicitly substitute modal |S21|², and code alone does not certify the formula's
actual source/mode normalization makes it an exact Tout derivative. Maxwell/port
normalization is not obtained by autograd through the callable; it is assumed by
the separately implemented field formula. Failed physical calibration remains failed.

Original stored NPZ illustrates why both observables must remain separate:

| fixed index | λ,nm | abs(Tout) | abs(S21)^2 | ratio |
|---|---:|---:|---:|---:|
|244|1560.902219323|0.857075358|0.925474423|0.926092971|
|252|1560.870219008|0.925724382|0.966142238|0.958165729|
|260|1560.838220005|0.852295736|0.851284270|1.001188165|

At these bins, |a2/a1|² reproduces |S21|² within~3e-15, with matching mode N values.
The differing Tout/modal ratio is wavelength-dependent. This does not identify their
geometry derivatives, or prove a1 is geometry-invariant. Do not calibrate away an
observable mismatch with a fitted global factor. Keep raw quadratures, fixed-frequency
FD abs(Tout), and fixed-frequency FD |S21|² separately labeled.

## Existing evidence and gaps

Original provenance s2_provenance_first_report_original.json records all four
Re/Im forward/adjoint datasets with501 frequencies, raw coordinates matching the
registered wavelengths within2.12e-22m, inferred E shape[1246,51,17,501,3], and
spatial interpolation none. Both original adjoint Port_2 phases are23.281589422deg;
Im=i is postprocessing, not a new peak-weighted injection. The original FSP/hash,
H5 size/mtime, exact point/spec/vendor checks remain necessary.

It did **not** capture FDTD::ports source-port/source-mode/global pulse spectrum
and amplitude, or actual finite E samples outside the old three-Jacobian support.
The inferred501-axis shape is not proof that each newly needed E slice is readable.
Selected source powers/mode normalizations also need explicit recording. The
reconstructor probe_other_classes_h1.py:108–160 retains a1..3-support check and
exact coordinate/λ component sampling; 247..257 quartic weights need a new bounded
support policy. The sampler itself can slice arbitrary registered indices.

## Minimal next test proposal; prioritize fixed frequencies

Use only the original saved point and each matching Re/Im pair. Read old peak3
support251,252,253 plus fixed Tout center/flanks244,252,260: union
**[244,251,252,253,260]**. Confirm actual original grids/index before pinning; an
unexpected index/order must be reported, not silently adjusted. Capture active
source-port/mode/spectrum/amplitude and finite a/b/N/sourcepower at these λ, then
read all Ex/Ey/Ez slices with existing strict no-solve/no-save-original guards.

For one parameter, preferably shift30 index149, rebuild its1nm mesher derivative
once with full nominal restoration. Apply old peak3 weights as the reproduction
control, then e244/e252/e260 as separately identified one-hot weights. Preserve
vendor phase/symmetry/normalization and report raw Re/Im, components/support, source
identities and finite-frequency FD comparisons for both Tout and modal. No fitted
coefficient or automatic pass. The union needs~0.483GiB selected Python fwd+adj
fields versus~0.290GiB for3; CAD full-component transient~8.06GiB is unchanged.

This is cheaper and more discriminating than adopting quartic11 now: it removes
peak selection/phase weighting from the immediate operator comparison. Available
coarse FD may still have finite-step error; the separately prepared smaller-step
ladder remains the qualification evidence, unchanged here. Quartic11 can later use
its own original-forward-derived247..257 Jacobian if the operator/source checks
support it. No new FDTD solely because the objective Jacobian changes.

Inspection only: normalized-source hash and saved-array arithmetic checks exit0.
No new executable, tests, integration, coefficients or hardware scientific pass.
