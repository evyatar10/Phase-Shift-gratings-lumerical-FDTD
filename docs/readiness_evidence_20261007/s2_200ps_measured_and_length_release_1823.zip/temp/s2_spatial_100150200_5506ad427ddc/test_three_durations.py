"""Focused new200 protocol tests; fake200 is copied150 data,NOT measured200."""
import argparse,copy,json,sys,tempfile,unittest
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
import compare_three_durations as m
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');EV=ROOT/'docs/readiness_evidence_20261007';DATA=EV/'s2_saved_profiles_fetch_154823'
def fixture():
 out=Path(tempfile.mkdtemp(prefix='SYNTHETIC200_',dir=Path(__file__).parent));center=json.loads((EV/'s2_temporal150_fetch_1434/s2_temporal150_task03_original.json').read_text());marker=json.loads((EV/'s2_temporal200_review_original.json').read_text());row=copy.deepcopy(center)
 review=dict(path=m.e.MARKER,sha256=m.e.MARKER_SHA,lead_verdict=marker['lead_verdict'],allowed_tasks=[0,1,2],parent150=marker['parent150'],completed_step150=marker['completed_step150'])
 row['identity']=dict(schema=1,task=0,spec=marker['spec'],point=center['identity']['point'],index=29,sign=0,delta_nm=0.,duration_ps=200.,task_map=marker['task_map'],center_checkpoint=m.e.CENTER,center_sha256=m.e.CENTER_SHA,parent150=marker['parent150'],completed_step150=marker['completed_step150'],code=marker['code'],vendor_api_sha256=marker['vendor_api_sha256'],parent_review=review,timing_changes=marker['timing_changes'])
 r=row['result'];attempt=m.e.ROOT+'/task_00_SYNTHETIC200';r.update(task=0,index=29,sign=0,delta_nm=0.,duration_ps=200.,parent_review=review,vendor_api_sha256=marker['vendor_api_sha256'],source=attempt+'/files/fwd_default.fsp',h5=attempt+'/files/fwd_default/fwd_default_output.h5',ports_npz=attempt+'/ports.npz',SYNTHETIC_TEST_ONLY=True)
 for state in ['after','persisted']:r['controls'][state]['timing']['simulation time']=200e-12
 r['termination'].update(requested_time_s=200e-12,physical_time_s=200e-12,recorded_dt_s=r['controls']['dt_s'],delta_s=0.,iterations=3000000)
 cp=out/'SYNTHETIC200_checkpoint.json';cp.write_text(json.dumps(row));cp_sha=m.c.sha(cp.read_bytes());npz=out/'SYNTHETIC200_profiles.npz';npz.write_bytes((DATA/'profiles_150ps.npz').read_bytes());npz_sha=m.c.sha(npz.read_bytes())
 report=json.loads((DATA/'report.json').read_text());stage=copy.deepcopy(report['stages']['150']);stage['duration_ps']=200;remote_out='/work/results/SYNTHETIC200_EXTRACT';stage['profile_npz']=remote_out+'/profiles_200ps.npz';stage['profile_npz_sha256']=npz_sha
 inputs=[]
 for path,digest in [(m.e.ROOT+'/task_00.json',cp_sha),(r['source'],r['fsp_sha256']),(r['h5'],r['h5_sha256']),(r['ports_npz'],r['ports_sha256']),(m.e.MARKER,m.e.MARKER_SHA),(m.e.CENTER,m.e.CENTER_SHA)]+[('/work/project/'+name,digest) for name,digest in row['identity']['code'].items()]+[('/opt/lumerical/v261/api/python/'+name,digest) for name,digest in row['identity']['vendor_api_sha256'].items()]:inputs.append(dict(path=path,sha256=digest,bytes=1,mtime_ns=0))
 report.update(job='171390',independent_checkpoint_sha256=cp_sha,stages={'200':stage},inputs={'200':inputs},immutable_inputs_rechecked=[dict(before=copy.deepcopy(p),after=copy.deepcopy(p),unchanged=True) for p in inputs],SYNTHETIC_TEST_ONLY=True)
 rp=out/'SYNTHETIC200_report.json';rp.write_text(json.dumps(report));report_sha=m.c.sha(rp.read_bytes())
 receipt=dict(schema=1,source_job_id='171390',extraction_job_id='999999',extraction_state='COMPLETED',extraction_exit_code='0:0',producer_sha256=m.PINS['extract200.py'],core_reader_sha256=m.PINS['extract_saved_spatial_profiles.py'],checkpoint_path=m.e.ROOT+'/task_00.json',checkpoint_sha256=cp_sha,report_path=remote_out+'/report.json',report_sha256=report_sha,npz_path=stage['profile_npz'],npz_sha256=npz_sha)
 receipt_file=out/'SYNTHETIC200_receipt.json';receipt_file.write_text(json.dumps(receipt))
 args=argparse.Namespace(repo=str(ROOT),evidence_dir=str(EV),history_dir=str(DATA),history_only=False,checkpoint200=str(cp),checkpoint_sha256200=cp_sha,ports200=str(EV/'s2_temporal150_fetch_1434/s2_temporal150_task03_ports.npz'),report200=str(rp),report_sha256200=report_sha,npz200=str(npz),npz_sha256200=npz_sha,receipt200=str(receipt_file),receipt_sha256200=m.c.sha(receipt_file.read_bytes()))
 return args,report,row,receipt,out
class Tests(unittest.TestCase):
 def test_actual_history_preserved_exactly(self):
  args=argparse.Namespace(repo=str(ROOT),evidence_dir=str(EV),history_dir=str(DATA),history_only=True);result,stored=m.analyze(args)
  self.assertEqual(result['history100150'],json.loads(Path(m.__file__).with_name('history_reference.json').read_text()));self.assertNotIn(200,result['stages'])
 def test_positive_SYNTHETIC200_metadata_profile_math_and_mat(self):
  args,report,row,receipt,out=fixture();result,stored=m.analyze(args);self.assertTrue(result['SYNTHETIC200_NOT_MEASURED']);self.assertEqual(result['changes']['200_minus_150']['tracked']['Tout']['FWHM_um'],0.)
  self.assertEqual(result['stages'][200]['profiles']['modal']['canonical_production_N98']['FWHM_um'],19.640126650574587)
  metadata=m.compact_mat(out/'SYNTHETIC200_processed.mat',result,stored);self.assertTrue(metadata['no_raw_E']);self.assertEqual(metadata['roundtrip'],'EXACT_ARRAYS_AND_NEARBY_TABLE')
  from scipy.io import loadmat
  mat=loadmat(out/'SYNTHETIC200_processed.mat',simplify_cells=True);self.assertEqual(json.loads(mat['metadata_json'])['units']['monitor_lambda_m'],'m');self.assertIn(200,mat['nearby_table'][:,0]);self.assertFalse(any(k=='E' or k.endswith('_E') for k in mat))
 def test_receipt_missing_producer_byte_pin_path_and_class_refuse(self):
  args,report,row,receipt,out=fixture()
  for key,value in [('producer_sha256','0'*64),('report_sha256','0'*64),('checkpoint_path',m.e.ROOT+'/task_01.json'),('npz_path','/work/results/../profiles_200ps.npz'),('extraction_state','RUNNING')]:
   bad=copy.deepcopy(receipt);bad[key]=value
   with self.assertRaises((ValueError,RuntimeError)):m.receipt200(bad,report,row,args.checkpoint_sha256200,args.report_sha256200,args.npz_sha256200)
  bad=copy.deepcopy(report);bad['FDTD_constructor_unchanged']=False
  with self.assertRaises(ValueError):m.receipt200(receipt,bad,row,args.checkpoint_sha256200,args.report_sha256200,args.npz_sha256200)
 def test_raw_input_hash_and_CP_role_refuse(self):
  args,report,row,receipt,out=fixture();args.npz_sha256200='0'*64
  with self.assertRaises(ValueError):m.analyze(args)
  marker=json.loads((EV/'s2_temporal200_review_original.json').read_text());center=json.loads((EV/'s2_temporal150_fetch_1434/s2_temporal150_task03_original.json').read_text());row['identity']['task']=1
  with self.assertRaises(RuntimeError):m.e.validate_metadata(row,marker,center)
 def test_grid_crop_and_nearby_support_refuse(self):
  args,report,row,receipt,out=fixture();arrays=m.c.npz(Path(args.npz200).read_bytes());ports=m.c.npz(Path(args.ports200).read_bytes());sys.path.insert(0,str(ROOT));from runners.lumopt2_design import lumopt2_design as eng
  bad={k:v.copy() for k,v in arrays.items()};bad['monitor_lambda_m'][0]+=1e-18
  with self.assertRaises(ValueError):m.stage200(report,row,bad,ports,eng)
  bad=copy.deepcopy(report);bad['stages']['200']['nearby_profiles'].pop('247')
  with self.assertRaises(ValueError):m.stage200(bad,row,arrays,ports,eng)
  bad={k:v.copy() for k,v in arrays.items()};bad['Tout__I_y_integrated'][0]+=1e-9
  with self.assertRaises(ValueError):m.stage200(report,row,bad,ports,eng)
if __name__=='__main__':unittest.main(verbosity=2)
