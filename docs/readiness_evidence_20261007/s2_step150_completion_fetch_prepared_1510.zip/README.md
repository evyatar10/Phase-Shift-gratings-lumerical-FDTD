# Step150 completion-fetch preparation

NEW TEMP helper only. No network, container, CAD, solve, repository edits,
upload or dispatch occurred during preparation. Parent reviews this packet
and decides when completion permits actual fetch. Importing the helper does
not perform any action; only its explicit CLI connects to Athena.

Target is exactly `runners.lumopt2_design.s2_temporal_step150`, runner SHA
`c41f522e8502598c4b8a3d4a4096baf094ede8a1c66763169992fbc82d696c8a`,
frozen temporal base SHA
`555f3d13b42c494171e7658cc4263c588ce418e5d937da1497d690824b41d44a`.
New tasks are 0/1, index149, +/-0.125nm, fixed150ps. Target output is
`/work/results/diagnose_te_s2_step150/results/s2_shift30_step150_20261007`.
Parent150 task03 is reused with exact checkpoint SHA
`a0ff55eacaa52e00a2aab17dcc43d0e5fff9a72566e15da371ff25279c172663`;
parent task04/05 and marker pins remain mandatory ancestry. The helper does
not interpret the older task3/4/5 mapping as new output tasks.

Required CLI arguments, with no guessed/default job or approval:

```
python -B fetch_step150.py --job-id ACTUAL_ARRAY_JOB_ID --review-marker ACTUAL_WORK_DATA_MARKER_JSON --review-marker-sha256 ACTUAL_LOWERCASE_SHA256 --environment-json ACTUAL_LOCAL_ENV_JSON --output-dir NEW_ABSOLUTE_LOCAL_DIRECTORY
```

The environment JSON must contain exactly the seven launch variables:
`S2_STEP150_REPO`, `S2_STEP150_OUTPUT_ROOT`, `S2_STEP150_PARENT_ROOT`,
`S2_STEP150_PARENT_MARKER`, `S2_STEP150_REVIEW_MARKER`,
`S2_STEP150_REVIEW_SHA256`, `KEEP_H5`. Paths equal the runner's fixed family
and parent paths; review path/hash must equal caller CLI arguments; KEEP_H5=1.
The parent supplies the actual exported launch environment. SYNTHETIC job
12345 in the tests is solely a test input; no job is submitted or contacted.

Both exact sacct array-task rows must be COMPLETED/0:0, with no duplicate or
additional array-task indices. Both completed checkpoints must exist before
entering container cold verification. A wrong/noncomplete job aborts before
runner import. Inside the same Linux config used by the Athena wrapper,
runner and base byte hashes and the actual new review marker are checked;
`main`, `forward_only`, parent main/forward_only, `make_project` and
`import_lumopt2` are explicitly blocked. Then `frozen_base`, `load_ancestry`,
`reviewed`, `identity`, `read_checkpoint` and `verify_result` run read only.
These enforce source/vendor/parent FSP/H5/ports/log/controls/time/grid/score
identities. Missing/corrupt evidence fails; it cannot start a replacement solve.
Python optimization flags are rejected so assert-based remote guards stay active.

Original CP/NPZ hashes are checked again after cold validation and before
transfer, catching concurrent changes. The local receiver checks task/family,
exact +/-step/150ps/point/center/source/marker/parent identities, transferred
hashes, duplicated cold score/vendor/control fingerprints and source records.
It does not rerun physical extraction from local FSP/H5; those large files
are checked remotely and retained there. Local NPZ bytes are transported
unchanged; no copied result is relabeled into a passing calibration.

Publication requires a NEW absolute directory and exclusive file opens.
Original CP/NPZ bytes and JSON receipts are fsynced. Existing output is refused
before SSH. If local publication is interrupted, evidence remains and another
explicit new destination is required; no deletion/overwrite/cleanup is attempted.
The artifact-pins file, completed receipt and fetch manifest record local/original
hashes, actual job/review/environment, source bindings and helper identity.
The CLI returns all three document SHA256 values. It downloads no FSP/H5.

Seven focused offline test groups cover exact launch inputs, accounting and
tasks, cold/no-solve guards and precheck ordering, original-byte exclusive
publication, job/marker/path/hash/task/family/missing-artifact tampering,
repinned checkpoint score/vendor/control tampering, and pre-SSH output refusal.
Fixtures are explicitly SYNTHETIC protocol evidence, using preserved parent
CP/NPZ bytes solely as test data. No current runner main is imported or executed
by local tests. Full remote completion validation and actual fetch remain pending.
