# Five-class stored-field h1 reconstruction: preparation only

No repository/server changes or FDTD dispatch. Parent decides preflight and dispatch.
Original corr30 probe and guard package remain untouched. Runner uses only the five
live-validator pairs `(0,corr_1),(60,avg_1),(120,shift_1),(149,shift_30),(295,wcav)`.
The exact original recovered point is retained: respective values 5,951.4,5,5,961.4nm.
Corr30 index29 is explicitly excluded. Each quadrature job shares one exact selected
three-wavelength vendor gradient assembly across the five 1nm CAD mesher derivatives.

## Safety and reference identity

Full nominal geometry is restored before every bounding-box lookup and in `finally`
after every private single-parameter call, including an exception. Bounds must leave
both central legs inside the original domain, so vendor midpoint shifts fail closed.
Objects come from each live geometric-Jacobian column; the original vendor bbox,
sparse derivative and postprocess remap are retained. The vendor one-element list
uses index0; actual parameter index is preserved in `params[index]` keys.

CLI and complete spec/original FSP+HDF5 identity/vendor source checks are inherited.
The exact original task00(Re)/task01(Im) complete JSON records are canonically SHA256
bound: `json.dumps(row,sort_keys=True,separators=(',',':'),allow_nan=False)`, UTF8.
This tolerates formatting changes only; changed code, gradients or other content fail.
Raw byte SHA is separately reported. Historical source is not falsely required equal
to the documented later optimizer-only integration. Current source/dependencies are
reported independently. No failed calibration coefficient is required or installed.
Guard is an exact private copy (SHA40dd4878...99d); no shared guard modification.
The runner uses generate/update_structure, never Project.set_fwd.

## Invocation after parent review

Use the same deployed repo/lumapi/provenance/old-root arguments as the successful
corr30 job, replace only runner filename and a new exclusive output directory.
For Re, `--quadrature re --saved-gradient
/work/results/recover_te_s2_peak/results/lumopt2_te_s2_peak_calibration_20261006/task_00.json`;
for Im choose `im` and task_01.json. `--provenance` must be the preserved original
complete report and `--reviewed-provenance-sha256` must equal
`a742c0d0921620a04d7e186a9baf7a1959d9752a40c7729815825265fe8c5c47`.
Output directories must not exist; final file is `other_classes_h1.json`.

Each class reports original six-vector position/value, new raw contraction,
signed/relative difference, Ex/Ey/Ez contractions, affected objects, sparse support
SHA/nonzero/L1/L2, index wavelength/globalshape and mesh readback. Field hash,
exact active wavelengths/Jacobian, original center, source/spec/vendor and CAD call
audits are preserved. No automatic calibration pass, inferred cause, tolerance,
noise estimate, coefficient fit or optimizer is included. Compare with original
six-vector and existing corr30 reports; a discrepancy is evidence to investigate.

## Tests and resources

Nine focused offline tests exit0, retained in offline_tests.log and
 offline_test_result.json. They include all five mappings/negative class and index
controls, full restoration success/failure, interior midpoint, actual saved checkpoint
and spec/task/code/vector negatives, complex selected-field equivalence and guards.
No full13 integration suites are necessary for this isolated helper.

CPU only: conservative128G,8CPUs,45min request as for the already completed original
CPU probes; parent must confirm time/resource headroom. Prefer serial Re then Im.
No runtime bound is measured for the new five-class path. It has10 central signed
CAD eps samplings plus nominal restoration/index meshing; shift/wcav supports may
be larger. Do not infer lower memory from fewer solves: no FDTD occurs here at all.
Each CAD getdata/pinch can temporarily hold a full component (~8.06GiB on the stored
1246x51x17x501 grid). Selected3-wavelength forward+adjoint Python fields are about
0.290GiB plus25MiB dense contraction; CAD saved results/index/sparse arrays add
implementation-dependent memory. Full E/H arrays are never requested into Python.

One optional actual hidden local wcav private-API check is in check_hidden_wcav.py;
exit0 result is retained under hidden_wcav/report.json: key params[295]::params[295],
shape[1246,51,17,1], cavity_198 support, eps_x/y/z nonzero126/108/96. This build/mesher check
uses no stored forward/adjoint field and establishes no new gradient physics.
