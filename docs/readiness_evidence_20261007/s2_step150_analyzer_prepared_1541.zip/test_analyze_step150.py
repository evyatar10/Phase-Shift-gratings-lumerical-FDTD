"""Offline SYNTHETIC new-task protocol/math fixtures, never new FDTD evidence."""
import ast
import base64
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
import numpy as np
import analyze_step150 as analyzer

ROOT = Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
E = ROOT/'docs/readiness_evidence_20261007'
PARENT = E/'s2_temporal150_fetch_1434'
PARENT_MARKER = E/'s2_temporal150_review_original.json'
NEW_MARKER = E/'s2_step150_review_1507.json'
NEW_SHA = '8cc8e9da52262b19f4fd51d98c11de1a686c7e61b8c8bf2b364944922677dc0f'


class StepAnalysisChecks(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix='SYNTHETIC_step_analysis_', dir=Path(__file__).parent))
        self.marker, _ = analyzer.h.load_json(NEW_MARKER, NEW_SHA)
        self.parent_marker, _ = analyzer.h.load_json(PARENT_MARKER, analyzer.contract.PARENT_MARKER_SHA)
        self.module = analyzer.modules(ROOT, self.parent_marker, self.marker)
        self.env = dict(S2_STEP150_REPO='/work/project', S2_STEP150_OUTPUT_ROOT=analyzer.contract.OUTPUT_ROOT,
                        S2_STEP150_PARENT_ROOT=analyzer.contract.PARENT_ROOT,
                        S2_STEP150_PARENT_MARKER=analyzer.contract.PARENT_MARKER,
                        S2_STEP150_REVIEW_MARKER='/work/data/s2_step150_review_20261007_1507.json',
                        S2_STEP150_REVIEW_SHA256=NEW_SHA, KEEP_H5='1')
        self.payload = dict(job_id='12345', review_marker=self.env['S2_STEP150_REVIEW_MARKER'],
                            review_marker_sha256=NEW_SHA, environment=self.env, family=analyzer.contract.FAMILY,
                            runner_sha256=analyzer.contract.RUNNER_SHA, base_helper_sha256=analyzer.contract.BASE_SHA,
                            at='SYNTHETIC_NOT_COLD_VERIFIED_NO_NEW_SOLVE',
                            accounting='12345_0|COMPLETED|0:0|\n12345_1|COMPLETED|0:0|', verified_records=[], files={})
        center = json.loads((PARENT/'s2_temporal150_task03_original.json').read_text())
        self.rows, self.arrays = {}, {}
        for task, old_task in ((0, 4), (1, 5)):
            row = json.loads((PARENT/f's2_temporal150_task{old_task:02d}_original.json').read_text())
            result = row['result']; point, index, duration, sign = self.module.task_params(task)
            review = dict(path=self.env['S2_STEP150_REVIEW_MARKER'], sha256=NEW_SHA,
                          lead_verdict=self.marker['lead_verdict'], allowed_tasks=[0, 1], parent150=self.marker['parent150'])
            identity = dict(schema=1, task=task, spec=self.marker['spec'], point=point.tolist(), index=149,
                            sign=sign, delta_nm=sign*.125, duration_ps=150., task_map=self.marker['task_map'],
                            center_checkpoint=analyzer.contract.PARENT_ROOT+'/task_03.json', center_sha256=analyzer.contract.CENTER_SHA,
                            code=self.marker['code'], vendor_api_sha256=self.marker['vendor_api_sha256'],
                            parent_review=review, timing_changes=self.marker['timing_changes'])
            source = analyzer.contract.OUTPUT_ROOT+f'/task_{task:02d}_SYNTHETIC/files/fwd_default.fsp'
            ports = analyzer.contract.OUTPUT_ROOT+f'/task_{task:02d}_SYNTHETIC/ports.npz'
            result.update(task=task, index=149, sign=sign, delta_nm=sign*.125, duration_ps=150., params=point.tolist(),
                          source=source, h5=source[:-4]+'/fwd_default_output.h5', ports_npz=ports,
                          parent_review=review, reviewed_center_sha256=analyzer.contract.CENTER_SHA,
                          comparison_status=self.module.COMPARISON_STATUS, FDTD_version='SYNTHETIC_PROTOCOL_ONLY')
            result['termination']['log'] = source[:-4]+'_p0.log'
            control = result['controls']; control['before']['geometry'] = self.module.plain(self.module.eng.make_func(self.module.SPEC)(point))
            control['after'] = copy.deepcopy(control['before'])
            control['after']['timing'].update({'simulation time': 150e-12, 'use early shutoff': 0})
            control['after']['optimization_dft_enabled'] = 0
            control['persisted'] = copy.deepcopy(control['after'])
            control.update(before_sha256=self.module.semantic(control['before']),
                           after_sha256=self.module.semantic(control['after']),
                           persisted_sha256=self.module.semantic(control['persisted']),
                           serialization=self.module.persisted_check(control['after'], control['persisted']))
            result['center_control_comparison'] = self.module.center_control_comparison(control['before'], dict(result=center['result']))
            row['identity'] = identity
            raw_ports = (PARENT/f's2_temporal150_task{old_task:02d}_ports.npz').read_bytes()
            result['ports_sha256'] = analyzer.h.sha(raw_ports)
            cp = analyzer.contract.OUTPUT_ROOT+f'/task_{task:02d}.json'; raw_cp = json.dumps(row).encode()
            self.payload['verified_records'].append(dict(task=task, checkpoint=cp, checkpoint_sha256=analyzer.h.sha(raw_cp),
                source=source, ports=ports, ports_sha256=result['ports_sha256'], termination=result['termination'],
                fsp_sha256=result['fsp_sha256'], h5_sha256=result['h5_sha256'], parent_review=review,
                metrics={key: result[key] for key in analyzer.contract.METRICS}, vendor_api_sha256=result['vendor_api_sha256'],
                control_sha256={key: control[key] for key in ('before_sha256', 'after_sha256', 'persisted_sha256')}))
            for role, path, raw in (('checkpoint', cp, raw_cp), ('ports', ports, raw_ports)):
                self.payload['files'][f'{task}:{role}'] = dict(path=path, bytes=len(raw), sha256=analyzer.h.sha(raw),
                                                            data=base64.b64encode(raw).decode())
            self.rows[task] = row; self.arrays[task] = analyzer.h.load_npz(raw_ports)
        decoded = analyzer.contract.validate_payload(self.payload, '12345', self.env['S2_STEP150_REVIEW_MARKER'], NEW_SHA, self.env)
        self.completion = self.root/'NEW_SYNTHETIC_COMPLETION'
        self.published = analyzer.contract.publish(self.payload, decoded, self.completion)

    def analyze(self, history=False):
        return analyzer.analyze(PARENT, PARENT_MARKER, self.completion, self.published['manifest_sha256'],
                                NEW_MARKER, NEW_SHA, ROOT,
                                E/'s2_temporal150_review_1442.json' if history else None,
                                E/'s2_temporal150_spectra_1442.json' if history else None)

    def test_same_center_two_h_math_and_actual_pinned_temporal_history(self):
        report, spectra = self.analyze(history=True)
        self.assertEqual(report['center_checkpoint_sha256'], analyzer.contract.CENTER_SHA)
        self.assertTrue(report['no_objective_change'] and report['no_coefficient_installation'] and report['no_automatic_approval'])
        for metric, observable in report['observables'].items():
            small, large = observable['same150ps_steps']['h0.0625'], observable['same150ps_steps']['h0.125']
            # Both synthetic new endpoints use preserved small-h samples: changing
            # only the denominator must halve the FD; this is not actual new physics.
            self.assertAlmostEqual(large['central_derivative'], small['central_derivative']/2, places=14)
            self.assertEqual(large['center_peak3'], small['center_peak3'])
            for values in (small, large):
                self.assertEqual(values['signed_even_numerator'], 2*values['even'])
                self.assertEqual(values['signed_odd_numerator'], 2*values['odd'])
                self.assertEqual(set(values['fixed_bins']), {'244', '252', '260'})
                self.assertEqual(set(values['spline_observer']['windows']), {'20', '25', '30'})
            self.assertEqual(len(spectra['observables'][metric]['h0.125']['spectral_central_fd']), 501)
        self.assertIn('old_autoshutoff_67ps_approx', report['pinned_temporal_history']['observables']['peak3_tout'])

    def test_published_byte_tamper_and_wrong_manifest_pin_reject(self):
        with self.assertRaises(analyzer.h.EvidenceError):
            analyzer.completion_inputs(self.completion, 'b'*64, self.marker, NEW_SHA)
        path = self.completion/'s2_step150_task00_original.json'; original = path.read_bytes()
        path.write_bytes(original+b' ')
        with self.assertRaises(analyzer.h.EvidenceError): self.analyze()

    def test_wrong_h_point_source_marker_score_controls_and_termination_reject(self):
        parent_rows, arrays, ancestry = analyzer.parent_inputs(PARENT, self.parent_marker, self.module)
        center = parent_rows[3]
        changes = [lambda r: r['identity'].update(delta_nm=.0625),
                   lambda r: r['identity']['point'].__setitem__(148, r['identity']['point'][148]+.1),
                   lambda r: r['identity']['code'].update({'s2_temporal_step150.py': 'b'*64}),
                   lambda r: r['result']['parent_review'].update(sha256='b'*64),
                   lambda r: r['result'].update(peak3_tout=.123),
                   lambda r: r['result']['controls']['after']['source'].update(pulselength=1.),
                   lambda r: r['result']['termination'].update(physical_time_s=100e-12)]
        for change in changes:
            row = copy.deepcopy(self.rows[0]); change(row)
            with self.assertRaises(RuntimeError):
                analyzer.new_metadata(row, self.arrays[0], 0, self.marker, NEW_SHA,
                                      self.env['S2_STEP150_REVIEW_MARKER'], ancestry, center, self.module)

    def test_exact_grids_and_nominal_port_phase_only_two_ulp(self):
        center = analyzer.h.load_npz((PARENT/'s2_temporal150_task03_ports.npz').read_bytes())
        changed = {k: v.copy() for k, v in self.arrays[0].items()}; changed['p2_f'].flat[0] += 100.
        with self.assertRaises(analyzer.h.EvidenceError): analyzer.h.check_grid(changed, center, 501)
        row = json.loads((PARENT/'s2_temporal150_task03_original.json').read_text())
        before = copy.deepcopy(row['result']['controls']['before']); value = before['ports']['FDTD::ports::Port_1']['phase']
        for _ in range(3): value = float(np.nextafter(value, np.inf))
        before['ports']['FDTD::ports::Port_1']['phase'] = value
        with self.assertRaises(RuntimeError): self.module.center_control_comparison(before, dict(result=row['result']))

    def test_no_cad_network_solver_or_calibration_calls(self):
        with patch.object(analyzer.contract.subprocess, 'run', side_effect=AssertionError('Network forbidden')):
            self.analyze()
        for entry in (self.module.main, self.module.forward_only, self.module.eng.make_project, self.module.eng.import_lumopt2):
            with self.assertRaisesRegex(RuntimeError, 'Offline analyzer'): entry()
        tree = ast.parse(Path(analyzer.__file__).read_text())
        attrs = {node.func.attr for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)}
        self.assertFalse(attrs & {'run_forward', 'run_adjoint', 'compute_gradient', 'run_campaign', 'run_projected', 'load_ancestry', 'main', 'fit'})


if __name__ == '__main__':
    unittest.main(verbosity=2)
