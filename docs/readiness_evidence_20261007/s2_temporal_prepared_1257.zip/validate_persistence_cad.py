"""Hidden no-solve NEW FSP persistence check; accepts generated baseline path."""
import argparse,json,sys,tempfile,time,traceback
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,'C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
import s2_temporal_forward as r
import no_solve_guard as guard
import config
parser=argparse.ArgumentParser();parser.add_argument('--baseline-fsp',required=True);a=parser.parse_args()
baseline=Path(a.baseline_fsp).resolve();package=Path(__file__).parent.resolve()
assert baseline.is_relative_to(package) and baseline.is_file()
ROOT=Path(tempfile.mkdtemp(prefix='actual_persistence_cad_',dir=package))
config.LUMAPI_PATH='C:/Program Files/Lumerical/v261/api/python/lumapi.py';config.USE_GPU=False
r.eng.import_lumopt2()
import lumapi
sessions=[];symbol=lumapi.FDTD;restore=guard.install_constructor_guard(symbol,ROOT,sessions)
report=dict(mode='HIDDEN_LOCAL_NEW_FSP_SAVE_RELOAD_NO_SOLVE',baseline=str(baseline),baseline_sha256=r.sha(baseline),
    started=time.time(),runner_sha256=r.sha(r.__file__),harness_sha256=r.sha(__file__),measurements=[])
try:
    f=lumapi.FDTD(hide=True);p,index,_,sign=r.task_params(1)
    for duration in (100.,150.):
        f.load(str(baseline));c=r.controls(f,p,duration)
        dest=ROOT/f'duration{int(duration)}'/'fwd_default.fsp';dest.parent.mkdir()
        f.save(str(dest));digest=r.sha(dest);f.load(str(dest));reloaded=r.snapshot(f,p)
        report['measurements'].append(dict(duration_ps=duration,index=index,delta_nm=sign*.0625,
            source=str(dest),fsp_sha256=digest,persisted_snapshot_sha256=r.semantic(reloaded),controls=c,reloaded=reloaded))
        report['measurements'][-1]['serialization']=r.persisted_check(c['after'],reloaded)
        assert digest==r.sha(dest),'Readback changed saved FSP bytes'
    assert report['baseline_sha256']==r.sha(baseline),'Original generated baseline changed'
    report.update(passed=True,class_preserved=lumapi.FDTD is symbol)
except Exception as exc:report.update(passed=False,error=repr(exc),traceback=traceback.format_exc())
finally:
    report['audits']=[s.audit for s in sessions]
    for s in sessions:guard.attempt(s.close)
    restore();report['elapsed_seconds']=time.time()-report['started'];out=ROOT/'validation.json'
    with out.open('x') as stream:json.dump(guard.plain(report),stream,indent=2,allow_nan=False)
    print(out,flush=True);print('PASS' if report['passed'] else 'FAIL',report.get('error',''),flush=True)
sys.exit(0 if report['passed'] else 2)
