---

name: pi-shift-inverse-design

description: Review, validate, or develop the TE/TM lumopt2 inverse-design lane in Evyatar's pi-shift Bragg grating project, including stored campaign results, width constraints, gradients, and Lumerical monitor geometry.

---



# Pi-shift Bragg inverse design



Repository: `C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes`.

Read its `AGENTS.md`, the current dated recovery/audit documents it links, and

`runners/lumopt2_design/THEORY.md` §13. Read relevant current code before

acting on the historical `CLAUDE.md`, handoff snapshots, or `.claude/skills`.

Do not assume the Claude tool permissions/hooks or model routing exist here.

For the code architecture, uniform/nonuniform seed lineage and restart bugs,

read [continuation map](references/continuation-map.md).



## Scientific contract



- Spatial envelope FWHM is a two-sided optical design constraint. Use the

  production y-integrated profile/envelope convention, never sigma or raw-line

  FWHM as its substitute. Pre-2026-08-18 inverse-design widths are invalid.

- Spectral FWHM is different: `Q_L = lambda_res/abs(spectral_fwhm)`.

  `Q_i = Q_L/(1-sqrt(T))` is model-derived. `1-T` includes reflection;

  `1-T-R` is a residual, not automatically independently measured radiation.

- Find the defect resonance with `find_bragg_resonance`/`measure_peak`.

  Global `argmax(T)` can pick a passband. Fail conclusions on dead/off-window

  peaks, missing widths, unresolved linewidths, or failed extraction.

- Compare engine version, geometry, mesher/dx, domain, boundaries, and spectral

  window/points. PVA and conformal results are distinct numerics families.

  Reuse stored identical-numerics controls; fields needed by a new gradient

  justify its forward solve, not a redundant standalone benchmark.



## Current implementation and evidence



The user's October 7 priority is increased transmission at nearly constant

spatial FWHM; wavelength may drift. Read

`docs/TE_OBJECTIVE_DECISION_2026-10-07.md` and its source audit before changing

the FOM, enabling width reuse or implementing combined-source AL. Current v3

wavelength limits are local model-trust safeguards, not a global wavelength

target. Port selectors reuse solved fields and cost no extra FDTD adjoints.

A scalar MixedFom still has two physical adjoint files in the installed code.

Check the current continuation for integration status. The October7 consolidated

restart/modal changes are integrated and all13 offline suites passed; the modal

guard remains opt-in and hardware validation remains separate. Do not reapply

the historical candidate patch or infer hardware readiness from offline tests.



TE specs use `layout(60)`: 296 slots, of which 181 affect the bare geometry.

The cavity slot is `layout(60).I_CAV == 295`; slot180 is an inert comb

radius in the bare design. Derive probe indices from the live layout/validator,

never from the three60-slot active blocks or legacy191-slot slices. S1 and S2 have different seed

width anchors; identical N does not mean identical width constraints.



The v3 `peak3` objective consumes lumopt2 `abs(T_out)`; callback `t_pk` uses

modal `abs(S)**2`. Do not conflate them. The bounded QP carries width and

wavelength bands; its metric is bound-half-range squared. Preserve the local

wavelength trust bound and classify a trial before recentering. Width reuse

is off in the current v3 specs. Calibration factors are device/numerics

specific; do not transfer S1 factors to S2 to bypass a missing gate.



The 2026-10-06 recovery reproduced the saved S1 FOM exactly from T_out:

0.889772414 versus modal peak3 0.934610017. The ratio varies with wavelength

and geometry; neither a fixed 0.95 factor nor T_out/T_in is an exact conversion

on these saved spectra. New logs label both metrics. The wavelength-selector

denominator must use T_out slopes, matching its adjoint numerator (fixed in

the callback); it remains a translating-lineshape approximation. See

`docs/TE_RECOVERY_2026-10-06.md` for evidence and limits. Do not silently

replace the objective with modal S power without a consistent adjoint.



For interrupted S2 calibration use `recover_te_s2` (one FD leg per task,

atomic identity-checked checkpoints) and `recover_te_s2_peak` (current peak3

validation from the saved broadband fields). The legacy monolithic validator

is still not restart-safe. Do not change fingerprinted sources during those

jobs. Preserve successful FSP **and companion HDF5** files: FSP alone may not

contain the results. Use success logs and actual extraction to establish

completion. Peak-fit success must include per-class and held-out errors;

an old softmax fit alone does not prove the current objective's calibration.



For a failed calibration, distinguish metric mismatch, finite-step error,

numerical reproducibility and adjoint/geometry provenance. Inspect actual

spectra and identities before adding solves. A closely matching center repeat

is not a statistical noise bound. For symmetric steps h, inspect odd

O=(f+ - f-)/2 and even E=(f+ + f- -2f0)/2 separately: large even response alone

does not invalidate central D=O/h. Two step sizes cannot establish convergence

order; Richardson extrapolation is conditional. Use the exact peak3 Jacobian

for a spectral comparison, and do not transfer one parameter's wavelength slope

to another. Spectral FWHM from port scoring is not the spatial width constraint.



The October7 S2 peak and legacy fits failed. Full-vector minimax analysis showed

that reweighting the same two-coefficient global factor could not meet the10%

gate. Preserve failed evidence; a selected probe, matching signs or smaller

step alone cannot validate a global coefficient. Read

`docs/TE_S2_CALIBRATION_FAILURE_2026-10-07.md` for measurements, corrected Claude

reviews and the tested offline comparison calculator. Adopt advisory claims

only after verifying against code/data; label open hypotheses explicitly.



Port `T_out` is outgoing mode-expansion transmission, not a general total-flux
monitor result. Check normalization against the saved expansion/source data;
the built-in mode expansion includes grid-dispersion corrections, so continuum
amplitude formulas or `T_out/T_in` need not reproduce reported S exactly.
[Ansys mode-expansion guidance](https://optics.ansys.com/hc/en-us/articles/360034902433-Using-and-understanding-Mode-Expansion-Monitors)
describes that distinction. Do not equate either observable's gradient by a
fixed transmission ratio when that ratio varies with geometry.

For the inspected broadband PortFom implementation, port-source setup does not
include objective-Jacobian weights; BaseFom applies them after field retrieval.
This permits isolated one-hot or alternative weighted reconstructions from
preserved broadband fields, after verifying exact vendor/source identity,
readable finite wavelength slices, unchanged normalization and a reproduced
original-objective control. It is not evidence that the reconstructed operator
is already the physically correct gradient. Keep Tout and modal FD comparisons
separate, and do not generalize this reuse to the forward-dependent width source.

Small peak-height error does not guarantee a small local gradient error: a

small ripple over a short parameter interval can have a substantial derivative.

When a finite perturbation moves the selected peak across frequency bins,

compare the moving-peak objective FD with the nominal objective-Jacobian

projection of the spectral FD. Their finite-step disagreement is not itself

an adjoint failure. Translation/interpolation models can test this mechanism,

but are not measured physics or noise bounds. Saved scalar Re/Im objective

contractions do not provide a full wavelength-resolved adjoint Jacobian.



When auditing PVA finite-step sensitivity, record both FDTD properties:

`mesh refinement` (method) and `meshing refinement` (accuracy setting).

[Ansys mesh guidance](https://optics.ansys.com/hc/en-us/articles/360034382614-Selecting-the-best-mesh-refinement-option-in-the-FDTD-simulation-object)

recommends precise volume averaging for inverse design and describes an

adjustable refinement setting. Read its actual saved value; a documented

default is not measured provenance. Changing it creates a new numerical

comparison and does not justify overwriting frozen calibration sources or

assuming it repairs a failed gradient.



A checkpoint made by a read-only exporter fingerprints that export operation,

not automatically the creation of the stored FSP. Bind exporter and forward-job

identities separately when their historical code maps differ; retain explicit

raw/semantic hashes and numerical-family checks. Never erase a mismatch by

accepting arbitrary source maps or call exporter metadata original-solve proof.

The October7 four-step analyzer has a tested role-specific correction for this.



Saved eval numbers restart from zero. Identify a row by its position/time,

parameters and provenance, not just `eval`. Use `_best_from_log` for eligible

restart selection and `_row_of_params` for the newest measurement. Verify

the returned vector against its own bounds and optstate before a restart.

Keep original JSONL, optstate, gradient NPZ, and costly results intact.



## Validation ladder



1. `python runners/lumopt2_design/gates/run_all_gates.py`: offline math,

   wrapper, bounds (including TE) and TM compatibility. Check exit status.

2. For geometry, source, monitor or wrapper changes,

   `python -u runners/lumopt2_design/gates/gate_te_local.py --generate`:

   hidden local CAD builds, geometry equivalence, monitor checks and

   `project.generate()`, no FDTD solve. Preserve the printed temp directory.

   For `bragg_device.py` edits, also diff all six scene snapshots against

   committed references, using a new output directory.

3. Only with run authorization: the relevant small hardware smoke, then

   device-gradient FD calibration/toy. Derive task IDs from `validate_te.py`;

   `N_TASKS=40` does not mean every index is implemented. S2 port fit must

   exist before its smoke/toy/campaign. An offline pass is not hardware proof.



For monitor reviews, inspect built extents, source/port directions, TE/TM

symmetry parity, frequency spacing, transverse integration and optimization

region containment at parameter bounds. The single-wavelength adjoint twin

is explicitly pinned and follows the previous evaluation: inspect its lag.

Frequency count 1 with source limits does not guarantee resonance sampling.

Geometric containment alone does not establish PML or domain convergence.



Use the installed API source at

`C:/Program Files/Lumerical/v261/api/python/lumopt2/` and official Ansys

documentation for uncertain command behavior. Scratch probes belong in a

unique temporary directory. Never edit the vendor installation to fix this

project without a specific need and a separate review of its effects.



In hidden-CAD test harnesses, preserve the `lumapi.FDTD` class symbol: the

installed constructor uses `super(FDTD,self)`, so replacing it with a factory

function breaks initialization. Wrap its constructor/methods while preserving

class identity; test no-solve guards without dispatching a live engine.



For stored-field diagnostics, reduce memory only when the exact objective Jacobian

has finite support: the October7 peak3 probe selects its three nonzero wavelengths,

uses the unchanged vendor phase/normalization, and reproduces original corr30 Re

and Im contractions before interpreting step sensitivity. This is evidence for

that probe, not proof for every parameter or a replacement global calibration.

Restore nominal geometry between single-parameter checks and verify live indices.



A hidden-CAD save/load guard must resolve relative paths against the CAD working

directory (`pwd`), which can differ from Python cwd. Then enforce allowed absolute

roots and preserve existing files. Test relative inside-root, escape and overwrite

cases offline; never weaken containment just to make `set_fwd` pass.



Capture verified findings and unresolved questions in the repo audit/state

record. Distinguish read-from-file, derived, and expected claims. Research

new design choices without silently changing the user's chosen device.



## Numerical termination and gradient sensitivity

When small finite differences disagree, inspect actual solver termination logs,
not only the requested simulation-time cap. Auto-shutoff energy statistics do
not establish a coherent DFT or derivative error bound. Compare full spectra,
fixed-frequency odd terms and moving-peak metrics separately. An equal-duration
center/plus/minus family can test temporal sensitivity; two durations agreeing
do not prove convergence or identify geometry/discretization as the cause.
Keep same-duration centers for even terms and distinguish new numerical families
from the stored-field calibration. Verify any early-stop override by hidden CAD
readback and actual solver termination; the current bragg_device builder maps
zero auto_shutoff_min back to its default, so zero passed through that builder
is not a verified off switch. One repeated center is not a noise-floor estimate.

## Saved-port arithmetic versus physical calibration

A saved FSP reload can change derived complex mode amplitudes at floating-point
roundoff even when source bytes, frequency and sourcepower remain exact. Retain
the entire before/after normalization arrays before diagnosing a guard failure.
October7 measured reload drift was at most9.24e-16 relative; the isolated V3
probe uses32float64-epsilon relative tolerance, no absolute floor, exact zeros,
and exact source/frequency/power checks. Vendor amplitudes are returned unchanged.
This is a measured arithmetic-reuse rule for that diagnostic, not a physics
tolerance, general source-identity relaxation or gradient/noise bound.

Fitting two quadrature coefficients to three frequency bins for one parameter
is a local diagnostic. Report held-out-bin errors as well as residual norms,
which can be dominated by the large resonance flanks. Even excellent flank fits
do not certify the small peakheight gradient, other geometry parameters, or
modal S21 derivatives. Preserve separate Tout and modal results and keep the
failed global calibration gate until independently validated.

## Evidence and experiment planning

Reconcile original Claude validation claims with their actual logs, fields,
objective, parameter classes and numerical settings. Distinguish an in-sample
fit from held-out validation, a numerical reconstruction from physical
correctness, and offline/build checks from an optimizer hardware test. Record
missing raw evidence explicitly. Reproduce decision-changing calculations;
do not repeat completed audits without a new discrepancy or changed inputs.

Plan the smallest useful experiments around the unresolved physical question
and their measured cost before dispatch. Prepare extraction/tests during
current solves and keep a conditional next-step plan. The cluster-ops runtime
planning reference covers resource and duration estimates. Matching a
parameter gradient requires matching its actual functional and numerical
family, including termination settings; old stored fields cannot certify a
new duration simply because the geometry is unchanged.

For a bounded diagnostic with reduced optimization-field frequencies, read
[selective field recording](references/selective-field-recording.md) before
changing a recorder or extractor; CAD property persistence is not a solved-grid
validation.
