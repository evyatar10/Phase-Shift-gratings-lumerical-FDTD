import base64,copy,hashlib,json,sys,tempfile,unittest
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
import analyze200 as a
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');E=ROOT/'docs/readiness_evidence_20261007'


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.marker,_=a.h.load_json(E/'s2_temporal200_review_original.json',a.MARKER_SHA);cls.m=a.modules(ROOT,cls.marker)
        cls.center,cls.rows,cls.arrays,cls.pair=a.ancestry(E,cls.marker,cls.m);cls.center['arrays']=cls.arrays[3]
    def fixture_row(self,task=0):
        m=self.m;p,index,d,s=m.task_params(task);z=copy.deepcopy(self.center['result']);c=z['controls']
        c['before']['geometry']=m.plain(m.eng.make_func(m.SPEC)(p));c['after']=copy.deepcopy(c['before']);c['after']['timing'].update({'simulation time':200e-12,'use early shutoff':0});c['after']['optimization_dft_enabled']=0
        c['persisted']=copy.deepcopy(c['after']);c['changed_properties']={'FDTD::simulation time':[2000e-12,200e-12],'FDTD::use early shutoff':[1,0],'optimization_dft::enabled':[1,0]}
        c.update(before_sha256=m.semantic(c['before']),after_sha256=m.semantic(c['after']),persisted_sha256=m.semantic(c['persisted']),serialization=m.persisted_check(c['after'],c['persisted']))
        review=dict(path=a.MARKER_REMOTE,sha256=a.MARKER_SHA,lead_verdict=self.marker['lead_verdict'],allowed_tasks=[0,1,2],parent150=self.center['bindings'],completed_step150=self.center['step150'])
        i=m.identity(task,self.center,review);i['vendor_api_sha256']=self.marker['vendor_api_sha256'];source=a.OUTPUT_ROOT+f'/task_{task:02d}_SYNTHETIC/files/fwd_default.fsp'
        term=dict(log=source.replace('.fsp','_p0.log'),log_sha256='b'*64,iterations=2998040,physical_time_s=200e-12,requested_time_s=200e-12,recorded_dt_s=c['dt_s'],delta_s=0.,status=1,reason='completed_full_simulation_time')
        z.update(task=task,index=index,duration_ps=200.,sign=s,delta_nm=s*.0625,params=p.tolist(),controls=c,parent_review=review,reviewed_center_sha256=m.CENTER_SHA,source=source,h5=source[:-4]+'/fwd_default_output.h5',ports_npz=a.OUTPUT_ROOT+f'/task_{task:02d}_SYNTHETIC/ports.npz',termination=term,comparison_status=m.COMPARISON_STATUS,center_control_comparison=m.center_control_comparison(c['before'],self.center))
        return dict(identity=i,result=z)
    def fixture_files(self):
        folder=Path(tempfile.mkdtemp(prefix='SYNTHETIC_',dir=Path(__file__).parent));pins={}
        port_raw=(E/'s2_temporal150_fetch_1434/s2_temporal150_task03_ports.npz').read_bytes()
        for task in range(3):
            row=self.fixture_row(task);cp=folder/f's2_temporal200_task{task:02d}_original.json';cp.write_text(json.dumps(row));pp=folder/f's2_temporal200_task{task:02d}_ports.npz';pp.write_bytes(port_raw)
            pins[f'{task}:checkpoint']=dict(local=str(cp),path=a.OUTPUT_ROOT+f'/task_{task:02d}.json',sha256=a.f.sha(cp),bytes=cp.stat().st_size)
            pins[f'{task}:ports']=dict(local=str(pp),path=row['result']['ports_npz'],sha256=a.f.sha(pp),bytes=pp.stat().st_size)
        return folder,pins
    def test_actual_release_and_all_five_ancestry_metadata_positive_control(self):
        a.marker_check(self.marker,self.m,self.center)
        self.assertEqual(set(self.center['bindings']['checkpoints']),{'3','4','5'})
        self.assertEqual(set(self.center['step150']['checkpoints']),{'0','1'})
        bad=copy.deepcopy(self.marker);bad['status']='NOT_REVIEWED'
        with self.assertRaises(a.h.EvidenceError):a.marker_check(bad,self.m,self.center)
    def test_complete_three_pinned_roles_and_source_control_checks(self):
        folder,pins=self.fixture_files();rows,arrays,comparisons=a.new_inputs(pins,folder,self.marker,self.center,self.m)
        self.assertEqual([r['result']['index'] for r in rows],[29,149,149]);self.assertEqual(len(comparisons),3)
        bad=dict(pins);bad.pop('2:ports')
        with self.assertRaises(a.h.EvidenceError):a.new_inputs(bad,folder,self.marker,self.center,self.m)
    def test_checkpoint_and_transferred_byte_pin_tampering_refuse(self):
        folder,pins=self.fixture_files();path=Path(pins['0:checkpoint']['local']);path.write_bytes(path.read_bytes()+b' ')
        with self.assertRaises(a.h.EvidenceError):a.new_inputs(pins,folder,self.marker,self.center,self.m)
        row=self.fixture_row();row['identity']['point'][149]+=.125
        with self.assertRaises(a.h.EvidenceError):a.row_check(row,self.arrays[3],0,self.marker,self.center,self.m)
    def test_wrong_duration_status_earlystop_phase_and_mesh_refuse(self):
        row=self.fixture_row()
        for key,value in [('physical_time_s',150e-12),('status',2),('reason','autoshutoff')]:
            bad=copy.deepcopy(row);bad['result']['termination'][key]=value
            with self.assertRaises(a.h.EvidenceError):a.row_check(bad,self.arrays[3],0,self.marker,self.center,self.m)
        bad=copy.deepcopy(row);bad['result']['controls']['after']['timing']['use early shutoff']=1
        with self.assertRaises(RuntimeError):a.row_check(bad,self.arrays[3],0,self.marker,self.center,self.m)
        left=self.rows[3]['result']['controls']['before'];right=copy.deepcopy(left);v=right['ports']['FDTD::ports::Port_1']['phase']
        for _ in range(3):v=float(np.nextafter(v,np.inf))
        right['ports']['FDTD::ports::Port_1']['phase']=v
        with self.assertRaises(RuntimeError):self.m.phase_compare(left,right)
        right=copy.deepcopy(left);right['mesh']['x'][0][0]=float(np.nextafter(right['mesh']['x'][0][0],np.inf))
        with self.assertRaises(RuntimeError):self.m.phase_compare(left,right)
    def test_exact_grid_and_FDTD_version_refuse(self):
        row=self.fixture_row();bad={k:v.copy() for k,v in self.arrays[3].items()};bad['p2_f'].flat[252]+=1.
        with self.assertRaises(a.h.EvidenceError):a.row_check(row,bad,0,self.marker,self.center,self.m)
        row['result']['FDTD_version']='OTHER_BUILD'
        with self.assertRaises(a.h.EvidenceError):a.row_check(row,self.arrays[3],0,self.marker,self.center,self.m)
    def test_accounting_exact_tasks_and_mat_roundtrip_no_new_physics(self):
        from scipy.io import loadmat
        with self.assertRaises(RuntimeError):a.contract.completed_rows('171390_0|RUNNING|0:0|','171390')
        data=self.arrays[3];curves={k:v.ravel().tolist() for k,v in data.items() if k in a.h.GRIDS}
        values={name:{str(d):dict(center=fn(data).tolist(),plus=fn(data).tolist(),minus=fn(data).tolist(),spectral_central_fd=np.zeros(501).tolist(),spectral_odd=np.zeros(501).tolist(),spectral_even_same_duration_center=np.zeros(501).tolist()) for d in (100,150,200)} for name,fn in a.h.METRICS.items()}
        raw={str(d):{role:{k:dict(real=data[k].ravel().real.tolist(),imag=data[k].ravel().imag.tolist()) for k in ('p1_T_in','p2_T_out','p2_S')} for role in ('center','plus','minus')} for d in (100,150,200)}
        spectra=dict(grids=curves,observables=values,raw_ports=raw);report=dict(status='SYNTHETIC_FIXTURE_ONLY_NO_MEASURED200_DATA')
        folder=Path(tempfile.mkdtemp(prefix='SYNTHETIC_MAT_',dir=Path(__file__).parent));path=folder/'curves.mat';a.mat_export(path,report,spectra);loaded=loadmat(path,simplify_cells=True)
        self.assertTrue(np.array_equal(loaded['peak3_tout_200'][:,0],abs(data['p2_T_out'].ravel())))
        self.assertTrue(np.array_equal(loaded['raw_ports_200']['plus']['p2_S'],data['p2_S'].ravel()))
        self.assertEqual(json.loads(loaded['metadata_json'])['FD_parameter_units'],'nm')
        with self.assertRaises(FileExistsError):a.mat_export(path,report,spectra)
    def test_complete_contract_history_pipeline_with_explicit_synthetic200_fixture(self):
        folder,pins=self.fixture_files();files={};records=[]
        for key,pin in pins.items():
            raw=Path(pin['local']).read_bytes();files[key]={k:pin[k] for k in ('path','sha256','bytes')};files[key]['data']=base64.b64encode(raw).decode()
        for task in range(3):
            row=json.loads(Path(pins[f'{task}:checkpoint']['local']).read_text());z=row['result'];records.append(dict(task=task,parent_review=z['parent_review'],cold_validation=dict(main_called=False,CAD_blocked=True,solve_blocked=True,runner_validator='read_checkpoint+verify_result'),controls=z['controls'],vendor_api_sha256=z['vendor_api_sha256'],metrics={k:z[k] for k in a.contract.METRICS},control_sha256={k:z['controls'][k] for k in ('before_sha256','after_sha256','persisted_sha256')},checkpoint=pins[f'{task}:checkpoint']['path'],checkpoint_sha256=pins[f'{task}:checkpoint']['sha256'],ports=z['ports_npz'],ports_sha256=z['ports_sha256'],source=z['source'],termination=z['termination'],fsp_sha256=z['fsp_sha256'],h5_sha256=z['h5_sha256']))
        env,_=a.h.load_json(E/'s2_temporal200_environment_released_1619.json',a.ENV_SHA)
        payload=dict(job_id='171390',family=a.FAMILY,runner_sha256=a.RUNNER_SHA,base_helper_sha256=self.m.BASE_SHA,step150_helper_sha256=self.m.STEP_SHA,review_marker=a.MARKER_REMOTE,review_marker_sha256=a.MARKER_SHA,environment=env,accounting=''.join(f'171390_{t}|COMPLETED|0:0|\n' for t in range(3)),verified_records=records,files=files,fixture_only_NOT_ACTUAL200_RESULTS=True)
        decoded=a.contract.validate_payload(payload,'171390',a.MARKER_REMOTE,a.MARKER_SHA,env)
        output=folder/'published';published=a.contract.publish(payload,decoded,output)
        final_pins,_=a.h.load_json(output/'s2_temporal200_artifact_pins_original.json',published['pins_sha256'])
        report,curves=a.analyze(final_pins,published['pins_sha256'],output,E,ROOT,published['manifest_sha256'])
        self.assertEqual(report['status'],'TEMPORAL200_COMPARISON_CALIBRATION_FAILED_UNCHANGED')
        self.assertEqual(set(curves['observables']['peak3_tout']),{'100','150','200'})
        self.assertEqual(report['observables']['peak3_tout']['triplets']['200']['central_derivative'],0.)
        bad=copy.deepcopy(final_pins);bad['0:ports']['path']='OFF_FAMILY'
        with self.assertRaises(a.h.EvidenceError):a.completion_check(output,bad,published['pins_sha256'],published['manifest_sha256'],env)


if __name__=='__main__':unittest.main(verbosity=2)
