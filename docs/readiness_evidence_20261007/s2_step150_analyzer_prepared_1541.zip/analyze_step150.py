"""Strict offline same150ps h=.0625/.125 diagnostic; no solve, fit or approval."""
import argparse
import base64
import dataclasses
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys

sys.dont_write_bytecode = True
REFERENCE_SHA = {
    'firstwave_helpers.py': '3b18b5b0663ae2350cc4e3f1fc2c787b6a5d7b4fedaacfe38ba84b92febf384c',
    'numerical_helpers.py': 'ac54418b98a196d7e9ed3d5f0adaba812dc6a829adeed6b59c48677a5445b18e',
    'peak_observer_reference.py': '7e62219489b457b1eb3fdced0383e758a6a8e88f444ff7d5f9388bf9510b1f50',
    'temporal_reference.py': 'bbe3a22f90a418c8cadc3fc0c7b95f8843b4d83127d611bb0f4481bb7fdee3dd',
    'fetch_contract_reference.py': 'ebbe44a0aba524ed22a641b33287a31c5e88d2dc52bc43c7521a72ac0d6702c9'}
for name, digest in REFERENCE_SHA.items():
    if hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest() != digest:
        raise RuntimeError('Reviewed offline reference helper changed: '+name)
import numpy as np
import firstwave_helpers as first
import temporal_reference as temporal
import peak_observer_reference as observer
import fetch_contract_reference as contract
h = first.h


def absolute(value):
    path = Path(value)
    h.require(path.is_absolute(), 'Absolute input/output path required')
    return path


def validated_npz(raw):
    arrays = h.load_npz(raw)
    h.require('p1_T_in' in arrays and all(np.isfinite(value).all() for value in arrays.values()),
              'Missing/nonfinite full port-array evidence')
    return arrays


def modules(repo, parent_marker, marker):
    temporal.frozen_sources(repo, parent_marker)
    temporal.frozen_sources(repo, marker)
    sys.path.insert(0, str(repo))
    from runners.lumopt2_design import s2_temporal_step150 as module
    h.require(first.sha(module.__file__) == contract.RUNNER_SHA, 'Reviewed step150 runner changed')
    def forbid(*args, **kwargs):
        raise RuntimeError('Offline analyzer cannot invoke main/CAD/solve')
    module.main = module.forward_only = module.base.main = module.base.forward_only = forbid
    module.eng.make_project = module.eng.import_lumopt2 = forbid
    module.frozen_base()
    h.require(module.code() == marker['code'], 'Complete frozen source identity mismatch')
    return module


def termination_and_paths(result, task, output_root):
    root = PurePosixPath(output_root)
    paths = {key: PurePosixPath(result[key]) for key in ('source', 'h5', 'ports_npz')}
    attempt = paths['ports_npz'].parent
    h.require(all(path.is_absolute() and '..' not in path.parts and path.is_relative_to(root)
                  for path in paths.values()) and attempt.name.startswith(f'task_{task:02d}_') and
              paths['ports_npz'].name == 'ports.npz' and paths['source'].is_relative_to(attempt) and
              paths['source'].name == 'fwd_default.fsp' and
              paths['h5'] == paths['source'].with_suffix('')/'fwd_default_output.h5',
              'Recorded artifacts escaped exact family/attempt')
    time = result['termination']; dt = result['controls']['dt_s']; actual = time['physical_time_s']
    h.require(time['requested_time_s'] == 150e-12 and time['recorded_dt_s'] == dt and
              np.isfinite([actual, dt]).all() and dt > 0 and abs(actual-150e-12) <= dt and
              time['delta_s'] == actual-150e-12 and time['status'] == 1 and
              time['reason'] == 'completed_full_simulation_time' and
              type(time['iterations']) is int and time['iterations'] > 0 and
              PurePosixPath(time['log']) == paths['source'].with_name('fwd_default_p0.log'),
              'Recorded150ps full-time termination mismatch')
    for digest in (result['fsp_sha256'], result['h5_sha256'], result['ports_sha256'], time['log_sha256']):
        h.require(contract.sha_string(digest), 'Invalid remote artifact digest')


def parent_inputs(folder, marker, module):
    rows, arrays, bindings = {}, {}, {}
    for task in (3, 4, 5):
        cp = folder/f's2_temporal150_task{task:02d}_original.json'
        row, digest = h.load_json(cp, contract.PARENT_CHECKPOINT_SHA[str(task)])
        raw = (folder/f's2_temporal150_task{task:02d}_ports.npz').read_bytes()
        h.require(h.sha(raw) == module.PARENT_PORT_SHA[task] == row['result']['ports_sha256'],
                  'Exact parent150 NPZ byte pin mismatch')
        module.validate_parent_metadata(row, task, marker, contract.PARENT_MARKER)
        termination_and_paths(row['result'], task, contract.PARENT_ROOT)
        data = validated_npz(raw); first.verify_scores(row, data, module.recovery.score)
        rows[task], arrays[task] = row, data
        result = row['result']
        bindings[str(task)] = dict(checkpoint=contract.PARENT_ROOT+f'/task_{task:02d}.json',
                                  sha256=digest, ports_sha256=result['ports_sha256'],
                                  fsp_sha256=result['fsp_sha256'], h5_sha256=result['h5_sha256'],
                                  termination=result['termination'])
    for data in arrays.values(): h.check_grid(data, arrays[3], 501)
    for task in (4, 5):
        module.center_control_comparison(rows[task]['result']['controls']['before'],
                                         dict(result=rows[3]['result']))
    return rows, arrays, dict(marker=contract.PARENT_MARKER,
                             marker_sha256=contract.PARENT_MARKER_SHA, checkpoints=bindings)


def completion_inputs(folder, manifest_sha, marker, marker_sha):
    manifest, digest = h.load_json(folder/'s2_step150_fetch_manifest.json', manifest_sha)
    h.require(manifest['family'] == contract.FAMILY and manifest['verified_tasks'] == [0, 1] and
              manifest['runner_sha256'] == contract.RUNNER_SHA and manifest['base_helper_sha256'] == contract.BASE_SHA and
              manifest['fetch_helper_sha256'] == REFERENCE_SHA['fetch_contract_reference.py'] and
              manifest['review_marker_sha256'] == marker_sha, 'Reviewed completion manifest mismatch')
    names = {f's2_step150_task{task:02d}_{suffix}' for task in (0, 1)
             for suffix in ('original.json', 'ports.npz')}
    names.update({'s2_step150_artifact_pins_original.json', 's2_step150_completed_receipt.json'})
    h.require(set(manifest['published_files']) == names, 'Completion publication files missing/off-family')
    for name in names: h.require(first.sha(folder/name) == manifest['published_files'][name],
                                'Completion original file hash mismatch: '+name)
    pins, _ = h.load_json(folder/'s2_step150_artifact_pins_original.json', manifest['artifact_pins_sha256'])
    receipt, _ = h.load_json(folder/'s2_step150_completed_receipt.json', manifest['receipt_sha256'])
    h.require(receipt['artifact_pins_sha256'] == manifest['artifact_pins_sha256'] and
              receipt['review_marker_sha256'] == marker_sha and receipt['review_marker'] == manifest['review_marker'] and
              receipt['job_id'] == manifest['job_id'], 'Completion receipt job/marker/pins mismatch')
    payload = dict(receipt); payload['files'] = copy_files = {}
    rows, arrays = {}, {}
    h.require(set(pins) == {f'{task}:{role}' for task in (0, 1) for role in ('checkpoint', 'ports')},
              'Completion pins must contain exactly both CP/NPZ pairs')
    for key, pin in pins.items():
        task, role = key.split(':'); task = int(task)
        suffix = 'original.json' if role == 'checkpoint' else 'ports.npz'
        expected = folder/f's2_step150_task{task:02d}_{suffix}'
        h.require(absolute(pin['local']).resolve() == expected.resolve(), 'Pinned local file outside explicit completion directory')
        raw = expected.read_bytes()
        h.require(len(raw) == pin['bytes'] and h.sha(raw) == pin['sha256'], 'Pinned transfer bytes changed')
        item = dict(receipt['files'][key]); item['data'] = base64.b64encode(raw).decode()
        h.require(all(item[k] == pin[k] for k in ('path', 'sha256', 'bytes')), 'Pins and receipt remote bindings disagree')
        copy_files[key] = item
        if role == 'checkpoint': rows[task] = json.loads(raw)
        else: arrays[task] = validated_npz(raw)
    contract.validate_payload(payload, receipt['job_id'], manifest['review_marker'], marker_sha, receipt['environment'])
    h.require(marker['output_root'] == contract.OUTPUT_ROOT and marker['parent150'] ==
              rows[0]['identity']['parent_review']['parent150'], 'New marker/output/parent binding mismatch')
    return rows, arrays, dict(manifest_sha256=digest, pins_sha256=manifest['artifact_pins_sha256'],
                             receipt_sha256=manifest['receipt_sha256'], job_id=manifest['job_id'],
                             original_files=manifest['published_files'], remote_marker=manifest['review_marker'])


def new_metadata(row, data, task, marker, marker_sha, remote_marker, ancestry, center, module):
    point, index, duration, sign = module.task_params(task)
    review = dict(path=remote_marker, sha256=marker_sha, lead_verdict=marker['lead_verdict'],
                  allowed_tasks=[0, 1], parent150=ancestry)
    expected = dict(schema=1, task=task, spec=marker['spec'], point=point.tolist(), index=index,
                    sign=sign, delta_nm=sign*.125, duration_ps=duration, task_map=marker['task_map'],
                    center_checkpoint=contract.PARENT_ROOT+'/task_03.json', center_sha256=contract.CENTER_SHA,
                    code=marker['code'], vendor_api_sha256=marker['vendor_api_sha256'], parent_review=review,
                    timing_changes=marker['timing_changes'])
    h.require(type(row['identity']['task']) is int and row['identity'] == expected,
              'Full new step checkpoint identity mismatch')
    result = row['result']
    for key, value in dict(task=task, index=149, sign=sign, delta_nm=sign*.125,
                           duration_ps=150., params=point.tolist(), parent_review=review,
                           reviewed_center_sha256=contract.CENTER_SHA,
                           vendor_api_sha256=marker['vendor_api_sha256'],
                           comparison_status=module.COMPARISON_STATUS,
                           existing_overall_gradient_gate='FAILED_UNCHANGED').items():
        h.require(result[key] == value, 'New result identity mismatch: '+key)
    module.validate_control(result['controls'], point)
    comparison = module.center_control_comparison(result['controls']['before'], dict(result=center['result']))
    h.require(result['center_control_comparison'] == comparison, 'Recorded nominal control comparison changed')
    termination_and_paths(result, task, contract.OUTPUT_ROOT)
    first.verify_scores(row, data, module.recovery.score)
    return comparison


def pair_observations(center, plus, minus, step, wavelengths, frequency, engine, window_center=None):
    select = lambda curve: first.selected_peak(curve, wavelengths, engine)
    result, derivative = first.pair_report(plus, minus, center, step, select)
    result.update(signed_odd_numerator=result['plus_peak3']-result['minus_peak3'],
                  signed_even_numerator=result['plus_peak3']+result['minus_peak3']-2*result['center_peak3'],
                  fixed_bins={str(k): float(derivative[k]) for k in (244, 252, 260)})
    df = np.diff(frequency)
    h.require(np.all(df > 0) and np.allclose(df, df[0], rtol=1e-9, atol=0),
              'Actual frequency grid must be increasing and uniform')
    coordinate = (frequency-frequency[0])/df[0]; windows = {}
    anchor = result['center_peak_index'] if window_center is None else window_center
    for radius in observer.WINDOW_RADII:
        peaks = {role: observer.spline_peak(coordinate, curve, anchor, radius)
                 for role, curve in (('center', center), ('plus', plus), ('minus', minus))}
        values = first.h.terms(peaks['plus']['height'], peaks['minus']['height'], peaks['center']['height'], step)
        windows[str(radius)] = dict(peaks=peaks, **values,
                                   signed_even_numerator=2*values['even'],
                                   signed_odd_numerator=2*values['odd'])
    result['spline_observer'] = dict(fixed_window_center=anchor, windows=windows,
                                    method='scipy CubicSpline', SciPy_version=observer.scipy.__version__,
                                    coordinate='Normalized actual uniform frequency',
                                    bc_type='not-a-knot', extrapolate=False,
                                    qualification='Same-sample diagnostic observer only; no objective change or continuous-peak error bound')
    return result, dict(center=center.tolist(), plus=plus.tolist(), minus=minus.tolist(),
                        spectral_central_fd=derivative.tolist(),
                        spectral_signed_odd_numerator=(plus-minus).tolist(),
                        spectral_signed_even_numerator=(plus+minus-2*center).tolist())


def analyze(parent_folder, parent_marker_path, completion_folder, completion_manifest_sha,
            new_marker_path, new_marker_sha, repo, history_reference=None, history_spectra=None):
    parent_marker, _ = h.load_json(parent_marker_path, contract.PARENT_MARKER_SHA)
    marker, _ = h.load_json(new_marker_path, new_marker_sha)
    module = modules(repo, parent_marker, marker)
    old_rows, old_arrays, ancestry = parent_inputs(parent_folder, parent_marker, module)
    expected = dict(schema=1, family=contract.FAMILY, duration_ps=150., step_nm=.125, index=149,
                    task_map=[[.125, 1], [.125, -1]], center_checkpoint=contract.PARENT_ROOT+'/task_03.json',
                    center_sha256=contract.CENTER_SHA, code=module.code(), base_helper_sha256=contract.BASE_SHA,
                    vendor_api_sha256=parent_marker['vendor_api_sha256'],
                    spec=module.plain(dataclasses.asdict(module.SPEC)), output_root=contract.OUTPUT_ROOT,
                    allowed_tasks=[0, 1], timing_changes={'simulation time': 150e-12, 'use early shutoff': 0}, parent150=ancestry)
    h.require(all(marker.get(k) == v for k, v in expected.items()) and marker['status'] == contract.STATUS and
              isinstance(marker['lead_verdict'], str) and marker['lead_verdict'].strip() not in ('', 'NOT_REVIEWED'),
              'Exact new marker scope/source/parent/vendor mismatch')
    rows, arrays, provenance = completion_inputs(completion_folder, completion_manifest_sha, marker, new_marker_sha)
    controls = [new_metadata(rows[task], arrays[task], task, marker, new_marker_sha,
                             provenance['remote_marker'], ancestry, old_rows[3], module) for task in (0, 1)]
    baseline = old_arrays[3]
    for data in arrays.values(): h.check_grid(data, baseline, 501)
    report = dict(schema=1, status='SAME150_STEP_DIAGNOSTIC_CALIBRATION_FAILED_UNCHANGED',
                  no_objective_change=True, no_coefficient_installation=True, no_automatic_approval=True,
                  center_checkpoint_sha256=contract.CENTER_SHA, comparison_controls=controls,
                  provenance=dict(parent150=ancestry, new_completion=provenance,
                                  new_marker_sha256=new_marker_sha, reader_references=REFERENCE_SHA),
                  observables={}, limitations=[
                      'Two h values do not establish asymptotic convergence order or an infinitesimal gradient.',
                      'Fixed-center peak3-J projections are spectral FD projections, not adjoint gradients.',
                      'Signed even terms are retained; no cancellation/noise bound or physics cause is inferred.',
                      'Local CP/NPZ hashes, metadata and scores checked; remote FSP/H5/log checks remain in cold-fetch provenance.',
                      'Spline peaks are diagnostic interpolation of the same samples and do not replace the optimizer FOM.'])
    spectra = dict(grids={key: baseline[key].ravel().tolist() for key in h.GRIDS}, observables={})
    for metric, transform in h.METRICS.items():
        center = transform(baseline); pairs = {}; curves = {}
        for label, step, plus, minus in (('h0.0625', .0625, old_arrays[4], old_arrays[5]),
                                        ('h0.125', .125, arrays[0], arrays[1])):
            pairs[label], curves[label] = pair_observations(center, transform(plus), transform(minus), step,
                                                           baseline['p2_lambda'], baseline['p2_f'].ravel(), module.eng)
        left, right = pairs['h0.0625'], pairs['h0.125']
        report['observables'][metric] = dict(same150ps_steps=pairs, large_minus_small=dict(
            central_derivative=right['central_derivative']-left['central_derivative'],
            exact_center_peak3_J_projection=right['exact_center_peak3_jacobian_projection']-left['exact_center_peak3_jacobian_projection'],
            signed_even_numerator=right['signed_even_numerator']-left['signed_even_numerator'],
            spline_primary_derivative=right['spline_observer']['windows']['25']['central_derivative']-
                                      left['spline_observer']['windows']['25']['central_derivative'],
            spectral_fd_difference=first.difference(curves['h0.125']['spectral_central_fd'], curves['h0.0625']['spectral_central_fd'])))
        spectra['observables'][metric] = curves
    if history_reference is not None or history_spectra is not None:
        h.require(history_reference is not None and history_spectra is not None, 'Both pinned temporal history files required')
        reference, _ = h.load_json(history_reference, observer.REFERENCE_SHA)
        full, _ = h.load_json(history_spectra, observer.SPECTRA_SHA)
        h.require(reference['status'] == 'DIAGNOSTIC_ONLY_CALIBRATION_FAILED_UNCHANGED', 'Wrong temporal history status')
        for key in h.GRIDS: h.require(np.array_equal(np.asarray(full['grids'][key]), baseline[key].ravel()), 'Temporal history full grid changed')
        history = {}
        for metric in h.METRICS:
            history[metric] = {}
            for duration in ('old_autoshutoff_67ps_approx', '100', '150'):
                curves = full['observables'][metric][duration]
                values, _ = pair_observations(np.asarray(curves['center']), np.asarray(curves['plus']),
                                              np.asarray(curves['minus']), .0625, baseline['p2_lambda'],
                                              baseline['p2_f'].ravel(), module.eng,
                                              report['observables'][metric]['same150ps_steps']['h0.0625']['center_peak_index'])
                saved = reference['observables'][metric]['triplets'][duration]
                h.require(all(values[key] == saved[key] for key in ('plus_peak3', 'minus_peak3', 'center_peak3',
                                                                   'central_derivative', 'even', 'exact_center_peak3_jacobian_projection')),
                          'Pinned temporal-history arithmetic not reproduced')
                history[metric][duration] = dict(**values,
                    step_nm=.0625, qualification='Pinned prior same-h temporal comparison; old autoshutoff times differ by geometry')
            for role in ('center', 'plus', 'minus'):
                h.require(np.array_equal(np.asarray(full['observables'][metric]['150'][role]),
                                         np.asarray(spectra['observables'][metric]['h0.0625'][role])),
                          'Temporal150 history differs from actual pinned .0625 triplet')
            left, right = history[metric]['100'], history[metric]['150']
            history[metric]['150_minus_100_same_h0.0625'] = dict(
                peak3_central_derivative=right['central_derivative']-left['central_derivative'],
                center_peak3_J_projection=right['exact_center_peak3_jacobian_projection']-left['exact_center_peak3_jacobian_projection'],
                signed_even_numerator=right['signed_even_numerator']-left['signed_even_numerator'],
                spline_primary_derivative=right['spline_observer']['windows']['25']['central_derivative']-
                                          left['spline_observer']['windows']['25']['central_derivative'])
        report['pinned_temporal_history'] = dict(reference_sha256=observer.REFERENCE_SHA,
                                                spectra_sha256=observer.SPECTRA_SHA, observables=history)
    return report, spectra


def cli():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('parent150-dir', 'parent150-marker', 'completion-dir', 'completion-manifest-sha256',
                 'new-marker', 'new-marker-sha256', 'repo', 'output', 'spectra-output'):
        parser.add_argument('--'+name, required=True)
    parser.add_argument('--history-reference'); parser.add_argument('--history-spectra')
    args = parser.parse_args()
    output, spectra_output = absolute(args.output), absolute(args.spectra_output)
    h.require(not output.exists() and not spectra_output.exists() and output.resolve() != spectra_output.resolve(),
              'Distinct NEW absolute output files required')
    report, spectra = analyze(absolute(args.parent150_dir), absolute(args.parent150_marker),
                              absolute(args.completion_dir), args.completion_manifest_sha256,
                              absolute(args.new_marker), args.new_marker_sha256, absolute(args.repo),
                              absolute(args.history_reference) if args.history_reference else None,
                              absolute(args.history_spectra) if args.history_spectra else None)
    first.write(spectra_output, spectra)
    report['full_spectra_file'] = str(spectra_output); report['full_spectra_sha256'] = first.sha(spectra_output)
    first.write(output, report)


if __name__ == '__main__':
    cli()
