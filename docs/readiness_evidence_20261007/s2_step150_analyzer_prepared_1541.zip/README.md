# Strict offline step150 and temporal-history analyzer

NEW TEMP preparation only. No repository edits, network, CAD, solve, dispatch,
coefficient fit/installation, objective change or approval. Parent reviews this
packet before use. No actual newly completed h0.125 pair was analyzed here.
Tests build explicitly SYNTHETIC protocol fixtures from preserved parent
CP/NPZ samples; those fixtures establish validation/arithmetic behavior only.

`analyze_step150.py` consumes the exact parent150 task03/04/05 CP/NPZ bytes,
the original parent marker, a NEW strict completion-fetch directory and its
caller-pinned manifest SHA, the actual new reviewed marker and SHA, and the
frozen local repository. Every CP/NPZ and completion receipt/pins file is
fingerprinted. Complete source, spec, all296 parameters, index149, sign,
0.125nm step,150ps duration, parent marker/all three parent checkpoints,
vendor ancestry, unique remote artifact paths, control intervention,
full-time termination and cold-fetch transport records are checked.

No remote path is opened locally. Remote FSP/H5/log validation is represented
by the verified cold-fetch receipt; this analyzer checks their pinned metadata,
local original CP/NPZ bytes and reproduced scores, and states that limitation.
Incoming remote vendor fingerprints must equal the pinned parent family.
It deliberately does not require the different Windows vendor byte tree to
equal Athena when doing pure offline math. Local mathematical/project source
files must equal marker hashes. New and parent runner main/forward functions
and engine CAD construction/import entry points are blocked in RAM.

The shared center is exactly the150ps task03 checkpoint SHA
`a0ff55eacaa52e00a2aab17dcc43d0e5fff9a72566e15da371ff25279c172663`.
Parent task04/05 is h0.0625; new task00/01 is h0.125. All501 port frequency
and wavelength values and shapes must agree exactly. Every port array must
be finite; p1_T_in is mandatory. The source/mesh/port/control comparison uses
only the existing bounded geometry serialization check and recorded Port_1
phase allowance<=2ULP; it introduces no physical/noise tolerance.

For both T_out magnitude and modal abs(S21)^2 the report/full-spectrum file
contains: selected peak3 values and indices, the exact center peak3 weights,
moving-peak central FD, fixed-center peak3-J spectral-FD projection, their
difference, signed odd/even numerators, even/second difference, per-bin FD at
244/252/260 and complete spectral curves/FD/odd/even arrays. The positive test
using identical endpoint samples at two different h values checks that the
FD denominator changes by precisely a factor2; it is not an h-convergence claim.

The copied, fingerprinted peak-observer diagnostic adds not-a-knot CubicSpline
interior maxima on actual normalized frequency. Windows20/25/30 use the metric's
same150ps center peak as a fixed anchor for both h values. The report records
all maxima, positions, boundaries, curvature, odd/even/FD and SciPy version.
This is an observer of the same samples, not a replacement objective, true
continuous-peak/error certificate or calibrated adjoint.

Optional `--history-reference` and `--history-spectra` must be supplied together.
They must equal the exact reviewed history fingerprints embedded in the copied
observer (`929527...52e8a` and `b7bf52...76a0` full hashes in its source).
All original history arithmetic is reproduced; its150ps h0.0625 curves must
equal the actual pinned parent triplet. The report includes old approximate
67ps-autoshutoff,100ps and150ps h0.0625 history, signed even numerators and
the100-to150 FD/J/observer differences. The old67ps label is approximate because
actual termination times differed by geometry. No noise floor, convergence
order or cause is inferred from two steps or three durations.

Required CLI (all actual paths absolute; both outputs NEW and distinct):

```
python -B analyze_step150.py --parent150-dir ACTUAL_PARENT150_FETCH_DIR --parent150-marker ORIGINAL_PARENT150_MARKER --completion-dir ACTUAL_NEW_COMPLETION_DIR --completion-manifest-sha256 ACTUAL_FETCH_MANIFEST_SHA --new-marker ACTUAL_NEW_LOCAL_MARKER --new-marker-sha256 ACTUAL_NEW_MARKER_SHA --repo FROZEN_REPOSITORY --output NEW_REPORT_JSON --spectra-output NEW_FULL_SPECTRA_JSON
```

Add both history arguments to compare the prior temporal history. Input pins
are never regenerated from unverified replacements. Output files use exclusive
creation; input files and imported source files are preserved. No coefficient
or acceptance gate is installed. Diagnostic status remains calibration FAILED.

Five offline test groups passed: same-center two-h math and actual pinned
history arithmetic; publication byte/manifest tampering; wrong step/point/
source/marker/score/control/termination metadata; exact grids and Port_1 phase
bound; and no network/CAD/solver/calibration calls. Helper/observer copies are
preserved byte-for-byte, with SHA256 checked before import. `manifest.json`
records source hashes, test exit codes and logs for parent review.
