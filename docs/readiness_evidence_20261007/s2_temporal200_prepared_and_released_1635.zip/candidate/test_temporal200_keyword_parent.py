"""Bounded offline tests; synthetic files are explicitly not CAD/FDTD evidence."""
import ast,copy,hashlib,importlib.util,json,os,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import s2_temporal200_forward as a
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');E=ROOT/'docs/readiness_evidence_20261007'
class Temporal200Checks(unittest.TestCase):
 def setUp(self):
  self.root=Path(tempfile.mkdtemp(prefix='SYNTHETIC_',dir=Path(__file__).parent))/a.LABEL;self.root.mkdir()
  self.parent=json.loads((E/'s2_temporal150_fetch_1434/s2_temporal150_task03_original.json').read_text())
  self.center=dict(checkpoint=a.PARENT_ROOT+'/task_03.json',sha256=a.CENTER_SHA,result=copy.deepcopy(self.parent['result']),bindings={'marker':a.PARENT_MARKER,'marker_sha256':a.PARENT_MARKER_SHA,'checkpoints':{'3':{'sha256':a.PARENT_SHA[3]},'4':{'sha256':a.PARENT_SHA[4]},'5':{'sha256':a.PARENT_SHA[5]}}})
  self.center['result']['ports_npz']=str(E/'s2_temporal150_fetch_1434/s2_temporal150_task03_ports.npz')
  step0=json.loads((E/'s2_step150_fetch_1600/s2_step150_task00_original.json').read_text());self.center['bindings']=copy.deepcopy(step0['identity']['parent_review']['parent150'])
  self.center['step150']=dict(marker=a.STEP_MARKER,marker_sha256=a.STEP_MARKER_SHA,checkpoints={str(t):dict(sha256=a.STEP_CP_SHA[t],ports_sha256=a.STEP_PORT_SHA[t]) for t in [0,1]})
  self.review=dict(path=str(self.root.parent/'marker.json'),sha256='a'*64,lead_verdict='SYNTHETIC_TEST_NO_APPROVAL',allowed_tasks=[0,1,2],parent150=self.center['bindings'],completed_step150=self.center['step150'])
 def result(self,task=0):
  p,index,d,s=a.task_params(task);c=copy.deepcopy(self.parent['result']['controls']);c['before']['geometry']=a.plain(a.eng.make_func(a.SPEC)(p));c['after']=copy.deepcopy(c['before']);c['after']['timing'].update({'simulation time':200e-12,'use early shutoff':0});c['after']['optimization_dft_enabled']=0;c['persisted']=copy.deepcopy(c['after']);c['changed_properties']={'FDTD::simulation time':[2000e-12,200e-12],'FDTD::use early shutoff':[1,0],'optimization_dft::enabled':[1,0]};c.update(before_sha256=a.semantic(c['before']),after_sha256=a.semantic(c['after']),persisted_sha256=a.semantic(c['persisted']),serialization=a.persisted_check(c['after'],c['persisted']))
  attempt=self.root/f'task_{task:02d}_SYNTHETIC';attempt.mkdir();source=attempt/'files/fwd_default.fsp';source.parent.mkdir();source.write_bytes(b'NOT_A_CAD_FILE_SYNTHETIC')
  h5=source.with_suffix('')/'fwd_default_output.h5';h5.parent.mkdir();h5.write_bytes(b'NOT_A_FIELD_FILE_SYNTHETIC');ports=attempt/'ports.npz';ports.write_bytes(Path(self.center['result']['ports_npz']).read_bytes());log=source.with_name('fwd_default_p0.log');log.write_text('Completed100 iterations, or2e-10s of Simulation Time\nSimulation completed successfully\n'.replace('Completed100','Completed 100').replace('or2','or 2'))
  with np.load(ports) as z:arrays={k:z[k] for k in z.files}
  return dict(task=task,index=index,duration_ps=d,sign=s,delta_nm=s*.0625,params=p.tolist(),source=str(source),h5=str(h5),ports_npz=str(ports),ports_sha256=a.sha(ports),fsp_sha256=a.sha(source),h5_sha256=a.sha(h5),setup_fsp_sha256='c'*64,controls=c,center_control_comparison=a.center_control_comparison(c['before'],self.center),termination=a.termination(source,200.,c['dt_s'],1),parent_review=self.review,reviewed_center_sha256=a.CENTER_SHA,**a.recovery.score(arrays),FDTD_version='SYNTHETIC_NO_ENGINE',vendor_api_sha256=a.base.vendor_sources(),comparison_status=a.COMPARISON_STATUS,existing_overall_gradient_gate='FAILED_UNCHANGED')
 def test_exact_points_map_bounds_and_task_rejection(self):
  nominal=a.val.te_point(a.SPEC)
  for t,sign in [(0,0),(1,1),(2,-1)]:
   p,index,d,s=a.task_params(t);expected=nominal.copy();expected[149]+=sign*.0625;self.assertTrue(np.array_equal(p,expected));self.assertEqual((index,d,s),(29 if sign==0 else 149,200.,sign))
  for t in [True,-1,3,.0,'0']:
   with self.assertRaises(ValueError):a.task_params(t)
 def test_new_marker_missing_wrong_stage_ancestry_and_source(self):
  with patch.dict(os.environ,{},clear=True):
   with self.assertRaises(RuntimeError):a.reviewed(0,self.root,self.center)
  marker=a.scope(self.root,self.center);marker.update(status=a.APPROVAL_STATUS,lead_verdict='SYNTHETIC_TEST_EXPLICIT_SCOPE')
  path=self.root.parent/'review.json'
  for change in [None,('duration_ps',150.),('family','wrong_family'),('task_map',[[.125,1]]),('completed_step150',{}),('parent150',{}),('base_helper_sha256','b'*64),('allowed_tasks',[0]),('lead_verdict','NOT_REVIEWED')]:
   m=copy.deepcopy(marker)
   if change:m[change[0]]=change[1]
   path.write_text(json.dumps(m));env={'S2_TEMP200_REVIEW_MARKER':str(path),'S2_TEMP200_REVIEW_SHA256':a.sha(path)}
   with patch.dict(os.environ,env):
    if change:
     with self.assertRaises(RuntimeError):a.reviewed(0,self.root,self.center)
    else:self.assertEqual(a.reviewed(0,self.root,self.center)['allowed_tasks'],[0,1,2])
  with patch.object(a,'sha',return_value='b'*64):
   with self.assertRaises(RuntimeError):a.frozen_base()
 def test_actual150_parent_metadata_and_repinned_negative(self):
  marker=json.loads((E/'s2_temporal150_review_original.json').read_text())
  for t in [3,4,5]:
   path=E/f's2_temporal150_fetch_1434/s2_temporal150_task{t:02d}_original.json';self.assertEqual(a.sha(path),a.PARENT_SHA[t]);row=json.loads(path.read_text());a.step.validate_parent_metadata(row,t,marker,a.PARENT_MARKER)
   bad=copy.deepcopy(row);bad['identity']['code']['s2_temporal_forward.py']='b'*64
   with self.assertRaises(RuntimeError):a.step.validate_parent_metadata(bad,t,marker,a.PARENT_MARKER)
  bad=copy.deepcopy(self.parent);bad['identity']['point'][149]+=.125
  with self.assertRaises(RuntimeError):a.step.validate_parent_metadata(bad,3,marker,a.PARENT_MARKER)
 def test_completed_pair_pins_and_exact_metadata(self):
  marker=json.loads((E/'s2_step150_review_1507.json').read_text());self.assertEqual(a.sha(E/'s2_step150_review_1507.json'),a.STEP_MARKER_SHA)
  pair_review=dict(path=a.STEP_MARKER,sha256=a.STEP_MARKER_SHA,lead_verdict=marker['lead_verdict'],allowed_tasks=[0,1],parent150=self.center['bindings'])
  for t in [0,1]:
   path=E/f's2_step150_fetch_1600/s2_step150_task{t:02d}_original.json';self.assertEqual(a.sha(path),a.STEP_CP_SHA[t]);row=json.loads(path.read_text())
   # Recorded Athena identity is used only in this read-only metadata test. Runtime guard is unchanged.
   with patch.object(a.base,'vendor_sources',return_value=row['identity']['vendor_api_sha256']):a.validate_step_metadata(row,t,self.center,pair_review)
   for key,value in [('duration_ps',200.),('delta_nm',.0625),('spec',{}),('code',{}),('parent_review',{})]:
    bad=copy.deepcopy(row);bad['identity'][key]=value
    with patch.object(a.base,'vendor_sources',return_value=row['identity']['vendor_api_sha256']):
     with self.assertRaises(RuntimeError):a.validate_step_metadata(bad,t,self.center,pair_review)
   self.assertEqual(a.sha(E/f's2_step150_fetch_1600/s2_step150_task{t:02d}_ports.npz'),a.STEP_PORT_SHA[t])
 def test_200_identity_control_no_150_reuse(self):
  r=self.result(1);p=a.task_params(1)[0];a.verify_result(r,1,self.root,self.center,self.review)
  for key,value in [('duration_ps',150.),('delta_nm',.125),('params',a.val.te_point(a.SPEC).tolist()),('task',0)]:
   bad=copy.deepcopy(r);bad[key]=value
   with self.assertRaises(RuntimeError):a.verify_result(bad,1,self.root,self.center,self.review)
  for duration in [100e-12,150e-12]:
   c=copy.deepcopy(r['controls']);c['after']['timing']['simulation time']=duration;c['after_sha256']=a.semantic(c['after'])
   with self.assertRaises(RuntimeError):a.validate_control(c,p)
  ident=a.identity(1,self.center,self.review);bad=copy.deepcopy(ident);bad['spec']['label']='wrong_family';cp=self.root/'task_01.json';a.recovery.checkpoint(cp,bad,r)
  with patch.object(a,'root_path',return_value=self.root),patch.object(a,'load_ancestry',return_value=self.center),patch.object(a,'reviewed',return_value=self.review),patch.object(a,'forward_only',side_effect=AssertionError('accidental solve')):
   with self.assertRaises(RuntimeError):a.main(1)
 def test_grid_and_no_default_review(self):
  with np.load(self.center['result']['ports_npz']) as z:arrays={k:z[k] for k in z.files}
  a.same_grid(arrays,arrays)
  for key in ['p1_f','p1_lambda','p2_f','p2_lambda']:
   bad={k:v.copy() for k,v in arrays.items()};bad[key].flat[0]=np.nextafter(bad[key].flat[0],np.inf)
   with self.assertRaises(RuntimeError):a.same_grid(arrays,bad)
  m=a.review_template(self.root,self.center);self.assertEqual(m['status'],'NOT_REVIEWED');self.assertEqual(m['allowed_tasks'],[])
  self.assertEqual(len(a.task_params(0)[0]),296);self.assertEqual((a.SPEC.n_periods_side,a.SPEC.n_free),(98,60))
 def test_completed_reuse_no_CAD_and_score_file_tamper(self):
  r=self.result();ident=a.identity(0,self.center,self.review);a.recovery.checkpoint(self.root/'task_00.json',ident,r)
  with patch.object(a,'root_path',return_value=self.root),patch.object(a,'load_ancestry',return_value=self.center),patch.object(a,'reviewed',return_value=self.review),patch.object(a.eng,'import_lumopt2',side_effect=AssertionError('CAD import')),patch.object(a,'forward_only',side_effect=AssertionError('accidental solve')):
   self.assertEqual(a.main(task_idx=0),r)
  bad=copy.deepcopy(r);bad['peak3_tout']+=1e-4
  with self.assertRaises(RuntimeError):a.verify_result(bad,0,self.root,self.center,self.review)
  Path(r['ports_npz']).write_bytes(b'CORRUPTED_SYNTHETIC_NPZ')
  with self.assertRaises(RuntimeError):a.verify_result(r,0,self.root,self.center,self.review)
  with self.assertRaises(FileExistsError):a.recovery.checkpoint(self.root/'task_00.json',ident,r)
 def test_control_and_termination_failclosed(self):
  r=self.result();p=a.task_params(0)[0];c=copy.deepcopy(r['controls']);c['after']['source']['pulselength']*=1.01;c['after_sha256']=a.semantic(c['after'])
  with self.assertRaises(RuntimeError):a.validate_control(c,p)
  bad=copy.deepcopy(r);bad['termination']['physical_time_s']=100e-12
  with self.assertRaises(RuntimeError):a.verify_result(bad,0,self.root,self.center,self.review)
 def test_phase_only_0_1_2_and_material_other_controls(self):
  left=copy.deepcopy(self.parent['result']['controls']['before']);phase=left['ports']['FDTD::ports::Port_1']['phase']
  for n in [0,1,2,3]:
   right=copy.deepcopy(left);v=phase
   for _ in range(n):v=float(np.nextafter(v,np.inf))
   right['ports']['FDTD::ports::Port_1']['phase']=v
   if n<=2:self.assertEqual(a.phase_compare(left,right)['ULP_distance'],n)
   else:
    with self.assertRaises(RuntimeError):a.phase_compare(left,right)
  for section,key,value in [('source','pulselength',1.),('timing','dt',1.),('mesh','x',[1.])]:
   right=copy.deepcopy(left);right[section][key]=value
   with self.assertRaises(RuntimeError):a.phase_compare(left,right)
  right=copy.deepcopy(left);right['ports']['FDTD::ports::Port_2']['phase']+=1e-10
  with self.assertRaises(RuntimeError):a.phase_compare(left,right)
 def test_import_tasklist_syntax_no_CAD_or_main(self):
  source=Path(a.__file__).read_text();ast.parse(source);tree=ast.parse(source)
  self.assertFalse(any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ['run_adjoint','compute_gradient','run_projected','run_campaign'] for n in ast.walk(tree)))
  with patch.object(a.eng,'import_lumopt2',side_effect=AssertionError('CAD import')):
   spec=importlib.util.spec_from_file_location('temporal200_import_probe',a.__file__);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
  proc=subprocess.run([sys.executable,'-B',a.__file__,'--tasklist'],capture_output=True,text=True,cwd=ROOT);self.assertEqual(proc.returncode,0,proc.stderr);self.assertEqual(json.loads(proc.stdout)['N_TASKS'],3)
if __name__=='__main__':unittest.main(verbosity=2)
