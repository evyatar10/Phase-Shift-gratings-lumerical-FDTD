"""Two isolated least-squares peak-height candidates, not production objectives."""
import numpy as np
CANDIDATES={'quadratic7':(2,7),'quartic11':(4,11)}
class UnsupportedPeak(ValueError):pass

def estimate(y,index,name):
    if name not in CANDIDATES:raise UnsupportedPeak('Unregistered candidate')
    degree,count=CANDIDATES[name];half=count//2
    y=np.asarray(y,float)
    if y.ndim!=1 or not np.all(np.isfinite(y)) or np.any(y<0):raise UnsupportedPeak('Finite nonnegative scalar spectrum required')
    if type(index) is not int or index-half<0 or index+half>=len(y):raise UnsupportedPeak('Complete centered sample window unavailable')
    indices=np.arange(index-half,index+half+1)
    x=np.arange(-half,half+1,dtype=float)/half
    design=np.polynomial.polynomial.polyvander(x,degree)
    if np.linalg.matrix_rank(design)!=degree+1:raise UnsupportedPeak('Rank-deficient fit')
    pinv=np.linalg.pinv(design,rcond=1e-14)
    coefficients=pinv@y[indices]
    derivative=np.polynomial.polynomial.polyder(coefficients)
    roots=np.polynomial.polynomial.polyroots(derivative)
    real=sorted(float(r.real) for r in roots if abs(r.imag)<=1e-10*max(1.,abs(r.real)))
    nearby=[r for r in real if abs(r*half)<=1.+1e-10]
    if len(nearby)!=1:raise UnsupportedPeak('Expected exactly one stationary branch within one bin')
    vertex=nearby[0]
    second_derivative=np.polynomial.polynomial.polyder(coefficients,2)
    arithmetic_tol=128*np.finfo(float).eps*max(1.,float(np.max(np.abs(coefficients))))
    # Companion-matrix roots can lose digits when the fitted highest terms
    # are almost zero. Polish the already unique supported root against the
    # original coefficients; never choose a new branch to rescue a fit.
    for _ in range(5):
        residual=float(np.polynomial.polynomial.polyval(vertex,derivative))
        curvature=float(np.polynomial.polynomial.polyval(vertex,second_derivative))
        if abs(curvature)<=arithmetic_tol:raise UnsupportedPeak('Numerically degenerate stationary root')
        vertex-=residual/curvature
        if abs(vertex*half)>1.+1e-10:raise UnsupportedPeak('Refined stationary root leaves supported central bin')
    stationary_residual=float(np.polynomial.polynomial.polyval(vertex,derivative))
    if abs(stationary_residual)>arithmetic_tol:raise UnsupportedPeak('Stationary root refinement did not converge')
    curvature=float(np.polynomial.polynomial.polyval(vertex,second_derivative))
    if curvature>=-arithmetic_tol:raise UnsupportedPeak('Stationary branch is not numerically concave')
    basis=vertex**np.arange(degree+1)
    height=float(basis@coefficients)
    weights=basis@pinv
    residual=y[indices]-design@coefficients
    if not np.isfinite(height) or height<=0:raise UnsupportedPeak('Nonpositive/nonfinite fitted peak')
    jac=np.zeros_like(y);jac[indices]=weights
    return dict(height=height,jacobian=jac,indices=indices,weights=weights,offset_bins=vertex*half,
        coefficients=coefficients,curvature_per_bin2=curvature/(half**2),
        fit_residual_rms=float(np.sqrt(np.mean(residual**2))),fit_residual_max_abs=float(np.max(np.abs(residual))),
        design_condition_number=float(np.linalg.cond(design)),jacobian_l2=float(np.linalg.norm(jac)),
        stationary_residual=stationary_residual,unique_stationary_branch_within_one_bin=True)
