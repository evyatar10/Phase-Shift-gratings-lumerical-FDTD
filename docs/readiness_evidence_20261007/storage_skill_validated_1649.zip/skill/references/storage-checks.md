# Storage checks during sustained work

The user requires periodic checks of the local computer and both clusters.
Delegate routine collection to a focused Sol worker when available; retain
launch/storage decisions with the lead. Fold checks into existing monitoring
about every20-30minutes while work is active, before new solves/large downloads,
and after completion. Check sooner if actual outputs exceed their budget.
This is a workflow cadence, not a new automation or guaranteed background service.

Use `scripts/check_storage.py --output NEW_ABSOLUTE_JSON_PATH`. It records local
repo/results/TEMP volumes, both clusters' filesystem bytes/inodes, quota and
queue, plus shared solver seats from IGUM. `--clusters athena` or `--clusters`
limits it to one cluster or local-only. `--local-path` can name an actual extra
destination. One bounded SSH per selected host, no repeated retries. Read all
exit codes: successful collection can contain missing commands or failed checks.
Preserve snapshots in the dated project evidence, not in the installed skill.

Compare filesystem free bytes AND user soft-quota headroom. Record inode/file
headroom when available. Do not add repeated rows from the same volume, or
confuse decimal GB with GiB. On Athena, `quota -v` reports1024-byte blocks;
human-rounded `quota -s` is sufficient for routine rough checks. IGUM uses a
Lustre filesystem; the ordinary quota command may be absent. The helper tries
the read-only `lfs quota -u UID PATH` when installed. Preserve unavailable,
permission-denied or unsupported quota results as unknown; filesystem free
space alone is not a user allowance. Zero user limits do not prove absence of
group/project limits. Never run quota-setting commands.

Budget outstanding queued/running outputs, proposed outputs and an explicit
retry/intermediate reserve against the smaller applicable headroom. Estimate
from stat sizes of known comparable artifacts, including large companion H5,
not only small MAT summaries. Forward-only recording and full adjoint recording
have different storage costs. A multiplier on observed sizes is a planning
allowance, not an upper bound. If headroom cannot cover the plan or output
growth is unexpected, report it and stop adding storage-intensive work until
a safe authorized alternative is concrete; preserve existing jobs/results.
Do not automatically delete, cancel, compress in place or move files. Avoid
recursive home scans for routine monitoring; investigate exact study paths
only when needed. Keep large solver files on servers and download selected MAT
profiles/spectra when that answers the scientific question.

Primary command reference: [Lustre quota administration](https://wiki.lustre.org/Lustre_Quota_Administration).
