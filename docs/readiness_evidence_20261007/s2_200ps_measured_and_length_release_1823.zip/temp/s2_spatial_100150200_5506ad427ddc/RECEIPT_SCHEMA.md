# Required independent200 extraction receipt

Lead constructs this minimal receipt ONLY from actual successful CPU dispatch/accounting, actual remote producer/helper source hashes and actual report/NPZ byte-hash+fetch evidence. It is not inferred authorship. Reader requires an independently recorded SHA256 for the receipt itself, plus separate raw checkpoint/report/NPZ SHA arguments. Exact keys only; no extra fields.

```json
{
  "schema": 1,
  "source_job_id": "171390",
  "extraction_job_id": "ACTUAL_CPU_JOB_ID_DIGITS",
  "extraction_state": "COMPLETED",
  "extraction_exit_code": "0:0",
  "producer_sha256": "36ff78a1c567a911c84d707682e9dfa0e0e3e51c740e142a8be4d43f65e4f9f3",
  "core_reader_sha256": "994c3e9757a10b5bd8ea211aaee8425c5d3540203a4da04b0439684163baf6ca",
  "checkpoint_path": "/work/results/diagnose_te_s2_temporal200/results/s2_shift30_temporal200_20261007/task_00.json",
  "checkpoint_sha256": "INDEPENDENT_ACTUAL_RAW_CHECKPOINT_SHA",
  "report_path": "/work/results/ACTUAL_EXCLUSIVE_OUTPUT/report.json",
  "report_sha256": "INDEPENDENT_ACTUAL_REMOTE_REPORT_BYTE_SHA",
  "npz_path": "/work/results/ACTUAL_EXCLUSIVE_OUTPUT/profiles_200ps.npz",
  "npz_sha256": "INDEPENDENT_ACTUAL_REMOTE_NPZ_BYTE_SHA"
}
```

Output paths must be canonical /work paths with no traversal, same outputparent and exactly these basenames. NPZpath must equal original extraction reportstage200.profile_npz. Digest values bind caller input bytes and report/profile/CP preservation receipts; successful jobID is an actual nonzero digitstring. Placeholders are NOT valid evidence. source_job_id171390 identifies the original200ps simulationarray; extraction_job_id is the later CPU reader allocation.
