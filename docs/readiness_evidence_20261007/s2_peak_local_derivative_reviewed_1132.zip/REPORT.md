# Local derivative of small peak3 phase ripple

The amplitude and derivative conclusions differ. Cubic translation of a fixed
measured center has only~6.7e-6 Tout height ripple, insufficient to explain the actual
0.5nm shift30 even term2.8e-4. Yet its local peak3 derivative can be material.
Using conditional peak speed-22.6bins/nm gives a one-bin phase period
1/22.6=0.0442478nm. Height-range/period is1.5162e-4/nm for repeated Tout,
not a derivative bound. The sampled branchwise derivative range is
[-3.2018e-4,+1.4038e-4]/nm. No behavior at selector switches is bounded here.

Exact chain rule: for spline s and translation speed v,
y(p)=s(x-v*p), and d(peak3)/dp=J_peak3(y(0)) dot (-v*s'(x)).
The frozen nominal Jacobian projection FD and moving-peak FD both converge to it.
Synthetic h is halved from0.0625nm through0.00000381470nm; no FDTD is used.

| Center/observable | exact model local derivative,/nm | final frozen-J FD | final moving-peak FD |
|---|---:|---:|---:|
|Repeated Tout|-1.032496862e-4|-1.032497138e-4|-1.032497239e-4|
|Original Tout|-9.783256320e-5|-9.783255402e-5|-9.783255518e-5|
|Repeated modal|4.077994315e-5|4.077994686e-5|4.077993799e-5|
|Original modal|5.195988439e-5|5.195987459e-5|5.195988342e-5|

Repeated Tout peak branches differ at h0.0625/0.03125, but remain252/252 at
0.015625 and below. At h0.015625 frozen/moving derivatives are-8.4002e-5/
-1.00576e-4; at0.00390625 they are-1.02047e-4/-1.03641e-4; by the final h,
both errors versus chain rule are below4e-11/nm. This is arithmetic/model convergence,
not a proposed hardware step or a scientific tolerance.

The original stored-forward export and repeated-center NPZ are byte-hash pinned.
Saved original Re probe Jacobian weights agree with exported-center reconstructed
weights within3.77e-14; applying those saved weights yields-9.783256319e-5/nm.
Thus the observation is not specific to the later repeated center. Complete original
FSP creation provenance is still not inferred from its read-only export.

The repeated Tout model derivative magnitude is~2.8 times the measured corr30
coarse derivative3.69e-5/nm and~38% of measured shift30 coarse magnitude2.70e-4/nm.
Repeated modal model4.08e-5/nm is comparable to corr30 coarse4.18e-5/nm and~10%
of shift30 coarse4.01e-4/nm. These are scale comparisons only: corr30 does not
inherit shift30's translation speed. Coarse measured derivatives are not assumed
infinitesimal physical truth. Interpolant uncertainty is material; the saved samples
do not uniquely identify s'(x), and actual geometry can change height/shape too.

Gradient validation must specify its target. For the current objective, the correct
local derivative includes the phase sensitivity of sampled peak3. A coarse FD that
moves over many phase periods need not match it even for constant physical peak
height. A physical continuous-height target is different and requires a validated
estimator/objective. This conditional mechanism could affect comparisons; it does
not establish that it caused the failed calibration. No full spectral adjoint J is
available: original Re/Im outputs remain scalar contractions.

A higher-order/multipoint fitted height is a future candidate if phase invariance is
wanted. It needs synthetic asymmetric/background/branch tests, differentiable weights,
estimator-bias checks and fresh gradient qualification under its own identity.
No production objective, prepared0.125/0.0625 hardware ladder or gate was changed.

Three focused tests (quadratic zero derivative; cubic exact chain-rule/convergence;
period units/exclusive output) and actual analysis passed, exit0. Code, numeric
report and validation command evidence are retained here. TEMP-only; no CAD/server
activity, coefficients, noise bounds or scientific approval.
