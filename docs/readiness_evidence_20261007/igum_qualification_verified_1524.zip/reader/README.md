# IGUM 101155_0 read-only qualification comparison

Prepared only; no SSH, CAD, solver, upload, dispatch or repository mutation was performed. Parent owns actual retrieval/release.

`collect_remote.py` is a standalone stdlib script. Parent can pipe its exact reviewed bytes into `python3 -` over the existing trusted IGUM connection and save stdout exclusively as a new local original bundle. No remote upload or output file is required; the script writes only stdout. It invokes only `sacct`, `scontrol` and `squeue`, reads existing files and hashes them. It imports no project, lumapi or lumopt2 code.

Frozen target: job 101155_0, native root `/home/evyatarrubin/research/bragg_sim_igum`; checkpoint `/home/evyatarrubin/research/bragg_sim_igum/results/diagnose_te_s2_fdstep/results/lumopt2_te_s2_fdstep_diagnostic_20261007/task_00.json`. Exact original recovered calibration reference `/home/evyatarrubin/research/bragg_sim_igum/data/te_s2_reference_20261007_original.json`, SHA 732ca5752ff2b0449a892ebafe7ba6a87a5ee1fce63bd929f8f7343bf50df13f. Native API root `/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261/api/python`. Collection needs no license or job environment. The existing solve used CONV_POL=TE, KEEP_H5=1, REQUIRE_GPU=1, 8 CPU threads, A100 80GB; these are not instructions to submit another run.

Completion guard requires exact array task COMPLETED exit0 from sacct or scontrol, plus the exact-job batch Finished/Exit0/new-checkpoint record and solver success. Missing accounting is retained in full, even if scontrol supplies trustworthy completion. An empty/failed queue never establishes completion. Without either trustworthy terminal scheduler record, stdout explicitly reports NOT_READY_OR_INVALID_NO_COMPLETION_CLAIM; the comparator refuses it. It does not retry or claim the cluster idle.

Only original checkpoint, ports NPZ, tasklist and complete solver/batch logs are embedded with SHA/size/full remote path. Original FSP/H5 are streamed through SHA256 and stat-checked, not downloaded or modified; this may cost read I/O proportional to their sizes (8MiB hashing buffer). No field extraction. Project sources must match all nine frozen hashes; complete checkpoint identity matches Athena apart from the reviewed native reference path. Installed API hashes are measured independently and differences/unavailability reported, not silently accepted as parity. Installed hashes collected now do not establish install immutability throughout the earlier run.

After parent saves/pins the actual bundle SHA, run locally:

```powershell
python -B test_qualification.py
python -B compare.py --bundle C:/absolute/new_igum_bundle_original.json --bundle-sha256 PARENT_PINNED_SHA256 --evidence-dir C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007 --repo C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes --output C:/absolute/new_igum_comparison.json --extract-dir C:/absolute/new_igum_originals_directory
```

Output and extraction directory must be new; existing files are never replaced. `--extract-dir` is optional. Comparator requires all frozen local source hashes and expected.json SHA, exact original Athena task0 checkpoint `cd2dd4a58be7b83c46ef6a6ac90a874e5fc33edda884edfc8ac50ce5e3be4a06` and NPZ `4c3c526b51973a2c8889608c69958b6d60e4dc27ddcf638c9932598629a035e4`. This is the original default-autoshutoff center, not the 150 ps center. It reproduces all saved scores within 1e-12, requires exact 501 grids and full 296-parameter/spec/task family, then reports Tout/modal separately: scalar/peak differences, peak indices/lambda, fixed 244/252/260 values, full spectra/differences, RMS/max differences, datatype/GPU and recorded termination time/reason/energy.

Limit: this legacy checkpoint records spec, input parameters and mesh counts, not measured saved CAD object properties, mesh coordinates or timing-property readbacks. The report marks all three unavailable. Port grids and matched source/parameters do not prove those stronger conditions. A100 40GB versus 80GB is explicitly recorded without assuming bitwise parity. No fit, gradient gate, qualification pass or optimization authorization is generated.

Seven meaningful offline groups pass, including actual Athena scalar arithmetic as an explicitly synthetic IGUM receipt, full-point/spec/grid/byte tampering, incomplete/reused outputs, exact-array/exit status and missing-accounting fallback, and AST proof of the collector's read-only command/import surface. Actual IGUM inputs remain pending parent retrieval.
