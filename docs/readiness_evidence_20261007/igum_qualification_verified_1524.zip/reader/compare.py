"""Compare parent-pinned IGUM original artifacts with original Athena task0.

Offline only. No CAD, SSH, solver or scientific approval.
"""
import argparse,base64,hashlib,io,json,re,sys
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
import numpy as np
from collect_body import EvidenceError,require


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def decode(item):
    raw=base64.b64decode(item['data'],validate=True)
    require(len(raw)==item['bytes'] and sha(raw)==item['sha256'],'Original artifact bytes/hash differs')
    return raw


def arrays(raw):
    with np.load(io.BytesIO(raw),allow_pickle=False) as data:
        out={k:data[k].copy() for k in data.files}
    require(all(np.isfinite(a).all() for a in out.values()),'Nonfinite spectral arrays')
    return out


def family(row,expected):
    identity=dict(expected['identity']);identity['reference_checkpoint']=expected['reference_path']
    require(row['identity']==identity,'Full nominal family/task/spec/code identity differs')
    result=row['result']
    require(result['task']==result['sign']==result['delta_nm']==0 and result['index']==29 and result['params']==identity['point'],'Result is not exact nominal point')
    require(result['reference']['path']==expected['reference_path'] and result['reference']['sha256']==identity['reference_sha256'],'Reference result differs')
    require(result['comparison_status']=='REVIEW_REQUIRED_NO_AUTOMATIC_PHYSICS_PASS' and result['existing_overall_gradient_gate']=='FAILED_UNCHANGED','Unexpected scientific status')


def grid(a,b):
    require(set(a)==set(b),'Port dataset keys differ')
    for k in a:
        require(a[k].shape==b[k].shape,'Array shape differs: '+k)
    for k in ('p1_f','p2_f','p1_lambda','p2_lambda'):
        require(k in a and a[k].size==501 and np.array_equal(a[k],b[k]),'Exact501 grid differs: '+k)


def termination(text):
    require('Simulation completed successfully' in text,'Solver completion missing')
    total=re.findall(r'Completed\s+(\d+) iterations, or ([0-9.eE+-]+)s of Simulation Time',text)
    require(len(total)==1,'Missing or ambiguous completed iteration/time record')
    samples=re.findall(r'Auto Shutoff:\s*([0-9.eE+-]+)',text)
    require(bool(samples),'Missing termination energy record')
    gpu=re.findall(r'Detected GPU \d+: ([^\n]+)',text)
    return dict(iterations=int(total[0][0]),simulation_time_s=float(total[0][1]),last_reported_auto_shutoff=float(samples[-1]),
        reason='autoshutoff' if 'autoshutoff criteria are satisfied' in text else 'not_explicitly_reported',
        GPU=gpu,datatype=re.findall(r'Using datatype: ([^\n]+)',text),
        GPU_run_seconds=[float(x) for x in re.findall(r'time to run GPU simulation:\s*([0-9.eE+-]+)',text)])


def delta(new,old):
    return dict(new=float(new),athena=float(old),signed_delta=float(new-old),relative_delta=float((new-old)/old) if old else None)


def analyze(bundle,expected,athena_row,athena_arrays,score):
    require(bundle['status']=='COMPLETION_EVIDENCE_COLLECTED_REVIEW_REQUIRED' and bundle['job']=='101155' and bundle['task']==0 and bundle['no_solve'],'Uncompleted/wrong job collection')
    from collect_body import completion
    require(completion(bundle['accounting'],bundle['control'])==bundle['completion_evidence'],'Completion provenance differs')
    files=bundle['files'];originals={k:decode(v) for k,v in files.items()}
    row=json.loads(originals['checkpoint']);family(row,expected)
    require(athena_row['identity']==expected['identity'],'Athena original identity differs')
    a=arrays(originals['ports']);grid(a,athena_arrays)
    require(bundle['current_code']==expected['identity']['code'],'Current source hashes differ')
    for key,role in (('source',None),('h5',None),('ports_npz','ports')):
        pin=bundle['artifact_hashes'][key]
        require(pin['path']==row['result'][key] and pin['bytes']>0 and re.fullmatch('[0-9a-f]{64}',pin['sha256']),'Associated artifact pin absent/invalid')
        if role:require(pin['sha256']==files[role]['sha256'],'Ports receipt/artifact pin differs')
    solver=originals['solver_log'].decode(errors='replace');batch=originals['batch_log'].decode(errors='replace')
    require(files['solver_log']['path']==str(PurePosixPath(row['result']['source']).with_name('fwd_default_p0.log')),'Solver log associated with other source')
    require('Array:      101155[0]' in batch and re.search(r'^Exit code:\s*0\s*$',batch,re.M) and 'Finished:' in batch,'Exact-job batch termination absent')
    require('DIAGNOSTIC checkpoint, review required '+files['checkpoint']['path'] in batch and 'REUSED diagnostic checkpoint' not in batch,'No new exact-checkpoint association in batch')
    require("device type readback = 'GPU'" in batch and 'FDTD threads = 8' in batch,'GPU/thread readback absent')
    require(originals['tasklist'].decode().strip()=='0','Not task0-only manifest')
    require(set(bundle['vendor_sources'])==set(expected['vendor_sources']),'Vendor source inventory incomplete')
    measured,baseline=score(a),score(athena_arrays)
    for name in measured:
        require(name in row['result'] and abs(float(measured[name])-float(row['result'][name]))<=1e-12,'IGUM saved scalar not reproduced: '+name)
        require(name in athena_row['result'] and abs(float(baseline[name])-float(athena_row['result'][name]))<=1e-12,'Athena saved scalar not reproduced: '+name)
    result=dict(status='COMPARISON_ONLY_CALIBRATION_FAILED_UNCHANGED',no_automatic_qualification=True,
        artifact_pins={k:{n:v for n,v in item.items() if n!='data'} for k,item in files.items()},
        accounting=bundle['accounting'],completion_evidence=bundle['completion_evidence'],
        source_hashes_match=True,spec_and_296_parameters_match=True,exact501_port_grids_match=True,
        mesh_point_counts=dict(igum=row['result']['mesh_points'],athena=athena_row['result']['mesh_points']),
        actual_saved_CAD_geometry_properties='UNAVAILABLE: checkpoint parameters are inputs, not a saved CAD property measurement',
        actual_mesh_coordinates='UNAVAILABLE: mesh counts alone do not establish coordinate parity',
        actual_timing_controls='UNAVAILABLE: this runner did not record saved timing properties',
        installed_API=dict(lumapi=delta_hash(bundle['lumapi_sha256'],expected['lumapi_sha256']),
            files={k:delta_hash(v['sha256'],expected['vendor_sources'][k]) for k,v in bundle['vendor_sources'].items()}),
        termination=dict(igum=termination(solver),athena=termination(expected['athena_termination']['tail']),athena_original_log_pin={k:v for k,v in expected['athena_termination'].items() if k!='tail'}),
        scalar_differences={k:delta(measured[k],baseline[k]) for k in measured},spectra={},
        limitations=bundle['limitations']+['One cross-cluster forward comparison establishes no gradient calibration or hardware error/noise bound.','Requested default timing family may terminate at different times; report termination differences without attributing spectral differences.'])
    t=result['termination']
    result['termination_differences']={k:delta(t['igum'][k],t['athena'][k]) for k in ('iterations','simulation_time_s','last_reported_auto_shutoff')}
    result['engine_version_evidence']=dict(igum_batch=re.findall(r"FDTD version '([^']+)'",batch),athena_original_log='UNAVAILABLE in preserved reference log tail; API/source hashes are separate evidence')
    for name,fn in [('Tout',lambda x:abs(x['p2_T_out'].ravel())),('modal',lambda x:abs(x['p2_S'].ravel())**2)]:
        new,old=fn(a),fn(athena_arrays);d=new-old;kn,ko=int(np.argmax(new)),int(np.argmax(old))
        result['spectra'][name]=dict(max_abs_difference=float(max(abs(d))),RMS_difference=float(np.sqrt(np.mean(d*d))),
            peak_indices=dict(igum=kn,athena=ko),peak_sample_lambda_nm=dict(igum=float(a['p2_lambda'].ravel()[kn]*1e9),athena=float(athena_arrays['p2_lambda'].ravel()[ko]*1e9)),
            lambda_nm=(a['p2_lambda'].ravel()*1e9).tolist(),igum=new.tolist(),athena=old.tolist(),signed_difference=d.tolist(),
            fixed_bins={str(k):delta(new[k],old[k]) for k in (244,252,260)})
    return result,originals


def delta_hash(new,old):
    return dict(igum=new,athena=old,equal=new==old,unavailable=new is None)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('bundle','bundle-sha256','evidence-dir','repo','output'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--extract-dir');args=parser.parse_args()
    expected_path=Path(__file__).with_name('expected.json');expected_raw=expected_path.read_bytes()
    require(sha(expected_raw)=='9762009f94b42332dee05ceacba01c5fd0699c87057817e82cea5744bca6336e', 'Prepared expectation bytes differ')
    expected=json.loads(expected_raw)
    raw=Path(args.bundle).read_bytes();require(sha(raw)==args.bundle_sha256,'Parent-pinned bundle bytes differ')
    ev=Path(args.evidence_dir);cp=(ev/'s2_fdstep_task00_original.json').read_bytes();ports=(ev/'s2_fdstep_task00_ports.npz').read_bytes()
    require(sha(cp)==expected['athena_checkpoint_sha256'] and sha(ports)==expected['athena_ports_sha256'],'Wrong original Athena reference bytes')
    repo=Path(args.repo).resolve()
    for name,digest in expected['identity']['code'].items():
        rel=Path(name) if name in ('bragg_device.py','simulation_config.py','sim_helpers.py') else Path('runners/lumopt2_design')/name
        require(sha((repo/rel).read_bytes())==digest,'Frozen local source differs: '+name)
    sys.path.insert(0,str(repo))
    from runners.lumopt2_design import recover_te_s2 as recovery
    require(sha(Path(recovery.eng.__file__).read_bytes())==expected['identity']['code']['lumopt2_design.py'] and sha(Path(recovery.__file__).read_bytes())==expected['identity']['code']['recover_te_s2.py'],'Frozen local scoring source differs')
    report,originals=analyze(json.loads(raw),expected,json.loads(cp),arrays(ports),recovery.score)
    report['parent_pinned_bundle_sha256']=args.bundle_sha256
    if args.extract_dir:
        folder=Path(args.extract_dir);folder.mkdir(exist_ok=False)
        for role,content in originals.items():
            suffix='.npz' if role=='ports' else '.json' if role=='checkpoint' else '.log' if 'log' in role else '.txt'
            with (folder/('igum101155_'+role+suffix)).open('xb') as stream:stream.write(content)
    with Path(args.output).open('x',encoding='utf-8') as stream:json.dump(report,stream,indent=2,allow_nan=False)
    print('Pinned spectra compared; scientific qualification remains review required')


if __name__=='__main__':main()
