"""Read-only extraction of independently pinned completed171390 center; no FDTD."""
import argparse,hashlib,importlib.util,json,re,sys
from pathlib import Path,PurePosixPath
import numpy as np
sys.dont_write_bytecode=True
HELPER_SHA='994c3e9757a10b5bd8ea211aaee8425c5d3540203a4da04b0439684163baf6ca'
RUNNER_SHA='fa6a6528e34cb9c004604ec490543c3b0579d76224c936568c2e11e4f9996053'
MARKER='/work/data/s2_temporal200_review_20261007_1619.json'
MARKER_SHA='4fe3c0e7fc37cced733ac7cf7b2ee3de3536213ee938e23a1095dffc307cd44f'
ROOT='/work/results/diagnose_te_s2_temporal200/results/s2_shift30_temporal200_20261007'
CENTER='/work/results/diagnose_te_s2_temporal/results/s2_shift30_temporal_20261007/task_03.json'
CENTER_SHA='a0ff55eacaa52e00a2aab17dcc43d0e5fff9a72566e15da371ff25279c172663'
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
hp=Path(__file__).with_name('extract_saved_spatial_profiles.py')
need(sha(hp)==HELPER_SHA,'Frozen read-only extraction helper changed')
sp=importlib.util.spec_from_file_location('profile_reference',hp);h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)

def server_path(value):
 need(isinstance(value,str) and value.startswith('/work/') and '\\' not in value and '..' not in value.split('/') and '.' not in value.split('/'),'Canonical absolute /work path required; no traversal')
 p=PurePosixPath(value);need(str(p)==value,'Canonical exact server path required');return p

def validate_metadata(row,marker,center):
 i,r=row['identity'],row['result']
 need(type(i['task']) is int and type(r['task']) is int and i['task']==r['task']==0 and i['index']==r['index']==29 and i['sign']==r['sign']==0 and i['delta_nm']==r['delta_nm']==0 and i['duration_ps']==r['duration_ps']==200.,'Wrong temporal200 center role')
 need(marker['center_checkpoint']==CENTER and marker['center_sha256']==CENTER_SHA and marker['output_root']==ROOT and marker['duration_ps']==200. and marker['allowed_tasks']==[0,1,2] and marker['code']['s2_temporal200_forward.py']==RUNNER_SHA,'Released marker numerical scope differs')
 review=dict(path=MARKER,sha256=MARKER_SHA,lead_verdict=marker['lead_verdict'],allowed_tasks=[0,1,2],parent150=marker['parent150'],completed_step150=marker['completed_step150'])
 expected=dict(schema=1,task=0,spec=marker['spec'],point=center['identity']['point'],index=29,sign=0,delta_nm=0.,duration_ps=200.,task_map=marker['task_map'],center_checkpoint=CENTER,center_sha256=CENTER_SHA,parent150=marker['parent150'],completed_step150=marker['completed_step150'],code=marker['code'],vendor_api_sha256=marker['vendor_api_sha256'],parent_review=review,timing_changes=marker['timing_changes'])
 need(i==expected and r['parent_review']==review and r['vendor_api_sha256']==marker['vendor_api_sha256'],'Full center/marker identity differs')
 point=np.asarray(i['point'],float);need(point.shape==(296,) and np.isfinite(point).all() and np.array_equal(point,np.asarray(r['params'],float)),'Finite full296 point differs')
 need(i['spec']['n_periods_side']==98 and i['spec']['n_free']==60 and i['spec']['bare'] and i['spec']['polarization']=='TE' and i['code']['lumopt2_design.py']==h.ENGINE_SHA,'Wrong center family/engine')
 dt=r['controls']['dt_s'];t=r['termination'];after=r['controls']['after'];persisted=r['controls']['persisted']
 need(not isinstance(dt,bool) and np.isfinite(dt) and dt>0 and dt==after['timing']['dt']==persisted['timing']['dt']==center['result']['controls']['dt_s'],'Finite positive reference-matched recorded timestep required')
 need(t['status']==1 and t['reason']=='completed_full_simulation_time' and t['requested_time_s']==200e-12 and t['recorded_dt_s']==dt and np.isfinite(t['physical_time_s']) and abs(t['physical_time_s']-200e-12)<=dt and t['delta_s']==t['physical_time_s']-200e-12 and type(t['iterations']) is int and t['iterations']>0,'Incomplete or inconsistent200ps termination')
 for controls in [after,persisted]:need(controls['optimization_dft_enabled']==0 and controls['timing']['use early shutoff']==0 and controls['timing']['use divergence checking']==1 and controls['timing']['simulation time']==200e-12,'Wrong physical controls')
 source,companion,ports=[server_path(r[key]) for key in ['source','h5','ports_npz']];root=server_path(ROOT);attempt=ports.parent
 need(attempt.parent==root and attempt.name.startswith('task_00_') and len(attempt.name)>8 and ports.name=='ports.npz' and source.is_relative_to(attempt) and source.name=='fwd_default.fsp' and companion==source.with_suffix('')/'fwd_default_output.h5','Artifacts escaped exact task00 family/attempt')
 return row

def validate(path,expected_sha,repo):
 need(re.fullmatch('[a-f0-9]{64}',expected_sha) is not None,'Independent raw checkpoint SHA required')
 need(str(server_path(str(path)))==ROOT+'/task_00.json','Only exact171390 center eligible')
 need(sha(path)==expected_sha,'Center checkpoint byte SHA differs')
 row=json.loads(Path(path).read_text(encoding='utf-8'));need(sha(MARKER)==MARKER_SHA and sha(CENTER)==CENTER_SHA,'Exact released marker/150center bytes required')
 marker=json.loads(Path(MARKER).read_text());center=json.loads(Path(CENTER).read_text());validate_metadata(row,marker,center);i,r=row['identity'],row['result']
 for name,digest in i['code'].items():
  p=repo/name if name in ['config.py','bragg_device.py','simulation_config.py','sim_helpers.py'] else repo/'runners/lumopt2_design'/name
  need(sha(p)==digest,'Frozen extraction dependency differs: '+name)
 for key,digest in [('source','fsp_sha256'),('h5','h5_sha256'),('ports_npz','ports_sha256')]:need(h.sha(r[key])==r[digest],'Saved artifact changed: '+key)
 return row

def run(a):
 out=Path(a.output);need(out.is_absolute() and not out.exists(),'New absolute output directory required')
 repo=Path(a.repo).resolve();row=validate(a.checkpoint,a.checkpoint_sha256,repo);r=row['result']
 api=Path(a.lumapi).resolve();vendor={str(p.relative_to(api.parent)).replace('\\','/'):h.sha(p) for p in sorted((api.parent/'lumopt2').rglob('*.py'))+[api]}
 extra=api.parent/'lumslurm.py'
 if extra.is_file():vendor['lumslurm.py']=h.sha(extra)
 need(vendor==row['identity']['vendor_api_sha256'],'Actual configured vendor differs; no substitution')
 sys.path.insert(0,str(repo));sys.path.insert(0,str(api.parent))
 from runners.lumopt2_design import lumopt2_design as eng,recover_te_s2 as recovery
 import numpy as np,lumapi
 need(Path(lumapi.__file__).resolve()==api,'Imported API path differs')
 need(Path(eng.__file__).resolve()==(repo/'runners/lumopt2_design/lumopt2_design.py').resolve() and h.sha(eng.__file__)==row['identity']['code']['lumopt2_design.py'],'Imported frozen engine differs')
 code_paths=[repo/name if name in ['config.py','bragg_device.py','simulation_config.py','sim_helpers.py'] else repo/'runners/lumopt2_design'/name for name in row['identity']['code']]
 vendor_paths=sorted((api.parent/'lumopt2').rglob('*.py'))+[api]+([extra] if extra.is_file() else [])
 snapshots=[h.identity(p) for p in [a.checkpoint,r['source'],r['h5'],r['ports_npz'],MARKER,CENTER]+code_paths+vendor_paths]
 out.mkdir();report=dict(status='STARTED_READ_ONLY',no_solve=True,job='171390',independent_checkpoint_sha256=a.checkpoint_sha256,inputs={'200':snapshots},stages={});cls=lumapi.FDTD;ctor=cls.__init__
 try:
  schema=h.optional_h5_inventory(r['h5']);report['stages']['200']={'h5_schema':schema}
  raw=lumapi.FDTD(hide=True);cad=h.ReadOnlyCAD(raw,r['source'])
  try:
   cad.load(r['source'])
   with np.load(r['ports_npz'],allow_pickle=False) as z:ports={k:z[k] for k in z.files}
   score=recovery.score(ports);need(all(abs(float(score[k])-float(r[k]))<=1e-12 for k in ['peak3_tout','peak3_modal','lam_nm']),'Saved port scores not reproduced')
   report['stages']['200'].update(h.extract(cad,eng,row,ports,out,200,True,report['stages']['200']))
  finally:cad.close()
  report['status']='SAVED_RAW_PROFILE_EXTRACTION_COMPLETE_NO_PHYSICS_PASS'
 except Exception as e:report['status']='EXTRACTION_FAILED_CLOSED';report['error']=type(e).__name__+': '+str(e)
 finally:
  after=[]
  for before in snapshots:
   try:
    current=h.identity(before['path']);after.append(dict(before=before,after=current,unchanged=current==before))
   except Exception as e:after.append(dict(before=before,unchanged=False,error=str(e)))
  report['immutable_inputs_rechecked']=after;report['all_inputs_preserved']=all(x['unchanged'] for x in after)
  report['FDTD_class_unchanged']=lumapi.FDTD is cls;report['FDTD_constructor_unchanged']=lumapi.FDTD.__init__ is ctor
  if not report['FDTD_class_unchanged'] or not report['FDTD_constructor_unchanged']:report['status']='EXTRACTION_FAILED_CLOSED';report['error']='Original FDTD class/constructor changed'
  if not report['all_inputs_preserved']:report['status']='EXTRACTION_FAILED_CLOSED';report['error']='Original artifact changed'
  with (out/'report.json').open('x',encoding='utf-8') as f:json.dump(h.plain(report),f,indent=2,allow_nan=False)
 print(report['status']);return 0 if report['status']=='SAVED_RAW_PROFILE_EXTRACTION_COMPLETE_NO_PHYSICS_PASS' else 1
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__)
 for name in ['repo','lumapi','checkpoint','checkpoint-sha256','output']:p.add_argument('--'+name,required=True)
 raise SystemExit(run(p.parse_args()))
