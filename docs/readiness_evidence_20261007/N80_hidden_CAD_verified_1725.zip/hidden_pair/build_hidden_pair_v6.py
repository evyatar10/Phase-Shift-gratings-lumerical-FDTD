"""Fresh native N98/N80 fixed-domain hidden CAD only. No solver entrypoint."""
import argparse,dataclasses,hashlib,json,re,sys,traceback
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
CP=ROOT/'docs/readiness_evidence_20261007/s2_temporal150_fetch_1434/s2_temporal150_task03_original.json'
PROFILES=ROOT/'docs/readiness_evidence_20261007/s2_saved_profiles_fetch_154823/report.json'
BLUEPRINT=Path('C:/Users/evyat/AppData/Local/Temp/s2_N80_fixed_domain_blueprint_r0clu8yf')
GUARD=Path('C:/Users/evyat/AppData/Local/Temp/s2_step150_hidden_cad_d8138b40abe4')
API=Path('C:/Program Files/Lumerical/v261/api/python')
CP_SHA='a0ff55eacaa52e00a2aab17dcc43d0e5fff9a72566e15da371ff25279c172663'
PROFILE_SHA='01a6fe6540c7cf903de67cecc42a89c6318983301364b679b9da0870dede595a'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(x,msg):
 if not x:raise RuntimeError(msg)
def plain(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 if isinstance(x,dict):return {k:plain(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [plain(v) for v in x]
 return x
def scalar(x):return float(np.asarray(x).squeeze())
sys.path.insert(0,str(GUARD));from no_solve_guard import NoSolveCAD
class PairCAD(NoSolveCAD):
 def __getattr__(self,name):
  if name.lower() in {'engine','fdtd_engine','launch','execute','addjobs','submit','submitjob'}:raise RuntimeError('No engine/job invocation allowed: '+name)
  return super().__getattr__(name)
 def load(self,path):
  need(Path(path).resolve().is_relative_to(self._root) and Path(path).is_file(),'Only owned new FSP may be reloaded')
  return super().load(path)
def differences(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  result={}
  for key in set(a)|set(b):
   q=path+'/'+key
   if key not in a or key not in b:result[q]={'left':a.get(key),'right':b.get(key)}
   else:result.update(differences(a[key],b[key],q))
  return result
 if a==b:return {}
 return {path:{'left':a,'right':b}}
def geometry_comparison(a,b):
 need(set(a)==set(b),'Semantic geometry keys differ');raw={};blocked={}
 for key in a:
  x,y=scalar(a[key]),scalar(b[key]);delta=y-x
  if delta:
   row=dict(left_m=x,right_m=y,delta_m=delta)
   okay=np.isfinite([x,y]).all() and abs(delta)<=1e-20 and abs(delta)<=64*np.finfo(float).eps*max(abs(x),abs(y))
   row['within_existing_serialization_allowance']=bool(okay);raw[key]=row
   if not okay:blocked[key]=row
 return dict(nonbitwise=raw,blockers=blocked,max_abs_delta_m=max([abs(v['delta_m']) for v in raw.values()]+[0.]),qualification='Existing reviewed geometry serialization bound only:absdelta<=1e-20m and64eps*scale;no physical tolerance')
def property_read(f,obj,keys):return {k:plain(f.getnamed(obj,k)) for k in keys}
FDTD_KEYS=['dimension','x','y','z','x span','y span','z span','mesh type','mesh accuracy','define x mesh by','define y mesh by','define z mesh by','dx','dy','dz','allow grading in x','allow grading in y','allow grading in z','grading factor','dt stability factor','force symmetric y mesh','force symmetric z mesh','background material','background index','x min bc','x max bc','y min bc','y max bc','z min bc','z max bc','pml layers','pml profile','mesh refinement','meshing refinement']
TIME_KEYS=['simulation time','use early shutoff','auto shutoff min','use divergence checking','auto shutoff max','down sample time','max source time signal length','dt']
SOURCE_KEYS=['pulselength','offset','frequency','bandwidth','source type','set time domain','set frequency','wavelength start','wavelength stop','optimize for short pulse']
PORT_KEYS=['x','y','z','x span','y span','z span','phase','injection axis','direction','enabled','mode selection','frequency dependent profile']
PROFILE_KEYS=['enabled','monitor type','x','y','z','x span','y span','z span','override global monitor settings','use source limits','frequency points','spatial interpolation','use wavelength spacing','down sample x','down sample y']
GEO_KEYS=['x','x span','y','y span','z','z span','material','index']
def optional_read(f,obj,keys):
 result={}
 for k in keys:
  try:result[k]={'available':True,'value':plain(f.getnamed(obj,k))}
  except Exception as e:result[k]={'available':False,'error':type(e).__name__+': '+str(e)}
 return result
def all_teeth(f,eng,n):
 # Names must be actual current objects,then canonical semantic names remove suffixes.
 names,cavity=eng.tooth_names(n,n);out={}
 for d,quad in names.items():
  for arm,kind,name in zip(['L','L','R','R'],['narrow','wide','narrow','wide'],quad):out[arm+'_'+kind+'_'+str(d)]=property_read(f,name,GEO_KEYS)
 out['cavity']=property_read(f,cavity,GEO_KEYS)
 for name in ['wg_left_inf_1','wg_right_inf_'+str(4*n+3)]:out[name.split('_inf_')[0]+'_feed']=property_read(f,name,GEO_KEYS)
 return out
def flatten_numeric_geometry(properties):
 numeric={};text={}
 for name,props in properties.items():
  for key,value in props.items():
   if isinstance(value,str):text[name+'::'+key]=value
   else:numeric[name+'::'+key]=scalar(value)
 return numeric,text
def restore_retained_outer_and_feed_joins(f,eng,baseline):
 """Hold retained N80 outer x at measured freshN98 values;not a tolerance waiver."""
 names,cavity=eng.tooth_names(80,80);changes={}
 for d in range(61,81):
  for arm,kind,name in zip(['L','L','R','R'],['narrow','wide','narrow','wide'],names[d]):
   semantic=arm+'_'+kind+'_'+str(d);anchor=baseline[semantic]
   before=property_read(f,name,GEO_KEYS)
   before_numeric,before_text=flatten_numeric_geometry({semantic:{k:v for k,v in before.items() if k!='x'}});anchor_numeric,anchor_text=flatten_numeric_geometry({semantic:{k:v for k,v in anchor.items() if k!='x'}})
   non_x_roundoff=geometry_comparison(before_numeric,anchor_numeric)
   need(not non_x_roundoff['blockers'] and before_text==anchor_text,'Unexpected retained outer non-x property differs beyond existing serialization allowance:'+semantic)
   f.setnamed(name,'x',anchor['x']);changes[semantic]=dict(native_x_m=before['x'],held_N98_x_m=anchor['x'],readback_x_m=plain(f.getnamed(name,'x')),non_x_pre_set_vs_serialized_anchor=non_x_roundoff)
 # Actual restored outer-edge readbacks define joins;no cell-alignment assertion.
 left_outer=names[80][0];right_outer=names[80][3]
 left_edge=scalar(f.getnamed(left_outer,'x min'));right_edge=scalar(f.getnamed(right_outer,'x max'))
 left_feed='wg_left_inf_1';right_feed='wg_right_inf_323'
 feed_before={o:property_read(f,o,['x min','x max','x','x span']) for o in [left_feed,right_feed]}
 f.setnamed(left_feed,'x max',left_edge);f.setnamed(right_feed,'x min',right_edge)
 feed_after={o:property_read(f,o,['x min','x max','x','x span']) for o in [left_feed,right_feed]}
 need(feed_after[left_feed]['x min']==feed_before[left_feed]['x min'] and feed_after[right_feed]['x max']==feed_before[right_feed]['x max'],'Feed outer domain endpoint changed')
 return dict(explicit_preserved_outer_x=changes,actual_outer_edge_m=dict(left=left_edge,right=right_edge),feed_before=feed_before,feed_after=feed_after,join_delta_m=dict(left=scalar(feed_after[left_feed]['x max'])-left_edge,right=scalar(feed_after[right_feed]['x min'])-right_edge),qualification='Explicit baseline-derived geometry restoration;rawendpointdeltas retained,no new tolerance or physical width claim')
def snapshot(f,eng,spec,p):
 mapped=eng.make_func(spec)(p)
 geo={k:plain(f.getnamed(*k.rsplit('::',1))) for k in mapped}
 return dict(inner_geometry=geo,all_teeth_and_feeds=all_teeth(f,eng,spec.n_periods_side),mesh={a:plain(f.getresult('FDTD',a)) for a in ['x','y','z']},user_mesh={a:plain(f.getnamed('FDTD','user specified mesh '+a)) for a in ['x','y','z']},FDTD=optional_read(f,'FDTD',FDTD_KEYS),timing=property_read(f,'FDTD',TIME_KEYS),source={k:plain(f.getglobalsource(k)) for k in SOURCE_KEYS},ports={o:property_read(f,o,PORT_KEYS) for o in ['FDTD::ports::Port_1','FDTD::ports::Port_2']},ports_monitor=property_read(f,'FDTD::ports',['monitor frequency points','source port','source mode']),field_profile=property_read(f,'field_profile',PROFILE_KEYS),time_monitors={o:property_read(f,o,['x','y','z','enabled','monitor type']) for o in ['time_input','time_cavity','time_output']},optimization={o:property_read(f,o,['enabled','x','y','z','x span','y span','z span','spatial interpolation']) for o in ['optimization_dft','optimization_index']},optimization_mesh=property_read(f,'optimization_mesh',['x','y','z','x span','y span','z span','dx','dy','dz']),mesh_override=property_read(f,'mesh_override',['x','y','z','x span','y span','z span','dx','dy','dz']),global_monitor={k:plain(f.getglobalmonitor(k)) for k in ['frequency points','use wavelength spacing','use source limits']})
def configure(sim,f,eng,spec,p,cp,profile,portability):
 cfg=eng.build_base_cfg(spec)
 sim.build();sim.update_scan(center_lambda_m=cfg.spectral.center_wavelength_m,width_nm=cfg.spectral.scan_width_nm,n_points=cfg.spectral.n_wl_points)
 eng.apply_monitor_overrides(sim,cfg)
 for key,value in eng.make_func(spec)(p).items():
  obj,prop=key.rsplit('::',1);need(f.getnamednumber(obj)==1,'Missing mapped object:'+obj);f.setnamed(obj,prop,value)
 # Pure supported vendor CAD helpers are called without their constructor/runner.
 from lumopt2.core.fdtd_session import FdtdSession
 from lumopt2.utils.common import Box
 box=Box(x_span=2*(spec.pitch_nm/4+spec.n_free*spec.pitch_nm+1000)*1e-9,y_span=2*spec.region_y_half_nm*1e-9,z_span=.8e-6,dx=spec.region_dx_nm*1e-9,dy=50e-9,dz=50e-9)
 from types import SimpleNamespace
 session=SimpleNamespace(fdtd=f)
 FdtdSession.set_mesh_refinement_region(session,box,box.dx,box.dy,box.dz);FdtdSession.add_field_monitors(session,box);FdtdSession.add_index_monitors(session,box)
 f.setnamed('FDTD','mesh refinement',cp['refinement']['mesh refinement'])
 # Vendor project.py relock path,with ACTUAL pinned mesh relative to solver centers.
 for axis,values in cp['mesh'].items():f.setnamed('FDTD','user specified mesh '+axis,np.asarray(values)-scalar(f.getnamed('FDTD',axis)))
 f.setnamed('FDTD','mesh type','user specified')
 # Restore the recorded vendor one-cell forward-source offset and phase. No mode/adjoint solver invoked.
 for obj,properties in cp['ports'].items():
  for prop in ['x','phase']:f.setnamed(obj,prop,properties[prop])
 # Measurement coverage is held at actual saved N98 settings;physical N80 production crop is separate.
 for key,item in profile['monitor_geometry'].items():
  if item['available'] and key in ['x','y','z','x span','y span','z span','override global monitor settings','use source limits','frequency points','spatial interpolation']:
   if plain(f.getnamed('field_profile',key))!=item['value']:f.setnamed('field_profile',key,item['value'])
 for obj,x in [('time_input',-(98*spec.pitch_nm*1e-9+spec.pitch_nm*1e-9/4)-.5e-6),('time_output',98*spec.pitch_nm*1e-9+spec.pitch_nm*1e-9/4+.5e-6)]:f.setnamed(obj,'x',x)
 f.setnamed('FDTD','simulation time',150e-12);f.setnamed('FDTD','use early shutoff',0);f.setnamed('optimization_dft','enabled',0)
 portability.append('Exact saved vendor port/source coordinates and phase restored;Windows vendor bytes differ from Athena and nativeIGUM requalification remains required')
def compare_saved(current,cp,profile,blue):
 result={}
 for key in ['mesh','timing','source']:
  result[key]=differences(cp[key],current[key])
 result['ports']=differences(cp['ports'],{o:{k:v for k,v in properties.items() if k in cp['ports'][o]} for o,properties in current['ports'].items()})
 result['ports_monitor']=differences(cp['monitor'],current['ports_monitor'])
 result['refinement']=differences(cp['refinement'],{k:current['FDTD'][k]['value'] for k in cp['refinement']})
 result['profile_inventory']=differences({k:item['value'] for k,item in profile['monitor_geometry'].items() if item['available']},{k:current['field_profile'][k] for k,item in profile['monitor_geometry'].items() if item['available']})
 result['PML_inventory']=differences({k:item['value'] for k,item in profile['FDTD_boundary_property_inventory'].items() if item['available']},{k:current['FDTD'][k].get('value') for k,item in profile['FDTD_boundary_property_inventory'].items() if item['available']})
 return result
def self_test():
 class Fake:
  def __getattr__(self,name):return lambda *a,**kw:(_ for _ in ()).throw(AssertionError('Unsafe fake underlyingcall:'+name))
 guard=PairCAD(Fake(),Path(__file__).parent)
 for method in ['run','runjobs','runanalysis','runparallel','runsystemcheck','runsweep','engine','execute','launch','addjob','addjobs','savejob','submitjob','system','feval']:
  try:getattr(guard,method)()
  except RuntimeError:pass
  else:raise AssertionError('Failed solve/jobguard:'+method)
 for script in ['run;','runsystemcheck;','runjobs("FDTD");','system("fdtd-engine");','feval("bad");','save("old.fsp");']:
  try:guard.eval(script)
  except RuntimeError:pass
  else:raise AssertionError('Failed scriptguard')
 try:guard.save(ROOT/'ORIGINAL.fsp')
 except RuntimeError:pass
 else:raise AssertionError('Save guard bypass')
 try:guard.load(CP)
 except RuntimeError:pass
 else:raise AssertionError('Loadguard bypass')
 a={'L_narrow_1::x':1e-6};okay={'L_narrow_1::x':np.nextafter(1e-6,np.inf)};need(not geometry_comparison(a,okay)['blockers'],'Existing serialization allowance refused')
 need(bool(geometry_comparison(a,{'L_narrow_1::x':1.1e-6})['blockers']),'Material geometry mismatch accepted')
 print('PASS21 solve/script/save/load guards and existing geometry allowance/refusal;no CAD')
def main():
 from datetime import datetime,timezone
 out=Path(__file__).parent/'attempt06';need(not out.exists(),'NEW attempt directory required');out.mkdir();report=dict(timestamp_UTC=datetime.now(timezone.utc).isoformat(),scope='HIDDEN_LOCAL_CAD_ONLY_NEW_NATIVE_PAIR_NO_SOLVE',no_solver_entrypoint=True,no_global_class_or_factory_patch=True,cases={},portability_notes=[])
 original={str(p):sha(p) for p in [CP,PROFILES]};need(original[str(CP)]==CP_SHA and original[str(PROFILES)]==PROFILE_SHA,'Actual CP/profile report bytes changed')
 sys.path.insert(0,str(BLUEPRINT));import blueprint
 row,eng=blueprint.load(CP,ROOT);point=np.asarray(row['identity']['point']);blue=blueprint.build(row,eng)
 source_pins={name:digest for name,digest in row['identity']['code'].items()}
 profile=json.loads(PROFILES.read_text())['stages']['150'];cp=row['result']['controls']['persisted']
 sys.path.insert(0,str(API));import lumapi
 from bragg_device import PiShiftBraggFDTD
 klass=lumapi.FDTD;ctor=klass.__init__;need(PiShiftBraggFDTD.__module__=='bragg_device','Unexpected builder')
 report.update(checkpoint_sha256=CP_SHA,profile_report_sha256=PROFILE_SHA,blueprint=blue,full_point_nm=point.tolist(),point_sha256=hashlib.sha256(point.astype('<f8').tobytes()).hexdigest(),original_source_pins=source_pins,local_vendor_sha256={str(p.relative_to(API)).replace('\\','/'):sha(p) for p in sorted((API/'lumopt2').rglob('*.py'))+[API/'lumapi.py']},Athena_vendor_sha256=row['identity']['vendor_api_sha256'])
 try:
  for n in [98,80]:
   spec=eng.CampaignSpec(**row['identity']['spec']) if n==98 else blueprint.candidate_spec(eng.CampaignSpec(**row['identity']['spec']))
   cfg=eng.build_base_cfg(spec)
   if n==80:cfg.mesh.n_periods_dist_to_port=38
   # Fresh hidden construction;material setup only in constructor,then guard beforebuild.
   sim=PiShiftBraggFDTD(**cfg.to_device_kwargs());f=PairCAD(sim.fdtd,out);sim.fdtd=f
   try:
    configure(sim,f,eng,spec,point,cp,profile,report['portability_notes'])
    # Stabilize native min/max rectangle representation through the saved format.
    # Raw construction conversion deltas are retained and NOT approved by a new tolerance.
    native_before=all_teeth(f,eng,n);native_fsp=out/f'N{n}_native_pre_correction_build_only.fsp';f.save(native_fsp);f.load(native_fsp);native_after=all_teeth(f,eng,n)
    native_bn,native_bt=flatten_numeric_geometry(native_before);native_an,native_at=flatten_numeric_geometry(native_after)
    native_conversion=dict(preparatory_fsp=str(native_fsp),sha256=sha(native_fsp),before=native_before,reloaded=native_after,raw_numeric_deltas=geometry_comparison(native_bn,native_an),text_differences=differences(native_bt,native_at),qualification='Native construction->saved-format conversion only;rawdeltas including bound exceedances retained,not a physics approval or tolerance waiver. Final baseline and corrected scenes use these measured saved-format inputs and unchanged final serialization guards.')
    outer_restoration=None
    if n==80:outer_restoration=restore_retained_outer_and_feed_joins(f,eng,report['cases']['98']['reloaded']['all_teeth_and_feeds'])
    before=snapshot(f,eng,spec,point);fsp=out/f'N{n}_fixed_domain_hidden_build_only.fsp';f.save(fsp);f.load(fsp);after=snapshot(f,eng,spec,point)
    inner=geometry_comparison(before['inner_geometry'],after['inner_geometry']);left={k:v for k,v in before.items() if k not in ['inner_geometry','all_teeth_and_feeds']};right={k:v for k,v in after.items() if k not in ['inner_geometry','all_teeth_and_feeds']};other=differences(left,right)
    case=dict(physical_N=n,native_port_distance_periods=cfg.mesh.n_periods_dist_to_port,saved_fsp=str(fsp),saved_fsp_sha256=sha(fsp),before=before,reloaded=after,inner_serialization=inner,other_reload_differences=other,original_saved_control_differences=compare_saved(after,cp,profile,blue),guard_audit=f.audit,version=plain(f.version()))
    case['native_saved_format_construction']=native_conversion
    before_num,before_text=flatten_numeric_geometry(before['all_teeth_and_feeds']);after_num,after_text=flatten_numeric_geometry(after['all_teeth_and_feeds']);case['all_geometry_reload_comparison']=geometry_comparison(before_num,after_num);case['all_geometry_reload_text_differences']=differences(before_text,after_text)
    if outer_restoration is not None:
     left_name=eng.tooth_names(80,80)[0][80][0];right_name=eng.tooth_names(80,80)[0][80][3]
     outer_restoration['reloaded_endpoint_delta_m']=dict(left=scalar(f.getnamed('wg_left_inf_1','x max'))-scalar(f.getnamed(left_name,'x min')),right=scalar(f.getnamed('wg_right_inf_323','x min'))-scalar(f.getnamed(right_name,'x max')))
     case['outer_geometry_restoration']=outer_restoration
    report['cases'][str(n)]=case
   finally:sim.close()
  a,b=[report['cases'][str(n)]['reloaded'] for n in [98,80]]
  report['cross_pair_inner723']=geometry_comparison(blueprint.canonical(a['inner_geometry']),blueprint.canonical(b['inner_geometry']))
  report['fresh_N98_vs_original_inner723']=geometry_comparison(blueprint.canonical(cp['geometry']),blueprint.canonical(a['inner_geometry']))
  aa={k:v for k,v in a.items() if k not in ['inner_geometry','all_teeth_and_feeds']};bb={k:v for k,v in b.items() if k not in ['inner_geometry','all_teeth_and_feeds']};report['cross_pair_control_differences']=differences(aa,bb)
  common=set(a['all_teeth_and_feeds'])&set(b['all_teeth_and_feeds']);retained={k:differences(a['all_teeth_and_feeds'][k],b['all_teeth_and_feeds'][k]) for k in common if 'feed' not in k};report['retained_all_tooth_raw_differences']={k:v for k,v in retained.items() if v}
  a_num,a_text=flatten_numeric_geometry({k:a['all_teeth_and_feeds'][k] for k in common if 'feed' not in k});b_num,b_text=flatten_numeric_geometry({k:b['all_teeth_and_feeds'][k] for k in common if 'feed' not in k});report['retained_all_geometry_comparison']=geometry_comparison(a_num,b_num);report['retained_all_geometry_text_differences']=differences(a_text,b_text)
  report['intentional_removed_N98_objects']=sorted(set(a['all_teeth_and_feeds'])-set(b['all_teeth_and_feeds']))
  report['feed_changes']={k:dict(N98=a['all_teeth_and_feeds'][k],N80=b['all_teeth_and_feeds'][k]) for k in common if 'feed' in k}
  blocks=report['cross_pair_control_differences'] or report['cross_pair_inner723']['blockers'] or report['fresh_N98_vs_original_inner723']['blockers'] or report['retained_all_geometry_comparison']['blockers'] or report['retained_all_geometry_text_differences']
  for case in report['cases'].values():blocks=blocks or case['inner_serialization']['blockers'] or case['all_geometry_reload_comparison']['blockers'] or case['all_geometry_reload_text_differences'] or case['other_reload_differences'] or any(case['original_saved_control_differences'].values())
  report['status']='CAD_PAIR_CONTROLS_PASS_NO_PHYSICS_PASS' if not blocks else 'CAD_PAIR_DIFFERENCES_REQUIRE_REVIEW_NO_PHYSICS_PASS'
 except Exception as e:report['status']='CAD_BUILD_FAILED_CLOSED';report['error']=type(e).__name__+': '+str(e);report['traceback']=traceback.format_exc()
 finally:
  report['original_inputs_preserved']=all(sha(p)==digest for p,digest in original.items());report['FDTD_class_unchanged']=lumapi.FDTD is klass;report['FDTD_constructor_unchanged']=klass.__init__ is ctor
  report['production_sources_preserved']=all(sha(ROOT/(name if name in ['config.py','bragg_device.py','sim_helpers.py','simulation_config.py'] else 'runners/lumopt2_design/'+name))==digest for name,digest in source_pins.items())
  with (out/'cad_pair_report.json').open('x',encoding='utf-8') as f:json.dump(plain(report),f,indent=2,allow_nan=False)
 print(report['status'],report.get('error',''));return 0 if report['status']=='CAD_PAIR_CONTROLS_PASS_NO_PHYSICS_PASS' else 1
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);g=parser.add_mutually_exclusive_group(required=True);g.add_argument('--self-test',action='store_true');g.add_argument('--cad-only',action='store_true');args=parser.parse_args()
 if args.self_test:self_test()
 else:raise SystemExit(main())
