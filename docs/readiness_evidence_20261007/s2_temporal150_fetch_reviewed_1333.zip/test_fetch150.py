"""Offline only: no SSH, container, CAD, solve or repository mutation."""
import ast,base64,copy,json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
import fetch_temporal150 as f
ENV=json.loads(Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007/s2_temporal_env_1257.json').read_text())
MARKER='/work/data/SYNTHETIC_later_review.json';SHA='e'*64;JOB='54321'

class FetchTests(unittest.TestCase):
    def setUp(self):
        self.root=Path(tempfile.mkdtemp(prefix='fixture_SYNTHETIC_',dir=Path(__file__).parent));self.env=f.validate_inputs(JOB,MARKER,SHA,ENV)
        self.payload=dict(job_id=JOB,review_marker_sha256=SHA,at='SYNTHETIC_NO_SERVER',accounting='\n'.join(f'{JOB}_{i}|COMPLETED|0:0|' for i in (3,4,5)),verified_records=[],files={})
        root=self.env['S2_TIME_OUTPUT_ROOT']
        for i in (3,4,5):
            cp=root+f'/task_{i:02d}.json';attempt=root+f'/task_{i:02d}_SYNTHETIC';source=attempt+'/files/fwd_default.fsp';ports=attempt+'/ports.npz';rawports=b'SYNTHETIC_PORT_BYTES_NOT_NPZ'
            review=dict(path=MARKER,sha256=SHA,duration_ps=150.,allowed_tasks=[3,4,5])
            termination=dict(log=source[:-4]+'_p0.log',log_sha256='c'*64,status=1)
            ident=dict(task=i,duration_ps=150.,spec={'label':f.FAMILY},code={'s2_temporal_forward.py':f.RUNNER_SHA},parent_review=review)
            result=dict(task=i,duration_ps=150.,ports_sha256=f.digest(rawports),ports_npz=ports,parent_review=review,source=source,termination=termination,fsp_sha256='a'*64,h5_sha256='b'*64)
            rawcp=json.dumps(dict(identity=ident,result=result)).encode()
            self.payload['verified_records'].append(dict(task=i,checkpoint=cp,source=source,ports=ports,termination=termination,parent_review=review,fsp_sha256='a'*64,h5_sha256='b'*64))
            for role,path,raw in [('checkpoint',cp,rawcp),('ports',ports,rawports)]:
                self.payload['files'][f'{i}:{role}']=dict(path=path,sha256=f.digest(raw),bytes=len(raw),data=base64.b64encode(raw).decode())
    def validate(self,p=None):return f.validate_payload(p or self.payload,JOB,MARKER,SHA,self.env)
    def test_required_job_marker_and_environment_controls(self):
        with patch.object(f.subprocess,'run',side_effect=AssertionError('Network touched')):
            for job in ('','0','54321;sbatch','54321_3','-1'):
                with self.assertRaises(RuntimeError):f.scripts(job,MARKER,SHA,ENV)
            for marker in ('relative.json','/work/data/../results/x.json',ENV['S2_TIME_FIRST_MARKER']):
                with self.assertRaises(RuntimeError):f.scripts(JOB,marker,SHA,ENV)
            with self.assertRaises(RuntimeError):f.scripts(JOB,MARKER,'NOT_SHA',ENV)
            env=dict(ENV);env['KEEP_H5']='0'
            with self.assertRaises(RuntimeError):f.scripts(JOB,MARKER,SHA,env)
    def test_cli_existing_output_refuses_before_any_ssh(self):
        env=self.root/'environment.json';env.write_text(json.dumps(ENV))
        args=['fetch_temporal150.py','--job-id',JOB,'--review-marker',MARKER,'--review-marker-sha256',SHA,
            '--environment-json',str(env),'--output-dir',str(self.root)]
        with patch.object(sys,'argv',args),patch.object(f.subprocess,'run',side_effect=AssertionError('SSH touched')):
            with self.assertRaisesRegex(RuntimeError,'before SSH'):f.cli()
    def test_exact_tasks_completed_zero_only(self):
        self.assertEqual(len(f.completed_rows(self.payload['accounting'],JOB)),3)
        for state in ('RUNNING','PENDING','FAILED','COMPLETED+','CANCELLED'):
            with self.assertRaises(RuntimeError):f.completed_rows(self.payload['accounting'].replace('COMPLETED',state,1),JOB)
        with self.assertRaises(RuntimeError):f.completed_rows(self.payload['accounting'].replace('0:0','1:0',1),JOB)
        with self.assertRaises(RuntimeError):f.completed_rows(self.payload['accounting'].replace(JOB+'_5',JOB+'_2'),JOB)
    def test_generated_scripts_ast_cold_only_and_job_is_not_hardcoded(self):
        inner,remote=f.scripts(JOB,MARKER,SHA,ENV);trees=[ast.parse(inner),ast.parse(remote)]
        calls=[n for tree in trees for n in ast.walk(tree) if isinstance(n,ast.Call)]
        attrs=[n.func.attr for n in calls if isinstance(n.func,ast.Attribute)]
        self.assertIn('verify_result',attrs);self.assertIn('read_checkpoint',attrs);self.assertIn('reviewed',attrs)
        self.assertNotIn('main',attrs);self.assertNotIn('run_forward',attrs);self.assertNotIn('import_lumopt2',attrs);self.assertNotIn('make_project',attrs)
        self.assertIn("m.main=forbid",inner);self.assertIn("m.forward_only=forbid",inner)
        for forbidden in ('sbatch','scancel','srun','runjobs','unlink','rmtree','write_bytes','mkdir'):
            self.assertNotIn(forbidden,inner+remote)
        self.assertIn("JOB_ID='54321'",remote);self.assertNotIn('171216',remote)
    def test_validated_payload_published_exclusively_and_pin_format(self):
        decoded=self.validate();out=self.root/'NEW_fetch'
        result=f.publish(self.payload,decoded,out);self.assertEqual(result['verified_tasks'],[3,4,5])
        pins=json.loads((out/'s2_temporal150_artifact_pins_original.json').read_text())
        self.assertEqual(set(pins),{f'{t}:{r}' for t in (3,4,5) for r in ('checkpoint','ports')})
        for key,p in pins.items():self.assertEqual(Path(p['local']).read_bytes(),decoded[key])
        firstbytes={p.name:p.read_bytes() for p in out.iterdir()}
        with self.assertRaises(RuntimeError):f.publish(self.payload,decoded,out)
        self.assertEqual({p.name:p.read_bytes() for p in out.iterdir()},firstbytes)
    def test_payload_job_marker_bytes_paths_missing_and_checkpoint_family_tamper(self):
        for key,value in [('job_id','54322'),('review_marker_sha256','f'*64)]:
            p=copy.deepcopy(self.payload);p[key]=value
            with self.assertRaises(RuntimeError):self.validate(p)
        p=copy.deepcopy(self.payload);p['files'].pop('5:ports')
        with self.assertRaises(RuntimeError):self.validate(p)
        p=copy.deepcopy(self.payload);p['files']['3:ports']['bytes']+=1
        with self.assertRaises(RuntimeError):self.validate(p)
        p=copy.deepcopy(self.payload);p['files']['4:ports']['path']='/work/results/other/ports.npz'
        with self.assertRaises(RuntimeError):self.validate(p)
        p=copy.deepcopy(self.payload);row=json.loads(base64.b64decode(p['files']['5:checkpoint']['data']));row['identity']['duration_ps']=100.
        raw=json.dumps(row).encode();p['files']['5:checkpoint'].update(data=base64.b64encode(raw).decode(),sha256=f.digest(raw),bytes=len(raw))
        with self.assertRaisesRegex(RuntimeError,'checkpoint family'):self.validate(p)
        self.assertFalse((self.root/'NEW_fetch').exists())

if __name__=='__main__':unittest.main(verbosity=2)
