import subprocess,json,hashlib,base64,sys,datetime
from pathlib import Path
REPO=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
E=REPO/'docs/readiness_evidence_20261007'
BASE='/home/evyatarrubin/bragg_sim_athena'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','StrictHostKeyChecking=yes']
def remote(host,code):
 args=SSH+(['-o','HostName=132.68.1.206','-o','HostKeyAlias=athena.technion.ac.il'] if host=='athena.technion.ac.il' else [])+['evyatarrubin@'+host,'python3 -']
 p=subprocess.run(args,input=code.encode(),capture_output=True,timeout=240)
 return dict(rc=p.returncode,out=p.stdout.decode(errors='replace'),err=p.stderr.decode(errors='replace'))
def save(name,obj):
 with (E/name).open('x',encoding='utf-8') as f:json.dump(obj,f,indent=2)
 print(name, 'saved', len(json.dumps(obj)), 'bytes')
COMMON="""import subprocess,json,datetime,hashlib,os
from pathlib import Path
def run(a):
 p=subprocess.run(a,capture_output=True,text=True,timeout=90);return dict(rc=p.returncode,out=p.stdout,err=p.stderr)
"""
if sys.argv[1]=='preflight':
 a=remote('athena.technion.ac.il',COMMON+f"""
b=Path({BASE!r})
print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),queue=run(['squeue','-u','evyatarrubin']),accounting=run(['sacct','-j','171236','--format=JobID,State,ExitCode,Elapsed,NodeList','--parsable2']),quota=run(['quota','-s']),qos=run(['sacctmgr','show','qos','12h_4g','format=Name,MaxWall,MaxTRESPU,MaxJobsPU,MaxSubmitPU','-P']),source={{str(p.relative_to(b)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [b/'project/runners/lumopt2_design/s2_temporal_forward.py',b/'jobs/run_python_array.sh']}},new_runner_exists=(b/'project/runners/lumopt2_design/s2_temporal_step150.py').exists(),new_output_exists=(b/'results/diagnose_te_s2_step150').exists())))
""")
 i=remote('132.68.58.101',COMMON+"""
print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),queue=run(['squeue','-u','evyatarrubin']),seats=run(['/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261/licensingclient/linx64/lmutil','lmstat','-c','1055@132.68.48.51','-f','lum_fdtd_solve']))))
""")
 save('s2_step150_preflight_1503.json',dict(athena=a,igum=i))
if sys.argv[1] in ('prepare','prepare2'):
 p=REPO/'runners/lumopt2_design/s2_temporal_step150.py';data=p.read_bytes();assert hashlib.sha256(data).hexdigest()=='c41f522e8502598c4b8a3d4a4096baf094ede8a1c66763169992fbc82d696c8a'
 env=json.loads((E/'s2_temporal_env_1257.json').read_text());env.update(S2_STEP150_REPO='/work/project',S2_STEP150_PARENT_ROOT='/work/results/diagnose_te_s2_temporal/results/s2_shift30_temporal_20261007',S2_STEP150_PARENT_MARKER='/work/data/s2_temporal150_review_20261007_1257.json',S2_STEP150_OUTPUT_ROOT='/work/results/diagnose_te_s2_step150/results/s2_shift30_step150_20261007')
 inner="""import json
import config
config.LUMAPI_PATH='/opt/lumerical/v261/api/python/lumapi.py';config.BASE_SAVE_DIR='/work/results'
config.NEFF_DATA_PATH='/work/data/FDE_sweep_results.mat';config.USE_GPU=True
from runners.lumopt2_design import s2_temporal_step150 as r
def blocked(*a,**k):raise RuntimeError('NO_SOLVE_PREPARATION')
r.main=r.forward_only=r.eng.make_project=r.eng.import_lumopt2=blocked
c=r.load_ancestry();print(json.dumps(r.review_template(r.root_path(),c)))
"""
 code=COMMON+f"""
import base64
b=Path({BASE!r});p=b/'project/runners/lumopt2_design/s2_temporal_step150.py';data=base64.b64decode({base64.b64encode(data).decode()!r})
if {sys.argv[1]=='prepare'!r}:
 assert not p.exists(),'New-only upload requires absent path'
 with p.open('xb') as f:f.write(data)
assert hashlib.sha256(p.read_bytes()).hexdigest()=='c41f522e8502598c4b8a3d4a4096baf094ede8a1c66763169992fbc82d696c8a'
args=['apptainer','exec','--bind',str(b/'project')+':/work/project','--bind',str(b/'results')+':/work/results','--bind',str(b/'data')+':/work/data','--bind','/home/evyatarrubin/scilibs:/scilibs','--pwd','/work/project','/home/evyatarrubin/containers/lumerical-2026R1.sif','env','LD_LIBRARY_PATH=/scilibs']+[{(str('unused'))!r}][0:0]+[k+'='+v for k,v in {env!r}.items()]+['/opt/lumerical/v261/python/bin/python','-B','-c',{inner!r}]
print(json.dumps(dict(upload_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),validation=run(args))))
"""
 result=remote('athena.technion.ac.il',code);save('s2_step150_remote_'+sys.argv[1]+'_1505.json',result)
 assert result['rc']==0;payload=json.loads(result['out']);assert payload['validation']['rc']==0,payload
 template=json.loads(payload['validation']['out']);save('s2_step150_review_template_1504.json',template);save('s2_step150_env_preparation_1504.json',env)
if sys.argv[1]=='release':
 m=json.loads((E/'s2_step150_review_template_1504.json').read_text());assert m['status']=='NOT_REVIEWED' and m['allowed_tasks']==[]
 m.update(status='APPROVED_FOR_TWO_FIXED150PS_SHIFT30_STEP0125_FORWARDS_ONLY',allowed_tasks=[0,1],lead_verdict='Lead reviewed exact150ps triplet, full spectra and temporal sensitivities; seven offline groups, actual driver tasklist0/1, both hidden CAD mappings/persistence, independent source review and strict remote parent artifact/vendor checks passed. Release ONLY two150ps shift30 +/-0.125nm forwards to compare finite-step dependence with existing +/-0.0625nm and reuse exact150center. Existing global calibration FAILED; no optimizer, no coefficients, no200ps or adjoint release. Cross-run Port_1 phase allowance limited to measured2ULP with raw values retained; no physics tolerance. Shared15:03 usage7/50, plus14new=21/50; quota228G/300G; Athena empty and IGUM101155 running.')
 raw=(json.dumps(m,indent=2,allow_nan=False)+'\n').encode();digest=hashlib.sha256(raw).hexdigest();marker='/work/data/s2_step150_review_20261007_1507.json';manifest='/work/data/s2_step150_tasks_20261007_1507.txt'
 with (E/'s2_step150_review_1507.json').open('xb') as f:f.write(raw)
 env=json.loads((E/'s2_step150_env_preparation_1504.json').read_text());env.update(S2_STEP150_REVIEW_MARKER=marker,S2_STEP150_REVIEW_SHA256=digest)
 inner="""import json,config
config.LUMAPI_PATH='/opt/lumerical/v261/api/python/lumapi.py';config.BASE_SAVE_DIR='/work/results'
config.NEFF_DATA_PATH='/work/data/FDE_sweep_results.mat';config.USE_GPU=True
from runners.lumopt2_design import s2_temporal_step150 as r
def blocked(*a,**k):raise RuntimeError('NO_SOLVE_RELEASE_CHECK')
r.main=r.forward_only=r.eng.make_project=r.eng.import_lumopt2=blocked
c=r.load_ancestry();print(json.dumps([r.reviewed(t,r.root_path(),c)['sha256'] for t in [0,1]]))
"""
 code=COMMON+f"""
import base64
b=Path({BASE!r});assert hashlib.sha256((b/'project/runners/lumopt2_design/s2_temporal_step150.py').read_bytes()).hexdigest()=='c41f522e8502598c4b8a3d4a4096baf094ede8a1c66763169992fbc82d696c8a'
assert hashlib.sha256((b/'jobs/run_python_array.sh').read_bytes()).hexdigest()=='ebf1780e1d23f6a5a885577ba6b562111482935b69be63f27389d5ae87bcdcf1'
q=run(['squeue','-u','evyatarrubin','--noheader']);assert q['rc']==0 and not q['out'].strip(),q
for path,data in [({marker!r},base64.b64decode({base64.b64encode(raw).decode()!r})),({manifest!r},b'0\\n1\\n')]:
 p=b/Path(path).relative_to('/work');assert not p.exists()
 with p.open('xb') as f:f.write(data)
env={env!r}
args=['apptainer','exec','--bind',str(b/'project')+':/work/project','--bind',str(b/'results')+':/work/results','--bind',str(b/'data')+':/work/data','--bind','/home/evyatarrubin/scilibs:/scilibs','--pwd','/work/project','/home/evyatarrubin/containers/lumerical-2026R1.sif','env','LD_LIBRARY_PATH=/scilibs']+[k+'='+v for k,v in env.items()]+['/opt/lumerical/v261/python/bin/python','-B','-c',{inner!r}]
v=run(args);assert v['rc']==0,v;assert json.loads(v['out'])==[{digest!r},{digest!r}]
env.update(SWEEP_KIND='lumopt2_design',SWEEP_LIST={manifest!r},SWEEP_SPEC_MODULE='runners.lumopt2_design.s2_temporal_step150',ATHENA_LICENSE='1055@132.68.48.51',ATHENA_INTERCONNECT='2325@132.68.48.51',REQUIRE_GPU='1',NTFY_TOPIC='')
a=['sbatch','--parsable','--array=0-1%2','--gpus=1','--cpus-per-task=8','--mem=256G','--time=02:00:00','--qos=12h_4g','--partition=a100-public','--mail-type=NONE','--chdir='+str(b/'jobs'),'--export=ALL,'+','.join(k+'='+v for k,v in env.items()),'jobs/run_python_array.sh']
os.chdir(b);test=run(a[:1]+['--test-only']+a[1:]);assert test['rc']==0,test
s=run(a);print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),queue=q,validation=v,test_only=test,args=a,submission=s,marker_sha256={digest!r},seat_budget='7current plus14new=21/50; IGUM running already counted',env=env)))
"""
 result=remote('athena.technion.ac.il',code);save('s2_step150_dispatch_1507.json',result);save('s2_step150_env_1507.json',env)
 assert result['rc']==0,result;payload=json.loads(result['out']);print(json.dumps({'submission':payload['submission'],'marker_sha256':digest}));assert payload['submission']['rc']==0
