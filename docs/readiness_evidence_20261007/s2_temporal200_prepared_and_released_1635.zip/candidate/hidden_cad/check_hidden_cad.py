import sys,json,hashlib
from pathlib import Path
import numpy as np
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
OUT=Path(__file__).resolve().parent
PKG=OUT.parent;sys.path.insert(0,str(PKG));import s2_temporal200_forward as r
from no_solve_guard import NoSolveCAD,file_identity,plain
BASE=Path('C:/Users/evyat/AppData/Local/Temp/s2_fdstep_hidden_build_nsak9n13/task_00_2pogl0a4/lumopt2_te_s2_fdstep_diagnostic_20261007_files/fwd_default.fsp')
API=Path('C:/Program Files/Lumerical/v261/api/python');sys.path.insert(0,str(API));import lumapi
EXPECTED='fa6a6528e34cb9c004604ec490543c3b0579d76224c936568c2e11e4f9996053'
def main():
 r.need(r.sha(r.__file__)==EXPECTED,'Reviewed TEMP runner changed');r.frozen_base();original=file_identity(BASE);klass=lumapi.FDTD;ctor=klass.__init__
 report=dict(scope='HIDDEN_LOCAL_CAD_ONLY_NO_SOLVE_NOT_ATHENA_IDENTITY',runner_sha256=EXPECTED,original_base=original,blocked_calls=[],measurements=[])
 try:
  raw=lumapi.FDTD(hide=True)
  with NoSolveCAD(raw,OUT) as f:
   report['version']=plain(f.version())
   for name in ['run','runjobs','runparallel']:
    try:getattr(f,name)()
    except RuntimeError as e:report['blocked_calls'].append({'method':name,'error':str(e)})
    else:raise RuntimeError('guard failure')
   try:f.eval('run;')
   except RuntimeError as e:report['blocked_calls'].append({'method':'eval run;','error':str(e)})
   else:raise RuntimeError('guard failure')
   for t in [0,1,2]:
    f.load(str(BASE));f.switchtolayout();base=r.snapshot(f,r.val.te_point(r.SPEC))
    # Existing FD-only scene has disabled DFT; restore expected fresh-builder
    # state only in this new in-memory scene,not in original saved source.
    f.setnamed('optimization_dft','enabled',1)
    p,index,d,sign=r.task_params(t);mapped=r.eng.make_func(r.SPEC)(p)
    for key,value in mapped.items():obj,prop=key.rsplit('::',1);f.setnamed(obj,prop,value)
    before=r.snapshot(f,p)
    for key in ['mesh','source','ports','refinement','monitor','timing']:r.need(before[key]==base[key],'Geometry step changed '+key)
    c=r.controls(f,p,200.);r.need(c['after']['monitor']['monitor frequency points']==501,'Ports501 changed');r.need(c['after']['optimization_dft_enabled']==0,'DFT not disabled');r.need(c['after']['timing']['use divergence checking']==1,'Divergence off')
    fsp=OUT/f'task_{t:02d}_build_only.fsp';f.save(fsp);f.load(fsp);after=r.snapshot(f,p);serialization=r.persisted_check(c['after'],after)
    c.update(persisted=after,persisted_sha256=r.semantic(after),serialization=serialization);r.validate_control(c,p)
    report['measurements'].append(dict(task=t,index=index,delta_nm=sign*.0625,duration_ps=200.,point=p.tolist(),controls=c,mapped_geometry_max_abs_error_m=max(abs(float(np.asarray(before['geometry'][k]).squeeze())-v) for k,v in mapped.items()),saved_fsp=file_identity(fsp),grid_source_ports_unchanged_from_prepared_base=True))
   report['audit']=f.audit;report['status']='ALL_THREE_TASKS_CAD_CONTROLS_AND_PERSISTENCE_PASS_NO_PHYSICS_PASS'
 except Exception as exc:report['status']='CAD_CHECK_FAILED';report['error']=type(exc).__name__+': '+str(exc)
 finally:
  report['FDTD_class_symbol_unchanged']=lumapi.FDTD is klass;report['FDTD_constructor_unchanged']=lumapi.FDTD.__init__ is ctor;report['original_base_unchanged']=file_identity(BASE)==original;report['runner_unchanged']=r.sha(r.__file__)==EXPECTED
  with (OUT/'cad_report.json').open('x',encoding='utf-8') as stream:json.dump(report,stream,indent=2,allow_nan=False)
 print(report['status'],report.get('error',''));print('blocked',len(report['blocked_calls']),'measurements',len(report['measurements']))
 return 0 if report['status'].startswith('ALL_THREE_TASKS') and report['original_base_unchanged'] and report['runner_unchanged'] else 1
if __name__=='__main__':raise SystemExit(main())
