# N80 physical truncation with fixed N98 measurement domain

Preparation only, TEMP-owned, no CAD/server/solve/production edits. No release or approval marker.

Pinned reference: temporal150 task03 original checkpoint SHA `a0ff55eacaa52e00a2aab17dcc43d0e5fff9a72566e15da371ff25279c172663`. It is the recovered validation point (shifts1/30=+5nm, cavity961.4nm), not the original seed or an accepted campaign candidate. All 296 slots remain exact; the 115 comb slots stay frozen/inactive for bare TE. Frozen source hashes verified before imports.

## Concrete mapping result

`lumopt2_design.py:734-783` anchors the free 60 region at pitch/4+60*pitch, independent of physical N. `tooth_names` changes only global object-number suffixes. All 723 free-tooth/cavity property values are bitwise identical for N80 and N98 after semantic-name remapping, including tested nonzero shift/corr/avg/cavity variants. Saved N98 persisted geometry differs from computed mapping in 180 properties by at most 1.69407e-21m: recorded serialization roundoff, not a physical N mismatch.

`build_base_cfg`:1305-1340 builds a uniform native scene; `_common.build_ports_base` and `_tm_base.build_base` disable native apodization. The final free 60 apodization is the exact make_func property map; never regenerate/rescale the Itai taper to 80 teeth. d61..80 stay uniform width 752.9/1247.1nm and occupy their original physical positions. Remove only d81..98, 18 periods per side. N80 physical ends are+/-39.407565um versus N98+/-48.246645um.

Do not pass the point through native `inner_shift_nm`: bragg_device.py:1183-1194 uses previous-tooth shift on the right, while engine make_func uses the current tooth. Direct N80 build plus engine property application preserves this actual engine geometry.

## Minimal future isolated build

1. Create a new private attempt and a fresh native N80 scene, never load/delete/trim the original N98 scene. Use a copy of the pinned spec with only physical N80 and a distinct label. Keep free 60, all point values, seed_override, pitch 491.06nm, TE/bare, materials and transverse settings.
2. Obtain `cfg80=eng.build_base_cfg(spec80)` and set `cfg80.mesh.n_periods_dist_to_port=38` (old 20 +18 removed). Builder formulas bragg_device.py:287-292 then give the SAME native port coordinate+/-58.067845um and domain+/-65.679275um, bitwise in this offline arithmetic. Port-to-PML distance remains unchanged. Build directly with `PiShiftBraggFDTD(**cfg80.to_device_kwargs())`; the frozen builder opens hidden CAD. Its reset affects only this new scene. No lumapi class/factory or engine helper patches.
3. Apply the exact `eng.make_func(spec80)(point)` mapped properties after asserting N80 object-name existence. This replaces only free 60/cavity properties; it preserves outer20 uniform periods and extends native feed waveguides into the removed bulk region.
4. Restore/check fixed profile/time monitor positions before saving: field_profile x=0, predicted span 98.49329um (not N80's automatic 80.81513um), y-span 1.87065um,z=0 and its baseline frequency settings; time_input/output stay+/-48.746645um, cavity0. Actual baseline CAD/profile coordinate coverage must verify these predictions first. Existing150 port checkpoint does not contain field_profile settings/results.
5. The original project is lumopt2-generated with locked user-specified mesh. Use its EXACT saved x/y/z arrays from task03.controls.persisted.mesh (2676/69/70), not just the native global steps or new N80 extrema. Preserve the optimization-region mesh dimensions/dx and disable optimization_dft only after mesh equality. Reuse the vendor's supported user-mesh-setting path; no setter was exercised here.
6. Preserve saved forward source/ports readbacks, including Port1 x=-58.018739um (one-cell vendor offset from native-58.067845), phase 18.625271537954255deg, Port2 x=+58.067845um, phase 0, transverse spans, source-mode/profile and exact 501 grid. A plain native N80 base alone does not reproduce these vendor-adjusted source properties. Verify pulse/offset/bandwidth and saved global source controls, not just physical port gap formulas.
7. Preserve PVA method/refinement 5, symmetry, PML face configuration/layers/profile, all max-step/grading/stability settings. CP supplies saved axes/dt/PVA but not full PML layers/profile; query a pinned baseline read-only before candidate comparison rather than assume defaults. Hold chosen common duration/early-stop controls (task03 is 150 ps, early shutoff OFF), divergence settings and dt 6.67102648e-17s. Temporal adequacy remains a separate pending decision.
8. Save only new FSP paths, reload them and repeat all equality checks before any release. Require exact mesh/source/ports/grid/timing/PML equality; for geometry serialization only use the reviewed bounded allowance with raw deltas recorded. Check physical truncation count/outer widths/feed joins and expected missing d81..98. Hash new files and preserve originals. No runnable solver entrypoint is supplied by this packet.

## Width semantics and release gates

Hold the N98 profile monitor coverage so raw captured axes are comparable. Production engine `_line_from_res`:2031-2061 crops at+/-N*pitch, not physical ends including pitch/4: N98+/-48.12388um, N80+/-39.2848um. Native sim_helpers uses physical ends; do not mix those definitions. Production envelope and relative-min halflevel can change solely from cropping or feed background. Report production width with each physical N, plus both fields on the common N80 crop as a labeled diagnostic. Preserve uncropped integrated intensity, monitor wavelength/y grid, crop mask, envelope/min/max/halflevel/crossings and end profiles; do not silently substitute a fixed N98 crop as the N80 production width.

Release remains conditional: first obtain a matched N98 validation-point field profile at its tracked defect wavelength and review adequate common duration; then complete the new build/reload controls above. Compare both Tout/modal, tracked mode/profile, wavelength/linewidth and widths against unchanged S2 seed band [19.24328,20.02872]um while also reporting change from the actual validation-point width. Do not infer the actual point width from the seed anchor 19.63um. An off-window peak requires explicit review, not automatic scan recentering or a pass claim.

Fixed N98 domain/mesh removes physical bulk periods without domain-cell saving. No speedup or N80 width/convergence has been measured. A compact-domain N80 comparison is a later distinct conditional test.

## Reproduction

`blueprint.py` produces only JSON, not a FSP or a runner:

```powershell
python -B test_blueprint.py
python -B blueprint.py --checkpoint C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes/docs/readiness_evidence_20261007/s2_temporal150_fetch_1434/s2_temporal150_task03_original.json --repo C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes --output C:/Users/evyat/AppData/Local/Temp/s2_N80_fixed_domain_blueprint_r0clu8yf/recomputed_blueprint.json
```

Output must be new. Five offline test groups and actual pinned-point blueprint execution exit0. Tests establish exact free/cavity mappings under nonzero variations, uniform retained outer geometry/joins, sole N/gap changes and fixed native formulas, off-family/altered-point refusal, and the production crop distinction. Hidden CAD was unnecessary to answer these source mapping questions; all actual N80 saved geometry/source/mesh/PML/monitor readback remains unmeasured.
