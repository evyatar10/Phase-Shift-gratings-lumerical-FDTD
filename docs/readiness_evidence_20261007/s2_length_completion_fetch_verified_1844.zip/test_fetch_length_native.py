"""Offline synthetic protocol tests. No new measured length results, CAD or network."""
import base64,copy,importlib.util,json,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
HERE=Path(__file__).resolve().parent
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
REF=Path('C:/Users/evyat/AppData/Local/Temp/s2_length_fixed150_candidate_n6nnepfe')
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT));sys.path.insert(0,str(HERE))
import fetch_length_native as f
from runners.lumopt2_design import s2_length_fixed150 as lane

def fixture():
 ctx=f.context('101434',ROOT/'docs/readiness_evidence_20261007/s2_length_two_forwards_environment_1812.json',ROOT/'docs/readiness_evidence_20261007/s2_length_two_forwards_review_original.json',REF/'reference_port_grids.json')
 reference=lane.ref.load(REF/'reference_150_center_original.json',REF/'reference_spatial_inventory_original.json',REF/'reference_port_grids.json')
 cad=json.loads((ROOT/'docs/readiness_evidence_20261007/s2_length_native_cad_report_original_1757.json').read_text())
 pb=(ROOT/'docs/readiness_evidence_20261007/s2_temporal150_fetch_1434/s2_temporal150_task03_ports.npz').read_bytes()
 import numpy as np,io
 with np.load(io.BytesIO(pb),allow_pickle=False) as z:scores=lane.recovery.score({k:z[k] for k in z.files})
 accounting=dict(sacct=dict(rc=1,out='',err='Synthetic database unavailable'),scontrol={str(t):dict(rc=1,out='',err='Synthetic Invalid job id specified') for t in (0,1)})
 payload=dict(schema=1,status='NATIVE_PAIR_COLD_VERIFIED_READ_ONLY',job_id=f.JOB,at='SYNTHETIC_NOT_MEASURED',env_sha256=f.ENV_SHA,marker_sha256=f.MARKER_SHA,helper_sha256=f.digest(f.raw(f.__file__)),accounting=accounting,wrapper_logs={},records=[],files=[],retained_artifacts={},all_inputs_preserved=True,no_CAD=True,no_solve=True,qualification=f.QUAL,synthetic_fixture=True)
 for t,n in enumerate((98,80)):
  attempt=f.CANON_ROOT+f'/task_{t:02d}_SYNTHETIC_ONLY';case=copy.deepcopy(cad['cases'][str(n)])
  def rewrite(c,path):
   c['source']=path+'/fwd_default.fsp';c['immutable_setup_fsp']=path+'/prepared_forward_before_solve.fsp'
   c['native_saved_format_construction']['preparatory_fsp']=path+f'/N{c["physical_N"]}_native_pre_correction.fsp'
  rewrite(case,attempt)
  anchor=copy.deepcopy(cad['cases']['98']) if t==1 else None
  if anchor:
   rewrite(anchor,attempt+'/fresh_N98_anchor');anchor.pop('immutable_setup_fsp')
  stage=reference['profile_stage'];coordinate=stage['raw_profile_coordinate_inventory']
  meta=dict(have_raw_data=True,have_E_result=True,axes={k:coordinate[k] for k in ['x_m','y_m','z_m','lambda_m']},E_shape=coordinate['E_shape'],monitor_configuration={k:v['value'] for k,v in stage['monitor_geometry'].items() if v['available']},readback='COLD_LOADED_NEW_SOLVED_FSP_RESULT_DATASET_COORDINATES_NO_E_TRANSFER')
  meta['axes']['f_Hz']=reference['grids']['p2_f']['values'];source=case['source'];h5=attempt+'/fwd_default/fwd_default_output.h5'
  sha='a'*64;hsha='b'*64;meta.update(source=source,h5=h5,fsp_sha256=sha,h5_sha256=hsha);meta['metadata_sha256']=f.semantic(meta)
  dt=case['reloaded']['timing']['dt'];log=attempt+'/fwd_default_p0.log'
  termination=dict(log=log,log_sha256='c'*64,iterations=1,physical_time_s=150e-12,requested_time_s=150e-12,recorded_dt_s=dt,delta_s=0.,status=1,reason='completed_full_simulation_time')
  result=dict(task=t,physical_N=n,duration_ps=150.,params=ctx['marker']['point'],source=source,h5=h5,ports_npz=attempt+'/ports.npz',fsp_sha256=sha,h5_sha256=hsha,ports_sha256=f.digest(pb),build_case=case,fresh_N98_anchor=anchor,pair_comparison=lane.compare_pair(anchor,case) if anchor else None,profile_metadata=meta,termination=termination,resource=dict(device_type='GPU',threads='8'),parent_review=ctx['review'],vendor_api_sha256=ctx['marker']['vendor_api_sha256'],qualification=f.QUAL,overall_gradient_gate='FAILED_UNCHANGED',**scores)
  identity=dict(schema=1,task=t,physical_N=n,point=ctx['marker']['point'],spec=ctx['marker']['specs'][str(t)],duration_ps=150.,task_map=[98,80],scope=ctx['scope'],parent_review=ctx['review'],overall_gradient_gate='FAILED_UNCHANGED')
  b=json.dumps(dict(identity=identity,result=result),allow_nan=False).encode();cp=f.CANON_ROOT+f'/task_{t:02d}.json'
  for kind,path,bytes_ in [('checkpoint',cp,b),('ports',result['ports_npz'],pb)]:payload['files'].append(dict(task=t,kind=kind,path=path,sha256=f.digest(bytes_),bytes=len(bytes_),base64=base64.b64encode(bytes_).decode()))
  wrapper=f'Array:      {f.JOB}[{t}]\nSWEEP_KIND: lumopt2_design\nSWEEP_LIST: {ctx["env"]["SWEEP_LIST"]}\nSWEEP_INDEX:{t}\nNew length diagnostic; no convergence pass {cp}\nFinished: synthetic\nExit code: 0\n'
  payload['wrapper_logs'][str(t)]=wrapper;payload['records'].append(dict(task=t,identity_sha256=f.semantic(identity),profile_metadata_sha256=meta['metadata_sha256'],completion=f.completion(accounting,t,wrapper,ctx['env'])))
  pins=payload['retained_artifacts']
  for path in [cp]+f.artifact_paths(result):pins[path]=dict(sha256='d'*64,bytes=10,mtime_ns=1)
  for path,digest in [(cp,f.digest(b)),(source,sha),(h5,hsha),(result['ports_npz'],f.digest(pb)),(log,'c'*64),(case['immutable_setup_fsp'],case['setup_fsp_sha256']),(case['native_saved_format_construction']['preparatory_fsp'],case['native_saved_format_construction']['sha256'])]:pins[path]['sha256']=digest
  if anchor:
   for path,digest in [(anchor['source'],anchor['setup_fsp_sha256']),(anchor['native_saved_format_construction']['preparatory_fsp'],anchor['native_saved_format_construction']['sha256'])]:pins[path]['sha256']=digest
  pins[f.CANON_BASE+f'/jobs/logs/lum_array-{f.JOB}_{t}.out']=dict(sha256=f.digest(wrapper.encode()),bytes=len(wrapper.encode()),mtime_ns=1)
 pins=payload['retained_artifacts']
 for path,digest in [(f.CANON_MARKER,f.MARKER_SHA)]+[(ctx['marker']['reference'][p],ctx['marker']['reference'][s]) for p,s in [('checkpoint_metadata','checkpoint_sha256'),('profile_metadata','profile_sha256'),('port_grid_metadata','port_grid_sha256')]]:pins[path]=dict(sha256=digest,bytes=1,mtime_ns=1)
 for name,digest in ctx['marker']['code'].items():
  rel=name if (ROOT/name).is_file() else 'runners/lumopt2_design/'+name;pins[ctx['marker']['repo']+'/'+rel]=dict(sha256=digest,bytes=1,mtime_ns=1)
 for name,digest in ctx['marker']['vendor_api_sha256'].items():pins[str(f.canonical(ctx['marker']['API_path']).parent)+'/'+name]=dict(sha256=digest,bytes=1,mtime_ns=1)
 return payload,ctx,reference

def change_cp(payload,task,edit):
 row=next(x for x in payload['files'] if x['task']==task and x['kind']=='checkpoint');cp=json.loads(base64.b64decode(row['base64']));edit(cp)
 b=json.dumps(cp,allow_nan=False).encode();row.update(base64=base64.b64encode(b).decode(),bytes=len(b),sha256=f.digest(b));payload['retained_artifacts'][row['path']]['sha256']=f.digest(b)
 payload['records'][task]['identity_sha256']=f.semantic(cp['identity'])

class Protocol(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.payload,cls.ctx,cls.reference=fixture();cls.pin=f.digest(f.raw(f.__file__))
 def verify(self,p):return f.verify_payload(p,self.ctx,self.reference,lane,self.pin)
 def test_01_synthetic_positive_originalbytes_exclusive(self):
  self.assertEqual(len(self.verify(self.payload)),4)
  if True:
   tmp=tempfile.mkdtemp(prefix='s2_length_fetch_SYNTHETIC_PRESERVED_')
   out=Path(tmp)/'NEW';result=f.publish(self.payload,self.ctx,self.reference,lane,out,self.pin);self.assertEqual(result['status'],'ORIGINAL_CP_PORT_BYTES_EXCLUSIVELY_PUBLISHED')
   self.assertEqual(len(list(out.iterdir())),6)
   for row in self.payload['files']:
    name=f'task_{row["task"]:02d}.json' if row['kind']=='checkpoint' else f'task_{row["task"]:02d}_ports.npz'
    self.assertEqual((out/name).read_bytes(),base64.b64decode(row['base64']))
   with self.assertRaises(RuntimeError):f.publish(self.payload,self.ctx,self.reference,lane,out,self.pin)
 def test_02_running_failed_or_wrongexit_veto_fallback(self):
  for state,exit_ in [('RUNNING','0:0'),('PENDING','0:0'),('FAILED','1:0'),('COMPLETED','1:0')]:
   p=copy.deepcopy(self.payload);p['accounting']['sacct']=dict(rc=0,out=f'{f.JOB}_0|{state}|{exit_}\n',err='')
   with self.assertRaises(RuntimeError):self.verify(p)
  for state,exit_ in [('RUNNING','0:0'),('FAILED','1:0'),('COMPLETED','0:9')]:
   p=copy.deepcopy(self.payload);p['accounting']['scontrol']['0']=dict(rc=0,out=f'JobId=123 ArrayJobId={f.JOB} ArrayTaskId=0 JobState={state} ExitCode={exit_}',err='')
   with self.assertRaises(RuntimeError):self.verify(p)
 def test_03_live_exact_success_and_unavailable_honesty(self):
  log=self.payload['wrapper_logs']['0'];account=copy.deepcopy(self.payload['accounting']);a=f.completion(account,0,log,self.ctx['env']);self.assertTrue(a['mode'].startswith('LIVE_ACCOUNTING_UNAVAILABLE'))
  account['scontrol']['0']=dict(rc=0,out=f'JobId=123 ArrayJobId={f.JOB} ArrayTaskId=0 JobState=COMPLETED ExitCode=0:0',err='');self.assertEqual(f.completion(account,0,log,self.ctx['env'])['mode'],'LIVE_COMPLETED0:0')
  account['scontrol']['0']['out']=account['scontrol']['0']['out'].replace('ArrayJobId=101434','ArrayJobId=101435')
  with self.assertRaises(RuntimeError):f.completion(account,0,log,self.ctx['env'])
 def test_04_exact_last_wrapper_segment_job_task_publication(self):
  log=self.payload['wrapper_logs']['0'];a=self.payload['accounting'];env=self.ctx['env']
  for changed in [log.replace('101434[0]','101435[0]'),log.replace('101434[0]','101434[1]'),log.replace('task_00.json','task_01.json'),log.replace('Exit code: 0','Exit code: 1'),log.replace('New length diagnostic; no convergence pass','REUSED native fixed-domain length checkpoint'),log+'Array: 101434[0]\n',log.replace('SWEEP_INDEX:0','SWEEP_INDEX:1'),log.replace('Finished: synthetic\n','')]:
   with self.assertRaises(RuntimeError):f.completion(a,0,changed,env)
 def test_05_rawhash_task_path_marker_missingartifact(self):
  for edit in [lambda p:p.update(job_id='171390'),lambda p:p.update(marker_sha256='a'*64),lambda p:p['files'].pop(),lambda p:p['files'][0].update(sha256='a'*64),lambda p:p['files'][0].update(task=3),lambda p:p['files'][0].update(path=f.CANON_ROOT+'/../task_00.json'),lambda p:p['retained_artifacts'].pop(next(k for k in p['retained_artifacts'] if k.endswith('.h5'))),lambda p:p['retained_artifacts'].pop(f.CANON_MARKER),lambda p:p['retained_artifacts'][self.ctx['marker']['repo']+'/runners/lumopt2_design/s2_length_fixed150.py'].update(sha256='a'*64)]:
   p=copy.deepcopy(self.payload);edit(p)
   with self.assertRaises((RuntimeError,KeyError)):self.verify(p)
 def test_06_coldfamily_score_grid_status_and_metadata(self):
  mutations=[lambda cp:cp['identity'].update(task=3),lambda cp:cp['identity'].update(task=False),lambda cp:cp['result'].update(physical_N=70),lambda cp:cp['result'].update(peak3_tout=999.),lambda cp:cp['result']['termination'].update(status=0),lambda cp:cp['result']['termination'].update(physical_time_s=100e-12),lambda cp:cp['result']['profile_metadata'].update(have_E_result=False),lambda cp:cp['result']['parent_review'].update(sha256='a'*64),lambda cp:cp['result']['build_case']['reloaded']['timing'].update(dt=0.)]
  for edit in mutations:
   p=copy.deepcopy(self.payload);change_cp(p,0,edit)
   with self.assertRaises((RuntimeError,KeyError)):self.verify(p)
 def test_07_no_solve_entrypoints_and_source_guards(self):
  stub=SimpleNamespace(main=lambda:None,forward_only=lambda:None,build_only=lambda:None,build_case=lambda:None,profile_metadata=lambda:None,eng=SimpleNamespace(make_project=lambda:None,import_lumopt2=lambda:None),base=SimpleNamespace(main=lambda:None,forward_only=lambda:None),recovery=SimpleNamespace(checkpoint=lambda:None),build=SimpleNamespace(configure=lambda:None,restore_retained_outer_and_feed_joins=lambda:None))
  f.install_blocks(stub)
  for module,names in [(stub,['main','forward_only','build_only','build_case','profile_metadata']),(stub.eng,['make_project','import_lumopt2']),(stub.base,['main','forward_only']),(stub.recovery,['checkpoint']),(stub.build,['configure','restore_retained_outer_and_feed_joins'])]:
   for name in names:
    with self.assertRaisesRegex(RuntimeError,'FORBIDS'):getattr(module,name)()
  self.assertEqual(lane.code(),self.ctx['marker']['code']);self.assertNotIn('lumapi',sys.modules)
 def test_08_context_job_rawpins_and_canonical_paths(self):
  for value in ['/work/x/../y','/work//x','relative/x','/work/./x','/work\\x']:
   with self.assertRaises(RuntimeError):f.canonical(value)
  for job in ['171390','101434_0','',101434,True]:
   with self.assertRaises(RuntimeError):f.context(job,'missing','missing','missing')
 def test_09_modified_portgrid_refused_even_after_score_recalculation(self):
  import io,numpy as np
  p=copy.deepcopy(self.payload);row=next(x for x in p['files'] if x['task']==0 and x['kind']=='ports')
  with np.load(io.BytesIO(base64.b64decode(row['base64'])),allow_pickle=False) as z:arrays={k:z[k] for k in z.files}
  arrays['p2_lambda']=arrays['p2_lambda'].copy();arrays['p2_lambda'].flat[0]=np.nextafter(arrays['p2_lambda'].flat[0],np.inf)
  stream=io.BytesIO();np.savez(stream,**arrays);b=stream.getvalue();sha=f.digest(b);scores=lane.recovery.score(arrays)
  row.update(base64=base64.b64encode(b).decode(),bytes=len(b),sha256=sha);p['retained_artifacts'][row['path']].update(sha256=sha,bytes=len(b))
  change_cp(p,0,lambda cp:cp['result'].update(ports_sha256=sha,**scores))
  with self.assertRaisesRegex(RuntimeError,'Exact port grid changed'):self.verify(p)

if __name__=='__main__':unittest.main(verbosity=2)
