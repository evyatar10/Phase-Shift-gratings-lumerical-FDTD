# Selective optimization_dft hidden CAD property feasibility

Result: PASS for local property support and save/reload persistence only. No FDTD solve or physical/result-grid validation. Runtime was Lumerical8.35.4572; session created with hide=True. No repository/server/source edits.

The actual saved local forward scene was loaded read-only:
C:/Users/evyat/AppData/Local/Temp/s2_fdstep_hidden_build_nsak9n13/task_00_2pogl0a4/lumopt2_te_s2_fdstep_diagnostic_20261007_files/fwd_default.fsp
Its original SHA,bytes and mtime were identical after the check. The original port NPZ was also preserved exactly. This is a CAD scene feasibility check, not a new matched-duration setup or nominal-geometry qualification.

The installed CAD's selected-object get() property enumeration explicitly exposes sample spacing/custom frequency samples/override global monitor settings/use source limits. Installed official vendor source also uses custom frequency samples (lumopt/figures_of_merit/modematch.py:228-233), while lumopt2/core/fdtd_session.py:989-1010 creates optimization_dft. These are local API/source checks; no web/network query was made.

Only optimization_dft properties were set:

| Property | Saved/reloaded value |
|---|---|
| enabled |1 |
| override global monitor settings |1 |
| use source limits |0 |
| sample spacing |custom |
| custom frequency samples |Exact5x1 frequency column below |
| spatial interpolation |none,unchanged |
| use wavelength spacing |0,unchanged |
| frequency points |501 legacy property; see caveat |

Pinned original grid indices244,251,252,253,260 yielded frequencies inHz:
192063573418475.4;
192067018825344.97;
192067511026326.3;
192068003227307.7;
192071448634177.22.

Configured and reloaded custom vectors matched those inputs bitwise. A NEW selective_five_frequency.fsp was saved only under attempt2/. Source and global monitor properties,ports source/mode/501-point count,domain,PVA refinement and timing all matched the before snapshot exactly. Source limits remained1559.878859628509–1561.878859628509nm,global sampling uniform frequency501,Port_1 mode1 active. Offline frequency-grid arithmetic from these saved source limits matches the pinned original501-frequency vector bitwise; this is not a simulated result-grid measurement.

The monitor's frequency points property still reads501 with sample spacing custom. The custom list containsfive entries and is persisted,but this check does NOT prove how many field frequencies will be returned after solve. Monitor wavelength start/stop are unavailable properties here; use recorded supported minimum/maximum/center/span properties or custom list rather than assuming those names. getdata(optimization_dft,f,2) fails in layout mode because no solved d-card exists; the exact error is retained in cad_report.json. Actual field frequency order/count,complex E shapes and compatible source/port results must be asserted after a separately authorized solve.

No-solve evidence: NoSolveCAD blocked direct run,runjobs,runparallel and eval('run;') before invoking the underlying API. All four live guard probes were rejected. Four offline guard tests passed exit0,checking direct/script solve rejection,quoted-name handling and refusal to overwrite an existing file. lumapi.FDTD class symbol AND constructor identity remained unchanged; no constructor/class monkeypatch was used. The guarded script accesses underlying raw object only to construct the wrapper; all CAD operations use that wrapper.

Attempt1 exited1 at loading an8-byte pre-existing fake test FSP selected by filename; no monitor configuration or solve occurred. Its failure/raw identity/log remain at package root. Attempt2 verified a3.3MB actual CAD scene first,then passed exit0. No failed evidence was overwritten.

Files:
- attempt2/probe_selective_properties.py: successful bounded reproducer; running it twice in the same directory is intentionally blocked by exclusive saved/report paths. Copy to a new unique attempt for rerun.
- attempt2/cad_report.json and cad.log: actual properties,persistence,input preservation and no-solve evidence.
- attempt2/selective_five_frequency.fsp: new saved CAD scene,not production or solve-ready release.
- source_grid_arithmetic.json: offline source-bound grid comparison.
- test_guard.py,test_guard.log: four focused guard tests.
- no_solve_guard.py and attempt2/no_solve_guard.py: byte-identical copies of the frozen guard; original remains untouched.
- manifest.json: code/report/FSP hashes and explicit exitcodes.

Remaining prerequisites: prepare an independently reviewed reduced-field extractor (current five-slice helper requires501 stored frequencies); pin new forward/adjoint identities and matched-duration controls; validate actual resulting frequency arrays/Ex,Ey,Ez/axes plus unchanged port501 grid; inspect temporal evidence before decidingD. No FDTD dispatch,calibration pass or field-count/storage-performance guarantee follows from this property check.
