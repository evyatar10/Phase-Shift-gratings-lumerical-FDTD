import importlib.util,runpy,sys
from pathlib import Path
ROOT=Path('C:\\Users\\evyat\\Lumerical\\phase_shift_grating_FTDT_codes')
CANDIDATE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
name="runners.lumopt2_design.lumopt2_design"
spec=importlib.util.spec_from_file_location(name,CANDIDATE/"runners/lumopt2_design/lumopt2_design.py")
m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m)
sys.modules["lumopt2_design"]=m
from runners.lumopt2_design import persistence
assert hasattr(m,"persistence")
target=sys.argv[1];sys.argv=[target]
runpy.run_path(target,run_name="__main__")
