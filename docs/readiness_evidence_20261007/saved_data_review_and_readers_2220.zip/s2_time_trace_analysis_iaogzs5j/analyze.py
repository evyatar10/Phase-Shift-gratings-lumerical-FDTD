import json,hashlib,sys
from pathlib import Path
import numpy as np
from scipy.io import loadmat

def stats(t,v):
 assert t.ndim==v.ndim==1 and len(t)==len(v) and len(t)>1
 assert np.isfinite(t).all() and np.isfinite(v).all() and np.all(np.diff(t)>0)
 peak=float(np.max(np.abs(v)));assert peak>0
 windows={}
 for ps in [1,5,10]:
  w=v[t>=t[-1]-ps*1e-12]
  windows[str(ps)]={'samples':len(w),'rms_over_trace_peak':float(np.sqrt(np.mean(abs(w)**2))/peak),'max_over_trace_peak':float(np.max(abs(w))/peak)}
 return {'samples':len(t),'t_first_s':float(t[0]),'t_last_s':float(t[-1]),'dt_median_s':float(np.median(np.diff(t))),'real_valued':bool(np.isrealobj(v)),'peak_abs':peak,'tail_windows_ps':windows}
def prefix(a,b):
 ta,va=a;tb,vb=b;n=min(len(ta),len(tb));same=bool(np.array_equal(ta[:n],tb[:n]))
 r={'samples':n,'time_prefix_bitwise_equal':same}
 if same:
  delta=vb[:n]-va[:n];den=np.linalg.norm(va[:n]);peak=np.max(abs(va[:n]));assert den>0 and peak>0
  r.update(field_prefix_bitwise_equal=bool(np.array_equal(va[:n],vb[:n])),relative_l2=float(np.linalg.norm(delta)/den),max_difference_over_reference_peak=float(np.max(abs(delta))/peak))
 return r
# Arithmetic checks; no physics claim.
t=np.arange(10.)*1e-12;v=np.ones(10);assert prefix((t,v),(t,v))['relative_l2']==0
assert abs(prefix((t,v),(t,2*v))['relative_l2']-1)<1e-15
assert not prefix((t,v),(t+1e-15,v))['time_prefix_bitwise_equal']
assert stats(t,v)['tail_windows_ps']['5']['rms_over_trace_peak']==1
repo=Path(sys.argv[1]);receipt=json.loads((repo/'docs/readiness_evidence_20261007/s2_time_MAT_fetch_2202.json').read_bytes())
traces={};r={'status':'MEASURED_POINT_TRACE_DIAGNOSTICS_ONLY','stages':{},'prefixes':{},'qualification':'Point Ey only, not injected-source isolation, port power, a global noise bound, calibration or convergence pass. Prefix mismatch does not alone identify nondeterminism or its cause.'}
for item in receipt['files']:
 raw=Path(item['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==item['sha256'];a=loadmat(item['path']);d=item['duration_ps'];traces[d]={};r['stages'][str(d)]={}
 for m in ['time_input','time_cavity','time_output']:
  t=a[m+'__t_s'].ravel();v=a[m+'__Ey'].ravel();traces[d][m]=(t,v);r['stages'][str(d)][m]=stats(t,v)
for lo,hi in [(100,150),(100,200),(150,200)]:r['prefixes'][str(lo)+'_'+str(hi)]={m:prefix(traces[lo][m],traces[hi][m]) for m in traces[lo]}
with Path(sys.argv[2]).open('x') as f:json.dump(r,f,indent=2)
print(json.dumps(r))
