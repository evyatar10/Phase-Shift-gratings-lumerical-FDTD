# Native length completion fetch: preparation only

This packet makes no SSH/network calls and never constructs/imports lumapi, runs
FDTD, builds CAD, saves an FSP, publishes a remote checkpoint, submits or cancels
jobs. The lead owns all remote execution and transfer. IGUM101434 was pending;
the synthetic fixture is NOT a measurement of N98 or N80.

The explicit actual job argument must be `101434`; exact tasks are 0=N98 and
1=N80,150ps,free60,296point,501profiles,finite-duration length sensitivity only.
Environment bytes61d913..., release bytesd824..., runner9076..., original
CPa0ff... and grids9aaa... are frozen. No inferred convergence/noise pass.

## CLI

Run with the current repo as the working directory. All output directories must
be new and absolute. `--prepare` only copies a local command packet:

```powershell
python -B C:/Users/evyat/AppData/Local/Temp/s2_length_native_fetch_7febdd132a81/fetch_length_native.py --prepare --job-id 101434 --environment docs/readiness_evidence_20261007/s2_length_two_forwards_environment_1812.json --marker docs/readiness_evidence_20261007/s2_length_two_forwards_review_original.json --grids C:/Users/evyat/AppData/Local/Temp/s2_length_fixed150_candidate_n6nnepfe/reference_port_grids.json --output C:/Users/evyat/AppData/Local/Temp/NEW_NATIVE_FETCH_COMMAND_PACKET
```

The emitted `remote_capture_stdin.py` embeds the exact context and byte-pinned
helper. It is intended for the lead's existing SSH stdin path, using:

```
/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261/python/bin/python -B -
```

Before native Python starts, reuse the standard native wrapper's relevant
runtime environment: `LD_LIBRARY_PATH=<LUM_HOME>/lib:<native base>/scilibs`,
LANG/LC_ALL=C, QT_QPA_PLATFORM=offscreen, PYTHONDONTWRITEBYTECODE=1.
The helper applies the pinned release environment and config paths in-process;
it neither writes source nor invokes the job wrapper. No need to upload the
helper or metadata: stdin is self-contained. Lead captures exit code, stdout
and stderr; only exit0 and exactly one complete JSON payload permit ingest.
Capture/pin the payload SHA independently from the remote response bytes.

```powershell
python -B C:/Users/evyat/AppData/Local/Temp/s2_length_native_fetch_7febdd132a81/fetch_length_native.py --ingest --job-id 101434 --environment docs/readiness_evidence_20261007/s2_length_two_forwards_environment_1812.json --marker docs/readiness_evidence_20261007/s2_length_two_forwards_review_original.json --grids C:/Users/evyat/AppData/Local/Temp/s2_length_fixed150_candidate_n6nnepfe/reference_port_grids.json --repo C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes --reference-cp C:/Users/evyat/AppData/Local/Temp/s2_length_fixed150_candidate_n6nnepfe/reference_150_center_original.json --reference-profile C:/Users/evyat/AppData/Local/Temp/s2_length_fixed150_candidate_n6nnepfe/reference_spatial_inventory_original.json --payload ABSOLUTE_CAPTURE.json --payload-sha256 INDEPENDENT_RAW_CAPTURE_SHA --output ABSOLUTE_NEW_RESULT_DIRECTORY
```

## Completion and cold-read rules

Both original task checkpoints must exist before cold reference/identity/reuse
checks. Available exact task accounting must be COMPLETED0:0; RUNNING, PENDING,
FAILED, malformed identity or nonzero exit vetoes fallback. sacct errors/missing
exact rows and expired scontrol records are explicitly unavailable, never a
completion claim. Even with accounting, require the LAST standard-wrapper
segment to bind Array101434[task],SWEEP_KIND,SWEEP_LIST,SWEEP_INDEX, the exact
new checkpoint publication, Finished and final Exit code0 in that order.
Old successful segments, reused-checkpoint text and other-job logs are refused.

Only then call native_paths/load_reference/reviewed/identity/read_checkpoint/
verify_result; all lane build/solve/publication entrypoints are blocked. No
lumapi import is allowed. Existing verification checks full controls, retained
geometry, PML/ports/source/mesh/profilemetadata and measured501 grids, actual
source/H5/setup/preparatory hashes, terminal engine log/full150ps/status and
reproducible port scores. Original inputs, wrapperlogs, sources/vendor and all
retained output artifacts receive before/after SHA/size/mtime snapshots.
FSP/H5 hashing is sequential and may take time; no E arrays or large FSP/H5
are downloaded. Only original CP and portsNPZ bytes (max64MiB each) transfer.

Local ingest independently checks raw hashes, released identity, physical pair,
profile metadata, exact grids and recalculated scores; it relies on the pinned
read-only remote producer for remote FSP/H5/log verification. Completion-mode
labels distinguish live accounting from wrapper+cold CP+terminal evidence.
Publication uses xb/fsync; existing and failed partial outputs are preserved.
The new output contains exactly two CPs,two NPZs,receipt.json,manifest.json.
Manifest pins receipt bytes. No fallback build/solve exists.

## Offline validation

```powershell
python -B C:/Users/evyat/AppData/Local/Temp/s2_length_native_fetch_7febdd132a81/test_fetch_length_native.py
```

Nine focused synthetic groups cover live-accounting vetoes, last job/task
segment binding, hash/path/marker/task/missing-artifact refusals, physical
family/status/metadata/score guards, exact-grid perturbation despite score
recalculation, disabled entrypoints and exclusive original-byte publication.
Tests use existing nativeCAD cases plus the old150ps center ports as a
synthetic protocol fixture, and preserve unique temporary publication outputs.
They do not establish real job completion, native runtime availability or new
length physics. Lead review and actual capture remain outstanding.
