"""Retained synthetic ladder fixtures over actual pinned first-wave inputs."""
import copy
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
sys.dont_write_bytecode=True
import numpy as np
import analyze_shift_steps as a

REPO=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
EVIDENCE=REPO/'docs/readiness_evidence_20261007'
sys.path.insert(0,str(REPO))
from runners.lumopt2_design import recover_te_s2 as recovery


class ShiftStepsChecks(unittest.TestCase):
    def setUp(self):
        self.root=Path(tempfile.mkdtemp(prefix='fixture_SYNTHETIC_',dir=Path(__file__).parent))
        names=list(a.f.EXISTING)+['s2_half_classes_first_review_original.json','s2_shift30_review_original.json']
        names += [f's2_half_classes_task{t:02d}_{suffix}' for t in range(4) for suffix in ('original.json','ports.npz')]
        for name in names:shutil.copyfile(EVIDENCE/name,self.root/name)
        self.pins=json.loads((EVIDENCE/'firstwave_analysis/actual_existing_pins.json').read_text())
        self.center=json.loads((self.root/'s2_fdstep_task00_original.json').read_text())
        self.marker=json.loads((self.root/'s2_shift30_review_original.json').read_text())
        self.baseline=a.h.load_npz((self.root/'s2_fdstep_task00_ports.npz').read_bytes())
        review=dict(path=a.MARKER_REMOTE,sha256=a.MARKER_SHA,first_wave=self.marker['first_wave'],
                    lead_verdict=self.marker['lead_verdict'],allowed_tasks=[0,1,2,3])
        for task,(step,sign) in enumerate(a.TASK_MAP):
            arrays={k:v.copy() for k,v in self.baseline.items()}
            factor=1+sign*.01*step+.002*step*step
            arrays['p2_T_out']*=factor
            arrays['p2_S']*=np.sqrt(factor)*np.exp(1j*sign*.2*step)
            ports=self.root/f'{a.PREFIX}{task:02d}_ports.npz'
            with ports.open('xb') as stream:np.savez(stream,**arrays)
            point=np.asarray(self.center['identity']['point']).copy();point[149]+=sign*step
            spec=copy.deepcopy(self.center['identity']['spec']);spec['label']=a.FAMILY
            attempt=self.marker['output_root']+f'/task_{task:02d}_SYNTHETIC_FIXTURE'
            source=attempt+'/'+a.FAMILY+'_files/fwd_default.fsp'
            ident=dict(schema=1,task=task,spec=spec,point=point.tolist(),index=149,class_label='shift_30',sign=sign,
                perturbation_nm=step,task_map=a.TASK_MAP,center_sha256=a.f.CENTER_SHA,center_checkpoint=a.f.CENTER_REMOTE,
                parent_review=review,code=self.marker['code'])
            result=dict(task=task,index=149,class_label='shift_30',sign=sign,perturbation_nm=step,delta_nm=step*sign,
                params=point.tolist(),source=source,h5=source[:-4]+'/fwd_default_output.h5',ports_npz=attempt+'/ports.npz',
                ports_sha256=a.f.sha(ports),reviewed_center_sha256=a.f.CENTER_SHA,parent_review=review,
                existing_overall_gradient_gate='FAILED_UNCHANGED',comparison_status='REVIEW_REQUIRED_NO_AUTOMATIC_PHYSICS_PASS',
                **recovery.score(arrays))
            self.put(dict(identity=ident,result=result),task)
        self.newpins=dict(schema=1,family=a.FAMILY,marker_sha256=a.MARKER_SHA,runner_sha256=a.RUNNER_SHA,
            marker_remote=a.MARKER_REMOTE,files={})
        self.repin()

    def row(self,t=0):return json.loads((self.root/f'{a.PREFIX}{t:02d}_original.json').read_text())
    def put(self,row,t=0):(self.root/f'{a.PREFIX}{t:02d}_original.json').write_text(json.dumps(row))
    def repin(self):
        self.newpins['files']={f'{a.PREFIX}{t:02d}_{s}':a.f.sha(self.root/f'{a.PREFIX}{t:02d}_{s}')
            for t in range(4) for s in ('original.json','ports.npz')}
    def analyze(self,pins=None):return a.analyze(self.root,pins or self.pins,REPO,self.newpins)

    def test_complete_full_arrays_centers_jacobians_and_observations(self):
        report,full=self.analyze()
        self.assertEqual(report['status'],'DIAGNOSTIC_ONLY_CALIBRATION_FAILED_UNCHANGED')
        self.assertTrue(report['no_automatic_approval'])
        self.assertEqual(report['steps_nm'],[2.,.5,.125,.0625])
        for metric,transform in a.h.METRICS.items():
            d=report['observables'][metric];s=full['observables'][metric]
            self.assertEqual(len(d['successive_observed_differences']),3)
            center=transform(self.baseline)
            for key,step in [('0.125',.125),('0.0625',.0625)]:
                r=d['common_center_steps'][key];arrays=s['full_grid_steps'][key]
                self.assertAlmostEqual(r['central_derivative'],.01*r['center_peak3'],places=12)
                self.assertAlmostEqual(r['exact_center_peak3_jacobian_projection'],r['central_derivative'],places=12)
                np.testing.assert_allclose(arrays['central_derivative'],center*.01,rtol=1e-10,atol=1e-14)
                np.testing.assert_allclose(arrays['even_with_repeated_center'],center*.002*step*step,rtol=1e-8,atol=1e-14)
                self.assertEqual(len(arrays['even_with_original_center']),501)
                diff=(np.asarray(arrays['even_with_original_center'])-np.asarray(arrays['even_with_repeated_center']))
                np.testing.assert_allclose(diff,s['center_difference'],atol=3e-17)
            self.assertIsNotNone(d['scalar_and_jacobian_by_center']['0.125']['original'])
        a.f.write(self.root/'SYNTHETIC_report.json',report);a.f.write(self.root/'SYNTHETIC_full.json',full)

    def test_independent_raw_checkpoint_and_npz_pins(self):
        row=self.row();self.put(row) # deterministic same serialization
        with (self.root/f'{a.PREFIX}00_original.json').open('a') as stream:stream.write(' ')
        with self.assertRaisesRegex(a.h.EvidenceError,'Raw checkpoint'):self.analyze()
        self.repin()
        with (self.root/f'{a.PREFIX}00_ports.npz').open('ab') as stream:stream.write(b'\0')
        with self.assertRaisesRegex(a.h.EvidenceError,'Independent transferred'):self.analyze()

    def test_full_task_point_spec_sources_and_marker_semantics_after_repin(self):
        original=self.row()
        changes=[('identity','task',1),('identity','index',29),('identity','sign',-1),
            ('identity','perturbation_nm',.5),('identity','task_map',[[.25,1]]),('identity','point',[0.]*296),
            ('result','params',[0.]*296),('result','source','/old/fwd_default.fsp'),
            ('result','h5',original['result']['source']),('result','ports_sha256','0'*64),
            ('result','existing_overall_gradient_gate','PASSED')]
        for outer,key,value in changes:
            row=copy.deepcopy(original);row[outer][key]=value;self.put(row);self.repin()
            with self.assertRaises(a.h.EvidenceError,msg=outer+'/'+key):self.analyze()
        for inner,key,value in [('spec','dp_tooth_nm',.25),('spec','record_fields',False),
            ('code','lumopt2_design.py','0'*64),('parent_review','sha256','0'*64),
            ('parent_review','path','/work/data/UNREVIEWED.json')]:
            row=copy.deepcopy(original);row['identity'][inner][key]=value;self.put(row);self.repin()
            with self.assertRaises(a.h.EvidenceError,msg=inner+'/'+key):self.analyze()

    def test_grid_tamper_even_with_both_pins_and_internal_hash_updated(self):
        path=self.root/f'{a.PREFIX}02_ports.npz';arrays=a.h.load_npz(path.read_bytes())
        arrays['p2_f']+=1.
        with path.open('wb') as stream:np.savez(stream,**arrays)
        row=self.row(2);row['result']['ports_sha256']=a.f.sha(path);self.put(row,2);self.repin()
        with self.assertRaisesRegex(a.h.EvidenceError,'grid mismatch'):self.analyze()

    def test_saved_score_mismatch_even_with_checkpoint_repin(self):
        row=self.row(3);row['result']['peak3_modal']+=1e-8;self.put(row,3);self.repin()
        with self.assertRaisesRegex(a.h.EvidenceError,'scalar not reproduced'):self.analyze()

    def test_marker_firstwave_binding_and_exact_pin_scope(self):
        first,_=a.f.analyze(self.root,self.pins,REPO)
        marker=copy.deepcopy(self.marker);marker['first_wave']['checkpoints']['2']['sha256']='0'*64
        with self.assertRaisesRegex(a.h.EvidenceError,'checkpoint binding'):a.validate_marker(marker,first,self.root)
        marker=copy.deepcopy(self.marker);marker['code']['validate_te.py']='0'*64
        with self.assertRaisesRegex(a.h.EvidenceError,'provenance/code'):a.validate_marker(marker,first,self.root)
        for key,value in [('runner_sha256','0'*64),('marker_remote','/work/data/other.json'),('files',{})]:
            pins=copy.deepcopy(self.newpins);pins[key]=value
            with self.assertRaises(a.h.EvidenceError):a.validate_new_pins(pins)

    def test_complete_local_dependency_hash_control_in_temp_mirror(self):
        mirror=self.root/'source_mirror';(mirror/'runners/lumopt2_design').mkdir(parents=True)
        for name in self.marker['code']:
            path=REPO/name if name in ('config.py','bragg_device.py','simulation_config.py','sim_helpers.py') else REPO/'runners/lumopt2_design'/name
            destination=mirror/path.relative_to(REPO)
            shutil.copyfile(path,destination)
        self.assertEqual(a.validate_local_sources(mirror,self.marker),self.marker['code'])
        with (mirror/'sim_helpers.py').open('a') as stream:stream.write('\n# SYNTHETIC TAMPER\n')
        with self.assertRaisesRegex(a.h.EvidenceError,'dependency hash mismatch: sim_helpers.py'):
            a.validate_local_sources(mirror,self.marker)

    def test_missing_required_and_optional_original_center(self):
        pins=copy.deepcopy(self.pins);pins['old_shift30']=dict(available=False,reason='Explicit test omission')
        report,full=self.analyze(pins)
        self.assertFalse(report['observables']['peak3_tout']['common_center_steps']['2']['available'])
        self.assertIsNone(full['observables']['peak3_tout']['full_grid_steps']['0.125']['even_with_original_center'])
        (self.root/f'{a.PREFIX}01_original.json').rename(self.root/'retained_required_checkpoint.json')
        with self.assertRaises(FileNotFoundError):self.analyze()

    def test_analytic_peak_phase_and_index_vertex_wavelength(self):
        n=11;x=np.arange(n)-5;center=2-.02*(x-.2)**2
        freq=190e12+np.arange(n)*1e9;base=dict(p2_lambda=299792458./freq,p2_f=freq)
        class Selector:
            DEAD_T_FLOOR=0.
            @staticmethod
            def measure_peak(wl,s):return wl[np.argmax(s)],max(s),1.
        loc=a.peak_location(center,base,Selector)
        self.assertEqual(loc['index'],5)
        self.assertAlmostEqual(loc['vertex_offset_samples'],.2,places=13)
        self.assertAlmostEqual(loc['fitted_index_vertex_lambda_nm'],299792458./(freq[5]+.2e9)*1e9,places=10)
        step=.125;plus=center*(1+.3*step+.04*step*step);minus=center*(1-.3*step+.04*step*step)
        r,d=a.f.pair_report(plus,minus,center,step)
        self.assertAlmostEqual(r['central_derivative'],.6,places=12)
        self.assertAlmostEqual(r['even'],2*.04*step*step,places=12)
        self.assertAlmostEqual(r['exact_center_peak3_jacobian_projection'],.6,places=12)
        # Independent modal construction includes opposite complex phases.
        zp=np.sqrt(plus)*np.exp(1j*.7);zm=np.sqrt(minus)*np.exp(-1j*.4)
        np.testing.assert_allclose((abs(zp)**2-abs(zm)**2)/(2*step),d,atol=5e-15)

    def test_exclusive_output_cli_refuses_existing_paths(self):
        pinfile=self.root/'pins.json';newpinfile=self.root/'newpins_SYNTHETIC.json'
        a.f.write(pinfile,self.pins);a.f.write(newpinfile,self.newpins)
        output=self.root/'existing.json';output.write_text('DO NOT OVERWRITE')
        spectral=self.root/'not_created.json'
        result=subprocess.run([sys.executable,'-B',str(Path(a.__file__)),
            '--repo',str(REPO),'--evidence-dir',str(self.root),'--pins',str(pinfile),'--pins-sha256',a.f.sha(pinfile),
            '--new-pins',str(newpinfile),'--new-pins-sha256',a.f.sha(newpinfile),
            '--output',str(output),'--spectra-output',str(spectral)],capture_output=True,text=True)
        self.assertNotEqual(result.returncode,0)
        self.assertIn('exclusive new paths',result.stderr)
        self.assertEqual(output.read_text(),'DO NOT OVERWRITE');self.assertFalse(spectral.exists())


if __name__=='__main__':unittest.main(verbosity=2)
