# Measured profile and crop comparison

Pinned original saved N98/free60 recovered validation-point fields; CPU-only extraction, no new FDTD. Exact501 spectral grids and actual 2008x39x1x501x3 profile provenance preserved. Reader and production arithmetic gates pass; calibration FAILED unchanged.

Canonical production FWHM (um):

| Profile wavelength selected by |100ps|150ps|150 minus100 |
|---|---:|---:|---:|
| Tout sampled peak,bin 252 |19.644107414176432|19.643717063777355|-0.0003903503990763113|
| modal sampled peak,bin 250 |19.640975592116185|19.640126650574587|-0.0008489415415979806|

Selected wavelengths/bins are identical between durations: Tout 1560.8702190080865nm, modal 1560.8782189638007nm. Relative width changes are -0.0019871% and-0.0043223%. Production sigma changes are -4.8501363e-5um (Tout) and -7.5808866e-5um (modal). These are measured differences, not a temporal convergence or noise bound.

At 150 ps, crop comparisons from the SAME N98 field:

| Measurement crop | Tout FWHMum | modal FWHMum |
|---|---:|---:|
| canonical production +/-48.12388um |19.643717063777355|19.640126650574587|
| nativeN98 physical end +/-48.246645um |19.643717063777355|19.640126650574587|
| N80 measurement crop +/-39.2848um |19.49219611775358|19.49267290832657|

The N80 measurement crop lowers FWHM by 0.1515209460um/0.7713456% (Tout) and 0.1474537422um/0.7507780% (modal). At 100 ps the changes are 0.1515128156 and 0.1474570161um. The halflevel crossings remain near+/-9.75um, far inside+/-39.2848um: they are not clipped by the crop boundary. Recropping raises the production envelope floor (150 ps Tout 8.18739e-7 to 2.06792e-6) and therefore the relative-min halflevel; the envelope endpoints also change. That gives a concrete extraction effect on this field. It does not establish the field or FWHM of a physically shorter N80 device.

NativeN98-end recropping changes FWHM exactly 0 for both durations/roles, while its larger tail support slightly changes sigma. N80 measurement cropping changes 150 ps sigma from 12.4372615345 to 11.6455957402um (Tout), from 12.4359627235 to 11.6432705857um (modal), illustrating second-moment tail sensitivity.

Nearby sampled W(lambda) covers bins 247..255 (1560.8902190511 to1560.8582192283nm). Width range is 19.6402812551..19.6441074142um at 100 ps, and19.6401266506..19.6437170638um at 150 ps. Full tables, same-bin duration changes, crop floors/halflevels/crossings and source pins are in JSON/MAT. This narrow diagnostic table does not validate a width-adjoint or a physical N80 truncation claim.

Seven meaningful offline tests passed (analytic Gaussian FWHM/sigma; crop tail sensitivity; complete two-duration/nearby tables; report preservation/CP guards; raw grids/anchor/integral tampering; incomplete nearby/cross-duration grids; MAT arrays/units/no-E/overwrite guards; caller hash mismatch grouped in the test suite). Actual comparison exits0 and MAT payload checks pass. No new geometry, solver run or automatic scientific pass.
