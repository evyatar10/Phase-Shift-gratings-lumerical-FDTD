"""Bounded offline tests; first-wave and new-forward fixtures are synthetic."""
import copy
import dataclasses
import json
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
sys.dont_write_bytecode=True
import numpy as np
import s2_shift30_convergence as runner
import fixture_helpers as fixture


class ShiftChecks(unittest.TestCase):
    def setUp(self):
        self.context=fixture.HalfChecks();self.context.setUp()
        self.addCleanup(self.context.doCleanups)
        self.context.wave(range(4))
        self.root=self.context.temp/runner.LABEL
        self.newmarker=self.context.temp/'new_shift_review.json'
        self.env=dict(S2_SHIFT_CENTER_CHECKPOINT=str(self.context.centerpath),S2_SHIFT_OUTPUT_ROOT=str(self.root),
            S2_SHIFT_FIRSTWAVE_ROOT=str(self.context.root),S2_SHIFT_FIRSTWAVE_MARKER=str(self.context.first),
            S2_SHIFT_REVIEW_MARKER=str(self.newmarker),KEEP_H5='1')
        self.patches=[patch.dict(os.environ,self.env),patch.object(runner,'CENTER_SHA256',self.context.centerhash),
            patch.object(runner,'FIRST_MARKER_SHA',runner.digest(self.context.first)),
            patch.object(runner,'FIRSTWAVE_TASK_SHA',{t:runner.digest(self.context.root/f'task_{t:02d}.json') for t in range(4)})]
        for p in self.patches:p.start();self.addCleanup(p.stop)
        self.center=runner.load_center()
        template=runner.review_template(self.root,self.center)
        self.assertEqual(template['status'],'NOT_REVIEWED');self.assertEqual(template['lead_verdict'],'NOT_REVIEWED')
        self.assertEqual(template['allowed_tasks'],[])
        template.update(status=runner.APPROVAL_STATUS,allowed_tasks=[0,1,2,3],
            lead_verdict='Lead reviewed exact first wave and approved only the provisional smaller shift30 translation ladder; calibration remains failed.')
        self.newmarker.write_text(json.dumps(template))
        self.start_builds=len(self.context.builds)

    def test_task149_steps_fullpoint_bounds_and_native_center29(self):
        self.assertEqual(runner.INDEX,149);self.assertEqual(runner.CENTER_INDEX,29)
        base=runner.val.te_point(runner.SPEC)
        self.assertEqual(json.loads(self.context.centerpath.read_text())['identity']['index'],29)
        for t,delta in enumerate((.125,-.125,.0625,-.0625)):
            p,h,sign=runner.task_params(t)
            np.testing.assert_array_equal(np.flatnonzero(p-base),[149])
            self.assertEqual(p[149]-base[149],delta);self.assertEqual(p[29],base[29]);self.assertEqual(h*sign,delta)
            bounds=np.asarray(runner.eng.param_bounds(runner.SPEC));self.assertTrue(np.all((p>=bounds[:,0])&(p<=bounds[:,1])))
        for t in (-1,4,True,1.5,'0'):
            with self.assertRaises(ValueError):runner.main(t)
        row=json.loads(self.context.centerpath.read_text());row['identity']['index']=149
        self.context.centerpath.write_text(json.dumps(row));digest=runner.digest(self.context.centerpath)
        (self.context.centerpath.parent/'center_reviewed.sha256').write_text(digest)
        with patch.object(runner,'CENTER_SHA256',digest):
            with self.assertRaisesRegex(RuntimeError,'original diagnostic task00'):runner.load_center()

    def test_immutable_firstwave_sha_metadata_ports_and_new_marker_gates(self):
        original=json.loads(self.newmarker.read_text())
        with patch.object(runner.eng,'import_lumopt2',side_effect=AssertionError('CAD touched')):
            for key,value in (('status','NOT_REVIEWED'),('allowed_tasks',[0,1]),('lead_verdict','NOT_REVIEWED'),('runner_sha256','0'*64)):
                altered=copy.deepcopy(original);altered[key]=value;self.newmarker.write_text(json.dumps(altered))
                with self.assertRaises(RuntimeError):runner.main(0)
            self.newmarker.write_text(json.dumps(original))
            altered=copy.deepcopy(original);altered['first_wave']['checkpoints']['3']['sha256']='0'*64
            self.newmarker.write_text(json.dumps(altered))
            with self.assertRaisesRegex(RuntimeError,'first-wave identities'):runner.main(0)
            self.newmarker.write_text(json.dumps(original))
            cp=self.context.root/'task_02.json';cp.write_bytes(cp.read_bytes()+b' ')
            with self.assertRaisesRegex(RuntimeError,'170962 checkpoint hash'):runner.main(0)

    def test_firstwave_ports_tamper_and_marker_reuse_refuse_before_cad(self):
        row=json.loads((self.context.root/'task_01.json').read_text())['result']
        Path(row['ports_npz']).write_bytes(b'tamper synthetic fixture')
        with patch.object(runner.eng,'import_lumopt2',side_effect=AssertionError('CAD touched')):
            with self.assertRaisesRegex(RuntimeError,'ports hash mismatch'):runner.main(0)
        with patch.dict(os.environ,{'S2_SHIFT_REVIEW_MARKER':str(self.context.first)}):
            with self.assertRaisesRegex(RuntimeError,'separate'):runner.main(0)

    def test_four_forward_artifacts_exclusive_checkpoint_and_cold_resume(self):
        oldcenter=self.context.centerpath.read_bytes();oldfirst=self.context.first.read_bytes()
        oldcheckpoints=[(self.context.root/f'task_{t:02d}.json').read_bytes() for t in range(4)]
        with patch.object(runner.eng,'import_lumopt2',return_value=object()),patch.object(runner.eng,'make_project',side_effect=self.context.fake_project):
            for task in range(4):
                result=runner.main(task);runner.verify_result(result,task,self.root)
                cp=self.root/f'task_{task:02d}.json';before=cp.read_bytes()
                with patch.object(runner.eng,'import_lumopt2',side_effect=AssertionError('repeat solve')):
                    self.assertEqual(runner.main(task),result)
                with self.assertRaises(FileExistsError):runner.recovery.checkpoint(cp,json.loads(before)['identity'],result)
                self.assertEqual(cp.read_bytes(),before)
        self.assertEqual(self.context.centerpath.read_bytes(),oldcenter);self.assertEqual(self.context.first.read_bytes(),oldfirst)
        self.assertEqual([(self.context.root/f'task_{t:02d}.json').read_bytes() for t in range(4)],oldcheckpoints)
        builds=self.context.builds[self.start_builds:];self.assertEqual(len(builds),4)
        self.assertTrue(all(b['forwards']==1 and b['closed'] for b in builds))

    def test_keep_h5_mesh_failure_preserve_attempts_and_frozen_family(self):
        with patch.dict(os.environ,{'KEEP_H5':'0'}),patch.object(runner.eng,'import_lumopt2',side_effect=AssertionError('CAD touched')):
            with self.assertRaisesRegex(RuntimeError,'KEEP_H5=1'):runner.main(2)
        with patch.object(runner.eng,'import_lumopt2',return_value=object()):
            for kwargs,pattern in ((dict(mesh_drift=True),'changed x mesh'),(dict(missing_h5=True),'HDF5'),(dict(fail=True),'interrupted')):
                with patch.object(runner.eng,'make_project',side_effect=lambda *a,kw=kwargs:self.context.fake_project(*a,**kw)):
                    with self.assertRaisesRegex(RuntimeError,pattern):runner.main(2)
                self.assertFalse((self.root/'task_02.json').exists())
            with patch.object(runner.eng,'make_project',side_effect=self.context.fake_project):runner.main(2)
        self.assertEqual(len(list(self.root.glob('task_02_*'))),4)
        prior=runner.SPEC
        with patch.object(runner,'SPEC',dataclasses.replace(prior,dp_tooth_nm=.25)):
            with self.assertRaisesRegex(RuntimeError,'numerical family'):runner.load_center()


if __name__=='__main__':unittest.main()
