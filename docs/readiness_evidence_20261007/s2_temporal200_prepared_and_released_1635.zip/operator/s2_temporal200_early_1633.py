import importlib.util,json,sys
from pathlib import Path
s=importlib.util.spec_from_file_location('ops','C:/Users/evyat/AppData/Local/Temp/s2_step150_ops_1503.py')
ops=importlib.util.module_from_spec(s);sys.argv=['readonly','none'];s.loader.exec_module(ops)
code=ops.COMMON+f'''
b=Path({ops.BASE!r});root=b/'results/diagnose_te_s2_temporal200/results/s2_shift30_temporal200_20261007'
logs={{str(p):p.read_text(errors='replace')[-11000:] for p in (b/'jobs/logs').glob('lum_array-171390_*.out')}}
engine={{str(p):p.read_text(errors='replace')[-4000:] for p in root.glob('task_*/*_p0.log')}}
print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),queue=run(['squeue','-j','171390']),accounting=run(['sacct','-j','171390','--format=JobID,State,ExitCode,Elapsed,NodeList','--parsable2']),jobs=[run(['scontrol','show','job','171390_'+str(i)]) for i in range(3)],logs=logs,engine=engine,checkpoints=[str(p) for p in root.glob('*.json')],source_sha256=hashlib.sha256((b/'project/runners/lumopt2_design/s2_temporal200_forward.py').read_bytes()).hexdigest())))
'''
compile(code,'remote_early','exec');r=ops.remote('athena.technion.ac.il',code)
ops.save('s2_temporal200_early_1633.json',r)
assert r['rc']==0,r
p=json.loads(r['out']);print(p['at']);print(p['queue']['out']);print(p['accounting']['out'])
print(json.dumps(dict(jobs=p['jobs'],logs=p['logs'],engine=p['engine'],source_sha256=p['source_sha256']),indent=2))
