"""Inventory-only alternate time result API; no field export, solve or save."""
import argparse,json,re,sys
from pathlib import Path
import numpy as np
import frozen_time_io as base
sys.dont_write_bytecode=True
BASE_SHA='0210def55c5998cb8f53c08323a73fae34b69fc58733568078768200b3618e2d'
need,sha,plain,identity=base.need,base.sha,base.plain,base.identity

class ResultCAD(base.TimeCAD):
 """Fixed monitor/results scripts; datasets stay in CAD, only names/shapes transfer."""
 def getresult(self,obj,result=None):
  if result is None:
   need(obj in base.MONITORS,'Unreviewed result listing');return self.raw.getresult(obj)
  return super().getresult(obj,result)
 def haveresult(self,obj,result):
  need(obj in base.MONITORS and result in ['E','H'],'Unreviewed result availability');return self.raw.haveresult(obj,result)
 def getv(self,name):
  need(name in ['rr_shape','rr_attributes','rr_parameters','tt_shape','tt_value'],'Full result/field transfer refused');return self.raw.getv(name)
 def value(self,monitor,key):
  need(key in ['t','x','y','z'],'Inventory-only component transfer refused');return super().value(monitor,key)
 def read_script(self,script,name):
  match=re.fullmatch(r"rr_dataset=getresult\('([^']+)','([EH])'\);(.+)",script)
  need(match is not None and match[1] in base.MONITORS,'Unreviewed result script')
  result=match[2];allowed={'rr_attributes':'rr_attributes=getattribute(rr_dataset);','rr_parameters':'rr_parameters=getparameter(rr_dataset);'}
  if name=='rr_shape':need(match[3] in [f'rr_shape=size(rr_dataset.{key});' for key in ['x','y','z','t',result]+[result+c for c in 'xyz']],'Unreviewed result shape script')
  else:need(name in allowed and match[3]==allowed[name],'Unreviewed result metadata script')
  self.scripts.add(script);self.eval(script);return self.getv(name)
 def metadata_names(self,monitor,result):
  need(monitor in base.MONITORS and result in ['E','H'],'Unreviewed dataset')
  prefix=f"rr_dataset=getresult('{monitor}','{result}');"
  attrs=self.read_script(prefix+'rr_attributes=getattribute(rr_dataset);','rr_attributes')
  params=self.read_script(prefix+'rr_parameters=getparameter(rr_dataset);','rr_parameters')
  return dict(attributes=plain(attrs),parameters=plain(params))
 def result_shape(self,monitor,result,key):
  need(monitor in base.MONITORS and result in ['E','H'] and key in ['x','y','z','t',result]+[result+c for c in 'xyz'],'Unreviewed dataset member')
  values=np.asarray(self.read_script(f"rr_dataset=getresult('{monitor}','{result}');rr_shape=size(rr_dataset.{key});",'rr_shape')).ravel()
  need(values.size>0 and np.isfinite(values).all() and np.all(values>0) and np.all(values==values.astype(int)),'Invalid result member shape')
  return values.astype(int).tolist()

def capture(call):
 try:return dict(available=True,value=plain(call()))
 except Exception as exc:return dict(available=False,error=type(exc).__name__+': '+str(exc))

def alternate_inventory(cad,monitor,time_cap):
 row=dict(raw_inventory=base.inventory(cad,monitor,time_cap),result_names=capture(lambda:cad.getresult(monitor)),output_component_flags={},datasets={})
 for key in base.COMPONENTS:row['output_component_flags']['output '+key]=capture(lambda key=key:cad.getnamed(monitor,'output '+key))
 for result in ['E','H']:
  item=dict(haveresult=capture(lambda result=result:cad.haveresult(monitor,result)));row['datasets'][result]=item
  if item['haveresult']['available'] and float(np.asarray(item['haveresult']['value']).squeeze())==1:
   item['metadata_names']=capture(lambda result=result:cad.metadata_names(monitor,result))
   item['member_shapes']={key:capture(lambda key=key,result=result:cad.result_shape(monitor,result,key)) for key in ['x','y','z','t',result]+[result+c for c in 'xyz']}
   raw=row['raw_inventory'];tshape=item['member_shapes']['t']
   if tshape['available'] and 'time' in raw:need(int(np.prod(tshape['value']))==raw['time']['samples'],'Result/raw time count mismatch')
   item['qualification']='Only dataset names and member shapes queried; no component payload transferred or finite-field/physics claim'
 return row

def run(args):
 out=Path(args.output).resolve();need(Path(args.output).is_absolute() and not out.exists(),'NEW absolute output required');need(args.max_time_validation_bytes>0,'Positive t validation cap required');out.mkdir()
 report=dict(status='STARTED',inventory_only=True,no_field_export=True,no_solve=True,no_save=True,stages={},qualification='Alternate API availability only; no cause, convergence or calibration claim');snapshots={};klass=ctor=None
 try:
  need(sha(base.__file__)==BASE_SHA and sha(base.io.__file__)==base.IO_SHA,'Frozen loaders changed');repo,api=Path(args.repo).resolve(),Path(args.lumapi).resolve();rows={}
  for duration in [100,150,200]:
   cp=Path(getattr(args,'checkpoint'+str(duration))).resolve();row=base.load_center(cp,duration);rows[duration]=row;required=base.verify_sources(repo,api,row);r=row['result']
   for path in [cp,r['source'],r['h5'],r['ports_npz']]+required+[Path(__file__)]:
    p=Path(path).resolve()
    if str(p) not in snapshots:snapshots[str(p)]=identity(p)
  need(all(rows[t]['identity']['point']==rows[100]['identity']['point'] for t in [150,200]),'Different center geometry');sys.path.insert(0,str(api.parent));import lumapi;need(Path(lumapi.__file__).resolve()==api,'Wrong official API');klass=lumapi.FDTD;ctor=klass.__init__
  for duration in [100,150,200]:
   r=rows[duration]['result'];cad=ResultCAD(lumapi.FDTD(hide=True),r['source'])
   try:
    cad.load(r['source']);need(float(np.asarray(cad.getresult('FDTD','status')).squeeze())==1,'Saved full-time status required')
    report['stages'][str(duration)]={m:alternate_inventory(cad,m,args.max_time_validation_bytes) for m in base.MONITORS};report.setdefault('guard_audit',{})[str(duration)]=cad.audit
   finally:cad.close()
  report['status']='ALTERNATE_RESULT_INVENTORY_COLLECTED_NO_PHYSICS_PASS'
 except Exception as exc:report.update(status='FAILED_CLOSED',error=type(exc).__name__+': '+str(exc))
 finally:
  report['immutable_inputs_rechecked']=[]
  for old in snapshots.values():
   try:new=identity(old['path']);report['immutable_inputs_rechecked'].append(dict(before=old,after=new,unchanged=old==new))
   except Exception as exc:report['immutable_inputs_rechecked'].append(dict(before=old,unchanged=False,error=str(exc)))
  report['all_inputs_preserved']=all(x['unchanged'] for x in report['immutable_inputs_rechecked'])
  if not report['all_inputs_preserved']:report.update(status='FAILED_CLOSED',error='Frozen input changed')
  if klass is not None:
   report['FDTD_class_unchanged']=lumapi.FDTD is klass;report['FDTD_constructor_unchanged']=klass.__init__ is ctor
   if not report['FDTD_class_unchanged'] or not report['FDTD_constructor_unchanged']:report.update(status='FAILED_CLOSED',error='Official class changed')
  with (out/'report.json').open('x',encoding='utf-8') as stream:json.dump(plain(report),stream,indent=2,allow_nan=False)
 print(report['status'],report.get('error',''));return int(report['status']=='FAILED_CLOSED')

if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__)
 for name in ['repo','lumapi','checkpoint100','checkpoint150','checkpoint200','output']:parser.add_argument('--'+name,required=True)
 parser.add_argument('--max-time-validation-bytes',type=int,default=33554432)
 raise SystemExit(run(parser.parse_args()))
