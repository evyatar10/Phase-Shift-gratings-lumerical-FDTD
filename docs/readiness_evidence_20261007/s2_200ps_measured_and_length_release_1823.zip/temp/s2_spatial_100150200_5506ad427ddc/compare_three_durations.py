"""Pinned100/150/200 saved spatial comparison; no solve or convergence/noise pass."""
import argparse,hashlib,json,re,sys
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
import numpy as np
PINS={'compare_reference.py':'4cb6276f2d8bb2efa20e76ce2643a34014f391758bd7ff375603d87e81b9ec35','history_reference.json':'bd523d099654f1386cedc32a4881741953ff55fd417ce02bb60c12165b6a74aa','extract200.py':'36ff78a1c567a911c84d707682e9dfa0e0e3e51c740e142a8be4d43f65e4f9f3','extract_saved_spatial_profiles.py':'994c3e9757a10b5bd8ea211aaee8425c5d3540203a4da04b0439684163baf6ca'}
for name,digest in PINS.items():
 if hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()!=digest:raise RuntimeError('Frozen spatial reference changed:'+name)
import compare_reference as c
import extract200 as e
HISTORY_PINS_SHA='ea650471e70e426373a75074520d64836bd21c6d87066e6f89869187257f33cf'
RECEIPT_KEYS={'schema','source_job_id','extraction_job_id','extraction_state','extraction_exit_code','producer_sha256','core_reader_sha256','checkpoint_path','checkpoint_sha256','report_path','report_sha256','npz_path','npz_sha256'}
def need(ok,msg):
 if not ok:raise ValueError(msg)
def full_preservation(report):
 need(report['status']=='SAVED_RAW_PROFILE_EXTRACTION_COMPLETE_NO_PHYSICS_PASS' and report['no_solve'] is True and report['all_inputs_preserved'] is True and report['FDTD_class_unchanged'] is True and report['FDTD_constructor_unchanged'] is True,'Incomplete/unpreserved/class-changed extraction')
 checks=report['immutable_inputs_rechecked'];need(checks and all(p['unchanged'] is True and p['before']==p['after'] for p in checks),'Missing original-input preservation')
 return checks
def receipt200(receipt,report,row,cp_sha,report_sha,npz_sha):
 need(set(receipt)==RECEIPT_KEYS and receipt['schema']==1 and receipt['source_job_id']=='171390' and re.fullmatch('[1-9][0-9]*',receipt['extraction_job_id']) and receipt['extraction_state']=='COMPLETED' and receipt['extraction_exit_code']=='0:0','Exact independent successful extraction receipt required')
 need(receipt['producer_sha256']==PINS['extract200.py'] and receipt['core_reader_sha256']==PINS['extract_saved_spatial_profiles.py'],'Wrong recorded actual producer/helper bytes')
 need(receipt['checkpoint_path']==e.ROOT+'/task_00.json' and receipt['checkpoint_sha256']==cp_sha and receipt['report_sha256']==report_sha and receipt['npz_sha256']==npz_sha,'Receipt/raw CP/report/NPZ byte pins differ')
 rp,npz=[e.server_path(receipt[k]) for k in ['report_path','npz_path']]
 need(rp.name=='report.json' and npz.name=='profiles_200ps.npz' and rp.parent==npz.parent and str(npz)==report['stages']['200']['profile_npz'],'Receipt output paths differ from original report')
 need(report['stages']['200']['profile_npz_sha256']==npz_sha and report['independent_checkpoint_sha256']==cp_sha and report['job']=='171390','200 report digest/source-job binding differs')
 checks=full_preservation(report);inputs=report['inputs']['200'];need(len(inputs)>=6,'200 fullinput inventory absent')
 expected=[(e.ROOT+'/task_00.json',cp_sha),(row['result']['source'],row['result']['fsp_sha256']),(row['result']['h5'],row['result']['h5_sha256']),(row['result']['ports_npz'],row['result']['ports_sha256']),(e.MARKER,e.MARKER_SHA),(e.CENTER,e.CENTER_SHA)]
 need([(p['path'],p['sha256']) for p in inputs[:6]]==expected,'200 original CP/artifact/marker/center bindings differ')
 for pin in inputs:need(any(p['before']==pin for p in checks),'Original input missing from preservation recheck')
 for name,digest in row['identity']['code'].items():need(any(PurePosixPath(p['path']).name==name and p['sha256']==digest for p in inputs),'Frozen source missing from extraction receipt:'+name)
 for rel,digest in row['identity']['vendor_api_sha256'].items():need(any(p['path'].endswith('/'+rel) and p['sha256']==digest for p in inputs),'Actual vendor source missing from extraction receipt:'+rel)
 return receipt
def stage200(report,row,arrays,ports,eng):
 full_preservation(report);s=report['stages']['200'];need(s['duration_ps']==200 and s['monitor_geometry']['enabled']['value']==1,'Wrong200 monitor/duration')
 grid=np.asarray(arrays['monitor_lambda_m']).ravel();inventory=s['raw_profile_coordinate_inventory'];need(grid.size==501 and np.array_equal(grid,ports['p2_lambda'].ravel()) and np.array_equal(grid,np.asarray(inventory['lambda_m'])),'Exact501 original200 spectral grid differs')
 result=dict(duration_ps=200,profiles={},nearby_W_lambda=[],monitor_geometry=s['monitor_geometry'],monitor_lambda_m=grid.tolist());grids={}
 for name,curve in [('Tout',abs(ports['p2_T_out'].ravel())),('modal',abs(ports['p2_S'].ravel())**2)]:
  meta=s['profiles'][name];lam,T,width=eng.measure_peak(grid*1e9,curve);k=int(np.argmin(abs(grid-lam*1e-9)))
  need(width is not None and T>eng.DEAD_T_FLOOR and k==meta['original_monitor_frequency_index'] and lam==meta['target_port_sampled_resonance_nm'] and meta['monitor_sampled_lambda_nm']==float(grid[k]*1e9),'200 actual port anchor differs')
  result['profiles'][name],v=c.profile(eng,arrays,name,meta);result['profiles'][name].update(original_monitor_frequency_index=k,target_nm=float(lam),monitor_sampled_lambda_nm=float(grid[k]*1e9))
  for axis,key in [('x','monitor_x_m'),('y','y_m')]:need(np.array_equal(v[key],np.asarray(inventory[axis+'_m'])),'200 original spatial grid differs:'+axis)
  grids[name]=v
 peaks=[result['profiles'][n]['original_monitor_frequency_index'] for n in ['Tout','modal']];needed=sorted({k+d for k in peaks for d in range(-3,4)})
 need(set(map(int,s['nearby_profiles']))==set(needed),'200 nearby support missing/off-family')
 for k in needed:
  meta=s['nearby_profiles'][str(k)];need(meta['original_monitor_frequency_index']==k and meta['monitor_sampled_lambda_nm']==float(grid[k]*1e9),'200 nearby wavelength mismatch')
  measured,v=c.profile(eng,arrays,'nearby_bin_'+str(k),meta)
  need(np.array_equal(v['monitor_x_m'],grids['Tout']['monitor_x_m']) and np.array_equal(v['y_m'],grids['Tout']['y_m']),'200 nearby spatial grid differs')
  result['nearby_W_lambda'].append(dict(index=k,lambda_nm=float(grid[k]*1e9),**measured['canonical_production_N98']))
 return result,grids
def changes(stages,grids,a,b):
 out={};need(np.array_equal(np.asarray(stages[a]['monitor_lambda_m']),np.asarray(stages[b]['monitor_lambda_m'])),'Cross-duration exact501 grid differs')
 for name in ['Tout','modal']:
  for key in ['monitor_x_m','y_m','x_um']:need(np.array_equal(grids[a][name][key],grids[b][name][key]),'Cross-duration spatial grid differs:'+name+'/'+key)
  left,right=[stages[d]['profiles'][name] for d in [a,b]];x,y=[p['canonical_production_N98'] for p in [left,right]]
  out[name]=dict(FWHM_um=y['FWHM_um']-x['FWHM_um'],sigma_um=y['sigma_um']-x['sigma_um'],floor=y['floor']-x['floor'],peak=y['peak']-x['peak'],half_level=y['half_level']-x['half_level'],selected_lambda_nm=right['monitor_sampled_lambda_nm']-left['monitor_sampled_lambda_nm'],target_lambda_nm=right['target_nm']-left['target_nm'],index_before=left['original_monitor_frequency_index'],index_after=right['original_monitor_frequency_index'],qualification='Separate actual tracked wavelengths;moving-width difference is not an isolated same-bin temporal change')
 bins={d:{r['index']:r for r in stages[d]['nearby_W_lambda']} for d in [a,b]};common=[]
 for k in sorted(set(bins[a])&set(bins[b])):
  x,y=bins[a][k],bins[b][k];need(x['lambda_nm']==y['lambda_nm'],'Common-bin wavelength differs')
  common.append(dict(index=k,lambda_nm=x['lambda_nm'],FWHM_change_um=y['FWHM_um']-x['FWHM_um'],sigma_change_um=y['sigma_um']-x['sigma_um'],floor_change=y['floor']-x['floor']))
 return dict(tracked=out,same_bin_nearby_changes=common)
def compact_mat(path,result,stored):
 from scipy.io import savemat,loadmat
 columns=['duration_ps','index','lambda_nm','FWHM_um','sigma_um','floor','peak','half_level','left_crossing_um','right_crossing_um'];payload={};table=[]
 for d,arrays in stored.items():
  prefixes=['Tout','modal']+['nearby_bin_'+str(r['index']) for r in result['stages'][d]['nearby_W_lambda']]
  for prefix in prefixes:
   for key in ['x_um','I_y_integrated','envelope_y_integrated','y_m','wy_m','monitor_x_m','monitor_I_y_integrated']:
    payload['d'+str(d)+'_'+prefix+'_'+key]=arrays[prefix+'__'+key]
  payload['d'+str(d)+'_monitor_lambda_m']=arrays['monitor_lambda_m']
  for r in result['stages'][d]['nearby_W_lambda']:table.append([d,r['index'],r['lambda_nm'],r['FWHM_um'],r['sigma_um'],r['floor'],r['peak'],r['half_level'],*r['half_level_crossings_um']])
 payload['nearby_table']=np.asarray(table);payload['table_columns']=np.asarray(columns,dtype=object);payload['metadata_json']=json.dumps(dict(status=result['status'],no_raw_E=True,SYNTHETIC200_NOT_MEASURED=bool(result.get('SYNTHETIC200_NOT_MEASURED')),source200=result.get('source200'),units=dict(x_um='um',FWHM_um='um',sigma_um='um',lambda_nm='nm',monitor_x_m='m',y_m='m',monitor_lambda_m='m',I='original allcomponent_y_integral,no renormalization'),qualification=result['qualification']),allow_nan=False)
 with Path(path).open('xb') as f:savemat(f,payload,do_compression=True,oned_as='column',long_field_names=True)
 read=loadmat(path)
 for key,v in payload.items():
  if isinstance(v,np.ndarray) and v.dtype!=object:need(np.array_equal(read[key].ravel(),v.ravel()),'Compact MAT roundtrip differs:'+key)
 return dict(path=str(Path(path).resolve()),sha256=c.sha(Path(path).read_bytes()),no_raw_E=True,roundtrip='EXACT_ARRAYS_AND_NEARBY_TABLE')
def analyze(a):
 repo=Path(a.repo).resolve();ev=Path(a.evidence_dir).resolve();data=Path(a.history_dir).resolve()
 need(c.sha((repo/'runners/lumopt2_design/lumopt2_design.py').read_bytes())==c.ENGINE_SHA,'Frozen width engine changed');sys.path.insert(0,str(repo));from runners.lumopt2_design import lumopt2_design as eng,recover_te_s2 as recovery
 def no_cad(*args,**kwargs):raise RuntimeError('Offline comparison refuses CAD/solve')
 eng.make_project=eng.import_lumopt2=no_cad
 history_pins=c.json_pin(data/'pins.json',HISTORY_PINS_SHA);stages={};grids={};stored={};rows={};source_pins={}
 for d in [100,150]:
  report=c.json_pin(data/'report.json',history_pins['report.json']['sha256']);raw=c.pinned(data/f'profiles_{d}ps.npz',history_pins[f'profiles_{d}ps.npz']['sha256']);arrays=c.npz(raw);need(c.sha(raw)==report['stages'][str(d)]['profile_npz_sha256'],'History report/NPZ binding differs')
  cp=ev/('s2_temporal100_task00_original.json' if d==100 else 's2_temporal150_fetch_1434/s2_temporal150_task03_original.json');row=c.json_pin(cp,c.CP_SHA[d]);rows[d]=row
  for name,digest in row['identity']['code'].items():need(c.sha((repo/name if name in ['config.py','bragg_device.py','simulation_config.py','sim_helpers.py'] else repo/'runners/lumopt2_design'/name).read_bytes())==digest,'Frozen history source differs:'+name)
  ports=c.npz(c.pinned(ev/('s2_temporal100_task00_ports.npz' if d==100 else 's2_temporal150_fetch_1434/s2_temporal150_task03_ports.npz'),row['result']['ports_sha256']));scores=recovery.score(ports);need(all(abs(scores[k]-row['result'][k])<=1e-12 for k in scores),'History port scalar differs')
  stages[d],grids[d]=c.stage(report,d,row,arrays,ports,eng);stored[d]=arrays;source_pins[d]=dict(report_sha256=history_pins['report.json']['sha256'],profile_npz_sha256=c.sha(raw),original_checkpoint_sha256=c.CP_SHA[d],ports_sha256=row['result']['ports_sha256'])
 need(rows[100]['identity']['point']==rows[150]['identity']['point'] and rows[100]['identity']['spec']==rows[150]['identity']['spec'],'History nominal point/spec differs')
 history=c.combine(stages,grids);history['source_pins']=source_pins;reference=c.json_pin(Path(__file__).with_name('history_reference.json'),PINS['history_reference.json']);expected={k:v for k,v in reference.items() if k!='MAT_export'}
 need(json.loads(json.dumps(history,allow_nan=False))==expected,'Actual100/150 verified history not reproduced EXACTLY')
 result=dict(status='OFFLINE_SPATIAL_DURATION_COMPARISON_ONLY_NO_PHYSICS_PASS',history100150=reference,history_reproduction='EXACT_ALL_PRIOR_NON_MAT_METADATA_AND_CALCULATIONS',stages=stages,changes={},nearby_spread={},qualification='Same physical N98/free60 point;no new solve,convergence criterion,noise floor,calibration approval,width-band change or physical N80 conclusion. Own production crop/envelope convention retained.')
 result['changes']['150_minus_100']=changes(stages,grids,100,150)
 if not a.history_only:
  for key in ['checkpoint200','checkpoint_sha256200','ports200','report200','report_sha256200','npz200','npz_sha256200','receipt200','receipt_sha256200']:need(bool(getattr(a,key,None)),'Independent200 input required:'+key)
  row=c.json_pin(a.checkpoint200,a.checkpoint_sha256200);report=c.json_pin(a.report200,a.report_sha256200);raw=c.pinned(a.npz200,a.npz_sha256200);arrays=c.npz(raw);receipt=c.json_pin(a.receipt200,a.receipt_sha256200);marker=c.json_pin(ev/'s2_temporal200_review_original.json',e.MARKER_SHA)
  e.validate_metadata(row,marker,rows[150]);receipt200(receipt,report,row,a.checkpoint_sha256200,a.report_sha256200,a.npz_sha256200)
  for name,digest in row['identity']['code'].items():need(c.sha((repo/name if name in ['config.py','bragg_device.py','simulation_config.py','sim_helpers.py'] else repo/'runners/lumopt2_design'/name).read_bytes())==digest,'Frozen200 source differs:'+name)
  ports=c.npz(c.pinned(a.ports200,row['result']['ports_sha256']));score=recovery.score(ports);need(all(abs(float(score[k])-float(row['result'][k]))<=1e-12 for k in ['peak3_tout','peak3_modal','lam_nm']),'200 original port scores differ')
  stages[200],grids[200]=stage200(report,row,arrays,ports,eng);stored[200]=arrays
  result['source200']=dict(checkpoint_sha256=a.checkpoint_sha256200,report_sha256=a.report_sha256200,npz_sha256=a.npz_sha256200,receipt_sha256=a.receipt_sha256200,receipt=receipt)
  result['changes'].update({'200_minus_150':changes(stages,grids,150,200),'200_minus_100':changes(stages,grids,100,200)})
  if report.get('SYNTHETIC_TEST_ONLY'):result['SYNTHETIC200_NOT_MEASURED']=True
 for d,stage in stages.items():
  w=np.asarray([r['FWHM_um'] for r in stage['nearby_W_lambda']]);l=np.asarray([r['lambda_nm'] for r in stage['nearby_W_lambda']]);result['nearby_spread'][d]=dict(indices=[r['index'] for r in stage['nearby_W_lambda']],lambda_min_nm=float(min(l)),lambda_max_nm=float(max(l)),FWHM_min_um=float(min(w)),FWHM_max_um=float(max(w)),FWHM_range_um=float(max(w)-min(w)),qualification='Actual sampled nearby W(lambda),not uncertainty/noise bound')
 return result,stored
def parser():
 p=argparse.ArgumentParser(description=__doc__)
 for key in ['repo','evidence-dir','history-dir','output']:p.add_argument('--'+key,required=True)
 p.add_argument('--mat-output');p.add_argument('--history-only',action='store_true')
 for key in ['checkpoint200','checkpoint-sha256200','ports200','report200','report-sha256200','npz200','npz-sha256200','receipt200','receipt-sha256200']:p.add_argument('--'+key)
 return p
if __name__=='__main__':
 a=parser().parse_args();need(Path(a.output).is_absolute() and not Path(a.output).exists(),'NEW absolute output required')
 if a.mat_output:need(Path(a.mat_output).is_absolute() and not Path(a.mat_output).exists() and Path(a.mat_output).resolve()!=Path(a.output).resolve(),'NEW distinct MAT required')
 result,stored=analyze(a)
 if a.mat_output:result['MAT_export']=compact_mat(a.mat_output,result,stored)
 with Path(a.output).open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,allow_nan=False)
 print(result['status'],'NO CONVERGENCE/NOISE PASS')
