import unittest
import numpy as np
from analyze import halfheight,decompose_ratio,require
class FocusedChecks(unittest.TestCase):
 def test_lorentzian_crossings(self):
  f=np.linspace(-10,10,20001); y=1/(1+(f/2)**2); r=halfheight(f,y)
  self.assertAlmostEqual(r['width_GHz']*1e9,4,places=10)
 def test_order_invariance(self):
  f=np.linspace(1e12,2e12,1001); y=1/(1+((f-1.5e12)/1e11)**2)
  self.assertEqual(halfheight(f,y),halfheight(f[::-1],y[::-1]))
 def test_reject_truncated_and_multipeak(self):
  f=np.linspace(1,11,1001)
  for y in [1/(1+((f-6)/20)**2),np.exp(-(f-3)**2)+np.exp(-(f-9)**2),np.ones_like(f)]:
   with self.assertRaises(ValueError):halfheight(f,y)
 def test_exact_ratio_decomposition(self):
  for n0,d0,n1,d1 in [(2,3,5,7),(8e-16,7e-16,9e-16,6e-16)]:
   x,y=decompose_ratio(n0,d0,n1,d1);self.assertAlmostEqual(x+y,n1/d1-n0/d0,places=14)
 def test_finite_and_grid_fail(self):
  for f,y in [([1,2,2,3,4],[0,1,2,1,0]),([1,2,3,4,5],[0,1,float('nan'),1,0])]:
   with self.assertRaises(ValueError):halfheight(f,y)
if __name__=='__main__':unittest.main()
