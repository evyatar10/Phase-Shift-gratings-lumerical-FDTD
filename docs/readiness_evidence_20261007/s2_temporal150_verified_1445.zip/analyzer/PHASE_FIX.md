# Narrow cross-duration Port_1 phase comparator

This isolated TEMP analyzer replaces ONLY the direct cross-duration call to r.persisted_check with cross_duration_controls. Source/identity/task/geometry/vendor/hash/grid/score/termination guards elsewhere remain unchanged. Frozen runner and original analyzer were not edited.

Recorded cross-run phase roundoff (cause not localized): accepted exception: /ports/FDTD::ports::Port_1/phase,finite scalarfloat64 difference no more than2 ordered representable ULPs. Zero must match bitwise; no absolute floor,general numeric tolerance or physics/noise allowance. Both raw phase values,signed/absolute degree difference,ULP distance and qualification are retained under cross_duration_control_comparisons. A comparison-only deep copy substitutes this single phase before delegating to the original unchanged r.persisted_check; original snapshots remain untouched. All other properties remain exact except the original persisted_check's already-existing bounded geometry serialization comparison.

Actual pinned100/150 analysis exit0:
- task0->3:18.625271537954248 ->18.625271537954255deg; +7.105427357601002e-15deg,2ULP.
- task1->4: exact,0ULP.
- task2->5: same measured2ULP difference as nominal.
- All actual geometry cross-duration differences zero; other control sections exact.
-100pin SHA94b062900bd3765dd4a3ef78543dd6998378720ed429264e5aa7833339d5e919.
-150pin SHA4fbe923b0fb770b19670946773edc5f892b0efedd07d821a3fee2a750793670b.
-150marker is byte-bound to task3 parent_review SHA/path; full ancestry and frozen555f runner checks passed.

Seven new test groups exit0:0/1/2ULP acceptance,>2ULP and material phase rejection,other-port changes,source/timing/mesh/monitor changes,nonfinite/scalar/zero rejection,and unchanged geometry comparison. Seven inherited reader groups exit0 include repinned negative identities/grid/score/control/termination/fetch paths and exclusive-output CLI controls. No CAD or runner main called by analysis/tests.

Actual results remain DIAGNOSTIC_ONLY_CALIBRATION_FAILED_UNCHANGED. Moving peak central derivative per parameternm:
|Observable |Earlier auto-stop |100ps |150ps |
|---|---:|---:|---:|
|Tout peak3 |-0.001763296004 |-0.000208331154 |-0.000153814689 |
|Modal peak3 |-0.002032697065 |-0.000316570523 |-0.000163699124 |
No temporal convergence/calibration pass is inferred by this arithmetic reader fix.

Files: analyze_temporal.py,new test_phase_controls.py,unchanged firstwave_helpers.py/numerical_helpers.py/test_reader.py; tests logs; actual_command_roundoff.json (complete parser CLI),actual_analysis.log,actual_temporal_review_roundoff.json and actual_temporal_spectra_roundoff.json. manifest_phase_fix_roundoff.json records hashes and exits. Run actual_command_roundoff.json with NEW exclusive output names; existing outputs intentionally cannot be overwritten. Original copied README.md remains historical and points to the old script; this PHASE_FIX.md supersedes that path for the new copy.
