# Saved150ps N98 field: analysis-window scan

This is NOT a physical N-short device result. The SAME saved N98/free60 TE bare field was recropped using the pinned production engine, without CAD/network/solve/repository edits. N below60 was not scanned because it would change the retained free-period parameterization. No width band or acceptance criterion was changed.

| Analysis window N | Tout FWHM um | modal FWHM um | Tout change vs actual N98 | modal change vs actual N98 |
|---|---:|---:|---:|---:|
|60|18.988229272|18.988905137|-3.336883%|-3.315770%|
|65|19.170808332|19.171444887|-2.407430%|-2.386348%|
|70|19.309358737|19.309929361|-1.702113%|-1.681238%|
|75|19.413812316|19.414306785|-1.170373%|-1.149788%|
|80|19.492196118|19.492672908|-0.771346%|-0.750778%|
|85|19.551741190|19.552250115|-0.468220%|-0.447434%|
|90|19.597401310|19.597860301|-0.235779%|-0.215204%|
|98|19.643717064|19.640126651|0%|0%|

Every row uses the actual selected150ps wavelength for its observable: Tout bin252,1560.8702190080865nm; modal bin250,1560.8782189638007nm. Production all-component y-integrated fields are unchanged. Each crop is abs(x_um)<=N*491.06/1000; cubic standing-wave envelope and floor-relative half-height FWHM are recomputed by exact frozen engine functions. The stored full monitor integral is the input, not a copied width scalar.

For Tout the floor/peak ratio rises from0.00711218 at N98 to0.05446873 at N60. Modal rises from0.00736880 to0.05442358. N60 half-level crossings remain near +/-9.49um inside crop +/-29.4636um; every row has two half-level crossings. Thus these crossings are not clipped by the analysis-window boundaries. This scan describes the crop/envelope convention on this field; it cannot establish a shorter physical field, minimum usable device length, noise or runtime.

samefield_window_scan.json retains all16 rows, floor/peak/halflevel/endlevels, sigma, all/outer halflevel crossings, sample counts, selected frequencies, input and engine pins, and changes from the actual N98 width. samefield_window_scan.mat contains the table with named columns, full monitor x/I and every cropped x/I/envelope without rawE. The PNG is a concise two-panel FWHM/sigma sensitivity plot with the nonphysical scope stated on it.

Verification: pinned input report, NPZ, previously validated comparator and reference JSON; N98 complete canonical statistics reproduced EXACTLY; N80 all matching comparator statistics reproduced EXACTLY. Actual MAT load verifies exact table and all exported curve arrays and excludes rawE. Runtime exits0. No elaborate loop-mirroring tests were added. run.log records the actual execution output.
