"""New-only upload and metadata validation; no CAD/solve/submission."""
import base64,hashlib,importlib.util,json,sys
from pathlib import Path
HERE=Path(__file__).parent
PACKET=Path('C:/Users/evyat/AppData/Local/Temp/s2_length_fixed150_candidate_v2_dag_pm08')
BASE='/home/evyatarrubin/research/bragg_sim_igum'
DATA=BASE+'/data/s2_length_native_20261007'
SRC=BASE+'/scripts/s2_length_native_cad_20261007'
OUTPUT=BASE+'/results/diagnose_te_s2_length/results/s2_length_N98_N80_fixed150_20261007'
CADOUT=BASE+'/results/s2_length_native_cad_20261007'
RUNNER_SHA='9076fb3d693604048df40f465d0987310651ebb92c39105979aa43a12a662490'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(PACKET/'s2_length_fixed150.py')==RUNNER_SHA
env=dict(S2_LEN_NATIVE_BASE=BASE,S2_LEN_REPO=BASE+'/project',S2_LEN_OUTPUT_ROOT=OUTPUT,S2_LEN_CAD_OUTPUT=CADOUT,S2_LEN_REFERENCE_CP=DATA+'/reference_150_center_original.json',S2_LEN_REFERENCE_PROFILE=DATA+'/reference_spatial_inventory_original.json',S2_LEN_REFERENCE_GRIDS=DATA+'/reference_port_grids.json',LUMAPI_PATH='/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261/api/python/lumapi.py')
sources=['s2_length_fixed150.py','s2_length_fixed_domain_build.py','s2_length_no_solve_guard.py','s2_length_reference_checks.py']
mapping={BASE+'/project/runners/lumopt2_design/'+name:PACKET/name for name in sources}
mapping.update({DATA+'/'+name:PACKET/name for name in ['reference_150_center_original.json','reference_spatial_inventory_original.json','reference_port_grids.json']})
mapping.update({SRC+'/qualify_igum_length.py':HERE/'qualify_igum_length.py',BASE+'/jobs/run_length_cad_only_20261007.sh':HERE/'run_length_cad_only.sh'})
payload={path:dict(sha256=sha(local),data=base64.b64encode(local.read_bytes()).decode()) for path,local in mapping.items()}
old_code=json.loads((PACKET/'reference_150_center_original.json').read_text())['identity']['code']
sp=importlib.util.spec_from_file_location('ops','C:/Users/evyat/AppData/Local/Temp/s2_step150_ops_1503.py');ops=importlib.util.module_from_spec(sp);sys.argv=['readonly','none'];sp.loader.exec_module(ops)
inner="""import sys,json,os
sys.path.insert(0,os.environ['S2_LEN_REPO'])
import config
config.LUMAPI_PATH=os.environ['LUMAPI_PATH'];config.BASE_SAVE_DIR=os.environ['S2_LEN_NATIVE_BASE']+'/results';config.NEFF_DATA_PATH=os.environ['S2_LEN_NATIVE_BASE']+'/data/FDE_sweep_results.mat';config.USE_GPU=True
from runners.lumopt2_design import s2_length_fixed150 as lane
def blocked(*a,**k):raise RuntimeError('METADATA_PREPARATION_ONLY')
lane.main=lane.forward_only=lane.build_only=lane.build_case=lane.eng.make_project=lane.eng.import_lumopt2=blocked
p=lane.native_paths(for_review=False);r=lane.load_reference(p)
print(json.dumps(lane.review_template(p,r)))
"""
code=ops.COMMON+'''
import base64,re
b=Path(__BASE__);payload=__PAYLOAD__;old=__OLD__;env=__ENV__
queue=run(['squeue','-u','evyatarrubin']);assert queue['rc']==0 and 's2_len_' not in queue['out'],queue
lm='/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261/licensingclient/linx64/lmutil'
gui=run([lm,'lmstat','-c','1055@132.68.48.51','-f','lum_fdtd_gui']);assert gui['rc']==0,gui
m=re.search(r'Total of (\d+) licenses issued;\s*Total of (\d+) licenses in use',gui['out']);assert m and int(m[2])<int(m[1]),gui
df=run(['df','-B1','-P',str(b/'results')]);assert df['rc']==0,df
assert int(df['out'].splitlines()[-1].split()[3])>10*1024**3,'Insufficient filesystem room for bounded CAD preparation'
existing={}
for name,digest in old.items():
 p=b/'project'/name if name in ['config.py','bragg_device.py','simulation_config.py','sim_helpers.py'] else b/'project/runners/lumopt2_design'/name
 actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==digest,(name,actual,digest);existing[str(p)]=actual
wrappers={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [b/'jobs/run_python_array.sh',b/'scripts/athena_run_one.py']}
assert not Path(__CADOUT__).exists() and not Path(__OUTPUT__).exists()
assert not Path(__DATA__).exists() and not Path(__SRC__).exists()
for name,item in payload.items():
 assert not Path(name).exists(),name
 assert hashlib.sha256(base64.b64decode(item['data'])).hexdigest()==item['sha256']
Path(__DATA__).mkdir();Path(__SRC__).mkdir()
for name,item in payload.items():
 with Path(name).open('xb') as f:f.write(base64.b64decode(item['data']))
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==item['sha256']
syntax=run(['bash','-n',str(b/'jobs/run_length_cad_only_20261007.sh')]);assert syntax['rc']==0,syntax
api=Path(env['LUMAPI_PATH']);lum=api.parents[2]
args=['env','LD_LIBRARY_PATH='+str(lum/'lib')+':'+str(b/'scilibs')]+[k+'='+v for k,v in env.items()]+[str(lum/'python/bin/python'),'-B','-c',__INNER__]
validation=run(args)
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in existing.items()),'Original source changed'
print(json.dumps(dict(at=datetime.datetime.now().astimezone().isoformat(),status='NEW_ONLY_METADATA_PREPARATION',queue=queue,GUI_seats=gui,df=df,existing_sources_preserved=existing,existing_wrapper_hashes=wrappers,new_hashes={k:v['sha256'] for k,v in payload.items()},environment=env,syntax=syntax,validation=validation,no_CAD=True,no_solve=True,no_submission=True)))
'''
for key,value in dict(BASE=BASE,PAYLOAD=payload,OLD=old_code,ENV=env,CADOUT=CADOUT,OUTPUT=OUTPUT,DATA=DATA,SRC=SRC,INNER=inner).items():code=code.replace('__'+key+'__',repr(value))
compile(code,'native_new_only_prepare','exec')
if __name__=='__main__':
 result=ops.remote('132.68.58.101',code);ops.save('s2_length_native_preparation_1751.json',result);assert result['rc']==0,result
 row=json.loads(result['out']);print(json.dumps({k:row[k] for k in ['at','status','GUI_seats','existing_wrapper_hashes','syntax','validation']},indent=2));assert row['validation']['rc']==0,row['validation']
 ops.save('s2_length_native_environment_1751.json',env);ops.save('s2_length_native_template_1751.json',json.loads(row['validation']['out']))
