import contextlib,hashlib,importlib.util,io,json,sys,tempfile,unittest,zipfile,types
from pathlib import Path
from unittest.mock import patch
P=Path('C:/Users/evyat/.codex/skills/pi-shift-cluster-ops');S=P/'scripts/check_storage.py'
s=importlib.util.spec_from_file_location('storage',S);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Checks(unittest.TestCase):
 def test_scalar_and_list_JSON_rejected(self):
  for v in [1,[],{'checks':[]}]:
   with patch.object(m,'command',return_value=dict(exit_code=0,stdout=json.dumps(v))):r=m.cluster_snapshot('igum')
   self.assertIn('parse_error',r);self.assertNotIn('snapshot',r)
 def test_existing_or_dangling_name_refused_before_collect(self):
  with patch.object(sys,'argv',['check','--output',str(Path(tempfile.gettempdir())/'SYNTHETIC_NAME')]),patch.object(m.os.path,'lexists',return_value=True),patch.object(m,'collect',side_effect=AssertionError('Must not collect')),contextlib.redirect_stderr(io.StringIO()):
   with self.assertRaises(SystemExit) as e:m.main()
  self.assertEqual(e.exception.code,2)
 def test_lustre_group_project_read_only_and_unknown_parse(self):
  for valid in [True,False]:
   calls=[]
   base='/research/owned/study';result_path=base+'/results'
   def fake(args,**kw):
    calls.append(args)
    out=('9000001 P '+result_path+'\n') if args[0:3]==['/usr/bin/lfs','project','-d'] and valid else 'unexpected\n'
    return types.SimpleNamespace(returncode=0,stdout=out.encode(),stderr=b'')
   stream=io.StringIO()
   with patch.object(m.subprocess,'run',side_effect=fake),patch.object(m.shutil,'which',return_value='/usr/bin/lfs'),patch.object(m.os,'getuid',return_value=123,create=True),patch.object(m.os,'stat',return_value=types.SimpleNamespace(st_gid=456)),patch.object(m.os.path,'realpath',side_effect=lambda p:p),contextlib.redirect_stdout(stream):exec(m.script(base,'igum'),{})
   row=json.loads(stream.getvalue())['checks']
   self.assertIn(['/usr/bin/lfs','quota','-g','456',result_path],calls)
   if valid:self.assertIn(['/usr/bin/lfs','quota','-p','9000001',result_path],calls)
   else:self.assertIn('unknown',row['lustre_result_project_quota']['error'])
   self.assertFalse(any('setquota' in args or '-s' in args or '-r' in args for args in calls))
if __name__=='__main__':unittest.main(verbosity=2)
