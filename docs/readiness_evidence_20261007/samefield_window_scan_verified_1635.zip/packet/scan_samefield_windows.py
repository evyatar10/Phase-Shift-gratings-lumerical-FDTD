"""Same saved150ps N98 field, eight analysis crops; NOT physical shorter devices."""
import contextlib,hashlib,io,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np
from scipy.io import savemat,loadmat
ROOT=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes')
EVIDENCE=ROOT/'docs/readiness_evidence_20261007/s2_saved_profiles_fetch_154823'
COMPARATOR=Path('C:/Users/evyat/AppData/Local/Temp/s2_spatial_duration_comparison_f42_di0g')
PINS={str(EVIDENCE/'report.json'):'01a6fe6540c7cf903de67cecc42a89c6318983301364b679b9da0870dede595a',str(EVIDENCE/'profiles_150ps.npz'):'bbf660c8d4d2d628bd4eae0a1aac4e9a9883bb12388ed51ee2aadf71dfcc3d27',str(COMPARATOR/'compare_profiles.py'):'4cb6276f2d8bb2efa20e76ce2643a34014f391758bd7ff375603d87e81b9ec35',str(COMPARATOR/'actual_comparison_v2.json'):'bd523d099654f1386cedc32a4881741953ff55fd417ce02bb60c12165b6a74aa'}
ENGINE_SHA='53108bbd368dd699179ab65029628aa4c4b2d8ad687777f88b82f404a0952569'
NS=[60,65,70,75,80,85,90,98]
def need(x,msg):
 if not x:raise RuntimeError(msg)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def run():
 out=Path(__file__).parent
 for path,digest in PINS.items():need(sha(path)==digest,'Frozen measured input/comparator differs: '+path)
 need(sha(ROOT/'runners/lumopt2_design/lumopt2_design.py')==ENGINE_SHA,'Frozen width engine changed')
 report=json.loads((EVIDENCE/'report.json').read_text());reference=json.loads((COMPARATOR/'actual_comparison_v2.json').read_text())
 need(report['status']=='SAVED_RAW_PROFILE_EXTRACTION_COMPLETE_NO_PHYSICS_PASS' and report['all_inputs_preserved'] and report['no_solve'],'Saved-field extraction provenance failed')
 need(report['stages']['150']['profile_npz_sha256']==PINS[str(EVIDENCE/'profiles_150ps.npz')],'Report/profile byte binding differs')
 sys.path.insert(0,str(ROOT));sys.path.insert(0,str(COMPARATOR))
 import compare_profiles as verified
 from runners.lumopt2_design import lumopt2_design as eng
 def forbid(*args,**kwargs):raise RuntimeError('Offline samefield scan cannot invoke CAD/solve')
 eng.make_project=eng.import_lumopt2=forbid
 with np.load(EVIDENCE/'profiles_150ps.npz',allow_pickle=False) as z:arrays={k:z[k].copy() for k in z.files}
 need(all(np.isfinite(a).all() for a in arrays.values()),'Nonfinite processed arrays')
 result=dict(status='SAME_N98_FIELD_ANALYSIS_WINDOW_SCAN_NOT_PHYSICAL_N_SHORT',duration_ps=150,actual_device_N=98,actual_free_periods=60,analysis_window_N=NS,pitch_nm=verified.PITCH_NM,engine_sha256=ENGINE_SHA,input_sha256=PINS,no_new_solve=True,no_new_width_band_or_gate=True,qualification='Each analysis crop is applied to the SAME measured saved150ps N98 field. This cannot establish physical N-short widths,minimum usable length,noise or runtime. N<60 would change retained parameterization and was not scanned.',profiles={},checks={})
 payload={};rows=[]
 columns=['observable_id_Tout0_modal1','analysis_N','crop_half_extent_um','sample_count','FWHM_um','sigma_um','floor','peak','half_level','floor_over_peak','left_crossing_um','right_crossing_um','left_end_x_um','right_end_x_um','left_end_I_over_peak','right_end_I_over_peak','left_end_envelope_over_peak','right_end_envelope_over_peak','FWHM_change_from_actual_N98_um','FWHM_change_from_actual_N98_percent']
 for observable_id,name in enumerate(['Tout','modal']):
  meta=report['stages']['150']['profiles'][name]
  reproduced,values=verified.profile(eng,arrays,name,meta)
  full_x=np.asarray(values['monitor_x_m']).ravel();full_I=np.asarray(values['monitor_I_y_integrated']).ravel()
  expected=reference['stages']['150']['profiles'][name]
  need(reproduced['canonical_production_N98']==expected['canonical_production_N98'],'N98 existing comparator values not EXACTLY reproduced')
  canonical=reproduced['canonical_production_N98']['FWHM_um'];table=[];checks={}
  payload[name+'__full_monitor_x_m']=full_x;payload[name+'__full_monitor_I_y_integrated']=full_I
  for n in NS:
   stats,mask,envelope=verified.crop_stats(eng,full_x,full_I,n*verified.PITCH_NM/1000.)
   x=full_x[mask]*1e6;intensity=full_I[mask];level=stats['half_level'];crossing=np.flatnonzero(np.diff(np.sign(envelope-level)))
   all_cross=[]
   for k in crossing:
    slope=(envelope[k+1]-envelope[k])/(x[k+1]-x[k]);all_cross.append(float(x[k]+(level-envelope[k])/slope) if slope else float(x[k]))
   if n in [80,98]:
    anchor=expected['canonical_production_N98'] if n==98 else expected['supplemental_crops']['N80_measurement_crop_of_same_N98_field']
    keys=list(stats);need(all(stats[k]==anchor[k] for k in keys),'N'+str(n)+' comparator statistics not EXACTLY reproduced');checks[str(n)]='EXACT_ALL_COMPARATOR_STATISTICS'
   stats.update(analysis_N=n,NOT_physical_N_short=True,selected_monitor_lambda_nm=meta['monitor_sampled_lambda_nm'],selected_monitor_frequency_index=meta['original_monitor_frequency_index'],floor_over_peak=stats['floor']/stats['peak'],end_envelope=[float(envelope[0]),float(envelope[-1])],end_envelope_over_peak=[float(envelope[0]/stats['peak']),float(envelope[-1]/stats['peak'])],end_I=[float(intensity[0]),float(intensity[-1])],all_half_level_crossings_um=all_cross,half_level_crossing_count=len(all_cross),FWHM_change_from_actual_N98_um=stats['FWHM_um']-canonical,FWHM_change_from_actual_N98_percent=100*(stats['FWHM_um']/canonical-1))
   need(stats['half_level_crossings_um']==[all_cross[0],all_cross[-1]],'Canonical outer crossing convention changed')
   table.append(stats)
   prefix=name+'__analysis_N'+str(n);payload[prefix+'__x_um']=x;payload[prefix+'__I_y_integrated']=intensity;payload[prefix+'__envelope_y_integrated']=envelope
   rows.append([observable_id,n,stats['crop_half_extent_um'],stats['sample_count'],stats['FWHM_um'],stats['sigma_um'],stats['floor'],stats['peak'],stats['half_level'],stats['floor_over_peak'],*stats['half_level_crossings_um'],*stats['end_x_um'],*stats['end_I_over_envelope_peak'],*stats['end_envelope_over_peak'],stats['FWHM_change_from_actual_N98_um'],stats['FWHM_change_from_actual_N98_percent']])
  result['profiles'][name]=table;result['checks'][name]=checks
 payload['samefield_window_table']=np.asarray(rows,float);payload['table_columns']=np.asarray(columns,dtype=object)
 payload['metadata_json']=json.dumps(dict(status=result['status'],qualification=result['qualification'],units=dict(x_um='um',FWHM_um='um',sigma_um='um',full_monitor_x_m='m',I_y_integrated='original integral_y sum(abs(E)^2),no renormalization',envelope_y_integrated='same intensity units'),input_sha256=PINS,engine_sha256=ENGINE_SHA),allow_nan=False)
 mat=out/'samefield_window_scan.mat'
 with mat.open('xb') as f:savemat(f,payload,do_compression=True,long_field_names=True,oned_as='column')
 reloaded=loadmat(mat);need(np.array_equal(reloaded['samefield_window_table'],payload['samefield_window_table']),'MAT table round-trip differs')
 for key,value in payload.items():
  if key.endswith('__x_um') or key.endswith('__I_y_integrated') or key.endswith('__envelope_y_integrated'):need(np.array_equal(reloaded[key].ravel(),value.ravel()),'MAT full profile round-trip differs: '+key)
 need(not any(key=='E' or key.endswith('__E') for key in reloaded),'Unexpected raw E MAT payload')
 result['checks']['MAT_roundtrip']='EXACT_TABLE_AND_ALL_PROFILES_NO_RAW_E';result['MAT_sha256']=sha(mat)
 import matplotlib
 matplotlib.use('Agg')
 from matplotlib import pyplot as plt
 fig,axes=plt.subplots(1,2,figsize=(10,4.2))
 for name,table in result['profiles'].items():
  for ax,key in zip(axes,['FWHM_um','sigma_um']):ax.plot(NS,[r[key] for r in table],'o-',label=name)
 for ax,title in zip(axes,['Production envelope FWHM (um)','Second-moment sigma (um)']):
  ax.set(xlabel='Analysis window N (same saved N98 field)',ylabel=title,xticks=NS);ax.grid(alpha=.25);ax.legend()
 fig.suptitle('Saved 150 ps N98 field: analysis-window sensitivity\nNot a physical shorter-device result',fontsize=11);fig.tight_layout()
 plot=out/'samefield_window_scan.png';need(not plot.exists(),'Preserve plot');fig.savefig(plot,dpi=160);plt.close(fig);result['plot_sha256']=sha(plot)
 with (out/'samefield_window_scan.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,allow_nan=False)
 print('All pins, exact N98/N80 reproduction and MAT round-trip PASS. No physical shortening or new solve.')
 for n in NS:
  r=[next(row for row in result['profiles'][name] if row['analysis_N']==n) for name in ['Tout','modal']]
  print(n,*[round(x['FWHM_um'],9) for x in r],*[round(x['FWHM_change_from_actual_N98_percent'],6) for x in r])
 return result
if __name__=='__main__':run()
