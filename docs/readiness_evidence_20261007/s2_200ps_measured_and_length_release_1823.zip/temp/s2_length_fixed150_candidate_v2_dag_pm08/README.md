# Isolated N98/N80 fixed-domain150ps preparation v2

Preparation only; no repository/vendor/server edits, upload, network, CAD or FDTD solve performed by this packet preparation. Old3248 packet and builder1788 remain unchanged. Native host qualification and substantive lead review are required before two new forwards. Full optimization/global calibration remain FAILED.

Runtime sources: s2_length_fixed150.py (solve study, tasks0=N98/side,1=N80/side only); s2_length_native_buildonly.py (separate guarded CAD-only task0); s2_length_fixed_domain_build.py (private portable adapter with function/class ASTs identical to frozen builder1788); s2_length_no_solve_guard.py; s2_length_reference_checks.py. Original builder's Windows paths/main are not imported. Both solve tasks use the same recovered296 validation parameters/free60/bareTE, fixed150ps, early shutoff OFF/divergence ON, optimization DFT OFF, full field_profile501 ON. No calibrated gradient/adjoint/optimizer is invoked. This is finite-duration physical-length sensitivity, not length/time/mesh/gradient convergence or production-N adoption.

Builder sequence is mandatory: native fresh cfg98 gap20/cfg80 gap38 -> configure/full point/pinned mesh/actual forward port x+phase/source/PML/profile -> preparatory save+reload BOTH scenes -> measured serialized N98 anchor -> N80 held outer61..80 x/feed joins -> final save+reload/strict validation. No width/material tolerance waiver. Inner723 and every retained tooth numeric/text property are exact between pair; feed transverse/material and outer-domain endpoints are exact. Removed objects are precisely72 d81..98 rectangles. Intentional feeds extend to the actual retained outer edges; joins are checked zero before/afterreload. Production crops remain N-dependent; profile coverage stays N98. No vendor forward-source one-cell adjustment is applied again.

Metadata supplied to native IGUM: exact original150 CP(a0ff55...2663), exact original spatial inventory(01a6fe...95a), and tiny derived exact f/lambda port-grid metadata(9aaaee...6f4) from already-local NPZ(a9a4...90d). Original JSON bytes are unchanged and their /work FSP/H5 strings are provenance only; they are NEVER loaded on IGUM. Original references remain separate from the new native source/vendor/API identities. Lambda-to-frequency roundtrip differs1ULP; grids are independently pinned, not recreated from reciprocal arithmetic.

Native bootstrap must configure config.BASE_SAVE_DIR, config.NEFF_DATA_PATH and config.LUMAPI_PATH BEFORE importing the lane, as the established BASE/scripts/athena_run_one.py does. Runtime validates native Linux, repo=BASE/project, unique outputs under BASE/results, official native API and metadata under BASE/data. BASE is /home/evyatarrubin/research/bragg_sim_igum. No /work source fallback. Do not patch the FDTD class in the candidate; existing standard dispatcher GPU setup is outside this code. Builder wraps only its own sim.fdtd instance in the no-solve guard. Candidate does not change base-helper globals.

Required common environment:
- S2_LEN_NATIVE_BASE=/home/evyatarrubin/research/bragg_sim_igum
- S2_LEN_REPO=BASE/project
- S2_LEN_OUTPUT_ROOT=BASE/results/s2_length_fixed150/results/s2_length_N98_N80_fixed150_20261007 (planned solve root)
- S2_LEN_REFERENCE_CP/PROFILE/GRIDS: absolute NEW metadata paths under BASE/data, exact bytes above.

Guarded native qualification first: configure the native bootstrap, import lane, prohibit lane.main/lane.forward_only/eng.make_project as lead's prepared driver does, then:
```
paths=lane.native_paths(for_review=False)
lane.build_only(paths, NEW_ABSOLUTE_NATIVE_BUILD_OUTPUT)
```
No review-marker path or SHA is required for CAD-only qualification. Output must be NEW under BASE/results and separate from planned solve family. Both cases run serially under PairCAD guards; no run path is called. Reports/FSPs/pre-correction conversion evidence are preserved even on failure. Class/constructor identity is checked. Independent entrypoint supports the normal main(task_idx) wrapper:
```
S2_LEN_NATIVE_BUILD_ROOT=NEW_ABSOLUTE_NATIVE_BUILD_OUTPUT
SWEEP_SPEC_MODULE=runners.lumopt2_design.s2_length_native_buildonly
main(task_idx=0)
```
It has N_TASKS=1/IS_HELPER=True and never calls the solve lane's main/forward_only. Root's direct-driver S2_LEN_CAD_OUTPUT can instead be passed straight to build_only. Planned bounded CPU qualification:8CPU64GiB,30-45min allowance pending host preflight; no GPU or FDTD seats requested. This is an estimate; native build/runtime is not yet measured.

Before forwards: native qualification must be reviewed; create a NEW immutable solve-review marker from review_template(paths,reference). Default status NOT_REVIEWED/allowed_tasks=[] denies solves. Actual status must be APPROVED_FOR_TWO_IGUM_FIXED150PS_N98_N80_FIXED_DOMAIN_FORWARDS_ONLY, allowed_tasks=[0,1], with substantive lead text and all exact scope fields (code/native vendor/specs/reference/point/API/root). S2_LEN_REVIEW_MARKER path under BASE/data and S2_LEN_REVIEW_SHA256 are mandatory; KEEP_H5=1,REQUIRE_GPU=1,positive SLURM_CPUS_PER_TASK before fresh run. No automatic dependency launch or further task.

After parent registration ONLY: explicit --lumopt2-design=runners.lumopt2_design.s2_length_fixed150 --array-tasks=0,1 is main(task_idx)/N_TASKS compatible. It uses the supported vendor call fdtd.run('FDTD','GPU') once, after exact saved scene validation and GPU/thread readback; no retry loop. Each attempt is unique. Immutable pre-solve FSP, preparatory FSPs, fresh anchor, completed FSP/H5/log/NPZ and failure reports are retained. Atomic checkpoints never overwrite and cold resume validates source/vendor/point/scope/artifact hashes, full150ps/status1 termination and reproduced scores without CAD or solve.

v2 corrections: after run the NEW solved source is explicitly reloaded, successful persisted status/termination checked, then havedata/haveresult and small coordinate/shape/monitor metadata queried. The E dataset stays inside CAD; only x/y/z/f/lambda vectors and shape/configuration transfer to Python. Exact reference501 f/lambda, E shape2008x39x1x501x3 and spatial coordinates/configuration are required. FSP/H5 bytes must stay unchanged across cold readback. Metadata is hashed and bound to both files; cold resume verifies that binding without CAD. This proves persisted profile availability/axes, not finite E payload or measured width: later guarded extraction still checks E and computes the four crop/floor views.

Checks: ten focused groups passed exit0. Exact tasks/point/spec/bounds; immutable refs and malformed/missing metadata; builder AST identity and required sequencing; explicit review refusals; actual frozen builder geometry/control cases with material/port/feed/endpoint negatives; synthetic immutable completion/cold resume with CAD/solve forbidden; source/score/CP tampering; no-CAD import/tasklist/AST; separate marker-free CAD entry; coordinate-only metadata fixture, missing E, nonfinite/grid/shape/configuration and source-H5 binding negatives. Synthetic files/arrays are NOT N80 or IGUM hardware evidence. No full13 rerun or new local CAD build. Frozen Windows builder already passed actual hidden CAD; native IGUM and new solved-profile readback remain host gates.

Run estimates: matched native150 pair ~2x50-70min,8CPU/256GiB/A100 each; fixed domain means no cell-count savings. Two A100s commit14 solve seats plus Athena's outstanding21; root must recheck actual shared pool/queues/quota/hardware. Original comparable FSP+H5=821,893,707bytes/forward; pair1,643,787,414bytes, twofold retained-attempt allowance3,287,574,828bytes plus small metadata/setup/logs. These are planning allowances, not storage bounds; reported zero quota limits do not prove no other limit. Root owns fresh storage/headroom and release.

v2_runtime_diff.txt is only a review comparison against preserved3248, not an instruction to patch old files. manifest.json binds final source/tests/raw inputs and retained evidence.
