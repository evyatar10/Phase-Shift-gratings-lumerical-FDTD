---
name: pi-shift-cluster-ops
description: Inspect, prepare, launch, or recover authorized Lumerical jobs for the pi-shift Bragg grating project on Technion Athena and IGUM, with resource checks and preservation of results.
---

# Pi-shift cluster operations

Repository: `C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes`.
Read `AGENTS.md` and its current audit/state pointer. Historical launch
recipes do not revoke a later stop instruction. Read-only checks are distinct
from submission, upload, cancellation, container changes, or cleanup.

The user's October7 continuation instruction is in the project `AGENTS.md`:
once a workflow is authorized, carry it through result inspection and the
next authorized stage. Job submission or a passing offline gate is not task
completion. During waits, advance independent work and preserve a checkpoint;
do not request the same authorization again or duplicate a running job.
Report real blockers and keep existing limits on destructive operations.

## Read-only inventory

For sustained work, follow [storage checks](references/storage-checks.md) on
the local computer and both clusters. The tested read-only helper collects
quota, filesystem bytes/inodes, queue and shared seats without cleanup.

Athena: `evyatarrubin@athena.technion.ac.il`, base
`/home/evyatarrubin/bragg_sim_athena`; container
`/home/evyatarrubin/containers/lumerical-2026R1.sif` with `/opt/lumerical/v261`.
IGUM: `evyatarrubin@132.68.58.101`, base
`/home/evyatarrubin/research/bragg_sim_igum`; native install
`/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261`.
Recheck current `.conf` and job scripts before use.
For the verified environment, task dispatch chain, QOS interpretation and
October 6 runtime checks, read [server runbook](references/server-runbook.md).

Use bounded, noninteractive SSH with existing host verification, e.g.
`ssh -o BatchMode=yes -o ConnectTimeout=10 -o StrictHostKeyChecking=yes USER@HOST 'squeue -u evyatarrubin --noheader'`.
On Windows PowerShell, a format string containing nested quotes/spaces may
be reinterpreted by native argument handling; the default queue format avoids
that problem. Keep shell quoting explicit. No shell-built deletion commands.

When feeding a multiline shell script from Windows through Python subprocess,
send UTF-8 bytes with LF newlines. `text=True` can translate input to CRLF and
make Bash arguments contain carriage returns. Check each command's output/status;
a final command exiting zero does not validate earlier failed preflight commands.
For an ad hoc container check, set required library paths inside the container
(e.g. `env LD_LIBRARY_PATH=/scilibs ...`); the host value may be replaced by the
container environment. Use the established job wrapper for actual solver work.

Fold queue/accounting/log/quota checks into one connection when practical.
For repeated monitoring, stay within roughly 3–6 connections/hour/cluster;
stop on authentication refusal rather than retrying. Athena `quota -s` is
cheap; recursively scanning home is not needed for ordinary status.

The user warned on October 7 that VPN connectivity is intermittent and may
require reconnection. A timeout or unreachable server means visibility is
unavailable, not that a job stopped or failed. Preserve job IDs, dependencies
and the last verified snapshot; do not duplicate submissions or cancel jobs.
After a failed bounded connection attempt, avoid repeated immediate probes.
Continue independent local work and report that VPN reconnection may be
needed. Do not change VPN settings or automate authentication/MFA without
appropriate authorization and an available supported method. After access
returns, reconcile queue/accounting and immutable checkpoints before acting;
restart a stopped read-only watcher only after checking no other copy is active.

Reliable shared-seat query from IGUM:
`/home/evyatarrubin/research/lumerical/Lumerical-2026-R1.3/opt/lumerical/v261/licensingclient/linx64/lmutil lmstat -c 1055@132.68.48.51 -f lum_fdtd_solve`.
Open TCP ports prove reachability only. Athena lmstat's historical DNS-related
`-96` is not by itself proof of outage. Count simultaneous solves and hardware:
standard GPU licensing uses ceil(SMs/16) seats (A100 7, L40S 9), also subject
to CPU requirements. LocalRunner capacity 1 serializes queued FD legs.
Check actual seat availability, not only your queues; it is a shared pool.

## Preparing a concrete launch

The user authorized needed gradient/diagnostic jobs across Athena and IGUM
in parallel on October7. Use independent task subsets with exclusive output
identities; preserve dependent scientific gates and the full-campaign boundary.
Before every dispatch, budget the SHARED license pool across both running and
queued commitments, including other users. Recheck seats near release; a live
snapshot does not reserve seats for later queued starts. Keep headroom and use
array throttles/dependencies for bounded concurrency, not two independent
per-server maxima. If the shared-seat query fails, do not expand concurrency
on an assumption that seats are free. Inspect applicable user/account/QOS,
memory and GPU constraints rather than treating a QOS label as a global cap.

Observed October7: Athena12h_4g has GPU4/user,512CPU,1792G limits;
IGUMqos-preempt shows GPU16/user,MaxJobsPU16,MaxSubmitPU40 for this user.
These are dated scheduler limits, not promised availability or authorization
to occupy that capacity. Re-query them before dispatch. IGUMqos-lumerical's
empty user-limit entry does not prove unlimited capacity. Evidence is in
`docs/readiness_evidence_20261007/dual_cluster_limits_20261007.json`.

IGUMpart-preempt is a mixed GPU pool: October7 sinfo showed A100 nodes and
an RTX PRO6000 node. When matching an A100 numerical comparison/seat budget,
request the observed typed resource `--gres=gpu:A100:1`; do not infer hardware
from partition name. Recheck actual GRES spelling and the assigned node.

Before distributing calibration legs, establish matching engine, numerical
family, code hashes, reference bytes and monitor settings. Athena `/work/`
paths do not exist unchanged on native IGUM. Recovery's original fields and
diagnostic reference paths are Athena-specific. Preserve remote sources before
updating, verify required artifacts/hashes on the destination, and qualify
cross-server reproducibility before pooling small derivative measurements.

First establish the authorized study/cluster and the decision the run will
answer. Reuse existing results. Check the live runner's exact task mapping,
calibrations, seed bounds, local gates, needed hardware smoke, disk, seats,
memory and walltime. TE v3 smoke history requires 256G host memory; do not
confuse host estimates with GPU memory. All Athena GPU lanes can requeue.
Work longer than about two hours needs incremental persistence and cold
resume with at most one solve/evaluation lost. The legacy
`run_validate_gradient` lacks that guarantee; repair it before rerunning long
S2 FD validation. Job-specific scratch must not collide with other runs.

S2 now has isolated task-array recovery runners; see
`docs/TE_RECOVERY_2026-10-06.md` before resubmitting anything. Each task saves
an immutable fingerprinted scalar checkpoint and preserves failed attempts.
Completed matching tasks cold-resume without starting CAD. The first new
FD solve and reconstruction checks gate the remaining legs via afterok.
All FSP/HDF5 evidence is preserved. The FD-only optimization DFT recorder
is disabled only after proving the locked mesh unchanged, reducing stored
data from ~6 GB to ~0.8 GB per leg. Do not disable field storage on adjoint
or width-gradient runs. Athena's 2h_2g lane rejected a 256G request with
QOSMaxMemoryPerUser; use a compatible lane rather than reducing necessary
memory blindly. Confirm actual QOS limits before a new allocation.

Compare allocated CPUs with the engine log's actual `-t` value. Recovery
170746_1 allocated eight CPUs but used one thread, slowing source setup.
Both local cluster wrappers now set/read back `threads` from
SLURM_CPUS_PER_TASK after selecting GPU. Initially only Athena received the
update; IGUM was updated after a preserved-source archive on October7. Verify
the deployed hash and early job log rather than assuming either copy is current.
Do not confuse threads with MPI processes or change process count to fix
this. An already running engine keeps its launch-time thread count. CPU
activity and solver phase distinguish slow initialization from a license hang.

Use Git Bash explicitly on this Windows host:
`C:/Program Files/Git/bin/bash.exe`; verify `command -v python rsync ssh` in
that shell. PowerShell's default `bash.exe` may be a different environment.
The deploy scripts build study lists then submit `run_python_array.sh`, whose
Python wrapper calls the runner's `main(task_idx)`. Derive flags from their
parser, never invent `--no-submit` or `--no-dispatch`.

- Code-only push: `--upload-only` (still modifies matching remote sources).
- Inverse-design entry: `--lumopt2-design=runners.lumopt2_design.<runner>`.
- Subset: `--array-tasks=<indices>`; throttle: `--max-concurrent=<count>`.
- Athena placement: `--gpu=a100`; do not pass this to IGUM.
- Long lumopt2 allocation: `LUMOPT2_QOS`, `LUMOPT2_TIME`, `SBATCH_MEM`.
  `ARRAY_TIME` as an environment override is overwritten by configuration.

Both deploy scripts now preserve remote-only files (no rsync `--delete`).
Matching files still get updated, and stale remote code can remain. Inspect
the diff and live-job dependencies before upload. Maintain Athena/IGUM script
changes as a pair. No remote upload is implicit in local code editing.

After an authorized dispatch, verify the returned job ID, task count,
resources, dependency and time limit, then report them. Fetch small incremental
state early into a destination that preserves previous evidence. Paths are
`results/<study>/results/<label>/` for campaign files and `jobs/logs/` for logs.
Do not download multi-GB fields for a small scalar question.

Report FDTD solve counts separately from scheduler jobs: stored-field gradient
reconstruction, extraction and fitting can run on a cluster without a new
solve. A reused FD leg is evidence but not a new simulation. Preserve original
checkpoint bytes when pinning SHA256: reserialized JSON can be semantically
identical with a different hash, and Git line-ending conversion must be disabled
for byte-pinned originals. Do not change a pin just to accept mismatching data.

Cancellation, deleting files, replacing containers and janitor changes need
specific authorization. Test guards OFFLINE against fake executables/invalid
hosts; never issue a harmful command to a live server to see whether it is
blocked. Claude's hooks are not Codex enforcement. Protect convergence data,
all stored results and unrelated benchmark directories. A deployment or
cleanup claim must describe what actually happened, not what was intended.

## GPU identity inside an allocation

Two jobs on the same node can each print CUDA_VISIBLE_DEVICES=0 and GPU0
while using different physical GPUs. The device index is local to the job's
visible-device namespace. Compare scheduler allocation and the per-job
nvidia-smi PCI bus IDs or UUIDs before diagnosing contention. In the October7
150ps triplet, both n311 jobs displayed GPU0 but different PCI bus IDs, and
all three jobs read back GPU operation with eight allocated CPU threads.
This verifies that allocation; it is not an assumption about future jobs.
Preserve job logs and use read-only checks; do not change device mappings or
cancel working jobs merely because their displayed indices are equal.

## Runtime-aware experimental planning

Before expensive validation or campaign stages, use
[runtime planning](references/runtime-planning.md). This user-requested
workflow combines scientific dependencies with measured runtime, queue risk,
shared seats and prepared post-processing. Keep the dated decision plan in
the project; revise estimates when hardware or numerics change.


## User scheduling preference (October 7)

Concurrent Athena and IGUM operation is expected and authorized within the
bounded diagnostic scope. Prefer the faster measured per-run turnaround for
sequential inverse-design dependencies and use additional available slots for
independent sweeps/validation. Athena is the user's usual performance preference;
IGUM is useful for parallel capacity. Verify actual assigned GPU, memory, queue,
QOS and shared license commitments; neither cluster name guarantees a speed
ranking. Preserve matched numerical families and exclusive output identities.

## Preserved completion and native diagnostic checks

IGUM can remove completed jobs from `scontrol` quickly. An invalid job ID after
an independently saved COMPLETED/0:0 record is not a failed or canceled run.
Preserve that original dated receipt, exact job log and artifact hashes; combine
them when current accounting is unavailable. Report the unavailable live record.
Never redispatch just because the scheduler no longer lists a completed job.

Parse both singular and plural license output (`1 license in use`, `2 licenses
in use`). An unparsed result remains unknown; it does not imply exhaustion or
free capacity. Test resource-parser fixes offline before retrying a release.

New diagnostic dependencies may not exist in the other cluster's checkout.
Compare every existing required source to its expected hash before any upload;
add only the explicitly needed missing files with verified bytes. Do not let
an upload silently replace a different existing source. Record partial or failed
preparation separately from submission and preserve its artifacts.

Native IGUM CAD qualification can use a CPU-only allocation. Verify actual
ReqTRES/AllocTRES, guarded no-solve entrypoint and final saved/reloaded report.
A missing GPU in such a job is expected. This does not qualify a later GPU
forward solve or prove physical convergence. Preserve the independently verified
build report before releasing a bounded physical comparison.
