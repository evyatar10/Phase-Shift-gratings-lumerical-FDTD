from pathlib import Path
import numpy as np,json,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('C:/Users/evyat/Lumerical/phase_shift_grating_FTDT_codes');base=root/'results_from_igum/te_readiness_20261007/length_profiles_2222'
report={};fig,ax=plt.subplots(figsize=(8,4.8))
for n,color in [(98,'#0072B2'),(80,'#D55E00')]:
 with np.load(base/f'N{n}_profiles.npz',allow_pickle=False) as z:
  for crop in [80,98]:
   x=z[f'modal_cropN{crop}__x_um'];env=z[f'modal_cropN{crop}__envelope_y_integrated'];v=env/env.max();above=np.flatnonzero(v>=.5);i,j=int(above[0]),int(above[-1]);assert i>0 and j<len(x)-1
   left=np.interp(.5,v[i-1:i+1],x[i-1:i+1]);right=np.interp(.5,v[j:j+2][::-1],x[j:j+2][::-1]);report[f'physicalN{n}_cropN{crop}']={'zero_baseline_halfmax_width_um':float(right-left),'halfmax_bracket_um':[float(left),float(right)],'own_window':n==crop,'qualification':'Diagnostic zero-baseline half maximum; production metric uses (min+max)/2 and is unchanged'}
   if crop==n:ax.plot(x,v,label=f'N{n}, own physical window',color=color,lw=1.8)
ax.axhline(.5,color='grey',ls=':',lw=1);ax.set(xlabel='Position along grating (µm)',ylabel='Envelope / peak',title='Saved TE profiles, 150 ps: physical N98 versus N80',xlim=(-50,50));ax.legend();ax.grid(alpha=.15);fig.tight_layout();out=base/'N98_N80_envelope_comparison.png';fig.savefig(out,dpi=180)
report['qualification']='Same native fixed domain/mesh, different physical length. Point profiles do not certify mesh/domain or gradient convergence. Sigma not used as width.'
e=root/'docs/readiness_evidence_20261007/length_zero_baseline_diagnostic_2226.json'
with e.open('x') as f:json.dump(report,f,indent=2)
print(json.dumps(report));print(out)
